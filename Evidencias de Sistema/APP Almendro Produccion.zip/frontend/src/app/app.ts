import { Component, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AppSettingsService } from './core/settings/app-settings.service';
import { SessionExperienceComponent } from './shared/session-experience/session-experience';
import { ConnectivityBannerComponent } from './shared/connectivity-banner/connectivity-banner';
import { BrandingService } from './core/settings/branding.service';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, SessionExperienceComponent, ConnectivityBannerComponent],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  private readonly settings = inject(AppSettingsService);
  private readonly branding = inject(BrandingService);

  constructor() {
    this.branding.load();
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => undefined));
    }
  }
}
