import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { App } from './app';
import { SessionExperienceService } from './core/auth/session-experience.service';

describe('App', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [App],
      providers: [provideRouter([])]
    })
      .compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(App);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it('renders the session experience at application level', () => {
    const fixture = TestBed.createComponent(App);
    const experience = TestBed.inject(SessionExperienceService);
    experience.showWelcome('Admin');
    fixture.detectChanges();

    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('.session-transition h1')?.textContent).toContain(
      'Bienvenido, Admin'
    );
    expect(
      compiled.querySelector<HTMLImageElement>('.transition-logo-light')?.src
    ).toContain('/assets/branding/hotel-logo-on-light.png');
    expect(
      compiled.querySelector<HTMLImageElement>('.transition-logo-dark')?.src
    ).toContain('/assets/branding/hotel-logo-on-dark.png');
  });
});
