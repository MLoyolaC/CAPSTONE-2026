import { HttpClient } from '@angular/common/http';
import { Injectable, OnDestroy, inject, signal } from '@angular/core';
import { Subscription, catchError, interval, of, startWith, switchMap, timeout } from 'rxjs';

export type ConnectionState = 'online' | 'intermittent' | 'offline';

@Injectable({ providedIn: 'root' })
export class ConnectivityService implements OnDestroy {
  private readonly http = inject(HttpClient);
  private readonly stateSignal = signal<ConnectionState>(navigator.onLine ? 'intermittent' : 'offline');
  readonly state = this.stateSignal.asReadonly();
  readonly restored = signal(false);
  private previous: ConnectionState = this.stateSignal();
  private readonly subscription: Subscription;

  constructor() {
    window.addEventListener('online', this.browserChanged);
    window.addEventListener('offline', this.browserChanged);
    this.subscription = interval(30_000).pipe(
      startWith(0),
      switchMap(() => navigator.onLine
        ? this.http.get<{ status: string }>('/api/health').pipe(timeout(5000), catchError(() => of(null)))
        : of(null)),
    ).subscribe(result => this.setState(!navigator.onLine ? 'offline' : result?.status === 'UP' ? 'online' : 'intermittent'));
  }

  checkNow(): void {
    if (!navigator.onLine) return this.setState('offline');
    this.http.get<{ status: string }>('/api/health').pipe(timeout(5000), catchError(() => of(null)))
      .subscribe(result => this.setState(result?.status === 'UP' ? 'online' : 'intermittent'));
  }

  private readonly browserChanged = () => this.checkNow();

  private setState(next: ConnectionState): void {
    this.restored.set(this.previous !== 'online' && next === 'online');
    this.previous = next;
    this.stateSignal.set(next);
    if (this.restored()) window.setTimeout(() => this.restored.set(false), 5000);
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
    window.removeEventListener('online', this.browserChanged);
    window.removeEventListener('offline', this.browserChanged);
  }
}
