export interface AuditChange {
  field: string;
  label: string;
  previousValue: string | null;
  newValue: string | null;
  valueType: string;
}

const STATUS_LABELS: Record<string, string> = {
  PLANNED: 'Planificada',
  PENDING: 'Pendiente',
  IN_PROGRESS: 'En curso',
  COMPLETED: 'Completada',
  OVERDUE: 'Atrasada',
  CANCELLED: 'Cancelada'
};

const PRIORITY_LABELS: Record<string, string> = {
  LOW: 'Baja', NORMAL: 'Normal', HIGH: 'Alta', URGENT: 'Urgente'
};

const MONTH_LABELS = [
  '', 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
  'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
];

export function auditColor(value: string | null): string | null {
  return value && /^#[0-9A-F]{6}$/i.test(value) ? value.toUpperCase() : null;
}

export function formatAuditValue(value: string | null, valueType: string): string {
  if (valueType === 'TEXT_COLOR' && !value) return 'Automático';
  if (!value) return 'Sin valor';
  if (valueType === 'STATUS') return STATUS_LABELS[value] ?? value;
  if (valueType === 'PRIORITY') return PRIORITY_LABELS[value] ?? value;
  if (valueType === 'MONTH') return MONTH_LABELS[Number(value)] ?? value;
  if (valueType === 'PERCENT') return `${Number(value)}%`;
  if (valueType === 'MONEY') {
    const amount = Number(value);
    return Number.isFinite(amount)
      ? new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', maximumFractionDigits: 0 }).format(amount)
      : value;
  }
  if (valueType === 'DATE' && /^\d{4}-\d{2}-\d{2}$/.test(value)) {
    const [year, month, day] = value.split('-');
    return `${day}-${month}-${year}`;
  }
  return value;
}
