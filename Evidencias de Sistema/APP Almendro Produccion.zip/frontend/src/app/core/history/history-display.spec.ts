import { auditColor, formatAuditValue } from './history-display';

describe('history display', () => {
  it('shows understandable old and new status values', () => {
    expect(formatAuditValue('PENDING', 'STATUS')).toBe('Pendiente');
    expect(formatAuditValue('COMPLETED', 'STATUS')).toBe('Completada');
  });

  it('shows null text color as automatic', () => {
    expect(formatAuditValue(null, 'TEXT_COLOR')).toBe('Automático');
    expect(formatAuditValue('#FFFFFF', 'TEXT_COLOR')).toBe('#FFFFFF');
  });

  it('normalizes valid color samples and rejects technical or unsafe values', () => {
    expect(auditColor('#ff0000')).toBe('#FF0000');
    expect(auditColor('#4F8F73')).toBe('#4F8F73');
    expect(auditColor('var(--text)')).toBeNull();
  });

  it('formats dates, percentages and empty legacy values', () => {
    expect(formatAuditValue('2026-11-08', 'DATE')).toBe('08-11-2026');
    expect(formatAuditValue('100.00', 'PERCENT')).toBe('100%');
    expect(formatAuditValue(null, 'TEXT')).toBe('Sin valor');
  });
});
