export const OMM_DISPLAY_COLOR_PALETTE = [
  '#4F8F72',
  '#D4A72C',
  '#547AA5',
  '#2F8F91',
  '#7B5EA7',
  '#C65D57'
] as const;

const HEX_COLOR = /^#[0-9A-Fa-f]{6}$/;

export function normalizeHexColor(value: string | null | undefined): string | null {
  const trimmed = value?.trim() ?? '';
  return HEX_COLOR.test(trimmed) ? trimmed.toUpperCase() : null;
}

export function normalizeDisplayColor(value: string | null | undefined): string | null {
  return normalizeHexColor(value);
}

export function displayColorText(value: string | null | undefined): '#FFFFFF' | '#000000' {
  const color = normalizeDisplayColor(value);
  if (!color) return '#000000';

  const components = [1, 3, 5].map(index => {
    const channel = Number.parseInt(color.slice(index, index + 2), 16) / 255;
    return channel <= 0.04045 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4;
  });
  const luminance = 0.2126 * components[0] + 0.7152 * components[1] + 0.0722 * components[2];
  const lightContrast = 1.05 / (luminance + 0.05);
  const darkContrast = (luminance + 0.05) / 0.05;
  return lightContrast >= darkContrast ? '#FFFFFF' : '#000000';
}

export function activityTextColor(displayColor: string | null | undefined, textColor: string | null | undefined): string {
  return normalizeHexColor(textColor) ?? displayColorText(displayColor);
}
