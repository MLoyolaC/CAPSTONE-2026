const DAY_MS = 86_400_000;
const DATE_ONLY_PATTERN = /^(\d{4})-(\d{2})-(\d{2})/;

export interface DateOnlyRange {
  startKey: string;
  endKey: string;
  startDay: number;
  endDay: number;
}

export interface CalendarMonth {
  year: number;
  month: number;
}

export function dateOnlyDay(value: string | null | undefined): number | null {
  const parts = dateOnlyParts(value);
  return parts ? Math.trunc(Date.UTC(parts.year, parts.month - 1, parts.day) / DAY_MS) : null;
}

export function normalizeDateOnlyRange(
  startValue: string | null | undefined,
  endValue: string | null | undefined
): DateOnlyRange | null {
  const startKey = dateOnlyKey(startValue) ?? dateOnlyKey(endValue);
  if (!startKey) return null;

  const requestedEnd = dateOnlyKey(endValue) ?? startKey;
  const startDay = dateOnlyDay(startKey)!;
  const requestedEndDay = dateOnlyDay(requestedEnd)!;
  const endDay = Math.max(startDay, requestedEndDay);

  return {
    startKey,
    endKey: dateOnlyKeyFromDay(endDay),
    startDay,
    endDay
  };
}

export function inclusiveDateOnlyDays(
  startValue: string | null | undefined,
  endValue: string | null | undefined
): number {
  const range = normalizeDateOnlyRange(startValue, endValue);
  return range ? range.endDay - range.startDay + 1 : 0;
}

export function isDateOnlyWithinInclusiveRange(
  value: string | null | undefined,
  startValue: string | null | undefined,
  endValue: string | null | undefined
): boolean {
  const day = dateOnlyDay(value);
  const range = normalizeDateOnlyRange(startValue, endValue);
  return day !== null && range !== null && day >= range.startDay && day <= range.endDay;
}

export function calendarMonthsForDateRange(
  startValue: string | null | undefined,
  endValue: string | null | undefined
): CalendarMonth[] {
  const range = normalizeDateOnlyRange(startValue, endValue);
  if (!range) return [];

  const start = dateOnlyParts(range.startKey)!;
  const end = dateOnlyParts(range.endKey)!;
  const months: CalendarMonth[] = [];
  let year = start.year;
  let month = start.month;

  while (year < end.year || (year === end.year && month <= end.month)) {
    months.push({ year, month });
    month += 1;
    if (month === 13) {
      month = 1;
      year += 1;
    }
  }
  return months;
}

export function dateOnlyKeyFromDay(day: number): string {
  const date = new Date(day * DAY_MS);
  return `${date.getUTCFullYear()}-${pad(date.getUTCMonth() + 1)}-${pad(date.getUTCDate())}`;
}

export function dateOnlyToLocalDate(value: string): Date {
  const parts = dateOnlyParts(value);
  if (!parts) return new Date(Number.NaN);
  return new Date(parts.year, parts.month - 1, parts.day, 12, 0, 0, 0);
}

export function localTodayDateOnly(): string {
  const today = new Date();
  return `${today.getFullYear()}-${pad(today.getMonth() + 1)}-${pad(today.getDate())}`;
}

function dateOnlyKey(value: string | null | undefined): string | null {
  const parts = dateOnlyParts(value);
  return parts ? `${parts.year}-${pad(parts.month)}-${pad(parts.day)}` : null;
}

function dateOnlyParts(value: string | null | undefined): { year: number; month: number; day: number } | null {
  const match = value?.match(DATE_ONLY_PATTERN);
  if (!match) return null;

  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const utc = new Date(Date.UTC(year, month - 1, day));
  if (utc.getUTCFullYear() !== year || utc.getUTCMonth() + 1 !== month || utc.getUTCDate() !== day) return null;
  return { year, month, day };
}

function pad(value: number): string {
  return String(value).padStart(2, '0');
}
