import { describe, expect, it } from 'vitest';
import { activityTextColor, normalizeDisplayColor } from '../colors/display-color';

import {
  calendarMonthsForDateRange,
  dateOnlyDay,
  inclusiveDateOnlyDays,
  isDateOnlyWithinInclusiveRange,
  normalizeDateOnlyRange
} from './date-only';

describe('date-only calendar ranges', () => {
  it.each([
    ['2026-11-10', '2026-11-14', 5],
    ['2026-11-29', '2026-12-03', 5],
    ['2026-12-30', '2027-01-02', 4],
    ['2026-11-04', '2026-11-04', 1],
    ['2026-11-04', '2026-11-05', 2],
    ['2026-11-28', '2026-12-03', 6],
    ['2026-12-31', '2027-01-02', 3]
  ])('keeps %s through %s inclusive', (start, end, expectedDays) => {
    const range = normalizeDateOnlyRange(start, end);
    expect(range?.startKey).toBe(start);
    expect(range?.endKey).toBe(end);
    expect(inclusiveDateOnlyDays(start, end)).toBe(expectedDays);
  });

  it('treats a missing end date as a one-day activity', () => {
    expect(inclusiveDateOnlyDays('2026-11-04', null)).toBe(1);
  });

  it('does not change a date-only value through local timezone conversion', () => {
    expect(dateOnlyDay('2026-11-04')).toBe(dateOnlyDay('2026-11-04T23:59:59Z'));
  });

  it('returns every month touched by an inclusive range', () => {
    expect(calendarMonthsForDateRange('2026-01-28', '2026-02-05')).toEqual([
      { year: 2026, month: 1 },
      { year: 2026, month: 2 }
    ]);
    expect(calendarMonthsForDateRange('2026-12-31', '2027-01-02')).toEqual([
      { year: 2026, month: 12 },
      { year: 2027, month: 1 }
    ]);
  });

  it.each([
    ['2026-11-08', '2026-11-11', ['2026-11-08', '2026-11-09', '2026-11-10', '2026-11-11']],
    ['2026-11-08', '2026-11-08', ['2026-11-08']],
    ['2026-11-28', '2026-12-03', ['2026-11-28', '2026-11-29', '2026-11-30', '2026-12-01', '2026-12-02', '2026-12-03']],
    ['2026-12-31', '2027-01-02', ['2026-12-31', '2027-01-01', '2027-01-02']],
    ['2026-11-08', null, ['2026-11-08']]
  ])('matches every visible day from %s through %s', (start, end, expectedDays) => {
    const firstDay = dateOnlyDay(start)! - 1;
    const candidates = Array.from({ length: expectedDays.length + 2 }, (_, index) =>
      new Date((firstDay + index) * 86_400_000).toISOString().slice(0, 10)
    );

    expect(candidates.filter(day => isDateOnlyWithinInclusiveRange(day, start, end))).toEqual(expectedDays);
  });

  it('keeps the complete range after filtering the activity list', () => {
    const activities = [
      { title: 'TEST prevención', start: '2026-11-08', end: '2026-11-11' },
      { title: 'Otra actividad', start: '2026-11-09', end: '2026-11-09' }
    ];
    const filtered = activities.filter(activity => activity.title.toLocaleLowerCase('es-CL').includes('test'));
    const visibleDays = ['2026-11-08', '2026-11-09', '2026-11-10', '2026-11-11']
      .filter(day => filtered.some(activity => isDateOnlyWithinInclusiveRange(day, activity.start, activity.end)));

    expect(filtered).toHaveLength(1);
    expect(visibleDays).toEqual(['2026-11-08', '2026-11-09', '2026-11-10', '2026-11-11']);
  });

  it('keeps the same background and manual text color on every day of a range', () => {
    const activity = { start: '2026-11-08', end: '2026-11-11', displayColor: '#FF0000', textColor: '#FFFFFF' };
    const renderedDays = ['2026-11-08', '2026-11-09', '2026-11-10', '2026-11-11']
      .filter(day => isDateOnlyWithinInclusiveRange(day, activity.start, activity.end))
      .map(day => ({ day, background: normalizeDisplayColor(activity.displayColor), text: activityTextColor(activity.displayColor, activity.textColor) }));

    expect(renderedDays).toEqual([
      { day: '2026-11-08', background: '#FF0000', text: '#FFFFFF' },
      { day: '2026-11-09', background: '#FF0000', text: '#FFFFFF' },
      { day: '2026-11-10', background: '#FF0000', text: '#FFFFFF' },
      { day: '2026-11-11', background: '#FF0000', text: '#FFFFFF' }
    ]);
  });
});
