import { TestBed } from '@angular/core/testing';
import { BodyScrollLockService } from './body-scroll-lock.service';

describe('BodyScrollLockService', () => {
  afterEach(() => { document.body.style.overflow = ''; document.body.style.paddingRight = ''; });

  it('blocks the body and restores its previous state', () => {
    document.body.style.overflow = 'auto';
    const service = TestBed.inject(BodyScrollLockService);
    service.lock();
    expect(document.body.style.overflow).toBe('hidden');
    service.unlock();
    expect(document.body.style.overflow).toBe('auto');
  });

  it('keeps nested previews locked until the last one closes', () => {
    const service = TestBed.inject(BodyScrollLockService);
    service.lock(); service.lock(); service.unlock();
    expect(document.body.style.overflow).toBe('hidden');
    service.unlock();
    expect(document.body.style.overflow).toBe('');
  });
});
