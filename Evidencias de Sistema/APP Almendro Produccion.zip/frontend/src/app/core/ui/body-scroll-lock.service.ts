import { DOCUMENT } from '@angular/common';
import { Injectable, inject } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class BodyScrollLockService {
  private readonly document = inject(DOCUMENT);
  private locks = 0;
  private previousOverflow = '';
  private previousPaddingRight = '';

  lock(): void {
    this.locks += 1;
    if (this.locks !== 1) return;
    const body = this.document.body;
    this.previousOverflow = body.style.overflow;
    this.previousPaddingRight = body.style.paddingRight;
    const view = this.document.defaultView;
    const scrollbar = view ? Math.max(0, view.innerWidth - this.document.documentElement.clientWidth) : 0;
    body.style.overflow = 'hidden';
    if (scrollbar > 0) body.style.paddingRight = `${scrollbar}px`;
  }

  unlock(): void {
    if (this.locks === 0) return;
    this.locks -= 1;
    if (this.locks !== 0) return;
    this.document.body.style.overflow = this.previousOverflow;
    this.document.body.style.paddingRight = this.previousPaddingRight;
  }
}
