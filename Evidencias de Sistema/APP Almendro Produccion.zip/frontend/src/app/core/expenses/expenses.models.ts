export interface AreaExpense {
  slug: string;
  name: string;
  total: number;
  records: number;
}

export interface ExpenseDetail {
  workItemId: string;
  areaSlug: string;
  areaName: string;
  title: string;
  supplierName: string | null;
  responsibleName: string | null;
  status: string;
  amount: number;
  operationDate: string | null;
  createdAt: string | null;
}

export interface ProposalDetail {
  workItemId:string; areaSlug:string; areaName:string; title:string; location:string|null; status:string; amount:number; targetDate:string|null; plannedYear:number|null; plannedMonth:number|null;
}
export interface ExpenseReport {
  totalActual: number;
  estimatedImprovements: number;
  expenseCount: number;
  byArea: AreaExpense[];
  expenses: ExpenseDetail[];
  proposals: ProposalDetail[];
}

export function formatCLP(value: number | null | undefined): string {
  return new Intl.NumberFormat('es-CL', {
    style: 'currency', currency: 'CLP', maximumFractionDigits: 0
  }).format(value ?? 0);
}
