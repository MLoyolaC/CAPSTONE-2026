import { mergeUpdatedWorkItems, WorkItemBulkStatusState } from './work-item-bulk-state';

describe('WorkItemBulkStatusState', () => {
  it('opens with the selected records and supports cancellation without applying changes', () => {
    const state = new WorkItemBulkStatusState();
    state.open(['a', 'b']);
    expect(state.dialog()).toEqual({ ids: ['a', 'b'], status: 'COMPLETED' });
    state.cancel();
    expect(state.dialog()).toBeNull();
  });

  it('updates the chosen status before confirmation', () => {
    const state = new WorkItemBulkStatusState();
    state.open(['a']);
    state.setStatus('IN_PROGRESS');
    expect(state.dialog()?.status).toBe('IN_PROGRESS');
  });

  it('refreshes only records returned by the persisted batch operation', () => {
    const current = [{ id: 'a', status: 'PENDING' }, { id: 'b', status: 'PENDING' }];
    const result = mergeUpdatedWorkItems(current, [{ id: 'b', status: 'COMPLETED' }]);
    expect(result).toEqual([{ id: 'a', status: 'PENDING' }, { id: 'b', status: 'COMPLETED' }]);
  });
});
