import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

export type WorkStatus =
  | 'PLANNED'
  | 'PENDING'
  | 'IN_PROGRESS'
  | 'COMPLETED'
  | 'OVERDUE'
  | 'CANCELLED';

export interface BulkStatusResponse<T> {
  operationId: string;
  updatedCount: number;
  items: T[];
}

export const WORK_STATUS_OPTIONS: ReadonlyArray<{ value: WorkStatus; label: string }> = [
  { value: 'PLANNED', label: 'Planificada' },
  { value: 'PENDING', label: 'Pendiente' },
  { value: 'IN_PROGRESS', label: 'En curso' },
  { value: 'COMPLETED', label: 'Completada' },
  { value: 'OVERDUE', label: 'Atrasada' },
  { value: 'CANCELLED', label: 'Cancelada' }
];

@Injectable({ providedIn: 'root' })
export class WorkItemBulkStatusService {
  private readonly http = inject(HttpClient);

  update<T>(ids: string[], areaSlug: string, status: WorkStatus): Observable<BulkStatusResponse<T>> {
    return this.http.patch<BulkStatusResponse<T>>(
      '/api/work-items/bulk-status',
      { ids, areaSlug, status },
      { withCredentials: true }
    );
  }
}
