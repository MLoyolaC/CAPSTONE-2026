import { signal } from '@angular/core';

export class WorkItemSelection {
  readonly ids = signal<Set<string>>(new Set());

  has(id: string): boolean {
    return this.ids().has(id);
  }

  toggle(id: string, checked?: boolean): void {
    const next = new Set(this.ids());
    const shouldSelect = checked ?? !next.has(id);
    if (shouldSelect) next.add(id); else next.delete(id);
    this.ids.set(next);
  }

  toggleAll(visibleIds: string[]): void {
    const next = new Set(this.ids());
    const allSelected = visibleIds.length > 0 && visibleIds.every(id => next.has(id));
    for (const id of visibleIds) {
      if (allSelected) next.delete(id); else next.add(id);
    }
    this.ids.set(next);
  }

  clear(): void {
    this.ids.set(new Set());
  }
}
