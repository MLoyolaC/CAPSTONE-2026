import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { WorkItemBulkStatusService } from './work-item-bulk-status.service';

describe('WorkItemBulkStatusService', () => {
  it('sends one transactional request and returns the refreshed records', () => {
    TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
    const service = TestBed.inject(WorkItemBulkStatusService);
    const http = TestBed.inject(HttpTestingController);
    let updatedCount = -1;

    service.update<{ id: string }>(['a', 'b'], 'mejoras', 'COMPLETED').subscribe(response => {
      updatedCount = response.updatedCount;
    });

    const request = http.expectOne('/api/work-items/bulk-status');
    expect(request.request.method).toBe('PATCH');
    expect(request.request.withCredentials).toBe(true);
    expect(request.request.body).toEqual({ ids: ['a', 'b'], areaSlug: 'mejoras', status: 'COMPLETED' });
    request.flush({ operationId: 'batch-1', updatedCount: 2, items: [{ id: 'a' }, { id: 'b' }] });
    expect(updatedCount).toBe(2);
    http.verify();
  });
});
