import { signal } from '@angular/core';
import type { WorkStatus } from './work-item-bulk-status.service';

export interface WorkItemBulkStatusDialog {
  ids: string[];
  status: WorkStatus;
}

export class WorkItemBulkStatusState {
  readonly dialog = signal<WorkItemBulkStatusDialog | null>(null);

  open(ids: string[], status: WorkStatus = 'COMPLETED'): void {
    if (ids.length) this.dialog.set({ ids: [...ids], status });
  }

  setStatus(status: WorkStatus): void {
    const dialog = this.dialog();
    if (dialog) this.dialog.set({ ...dialog, status });
  }

  cancel(): void {
    this.dialog.set(null);
  }
}

export function mergeUpdatedWorkItems<T extends { id: string }>(current: T[], updated: T[]): T[] {
  const byId = new Map(updated.map(item => [item.id, item]));
  return current.map(item => byId.get(item.id) ?? item);
}
