import { WorkItemSelection } from './work-item-selection';

describe('WorkItemSelection', () => {
  it('selects and deselects the same activity without creating another selection model', () => {
    const selection = new WorkItemSelection();
    selection.toggle('a', true);
    expect(selection.has('a')).toBe(true);
    selection.toggle('a', false);
    expect(selection.has('a')).toBe(false);
  });

  it('selects and deselects all visible activities while preserving hidden selections', () => {
    const selection = new WorkItemSelection();
    selection.toggle('hidden', true);
    selection.toggleAll(['a', 'b']);
    expect([...selection.ids()].sort()).toEqual(['a', 'b', 'hidden']);
    selection.toggleAll(['a', 'b']);
    expect([...selection.ids()]).toEqual(['hidden']);
  });

  it('clears selection after a successful or cancelled workflow', () => {
    const selection = new WorkItemSelection();
    selection.toggleAll(['a', 'b', 'c']);
    selection.clear();
    expect(selection.ids().size).toBe(0);
  });
});
