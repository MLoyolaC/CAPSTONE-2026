import { HttpClient } from '@angular/common/http';
import { Injectable, inject, signal } from '@angular/core';
import { Observable, tap } from 'rxjs';

export interface BrandingState {
  preset: 'hotel' | 'bell' | 'building' | 'key' | 'landmark';
  customImage: boolean;
  updatedAt: string;
}

@Injectable({ providedIn: 'root' })
export class BrandingService {
  private readonly http = inject(HttpClient);
  private readonly stateSignal = signal<BrandingState>({ preset: 'hotel', customImage: false, updatedAt: '' });
  readonly state = this.stateSignal.asReadonly();
  private loaded = false;

  load(): void {
    if (this.loaded) return;
    this.loaded = true;
    this.http.get<BrandingState>('/api/settings/branding', { withCredentials: true })
      .subscribe({ next: state => this.stateSignal.set(state), error: () => { this.loaded = false; } });
  }

  choosePreset(preset: BrandingState['preset']): Observable<BrandingState> {
    return this.http.put<BrandingState>('/api/settings/branding/preset', { preset }, { withCredentials: true })
      .pipe(tap(state => this.stateSignal.set(state)));
  }

  upload(file: File): Observable<BrandingState> {
    const data = new FormData();
    data.append('file', file);
    return this.http.post<BrandingState>('/api/settings/branding/image', data, { withCredentials: true })
      .pipe(tap(state => this.stateSignal.set(state)));
  }

  iconClass(): string {
    return `fa-solid fa-${({ hotel: 'hotel', bell: 'bell-concierge', building: 'building', key: 'key', landmark: 'landmark' } as const)[this.state().preset]}`;
  }

  imageUrl(): string {
    return `/api/settings/branding/image?v=${encodeURIComponent(this.state().updatedAt || '0')}`;
  }
}
