import { TestBed } from '@angular/core/testing';
import { AppSettingsService } from './app-settings.service';

describe('AppSettingsService accessibility', () => {
  beforeEach(() => {
    localStorage.removeItem('omm-admin-settings-v1');
    document.documentElement.className = '';
    TestBed.configureTestingModule({});
  });

  afterEach(() => {
    localStorage.removeItem('omm-admin-settings-v1');
    document.documentElement.className = '';
    document.documentElement.style.removeProperty('--omm-ui-zoom');
  });

  it('persists four font levels and applies the selected scale globally', () => {
    const service = TestBed.inject(AppSettingsService);
    service.setFontSize('xlarge');
    expect(service.fontSize()).toBe('xlarge');
    expect(document.documentElement.classList.contains('omm-font-xlarge')).toBe(true);
    expect(JSON.parse(localStorage.getItem('omm-admin-settings-v1') || '{}').fontSize).toBe('xlarge');
  });

  it('applies and persists real accessibility classes', () => {
    const service = TestBed.inject(AppSettingsService);
    service.setAccessibility('highContrast', true);
    service.setAccessibility('reduceMotion', true);
    service.setAccessibility('enhancedFocus', true);
    service.setAccessibility('underlineLinks', true);
    expect(document.documentElement.classList.contains('omm-high-contrast')).toBe(true);
    expect(document.documentElement.classList.contains('omm-reduce-motion')).toBe(true);
    expect(document.documentElement.classList.contains('omm-enhanced-focus')).toBe(true);
    expect(document.documentElement.classList.contains('omm-underline-links')).toBe(true);
  });
});
