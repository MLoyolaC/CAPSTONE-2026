import { DOCUMENT } from '@angular/common';
import { computed, inject, Injectable, signal } from '@angular/core';

export type FontSizePreference = 'small' | 'normal' | 'large' | 'xlarge';
export type AccessRole = 'ADMIN' | 'OPERATOR' | 'READ_ONLY';

export interface AccessProfile {
  id: string;
  name: string;
  username: string;
  role: AccessRole;
  enabled: boolean;
  permissions: string[];
}

interface StoredSettings {
  displayName: string;
  phone: string;
  hotelName: string;
  systemName: string;
  fontSize: FontSizePreference;
  denseUi: boolean;
  highContrast: boolean;
  reduceMotion: boolean;
  enhancedFocus: boolean;
  underlineLinks: boolean;
  notificationSound: boolean;
  welcomeAnimation: boolean;
  monthlyAlerts: boolean;
  accessProfiles: AccessProfile[];
}

const STORAGE_KEY = 'omm-admin-settings-v1';

const DEFAULTS: StoredSettings = {
  displayName: '',
  phone: '',
  hotelName: 'El Almendro',
  systemName: 'Sistema OMM',
  fontSize: 'normal',
  denseUi: false,
  highContrast: false,
  reduceMotion: false,
  enhancedFocus: false,
  underlineLinks: false,
  notificationSound: true,
  welcomeAnimation: true,
  monthlyAlerts: true,
  accessProfiles: []
};

@Injectable({ providedIn: 'root' })
export class AppSettingsService {
  private readonly document = inject(DOCUMENT);
  private readonly state = signal<StoredSettings>(this.read());

  readonly displayName = computed(() => this.state().displayName);
  readonly phone = computed(() => this.state().phone);
  readonly hotelName = computed(() => this.state().hotelName);
  readonly systemName = computed(() => this.state().systemName);
  readonly fontSize = computed(() => this.state().fontSize);
  readonly denseUi = computed(() => this.state().denseUi);
  readonly highContrast = computed(() => this.state().highContrast);
  readonly reduceMotion = computed(() => this.state().reduceMotion);
  readonly enhancedFocus = computed(() => this.state().enhancedFocus);
  readonly underlineLinks = computed(() => this.state().underlineLinks);
  readonly notificationSound = computed(() => this.state().notificationSound);
  readonly welcomeAnimation = computed(() => this.state().welcomeAnimation);
  readonly monthlyAlerts = computed(() => this.state().monthlyAlerts);
  readonly accessProfiles = computed(() => this.state().accessProfiles);

  constructor() {
    this.applyVisualPreferences();
  }

  displayNameFor(username?: string | null): string {
    const configured = this.displayName().trim();
    if (configured) return configured;
    const raw = username?.trim() || 'Usuario';
    return raw.charAt(0).toLocaleUpperCase('es-CL') + raw.slice(1);
  }

  updateProfile(displayName: string, phone: string): void {
    this.patch({ displayName: displayName.trim(), phone: phone.trim() });
  }

  updateSystem(hotelName: string, systemName: string): void {
    this.patch({
      hotelName: hotelName.trim() || DEFAULTS.hotelName,
      systemName: systemName.trim() || DEFAULTS.systemName
    });
  }

  setFontSize(fontSize: FontSizePreference): void {
    this.patch({ fontSize });
    this.applyVisualPreferences();
  }

  setDenseUi(denseUi: boolean): void {
    this.patch({ denseUi });
    this.applyVisualPreferences();
  }

  setAccessibility(option: 'highContrast' | 'reduceMotion' | 'enhancedFocus' | 'underlineLinks', value: boolean): void {
    this.patch({ [option]: value });
    this.applyVisualPreferences();
  }

  setNotificationSound(notificationSound: boolean): void {
    this.patch({ notificationSound });
  }

  setWelcomeAnimation(welcomeAnimation: boolean): void {
    this.patch({ welcomeAnimation });
  }

  setMonthlyAlerts(monthlyAlerts: boolean): void {
    this.patch({ monthlyAlerts });
  }

  saveAccessProfile(profile: AccessProfile): void {
    const profiles = [...this.accessProfiles()];
    const index = profiles.findIndex(item => item.id === profile.id);
    if (index >= 0) profiles[index] = { ...profile, permissions: [...profile.permissions] };
    else profiles.push({ ...profile, permissions: [...profile.permissions] });
    this.patch({ accessProfiles: profiles });
  }

  deleteAccessProfile(id: string): void {
    this.patch({ accessProfiles: this.accessProfiles().filter(item => item.id !== id) });
  }

  resetPreferences(): void {
    const profiles = this.accessProfiles();
    this.state.set({ ...DEFAULTS, accessProfiles: profiles });
    this.persist();
    this.applyVisualPreferences();
  }

  exportSnapshot(username: string | null | undefined, role: string | null | undefined): string {
    return JSON.stringify({
      exportedAt: new Date().toISOString(),
      currentAccount: { username: username || '', role: role || '' },
      theme: localStorage.getItem('omm-theme') || 'system',
      settings: this.state()
    }, null, 2);
  }

  private patch(partial: Partial<StoredSettings>): void {
    this.state.update(current => ({ ...current, ...partial }));
    this.persist();
  }

  private persist(): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state()));
    } catch {
      // La aplicación sigue funcionando aunque el navegador bloquee almacenamiento local.
    }
  }

  private read(): StoredSettings {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return { ...DEFAULTS };
      const parsed = JSON.parse(raw) as Partial<StoredSettings>;
      const legacyFont = (parsed.fontSize as string) === 'compact' ? 'small' : parsed.fontSize;
      return {
        ...DEFAULTS,
        ...parsed,
        fontSize: (legacyFont || DEFAULTS.fontSize) as FontSizePreference,
        accessProfiles: Array.isArray(parsed.accessProfiles) ? parsed.accessProfiles : []
      };
    } catch {
      return { ...DEFAULTS };
    }
  }

  private applyVisualPreferences(): void {
    const root = this.document.documentElement;
    root.classList.toggle('omm-font-small', this.fontSize() === 'small');
    root.classList.toggle('omm-font-large', this.fontSize() === 'large');
    root.classList.toggle('omm-font-xlarge', this.fontSize() === 'xlarge');
    root.classList.toggle('omm-dense-ui', this.denseUi());
    root.classList.toggle('omm-high-contrast', this.highContrast());
    root.classList.toggle('omm-reduce-motion', this.reduceMotion());
    root.classList.toggle('omm-enhanced-focus', this.enhancedFocus());
    root.classList.toggle('omm-underline-links', this.underlineLinks());
    const zoom = this.fontSize() === 'xlarge' ? '1.13' : this.fontSize() === 'large' ? '1.065' : this.fontSize() === 'small' ? '0.965' : '1';
    root.style.setProperty('--omm-ui-zoom', zoom);
    root.style.fontSize = `${Number(zoom) * 100}%`;
  }
}
