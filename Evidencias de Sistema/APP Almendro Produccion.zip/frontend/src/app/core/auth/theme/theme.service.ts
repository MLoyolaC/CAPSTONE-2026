import { DOCUMENT } from '@angular/common';
import { inject, Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {

  private readonly document = inject(DOCUMENT);

  readonly isDark = signal(false);

  constructor() {
    const savedTheme = localStorage.getItem('omm-theme');

    if (savedTheme === 'dark') {
      this.applyTheme(true);
      return;
    }

    if (savedTheme === 'light') {
      this.applyTheme(false);
      return;
    }

    const prefersDark =
      window.matchMedia('(prefers-color-scheme: dark)').matches;

    this.applyTheme(prefersDark);
  }

  toggle(): void {
    this.setTheme(!this.isDark());
  }

  setTheme(dark: boolean): void {
    this.applyTheme(dark);
  }

  private applyTheme(dark: boolean): void {
    this.isDark.set(dark);

    this.document.documentElement.classList.toggle(
      'dark-theme',
      dark
    );

    localStorage.setItem(
      'omm-theme',
      dark ? 'dark' : 'light'
    );
  }
}