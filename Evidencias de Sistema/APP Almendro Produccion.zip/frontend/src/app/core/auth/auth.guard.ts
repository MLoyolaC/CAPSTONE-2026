import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { catchError, map, of } from 'rxjs';

import { AuthService } from './auth.service';

export const authGuard: CanActivateFn = () => {
  const authService = inject(AuthService);
  const router = inject(Router);

  if (authService.currentUser()) {
    return true;
  }

  return authService.loadCurrentUser().pipe(
    map(() => true),
    catchError(() =>
      of(router.createUrlTree(['/login']))
    )
  );
};

const AREA_PERMISSION: Record<string, string> = {
  'mantencion-maquinas': 'maquinas',
  'mantencion-jardineria': 'jardineria',
  'prevencion-riesgos': 'prevencion'
};

export const permissionGuard: CanActivateFn = route => {
  const auth = inject(AuthService);
  const router = inject(Router);
  const authorize = () => {
    const required = [...((route.data?.['permissions'] as string[] | undefined) ?? [])];
    const areaParam = route.data?.['areaParam'] as string | undefined;
    if (areaParam) {
      const slug = route.paramMap.get(areaParam) ?? '';
      const areaPermission = AREA_PERMISSION[slug] ?? slug;
      const alternative = route.data?.['areaAlternative'] as string | undefined;
      if (!alternative || !auth.hasPermission(alternative)) required.push(areaPermission);
    }
    return required.every(permission => auth.hasPermission(permission))
      ? true : router.createUrlTree(['/sin-permiso']);
  };
  if (auth.currentUser()) return authorize();
  return auth.loadCurrentUser().pipe(
    map(() => authorize()),
    catchError(() => of(router.createUrlTree(['/login'])))
  );
};
