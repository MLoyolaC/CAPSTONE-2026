import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { Observable, switchMap, tap } from 'rxjs';

export interface AuthUser {
  id: number;
  username: string;
  fullName: string;
  email: string | null;
  role: string;
  status: string;
  permissions: string[];
  avatarPreset?: string;
  customAvatar?: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private readonly http = inject(HttpClient);

  private readonly currentUserSignal = signal<AuthUser | null>(null);

  readonly currentUser = this.currentUserSignal.asReadonly();

  hasPermission(permission: string): boolean {
    return this.currentUserSignal()?.permissions.includes(permission) ?? false;
  }

  firstAuthorizedRoute(user: AuthUser | null = this.currentUserSignal()): string {
    if (!user) return '/login';
    const routes: Array<[string, string]> = [
      ['dashboard', '/dashboard'],
      ['mantencion-general', '/areas/mantencion-general'],
      ['mantencion-reactiva', '/areas/mantencion-reactiva'],
      ['mejoras', '/areas/mejoras'],
      ['remodelacion', '/areas/remodelacion'],
      ['maquinas', '/areas/mantencion-maquinas'],
      ['jardineria', '/areas/mantencion-jardineria'],
      ['prevencion', '/areas/prevencion-riesgos'],
      ['calendario', '/calendario'], ['gastos', '/gastos'], ['documentos', '/documentos'],
      ['activos', '/activos'], ['trabajadores', '/trabajadores'], ['configuracion', '/configuracion'],
      ['history', '/historial']
    ];
    return routes.find(([permission]) => user.permissions.includes(permission))?.[1] ?? '/sin-accesos';
  }

  initializeCsrf(): Observable<void> {
    return this.http.get<void>('/api/auth/csrf', {
      withCredentials: true
    });
  }

  login(username: string, password: string): Observable<AuthUser> {
    const body = new HttpParams()
      .set('username', username.trim().toLowerCase())
      .set('password', password);

    return this.initializeCsrf().pipe(
      switchMap(() =>
        this.http.post<void>(
          '/api/auth/login',
          body.toString(),
          {
            headers: new HttpHeaders({
              'Content-Type': 'application/x-www-form-urlencoded'
            }),
            withCredentials: true
          }
        )
      ),

      // Spring renueva el token CSRF después de autenticarse.
      switchMap(() => this.initializeCsrf()),

      switchMap(() => this.loadCurrentUser())
    );
  }

  loadCurrentUser(): Observable<AuthUser> {
    return this.http.get<AuthUser>('/api/auth/me', {
      withCredentials: true
    }).pipe(
      tap(user => {
        this.currentUserSignal.set(user);
        document.documentElement.setAttribute('data-permissions', user.permissions.join(' '));
      })
    );
  }

  logout(): Observable<void> {
    return this.initializeCsrf().pipe(
      switchMap(() =>
        this.http.post<void>(
          '/api/auth/logout',
          null,
          { withCredentials: true }
        )
      ),

      tap(() => {
        this.currentUserSignal.set(null);
        document.documentElement.removeAttribute('data-permissions');
      }),

      // Obtener un token CSRF nuevo después del logout.
      switchMap(() => this.initializeCsrf())
    );
  }
}
