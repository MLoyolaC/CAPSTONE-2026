import { Injectable, signal } from '@angular/core';

export const WELCOME_HOLD_MS = 2500;
export const LOGOUT_HOLD_MS = 1700;
export const DEADLINE_ALERT_DELAY_MS = 3000;

export interface SessionDeadlineAlert {
  thisMonth: number;
  overdue: number;
  message: string;
}

export type SessionTransition =
  | { kind: 'welcome'; name: string }
  | { kind: 'logout' };

@Injectable({ providedIn: 'root' })
export class SessionExperienceService {
  private transitionTimer: ReturnType<typeof setTimeout> | null = null;
  private welcomeStartedAt = 0;
  private notificationTimer: ReturnType<typeof setTimeout> | null = null;
  private queuedDeadlineAlert: SessionDeadlineAlert | null = null;
  private deadlineAlertPending = false;
  private deadlineAlertDismissed = false;
  private dashboardReady = false;

  readonly transition = signal<SessionTransition | null>(null);
  readonly transitionLeaving = signal(false);
  readonly deadlineAlert = signal<SessionDeadlineAlert | null>(null);
  readonly deadlineAlertLeaving = signal(false);

  beginAuthenticatedSession(): void {
    this.deadlineAlertPending = true;
    this.deadlineAlertDismissed = false;
    this.dashboardReady = false;
    this.clearDeadlineAlert();
  }

  showWelcome(name: string): void {
    this.clearTransitionTimer();
    this.welcomeStartedAt = Date.now();
    this.transitionLeaving.set(false);
    this.transition.set({ kind: 'welcome', name });
  }

  showLogout(): void {
    this.clearTransitionTimer();
    this.clearDeadlineAlert();
    this.transitionLeaving.set(false);
    this.transition.set({ kind: 'logout' });
  }

  finishTransition(): void {
    if (!this.transition()) return;

    this.transitionLeaving.set(true);
    this.clearTransitionTimer();
    this.transitionTimer = setTimeout(() => {
      this.transition.set(null);
      this.transitionLeaving.set(false);
      this.transitionTimer = null;
      this.scheduleQueuedDeadlineAlert();
    }, 320);
  }

  finishWelcomeWhenReady(): void {
    this.dashboardReady = true;
    if (this.transition()?.kind !== 'welcome') {
      this.scheduleQueuedDeadlineAlert();
      return;
    }

    const remaining = Math.max(0, WELCOME_HOLD_MS - (Date.now() - this.welcomeStartedAt));
    this.clearTransitionTimer();
    this.transitionTimer = setTimeout(() => {
      this.transitionTimer = null;
      this.finishTransition();
    }, remaining);
  }

  cancelTransition(): void {
    this.clearTransitionTimer();
    this.transition.set(null);
    this.transitionLeaving.set(false);
    this.welcomeStartedAt = 0;
  }

  consumeDeadlineAlertRequest(): boolean {
    if (!this.deadlineAlertPending) return false;
    this.deadlineAlertPending = false;
    return !this.deadlineAlertDismissed;
  }

  showDeadlineAlert(alert: SessionDeadlineAlert): void {
    if (this.deadlineAlertDismissed) return;
    this.clearNotificationTimer();
    this.deadlineAlertLeaving.set(false);
    this.deadlineAlert.set(alert);
  }

  queueDeadlineAlert(alert: SessionDeadlineAlert): void {
    if (this.deadlineAlertDismissed || this.deadlineAlert() || this.queuedDeadlineAlert) return;
    this.queuedDeadlineAlert = alert;
    this.scheduleQueuedDeadlineAlert();
  }

  dismissDeadlineAlert(): void {
    if (!this.deadlineAlert()) return;

    this.deadlineAlertDismissed = true;
    this.deadlineAlertLeaving.set(true);
    this.clearNotificationTimer();
    this.notificationTimer = setTimeout(() => {
      this.deadlineAlert.set(null);
      this.deadlineAlertLeaving.set(false);
      this.notificationTimer = null;
    }, 220);
  }

  endAuthenticatedSession(): void {
    this.deadlineAlertPending = false;
    this.deadlineAlertDismissed = false;
    this.dashboardReady = false;
    this.queuedDeadlineAlert = null;
    this.clearDeadlineAlert();
  }

  private clearDeadlineAlert(): void {
    this.clearNotificationTimer();
    this.queuedDeadlineAlert = null;
    this.deadlineAlert.set(null);
    this.deadlineAlertLeaving.set(false);
  }

  private clearTransitionTimer(): void {
    if (this.transitionTimer) clearTimeout(this.transitionTimer);
    this.transitionTimer = null;
  }

  private clearNotificationTimer(): void {
    if (this.notificationTimer) clearTimeout(this.notificationTimer);
    this.notificationTimer = null;
  }

  private scheduleQueuedDeadlineAlert(): void {
    if (!this.dashboardReady || !this.queuedDeadlineAlert || this.transition() || this.transitionLeaving() || this.notificationTimer) return;

    this.notificationTimer = setTimeout(() => {
      const alert = this.queuedDeadlineAlert;
      this.queuedDeadlineAlert = null;
      this.notificationTimer = null;
      if (alert) this.showDeadlineAlert(alert);
    }, DEADLINE_ALERT_DELAY_MS);
  }
}
