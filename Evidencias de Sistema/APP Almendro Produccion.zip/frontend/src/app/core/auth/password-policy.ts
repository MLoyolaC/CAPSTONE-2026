import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export const PASSWORD_MIN_LENGTH = 12;
export const PASSWORD_MAX_LENGTH = 128;
export const PASSWORD_REQUIREMENTS = 'Mínimo 12 caracteres y al menos una mayúscula.';

export interface PasswordPolicyState {
  length: number;
  minimumValid: boolean;
  maximumValid: boolean;
  lengthValid: boolean;
  uppercaseValid: boolean;
  remaining: number;
  valid: boolean;
}

export function evaluatePasswordPolicy(value: string | null | undefined): PasswordPolicyState {
  const password = value ?? '';
  const minimumValid = password.length >= PASSWORD_MIN_LENGTH;
  const maximumValid = password.length <= PASSWORD_MAX_LENGTH;
  const lengthValid = minimumValid && maximumValid;
  const uppercaseValid = /\p{Lu}/u.test(password);
  return {
    length: password.length,
    minimumValid,
    maximumValid,
    lengthValid,
    uppercaseValid,
    remaining: Math.max(0, PASSWORD_MIN_LENGTH - password.length),
    valid: lengthValid && uppercaseValid,
  };
}

export function passwordsMatch(password: string | null | undefined, confirmation: string | null | undefined): boolean {
  return (confirmation ?? '').length > 0 && password === confirmation;
}

export const passwordPolicyValidator: ValidatorFn = (
  control: AbstractControl,
): ValidationErrors | null => {
  return evaluatePasswordPolicy(control.value).valid
    ? null
    : { passwordPolicy: true };
};
