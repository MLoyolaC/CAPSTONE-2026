import { SessionExperienceService } from './session-experience.service';

describe('SessionExperienceService', () => {
  beforeEach(() => vi.useFakeTimers());
  afterEach(() => vi.useRealTimers());

  it('keeps the monthly notification until it is explicitly dismissed', () => {
    const service = new SessionExperienceService();
    const alert = {
      thisMonth: 1,
      overdue: 2,
      message: 'Tienes 1 actividad con fecha este mes y 2 atrasadas.'
    };

    service.beginAuthenticatedSession();
    expect(service.consumeDeadlineAlertRequest()).toBe(true);
    expect(service.consumeDeadlineAlertRequest()).toBe(false);

    service.showDeadlineAlert(alert);
    vi.advanceTimersByTime(30000);
    expect(service.deadlineAlert()).toEqual(alert);

    service.dismissDeadlineAlert();
    vi.advanceTimersByTime(220);
    expect(service.deadlineAlert()).toBeNull();

    service.showDeadlineAlert(alert);
    expect(service.deadlineAlert()).toBeNull();
  });

  it('resets the dismissed notification for a new authenticated session', () => {
    const service = new SessionExperienceService();
    const alert = { thisMonth: 0, overdue: 1, message: 'Tienes 1 atrasada.' };

    service.beginAuthenticatedSession();
    service.showDeadlineAlert(alert);
    service.dismissDeadlineAlert();
    vi.advanceTimersByTime(220);

    service.beginAuthenticatedSession();
    service.showDeadlineAlert(alert);

    expect(service.deadlineAlert()).toEqual(alert);
  });

  it('keeps the transition mounted while its exit animation runs', () => {
    const service = new SessionExperienceService();
    service.showWelcome('Admin');

    service.finishTransition();
    expect(service.transitionLeaving()).toBe(true);
    expect(service.transition()?.kind).toBe('welcome');

    vi.advanceTimersByTime(320);
    expect(service.transition()).toBeNull();
    expect(service.transitionLeaving()).toBe(false);
  });
});
