import { FormControl } from '@angular/forms';

import {
  PASSWORD_REQUIREMENTS,
  evaluatePasswordPolicy,
  passwordsMatch,
  passwordPolicyValidator,
} from './password-policy';

describe('password policy', () => {
  it('matches the published requirement', () => {
    expect(PASSWORD_REQUIREMENTS).toBe('Mínimo 12 caracteres y al menos una mayúscula.');
    expect(passwordPolicyValidator(new FormControl('Una frase larga'))).toBeNull();
    expect(passwordPolicyValidator(new FormControl('una frase larga'))).toEqual({
      passwordPolicy: true,
    });
    expect(passwordPolicyValidator(new FormControl('Corta'))).toEqual({
      passwordPolicy: true,
    });
  });

  it('reports every real requirement without inventing additional rules', () => {
    expect(evaluatePasswordPolicy('')).toMatchObject({length: 0, remaining: 12, lengthValid: false, uppercaseValid: false, valid: false});
    expect(evaluatePasswordPolicy('Clave')).toMatchObject({remaining: 7, lengthValid: false, uppercaseValid: true, valid: false});
    expect(evaluatePasswordPolicy('abcdefghijkl')).toMatchObject({remaining: 0, lengthValid: true, uppercaseValid: false, valid: false});
    expect(evaluatePasswordPolicy('Abcdefghijkl')).toMatchObject({lengthValid: true, uppercaseValid: true, valid: true});
    expect(evaluatePasswordPolicy(`A${'b'.repeat(128)}`)).toMatchObject({maximumValid: false, valid: false});
  });

  it('reports matching and different confirmations', () => {
    expect(passwordsMatch('Abcdefghijkl', 'otra')).toBe(false);
    expect(passwordsMatch('Abcdefghijkl', 'Abcdefghijkl')).toBe(true);
  });
});
