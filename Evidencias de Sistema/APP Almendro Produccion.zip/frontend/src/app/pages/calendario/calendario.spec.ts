import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';

import { CalendarioComponent } from './calendario';

describe('CalendarioComponent date ranges', () => {
  let http: HttpTestingController;

  beforeEach(async () => {
    Object.defineProperty(window, 'matchMedia', {
      writable: true,
      value: (query: string): MediaQueryList => ({
        matches: false,
        media: query,
        onchange: null,
        addListener: () => undefined,
        removeListener: () => undefined,
        addEventListener: () => undefined,
        removeEventListener: () => undefined,
        dispatchEvent: () => false
      })
    });

    await TestBed.configureTestingModule({
      imports: [CalendarioComponent],
      providers: [provideHttpClient(), provideHttpClientTesting(), provideRouter([])]
    }).compileComponents();
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('includes an activity in every month touched by its inclusive range', () => {
    const fixture = TestBed.createComponent(CalendarioComponent);
    const component = fixture.componentInstance as any;
    for (const request of http.match(req => req.url === '/api/work-items')) request.flush([]);

    component.items.set([{
      id: 'cross-month',
      areaSlug: 'prevencion-riesgos',
      workType: 'PREVENTION',
      title: 'Actividad entre meses',
      scheduledStart: '2026-01-28',
      scheduledEnd: '2026-02-05',
      status: 'PLANNED'
    }]);
    component.year.set(2026);

    const cards = component.monthCards();
    expect(cards[0].events.map((item: any) => item.id)).toEqual(['cross-month']);
    expect(cards[1].events.map((item: any) => item.id)).toEqual(['cross-month']);
    expect(component.yearTotal()).toBe(1);
  });

  it('treats a missing end date as one day and exposes a cross-year range in both years', () => {
    const fixture = TestBed.createComponent(CalendarioComponent);
    const component = fixture.componentInstance as any;
    for (const request of http.match(req => req.url === '/api/work-items')) request.flush([]);

    component.items.set([
      {
        id: 'one-day',
        areaSlug: 'mejoras',
        workType: 'IMPROVEMENT',
        title: 'Actividad de un día',
        scheduledStart: '2026-11-04',
        scheduledEnd: null,
        status: 'PLANNED'
      },
      {
        id: 'cross-year',
        areaSlug: 'prevencion-riesgos',
        workType: 'PREVENTION',
        title: 'Actividad entre años',
        scheduledStart: '2026-12-31',
        scheduledEnd: '2027-01-02',
        status: 'PLANNED'
      }
    ]);
    component.year.set(2026);

    expect(component.monthCards()[10].events.map((item: any) => item.id)).toEqual(['one-day']);
    expect(component.monthCards()[11].events.map((item: any) => item.id)).toEqual(['cross-year']);
    expect(component.years()).toContain(2027);
  });

  it('keeps the persisted activity color when rendering a complete range', () => {
    const fixture = TestBed.createComponent(CalendarioComponent);
    const component = fixture.componentInstance as any;
    for (const request of http.match(req => req.url === '/api/work-items')) request.flush([]);

    const item = {
      id: 'colored-range',
      areaSlug: 'prevencion-riesgos',
      workType: 'PREVENTION',
      title: 'PRUEBA COLOR VERDE',
      scheduledStart: '2026-11-08',
      scheduledEnd: '2026-11-11',
      displayColor: '#4F8F72',
      textColor: '#FFFFFF',
      status: 'PLANNED'
    };
    component.items.set([item]);
    component.year.set(2026);

    expect(component.monthCards()[10].events).toEqual([item]);
    expect(component.activityColor(item)).toBe('#4F8F72');
    expect(component.activityTextColor(item)).toBe('#FFFFFF');
  });

  it('changes the visible year from the year selector and closes an opened month', () => {
    const fixture = TestBed.createComponent(CalendarioComponent);
    const component = fixture.componentInstance as any;
    for (const request of http.match(req => req.url === '/api/work-items')) request.flush([]);
    component.items.set([
      { id: 'in-2026', areaSlug: 'mejoras', title: 'Plan 2026', scheduledStart: '2026-06-10', scheduledEnd: null, status: 'PLANNED' },
      { id: 'in-2027', areaSlug: 'mejoras', title: 'Plan 2027', scheduledStart: '2027-06-10', scheduledEnd: null, status: 'PLANNED' }
    ]);
    component.year.set(2026);
    component.openedMonth.set(6);

    component.setYear({ target: { value: '2027' } } as unknown as Event);

    expect(component.year()).toBe(2027);
    expect(component.openedMonth()).toBeNull();
    expect(component.monthCards()[5].events.map((item: any) => item.id)).toEqual(['in-2027']);
  });
});
