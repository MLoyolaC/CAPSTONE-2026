import { HttpClient } from '@angular/common/http';
import { Component, computed, inject, signal } from '@angular/core';
import { Router } from '@angular/router';

import {
  calendarMonthsForDateRange,
  dateOnlyToLocalDate,
  localTodayDateOnly,
  normalizeDateOnlyRange
} from '../../core/dates/date-only';
import { activityTextColor as resolveActivityTextColor, normalizeDisplayColor } from '../../core/colors/display-color';
import { AppSidebarComponent } from '../../shared/app-sidebar/app-sidebar';
import { CountUpDirective } from '../../shared/count-up/count-up';

interface CalendarItem {
  id: string;
  areaSlug: string;
  areaName?: string;
  workType: string;
  title: string;
  scheduledStart: string | null;
  scheduledEnd?: string | null;
  displayColor?: string | null;
  textColor?: string | null;
  plannedYear?: number | null;
  plannedMonth?: number | null;
  location?: string | null;
  status: string;
  responsibleName?: string | null;
}

interface AreaOption {
  slug: string;
  name: string;
  icon: string;
  type: string;
}

const AREAS: AreaOption[] = [
  { slug: 'mantencion-general', type: 'GENERAL_MAINTENANCE', name: 'M. General', icon: 'fa-solid fa-screwdriver-wrench' },
  { slug: 'mantencion-reactiva', type: 'REACTIVE_MAINTENANCE', name: 'M. Reactiva', icon: 'fa-solid fa-bolt' },
  { slug: 'mejoras', type: 'IMPROVEMENT', name: 'Mejoras', icon: 'fa-solid fa-chart-line' },
  { slug: 'remodelacion', type: 'REMODELING', name: 'Remodelación', icon: 'fa-solid fa-building' },
  { slug: 'mantencion-maquinas', type: 'MACHINE_MAINTENANCE', name: 'Máquinas', icon: 'fa-solid fa-gears' },
  { slug: 'mantencion-jardineria', type: 'GARDENING', name: 'Jardinería', icon: 'fa-solid fa-leaf' },
  { slug: 'prevencion-riesgos', type: 'PREVENTION', name: 'Prevención', icon: 'fa-solid fa-shield-halved' }
];

@Component({
  selector: 'app-calendario',
  standalone: true,
  imports: [AppSidebarComponent, CountUpDirective],
  templateUrl: './calendario.html',
  styleUrl: './calendario.scss'
})
export class CalendarioComponent {
  protected readonly Math = Math;
  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);

  protected readonly areas = AREAS;
  protected readonly items = signal<CalendarItem[]>([]);
  protected readonly loading = signal(true);
  protected readonly hasError = signal(false);
  protected readonly filter = signal('todas');
  protected readonly year = signal(new Date().getFullYear());
  protected readonly openedMonth = signal<number | null>(null);

  protected readonly visibleItems = computed(() =>
    this.items().filter(item => this.filter() === 'todas' || item.areaSlug === this.filter())
  );

  protected readonly years = computed(() => {
    const years = new Set<number>([new Date().getFullYear(), this.year()]);
    for (const item of this.items()) {
      for (const month of this.itemMonths(item)) years.add(month.year);
    }
    return Array.from(years).sort((a, b) => b - a);
  });

  protected readonly monthCards = computed(() =>
    Array.from({ length: 12 }, (_, index) => {
      const month = index + 1;
      const events = this.visibleItems().filter(item => this.isInMonth(item, this.year(), month));
      return {
        month,
        label: new Intl.DateTimeFormat('es-CL', { month: 'long' }).format(new Date(this.year(), index, 1)),
        events,
        overdue: events.filter(item => this.isOverdue(item)).length,
        completed: events.filter(item => item.status === 'COMPLETED').length
      };
    })
  );

  protected readonly yearTotal = computed(() =>
    this.visibleItems().filter(item => this.itemMonths(item).some(month => month.year === this.year())).length
  );

  protected readonly yearOverdue = computed(() =>
    this.visibleItems().filter(item =>
      this.itemMonths(item).some(month => month.year === this.year()) && this.isOverdue(item)
    ).length
  );

  protected readonly monthGroups = computed(() => {
    const month = this.openedMonth();
    if (!month) return [];

    const rows = this.visibleItems()
      .filter(item => this.isInMonth(item, this.year(), month))
      .sort((a, b) => (this.sortDate(a) || '').localeCompare(this.sortDate(b) || ''));
    const groups = new Map<string, CalendarItem[]>();
    for (const row of rows) groups.set(row.areaSlug, [...(groups.get(row.areaSlug) || []), row]);
    return Array.from(groups, ([slug, events]) => ({
      slug,
      name: this.areaName(slug),
      icon: AREAS.find(area => area.slug === slug)?.icon || 'fa-solid fa-folder',
      events
    }));
  });

  protected readonly openedMonthLabel = computed(() => {
    const month = this.openedMonth();
    return month
      ? new Intl.DateTimeFormat('es-CL', { month: 'long', year: 'numeric' }).format(new Date(this.year(), month - 1, 1))
      : '';
  });

  constructor() {
    this.refresh();
  }

  private refresh(): void {
    this.loading.set(true);
    this.hasError.set(false);
    const requests = [
      ...AREAS.map(area => ({ slug: area.slug, type: area.type })),
      { slug: 'mejoras', type: 'IMPROVEMENT_GANTT' },
      { slug: 'remodelacion', type: 'REMODELING_GANTT' }
    ];
    let pending = requests.length;
    const all: CalendarItem[] = [];

    for (const request of requests) {
      this.http.get<CalendarItem[]>('/api/work-items', {
        params: { area: request.slug, type: request.type },
        withCredentials: true
      }).subscribe({
        next: items => {
          all.push(...items.map(item => ({ ...item, areaSlug: request.slug })));
          if (--pending === 0) {
            this.items.set(all);
            this.loading.set(false);
          }
        },
        error: () => {
          this.hasError.set(true);
          if (--pending === 0) {
            this.items.set(all);
            this.loading.set(false);
          }
        }
      });
    }
  }

  protected setArea(event: Event): void {
    this.filter.set((event.target as HTMLSelectElement).value);
    this.openedMonth.set(null);
  }

  protected setYear(event: Event): void {
    this.year.set(Number((event.target as HTMLSelectElement).value));
    this.openedMonth.set(null);
  }

  protected shiftYear(amount: number): void {
    this.year.update(year => year + amount);
    this.openedMonth.set(null);
  }

  protected currentYear(): void {
    this.year.set(new Date().getFullYear());
    this.openedMonth.set(null);
  }

  protected openMonth(month: number): void { this.openedMonth.set(month); }
  protected closeMonth(): void { this.openedMonth.set(null); }

  protected monthAreaCount(month: number, slug: string): number {
    return this.monthCards().find(card => card.month === month)?.events.filter(event => event.areaSlug === slug).length || 0;
  }

  protected monthAreaWidth(month: number, slug: string): number {
    const card = this.monthCards().find(item => item.month === month);
    if (!card?.events.length) return 0;
    return Math.max(7, this.monthAreaCount(month, slug) / card.events.length * 100);
  }

  protected areaName(slug: string): string {
    return AREAS.find(area => area.slug === slug)?.name || slug;
  }

  protected edit(item: CalendarItem): void {
    this.router.navigate(['/areas', item.areaSlug], { queryParams: { editar: item.id } });
  }

  protected add(): void {
    const slug = this.filter() === 'todas' ? 'mantencion-general' : this.filter();
    const month = this.openedMonth() || new Date().getMonth() + 1;
    this.router.navigate(['/areas', slug], { queryParams: { crearMes: month, crearAnio: this.year() } });
  }

  protected displayDate(item: CalendarItem): string {
    const range = normalizeDateOnlyRange(item.scheduledStart, item.scheduledEnd);
    if (!range) {
      const month = this.itemMonths(item)[0];
      return month ? `Mes ${month.month}` : 'Sin fecha exacta';
    }

    const formatter = new Intl.DateTimeFormat('es-CL', { day: '2-digit', month: 'short' });
    const start = formatter.format(dateOnlyToLocalDate(range.startKey));
    if (range.startKey === range.endKey) return start;
    return `${start} – ${formatter.format(dateOnlyToLocalDate(range.endKey))}`;
  }

  protected activityColor(item: CalendarItem): string | null {
    return normalizeDisplayColor(item.displayColor);
  }

  protected activityTextColor(item: CalendarItem): string {
    return resolveActivityTextColor(item.displayColor, item.textColor);
  }

  private sortDate(item: CalendarItem): string {
    return normalizeDateOnlyRange(item.scheduledStart, item.scheduledEnd)?.startKey
      || `${item.plannedYear || 9999}-${String(item.plannedMonth || 12).padStart(2, '0')}-15`;
  }

  private itemMonths(item: CalendarItem): { year: number; month: number }[] {
    const scheduled = calendarMonthsForDateRange(item.scheduledStart, item.scheduledEnd);
    if (scheduled.length) return scheduled;
    return item.plannedYear && item.plannedMonth
      ? [{ year: item.plannedYear, month: item.plannedMonth }]
      : [];
  }

  private isInMonth(item: CalendarItem, year: number, month: number): boolean {
    return this.itemMonths(item).some(value => value.year === year && value.month === month);
  }

  private isOverdue(item: CalendarItem): boolean {
    if (['COMPLETED', 'CANCELLED'].includes(item.status)) return false;
    const range = normalizeDateOnlyRange(item.scheduledStart, item.scheduledEnd);
    return !!range && range.endKey < localTodayDateOnly();
  }
}
