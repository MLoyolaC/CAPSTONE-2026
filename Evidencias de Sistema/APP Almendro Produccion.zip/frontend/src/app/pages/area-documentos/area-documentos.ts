import { AppSidebarComponent } from '../../shared/app-sidebar/app-sidebar';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import { Subscription } from 'rxjs';
import { BodyScrollLockService } from '../../core/ui/body-scroll-lock.service';

import {
  Component,
  OnDestroy,
  computed,
  inject,
  signal
} from '@angular/core';

import {
  ActivatedRoute,
  Router,
  RouterLink
} from '@angular/router';

interface Area {
  id: number;

  name: string;

  slug: string;

  description: string;

  sortOrder: number;

  documentCount: number;
}


interface DocumentSummary {
  id: string;

  name: string;

  fileType:
    | 'XLSX'
    | 'DOCX'
    | 'PDF';

  indexStatus:
    | 'PENDING'
    | 'INDEXED'
    | 'ERROR'
    | 'NOT_APPLICABLE';

  versionNumber: number;

  sizeBytes: number;

  originalFilename: string;

  createdAt: string;
}


interface ExcelCellPreview {
  columnNumber: number;

  reference: string;

  value: string;

  note: string | null;
}


interface ExcelRowPreview {
  rowNumber: number;

  cells: ExcelCellPreview[];
}


interface ExcelSheetPreview {
  name: string;

  totalRows: number;

  totalColumns: number;

  truncated: boolean;

  rows: ExcelRowPreview[];
}


interface ExcelPreview {
  filename: string;

  sheets: ExcelSheetPreview[];
}


interface DocxPreview { filename:string; blocks:{type:string;text:string|null;rows:string[][]}[]; }

interface SearchResult {
  documentId: string;

  documentName: string;

  fileType: string;

  areaSlug: string;

  areaName: string;

  matchCount: number;

  filenameMatch: boolean;

  locations: string[];
}


@Component({
  selector: 'app-area-documentos',

  imports: [ AppSidebarComponent,
    RouterLink
  ],

  templateUrl:
    './area-documentos.html',

  styleUrl:
    './area-documentos.scss'
})
export class AreaDocumentosComponent
implements OnDestroy {

  private readonly http =
    inject(HttpClient);


  private readonly route =
    inject(ActivatedRoute);


  private readonly router =
    inject(Router);

  private readonly sanitizer = inject(DomSanitizer);
  private readonly scrollLock = inject(BodyScrollLockService);
  private previewLocked = false;


  private targetDocumentId:
    string | null =
    null;


  private searchTimer:
    ReturnType<typeof setTimeout> | null =
    null;


  /*
   * ============================================================
   * ÁREA
   * ============================================================
   */

  protected readonly areaSlug =
    signal('');


  protected readonly areaName =
    signal('');


  protected readonly areaDescription =
    signal('');


  /*
   * ============================================================
   * DOCUMENTOS
   * ============================================================
   */

  protected readonly documents =
    signal<DocumentSummary[]>([]);


  protected readonly documentCount =
    computed(
      () =>
        this.documents().length
    );


  /*
   * ============================================================
   * BÚSQUEDA INTELIGENTE DEL ÁREA
   * ============================================================
   */

  protected readonly searchQuery =
    signal('');


  protected readonly searchResults =
    signal<SearchResult[]>([]);


  protected readonly searching =
    signal(false);


  protected readonly searchError =
    signal('');


  protected readonly searchActive =
    computed(
      () =>
        this.searchQuery()
          .trim()
          .length >= 2
    );


  /*
   * ============================================================
   * ESTADOS GENERALES
   * ============================================================
   */

  protected readonly loading =
    signal(true);


  protected readonly uploading =
    signal(false);


  protected readonly dragging =
    signal(false);


  protected readonly errorMessage =
    signal('');


  protected readonly successMessage =
    signal('');


  /*
   * ============================================================
   * VISTA PREVIA
   * ============================================================
   */

  protected readonly previewDocument =
    signal<DocumentSummary | null>(
      null
    );


  protected readonly preview =
    signal<ExcelPreview | null>(
      null
    );


  protected readonly previewLoading =
    signal(false);

  protected readonly docxPreview = signal<DocxPreview | null>(null);
  protected readonly pdfPreviewUrl = signal<SafeResourceUrl | null>(null);
  protected readonly previewError = signal('');
  private pdfObjectUrl: string | null = null;
  private pdfRequest: Subscription | null = null;


  protected readonly selectedSheetIndex =
    signal(0);


  /*
   * ============================================================
   * EDICIÓN
   * ============================================================
   */

  protected readonly editingDocument =
    signal<DocumentSummary | null>(
      null
    );


  protected readonly replacing =
    signal(false);

  protected readonly replacementFile = signal<File | null>(null);
  protected readonly discardReplacement = signal(false);
  protected readonly replacementDragging = signal(false);


  /*
   * ============================================================
   * ELIMINACIÓN
   * ============================================================
   */

  protected readonly deleteDocument =
    signal<DocumentSummary | null>(
      null
    );


  protected readonly deleteSeconds =
    signal(5);


  protected readonly deleting =
    signal(false);


  private deleteTimer:
    ReturnType<typeof setInterval> | null =
    null;


  /*
   * ============================================================
   * CONSTRUCTOR
   * ============================================================
   */

  constructor() {

    this.route.paramMap.subscribe(
      params => {

        const slug =
          params.get('slug');


        if (!slug) { this.router.navigateByUrl('/dashboard'); return; }
        if (slug === 'trabajadores') { this.router.navigateByUrl('/trabajadores'); return; }


        this.targetDocumentId =
          this.route
            .snapshot
            .queryParamMap
            .get('document');


        this.areaSlug.set(
          slug
        );


        this.resetAreaState();


        this.loadArea();
      }
    );
  }


  ngOnDestroy(): void {

    this.clearDeleteTimer();

    this.clearSearchTimer();
    this.clearPdfObjectUrl();
    if (this.previewLocked) { this.scrollLock.unlock(); this.previewLocked = false; }
  }


  /*
   * ============================================================
   * CARGAR ÁREA
   * ============================================================
   */

  private loadArea(): void {

    this.loading.set(
      true
    );


    this.errorMessage.set(
      ''
    );


    this.http
      .get<Area[]>(
        '/api/areas',
        {
          withCredentials: true
        }
      )
      .subscribe({

        next: areas => {

          const area =
            areas.find(
              item =>
                item.slug ===
                this.areaSlug()
            );


          if (!area) {

            this.errorMessage.set(
              'El área solicitada no existe.'
            );


            this.loading.set(
              false
            );


            return;
          }


          this.areaName.set(
            area.name
          );


          this.areaDescription.set(
            area.description
          );


          this.loadDocuments();
        },


        error: () => {

          this.errorMessage.set(
            'No se pudo cargar la información del área.'
          );


          this.loading.set(
            false
          );
        }
      });
  }


  /*
   * ============================================================
   * CARGAR DOCUMENTOS
   * ============================================================
   */

  private loadDocuments(): void {

    this.http
      .get<DocumentSummary[]>(
        `/api/areas/${this.areaSlug()}/documents`,
        {
          withCredentials: true
        }
      )
      .subscribe({

        next: documents => {

          this.documents.set(
            documents
          );


          this.loading.set(
            false
          );


          this.openTargetDocument(
            documents
          );
        },


        error: () => {

          this.errorMessage.set(
            'No se pudieron cargar los documentos del área.'
          );


          this.loading.set(
            false
          );
        }
      });
  }


  /*
   * ============================================================
   * DOCUMENTO QUE VIENE DESDE DASHBOARD
   * ============================================================
   */

  private openTargetDocument(
    documents: DocumentSummary[]
  ): void {

    if (!this.targetDocumentId) {
      return;
    }


    const documentId =
      this.targetDocumentId;


    this.targetDocumentId =
      null;


    const document =
      documents.find(
        item =>
          item.id === documentId
      );


    if (!document) {

      this.errorMessage.set(
        'El documento seleccionado ya no está disponible.'
      );


      return;
    }


    this.openDocument(
      document
    );
  }


  /*
   * ============================================================
   * BUSCADOR INTELIGENTE DEL ÁREA
   * ============================================================
   */

  protected onSearchInput(
    event: Event
  ): void {

    const input =
      event.target as HTMLInputElement;


    const value =
      input.value;


    this.searchQuery.set(
      value
    );


    this.searchError.set(
      ''
    );


    this.clearSearchTimer();


    /*
     * Se requieren al menos 2 caracteres.
     */

    if (
      value.trim().length < 2
    ) {

      this.searchResults.set(
        []
      );


      this.searching.set(
        false
      );


      return;
    }


    this.searching.set(
      true
    );


    /*
     * Debounce de 1 segundo.
     */

    this.searchTimer =
      setTimeout(
        () => {

          this.performAreaSearch(
            value
          );

        },
        1000
      );
  }


  private performAreaSearch(
    query: string
  ): void {

    const currentQuery =
      query.trim();


    if (
      currentQuery.length < 2
    ) {

      this.searching.set(
        false
      );


      return;
    }


    this.http
      .get<SearchResult[]>(
        '/api/search',
        {
          params: {

            q:
              currentQuery,

            areaSlug:
              this.areaSlug()
          },

          withCredentials:
            true
        }
      )
      .subscribe({

        next: results => {

          /*
           * Ignoramos respuestas viejas
           * si el usuario siguió escribiendo.
           */

          if (
            this.searchQuery()
              .trim() !== currentQuery
          ) {

            return;
          }


          this.searchResults.set(
            results
          );


          this.searching.set(
            false
          );
        },


        error: () => {

          this.searchResults.set(
            []
          );


          this.searchError.set(
            'No se pudo realizar la búsqueda.'
          );


          this.searching.set(
            false
          );
        }
      });
  }


  protected clearSearch(): void {

    this.clearSearchTimer();


    this.searchQuery.set(
      ''
    );


    this.searchResults.set(
      []
    );


    this.searchError.set(
      ''
    );


    this.searching.set(
      false
    );
  }


  protected openSearchResult(
    result: SearchResult
  ): void {

    const document =
      this.documents().find(
        item =>
          item.id === result.documentId
      );


    if (!document) {

      this.errorMessage.set(
        'El documento seleccionado ya no está disponible.'
      );


      return;
    }


    /*
     * Limpiamos búsqueda y abrimos
     * el documento directamente.
     */

    this.clearSearch();


    this.openDocument(
      document
    );
  }


  protected resultCountLabel(
    count: number
  ): string {

    if (
      count === 1
    ) {

      return '1 coincidencia';
    }


    return `${count} coincidencias`;
  }


  private clearSearchTimer(): void {

    if (!this.searchTimer) {
      return;
    }


    clearTimeout(
      this.searchTimer
    );


    this.searchTimer =
      null;
  }


  /*
   * ============================================================
   * HISTORIAL
   * ============================================================
   */

  protected openAreaHistory(): void {

    this.router.navigate([
      '/areas',
      this.areaSlug(),
      'historial'
    ]);
  }


  protected openDocumentHistory(
    document: DocumentSummary
  ): void {

    this.router.navigate([
      '/documentos',
      document.id,
      'historial'
    ]);
  }


  /*
   * ============================================================
   * NUEVO ARCHIVO
   * ============================================================
   */

  protected openFilePicker(
    input: HTMLInputElement
  ): void {

    if (
      this.uploading()
    ) {

      return;
    }


    input.click();
  }


  protected onFileSelected(
    event: Event
  ): void {

    const input =
      event.target as HTMLInputElement;


    const file =
      input.files?.[0];


    input.value =
      '';


    if (!file) {
      return;
    }


    this.processNewFile(
      file
    );
  }


  /*
   * ============================================================
   * DRAG & DROP
   * ============================================================
   */

  protected onDragOver(
    event: DragEvent
  ): void {

    event.preventDefault();

    event.stopPropagation();


    if (
      this.uploading()
    ) {

      return;
    }


    this.dragging.set(
      true
    );


    if (
      event.dataTransfer
    ) {

      event.dataTransfer.dropEffect =
        'copy';
    }
  }


  protected onDragEnter(
    event: DragEvent
  ): void {

    event.preventDefault();

    event.stopPropagation();


    if (
      !this.uploading()
    ) {

      this.dragging.set(
        true
      );
    }
  }


  protected onDragLeave(
    event: DragEvent
  ): void {

    event.preventDefault();

    event.stopPropagation();


    this.dragging.set(
      false
    );
  }


  protected onDrop(
    event: DragEvent
  ): void {

    event.preventDefault();

    event.stopPropagation();


    this.dragging.set(
      false
    );


    if (
      this.uploading()
    ) {

      return;
    }


    const files =
      event.dataTransfer?.files;


    if (!files?.length) {
      return;
    }


    if (
      files.length > 1
    ) {

      this.errorMessage.set(
        'Carga un documento a la vez.'
      );


      return;
    }


    this.processNewFile(
      files[0]
    );
  }


  /*
   * ============================================================
   * VALIDAR ARCHIVO
   * ============================================================
   */

  private processNewFile(
    file: File
  ): void {

    this.clearMessages();


    if (
      !this.isAllowedFile(
        file
      )
    ) {

      this.errorMessage.set(
        'Solo se permiten archivos XLSX, DOCX o PDF.'
      );


      return;
    }


    if (
      file.size >
      25 * 1024 * 1024
    ) {

      this.errorMessage.set(
        'El archivo supera el máximo permitido de 25 MB.'
      );


      return;
    }


    this.uploadDocument(
      file
    );
  }


  /*
   * ============================================================
   * SUBIR DOCUMENTO
   * ============================================================
   */

  private uploadDocument(
    file: File
  ): void {

    this.uploading.set(
      true
    );


    this.dragging.set(
      false
    );


    const formData =
      new FormData();


    formData.append(
      'file',
      file,
      file.name
    );


    this.http
      .post<DocumentSummary>(
        `/api/areas/${this.areaSlug()}/documents`,

        formData,

        {
          withCredentials: true
        }
      )
      .subscribe({

        next: document => {

          this.documents.update(
            documents => [
              document,
              ...documents
            ]
          );


          this.clearSearch();


          this.successMessage.set(
            'Documento cargado correctamente.'
          );


          this.uploading.set(
            false
          );
        },


        error: () => {

          this.errorMessage.set(
            'No se pudo cargar el documento.'
          );


          this.uploading.set(
            false
          );
        }
      });
  }


  /*
   * ============================================================
   * ABRIR DOCUMENTO
   * ============================================================
   */

  protected openDocument(
    document: DocumentSummary
  ): void {

    this.clearMessages();
    if (!this.previewLocked) { this.scrollLock.lock(); this.previewLocked = true; }


    this.previewDocument.set(document);
    this.preview.set(null);
    this.docxPreview.set(null);
    this.clearPdfObjectUrl();
    this.previewError.set('');
    this.previewLoading.set(true);
    this.selectedSheetIndex.set(0);

    if (document.fileType === 'PDF') {
      this.pdfRequest = this.http.get(`/api/documents/${document.id}/inline`, {
        responseType: 'blob',
        withCredentials: true
      }).subscribe({
        next: blob => {
          this.pdfRequest = null;
          if (blob.type && blob.type !== 'application/pdf') {
            this.previewError.set('No fue posible cargar la vista previa del PDF.');
          } else {
            this.pdfObjectUrl = URL.createObjectURL(blob);
            this.pdfPreviewUrl.set(this.sanitizer.bypassSecurityTrustResourceUrl(this.pdfObjectUrl));
          }
          this.previewLoading.set(false);
        },
        error: error => {
          this.pdfRequest = null;
          this.previewError.set(this.apiMessage(error, 'No fue posible cargar la vista previa del PDF.'));
          this.previewLoading.set(false);
        }
      });
      return;
    }

    if (document.fileType === 'DOCX') {
      this.http.get<DocxPreview>(`/api/documents/${document.id}/docx-preview`, {withCredentials:true}).subscribe({
        next: value => { this.docxPreview.set(value); this.previewLoading.set(false); },
        error: error => { this.previewLoading.set(false); this.previewError.set(this.apiMessage(error, 'No fue posible cargar la vista previa del Word.')); }
      });
      return;
    }

    this.http.get<ExcelPreview>(`/api/documents/${document.id}/preview`, {withCredentials:true}).subscribe({
      next: value => { this.preview.set(value); this.previewLoading.set(false); },
      error: error => { this.previewLoading.set(false); this.previewError.set(this.apiMessage(error, 'No fue posible cargar la vista previa del Excel.')); }
    });
  }


  /*
   * ============================================================
   * VISTA PREVIA
   * ============================================================
   */

  protected closePreview(): void {

    if (this.previewLocked) { this.scrollLock.unlock(); this.previewLocked = false; }

    this.previewDocument.set(
      null
    );


    this.preview.set(null);
    this.docxPreview.set(null);
    this.clearPdfObjectUrl();
    this.previewError.set('');
    this.selectedSheetIndex.set(0);
  }


  protected selectSheet(
    index: number
  ): void {

    this.selectedSheetIndex.set(
      index
    );
  }


  protected selectedSheet():
    ExcelSheetPreview | null {

    const workbook =
      this.preview();


    if (!workbook) {
      return null;
    }


    return workbook.sheets[
      this.selectedSheetIndex()
    ] ?? null;
  }


  protected columnName(
    index: number
  ): string {

    let number =
      index + 1;


    let result =
      '';


    while (
      number > 0
    ) {

      const remainder =
        (number - 1) % 26;


      result =
        String.fromCharCode(
          65 + remainder
        ) + result;


      number =
        Math.floor(
          (number - 1) / 26
        );
    }


    return result;
  }


  /*
   * ============================================================
   * DESCARGAR
   * ============================================================
   */

  protected downloadDocument(
    document: DocumentSummary
  ): void {

    this.clearMessages();


    this.http
      .get(
        `/api/documents/${document.id}/download`,

        {
          responseType:
            'blob',

          observe:
            'response',

          withCredentials:
            true
        }
      )
      .subscribe({

        next: response => {

          if (
            !response.body
          ) {

            return;
          }


          this.saveBlob(
            response.body,
            document.originalFilename
          );
        },


        error: error => {

          this.errorMessage.set(
            this.apiMessage(error, 'No fue posible descargar el documento.')
          );
        }
      });
  }


  /*
   * ============================================================
   * EDITAR
   * ============================================================
   */

  protected startEdit(
    document: DocumentSummary
  ): void {

    this.clearMessages();
    this.closePreview();
    this.replacementFile.set(null);
    this.discardReplacement.set(false);
    this.editingDocument.set(document);
  }


  protected selectReplacement(
    input: HTMLInputElement
  ): void {

    if (
      this.replacing()
    ) {

      return;
    }


    input.click();
  }


  protected onReplacementSelected(
    event: Event
  ): void {

    const input =
      event.target as HTMLInputElement;


    const file =
      input.files?.[0];


    input.value =
      '';


    if (file) this.setReplacementFile(file);
  }

  protected onReplacementDragOver(event: DragEvent): void {
    event.preventDefault();
    if (!this.replacing()) this.replacementDragging.set(true);
  }

  protected onReplacementDragLeave(event: DragEvent): void {
    event.preventDefault();
    this.replacementDragging.set(false);
  }

  protected onReplacementDrop(event: DragEvent): void {
    event.preventDefault();
    this.replacementDragging.set(false);
    const file = event.dataTransfer?.files?.[0];
    if (file && !this.replacing()) this.setReplacementFile(file);
  }

  private setReplacementFile(file: File): void {
    const document = this.editingDocument();
    if (!document) return;
    const extension = file.name.split('.').pop()?.toLowerCase();
    if (extension !== document.fileType.toLowerCase()) {
      this.errorMessage.set('El formato seleccionado no corresponde al tipo permitido.');
      return;
    }
    if (file.size > 25 * 1024 * 1024) {
      this.errorMessage.set('El archivo supera el máximo permitido de 25 MB.');
      return;
    }
    this.errorMessage.set('');
    this.replacementFile.set(file);
  }

  protected confirmReplacement(): void {
    const document = this.editingDocument();
    const file = this.replacementFile();
    if (!document || !file || this.replacing()) return;
    this.replaceDocument(document, file);
  }


  private replaceDocument(
    document: DocumentSummary,
    file: File
  ): void {

    this.replacing.set(
      true
    );


    this.clearMessages();


    const formData =
      new FormData();


    formData.append(
      'file',
      file,
      file.name
    );


    this.http
      .post<DocumentSummary>(
        `/api/documents/${document.id}/replace`,

        formData,

        {
          withCredentials: true
        }
      )
      .subscribe({

        next: updated => {

          this.documents.update(
            documents =>
              documents.map(
                item =>
                  item.id === updated.id
                    ? updated
                    : item
              )
          );


          this.editingDocument.set(
            null
          );
          this.replacementFile.set(null);


          this.replacing.set(
            false
          );


          this.clearSearch();


          this.successMessage.set(
            `Nueva versión guardada correctamente. Versión ${updated.versionNumber}.`
          );
        },


        error: error => {

          this.replacing.set(
            false
          );


          if (
            error.status === 409
          ) {

            this.errorMessage.set(
              'El archivo seleccionado no contiene cambios.'
            );


            return;
          }


          this.errorMessage.set(this.apiMessage(error, 'No fue posible actualizar el documento.'));
        }
      });
  }


  protected cancelEdit(): void {
    if (this.replacementFile()) {
      this.discardReplacement.set(true);
      return;
    }
    this.closeEdit();
  }

  protected confirmDiscardReplacement(): void {
    this.discardReplacement.set(false);
    this.closeEdit();
  }

  private closeEdit(): void {
    this.replacementFile.set(null);
    this.replacementDragging.set(false);
    this.editingDocument.set(null);
  }


  /*
   * ============================================================
   * ELIMINAR
   * ============================================================
   */

  protected askDelete(
    document: DocumentSummary
  ): void {

    this.clearDeleteTimer();


    this.deleteDocument.set(
      document
    );


    this.deleteSeconds.set(
      5
    );


    this.deleting.set(
      false
    );


    this.deleteTimer =
      setInterval(
        () => {

          const current =
            this.deleteSeconds();


          if (
            current <= 1
          ) {

            this.deleteSeconds.set(
              0
            );


            this.clearDeleteTimer();


            return;
          }


          this.deleteSeconds.set(
            current - 1
          );

        },
        1000
      );
  }


  protected cancelDelete(): void {

    if (
      this.deleting()
    ) {

      return;
    }


    this.clearDeleteTimer();


    this.deleteDocument.set(
      null
    );


    this.deleteSeconds.set(
      5
    );
  }


  protected confirmDelete(): void {

    const document =
      this.deleteDocument();


    if (
      !document
      || this.deleteSeconds() > 0
      || this.deleting()
    ) {

      return;
    }


    this.deleting.set(
      true
    );


    this.http
      .delete(
        `/api/documents/${document.id}`,

        {
          withCredentials: true
        }
      )
      .subscribe({

        next: () => {

          this.documents.update(
            documents =>
              documents.filter(
                item =>
                  item.id !==
                  document.id
              )
          );


          if (
            this.previewDocument()?.id
            === document.id
          ) {

            this.closePreview();
          }


          if (
            this.editingDocument()?.id
            === document.id
          ) {

            this.editingDocument.set(
              null
            );
          }


          this.deleteDocument.set(
            null
          );


          this.deleting.set(
            false
          );


          this.clearSearch();


          this.successMessage.set(
            `El documento "${document.name}" fue eliminado.`
          );
        },


        error: () => {

          this.deleting.set(
            false
          );


          this.errorMessage.set(
            'No se pudo eliminar el documento.'
          );
        }
      });
  }


  /*
   * ============================================================
   * FORMATO
   * ============================================================
   */

  protected formatFileSize(
    bytes: number
  ): string {

    if (
      bytes < 1024
    ) {

      return `${bytes} B`;
    }


    const kb =
      bytes / 1024;


    if (
      kb < 1024
    ) {

      return `${kb.toFixed(1)} KB`;
    }


    return `${(
      kb / 1024
    ).toFixed(1)} MB`;
  }


  protected getFileIcon(
    fileType: string
  ): string {

    switch (
      fileType
    ) {

      case 'XLSX':

        return 'fa-solid fa-file-excel';


      case 'DOCX':

        return 'fa-solid fa-file-word';


      case 'PDF':

        return 'fa-solid fa-file-pdf';


      default:

        return 'fa-solid fa-file';
    }
  }


  protected getFileLabel(
    fileType: string
  ): string {

    switch (
      fileType
    ) {

      case 'XLSX':

        return 'Excel';


      case 'DOCX':

        return 'Word';


      case 'PDF':

        return 'PDF';


      default:

        return fileType;
    }
  }


  /*
   * ============================================================
   * UTILIDADES
   * ============================================================
   */

  private saveBlob(
    blob: Blob,
    filename: string
  ): void {

    const url =
      URL.createObjectURL(
        blob
      );


    const anchor =
      window.document
        .createElement('a');


    anchor.href =
      url;


    anchor.download =
      filename;


    anchor.click();


    URL.revokeObjectURL(
      url
    );
  }

  private clearPdfObjectUrl(): void {
    this.pdfRequest?.unsubscribe();
    this.pdfRequest = null;
    if (this.pdfObjectUrl) {
      URL.revokeObjectURL(this.pdfObjectUrl);
      this.pdfObjectUrl = null;
    }
    this.pdfPreviewUrl.set(null);
  }

  private apiMessage(error: any, fallback: string): string {
    return typeof error?.error?.message === 'string' && error.error.message.trim()
      ? error.error.message
      : fallback;
  }


  private isAllowedFile(
    file: File
  ): boolean {

    const extension =
      file.name
        .split('.')
        .pop()
        ?.toLowerCase();


    return (
      extension === 'xlsx'
      || extension === 'docx'
      || extension === 'pdf'
    );
  }


  private clearMessages(): void {

    this.errorMessage.set(
      ''
    );


    this.successMessage.set(
      ''
    );
  }


  private clearDeleteTimer(): void {

    if (
      !this.deleteTimer
    ) {

      return;
    }


    clearInterval(
      this.deleteTimer
    );


    this.deleteTimer =
      null;
  }


  private resetAreaState(): void {

    this.clearDeleteTimer();

    this.clearSearchTimer();


    this.documents.set(
      []
    );


    this.searchQuery.set(
      ''
    );


    this.searchResults.set(
      []
    );


    this.searching.set(
      false
    );


    this.searchError.set(
      ''
    );


    this.areaName.set(
      ''
    );


    this.areaDescription.set(
      ''
    );


    this.errorMessage.set(
      ''
    );


    this.successMessage.set(
      ''
    );


    this.previewDocument.set(
      null
    );


    this.preview.set(
      null
    );


    this.previewLoading.set(
      false
    );


    this.selectedSheetIndex.set(
      0
    );


    this.editingDocument.set(
      null
    );
    this.replacementFile.set(null);
    this.discardReplacement.set(false);
    this.previewError.set('');
    this.clearPdfObjectUrl();


    this.deleteDocument.set(
      null
    );


    this.dragging.set(
      false
    );


    this.uploading.set(
      false
    );


    this.replacing.set(
      false
    );


    this.deleting.set(
      false
    );


    this.deleteSeconds.set(
      5
    );
  }
}
