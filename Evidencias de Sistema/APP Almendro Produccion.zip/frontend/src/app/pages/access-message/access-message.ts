import { Component, inject } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { AppSidebarComponent } from '../../shared/app-sidebar/app-sidebar';

@Component({
  selector: 'app-access-message',
  standalone: true,
  imports: [AppSidebarComponent, RouterLink],
  template: `<app-sidebar />
    <main class="access-page"><section>
      <i class="fa-solid fa-shield-halved"></i>
      <h1>{{ noAccess ? 'No tienes accesos asignados' : 'No tienes permisos para acceder a esta sección' }}</h1>
      <p>{{ noAccess ? 'Contacta al administrador para que asigne las áreas necesarias a tu cuenta.' : 'Tu cuenta está activa, pero esta sección no forma parte de tus permisos.' }}</p>
      <a routerLink="/login">Volver al inicio</a>
    </section></main>`,
  styles: [`:host{display:block;min-height:100vh;background:var(--bg);color:var(--text)}.access-page{min-height:calc(100vh - 118px);display:grid;place-items:center;padding:28px}.access-page section{width:min(560px,100%);text-align:center;padding:42px 28px;border:1px solid var(--border);border-radius:18px;background:var(--surface);box-shadow:var(--shadow-sm)}i{width:58px;height:58px;display:grid;place-items:center;margin:0 auto 16px;border-radius:16px;background:var(--accent-soft);color:var(--accent-strong);font-size:22px}h1{font-size:23px;margin:0 0 9px}p{margin:0 auto 22px;color:var(--text-muted);font-size:11px;line-height:1.7;max-width:440px}a{display:inline-flex;padding:10px 15px;border-radius:9px;background:var(--button-primary);color:var(--button-primary-text);text-decoration:none;font-size:10px;font-weight:800}`]
})
export class AccessMessageComponent {
  private readonly route = inject(ActivatedRoute);
  protected readonly noAccess = this.route.snapshot.data['noAccess'] === true;
}
