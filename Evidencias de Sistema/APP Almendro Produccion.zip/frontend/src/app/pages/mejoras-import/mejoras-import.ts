import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AppSidebarComponent } from '../../shared/app-sidebar/app-sidebar';

interface ImprovementCandidate {
  sourceKey: string; sourceKind: string; sourceSection: string; sourceSheetName: string;
  sourceRowNumber: number; sourceColumn: string; workType: string; phase: string | null;
  title: string; description: string | null; sector: string | null; category: string | null;
  responsibleName: string | null; frequency: string | null; ideaDate: string | null;
  targetYear: number | null; targetMonth: number | null; targetDate: string | null;
  status: string; supplierName: string | null; materials: string | null; estimatedCost: number | null;
  progressPercent: number | null; notes: string | null; realizedDate: string | null;
  originalText: string | null; confidence: string; recommended: boolean; alreadyImported: boolean;
  selected?: boolean;
}
interface AnalysisResult {
  filename: string; checksum: string; candidateCount: number; pendingCount: number;
  historicalCount: number; byKind: Record<string, number>; candidates: ImprovementCandidate[]; warnings: string[];
}
interface ExistingImprovement { id:string; title:string; areaSlug:string; areaName:string; location:string|null; workType:string; }
interface ImprovementDuplicate { existing:ExistingImprovement; incoming:ImprovementCandidate; }
interface ImportGroup {
  key: string; kind: string; title: string; subtitle: string; icon: string;
  candidates: ImprovementCandidate[]; selected: number; imported: number; completed: number;
}

@Component({
  selector: 'app-mejoras-import', imports: [RouterLink, AppSidebarComponent],
  templateUrl: './mejoras-import.html', styleUrl: './mejoras-import.scss'
})
export class MejorasImportComponent {
  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);
  protected readonly selectedFile = signal<File | null>(null);
  protected readonly analysis = signal<AnalysisResult | null>(null);
  protected readonly analyzing = signal(false);
  protected readonly importing = signal(false);
  protected readonly errorMessage = signal('');
  protected readonly duplicateDialog = signal<ImprovementDuplicate[] | null>(null);
  private pendingCandidates: ImprovementCandidate[] = [];
  protected candidates: ImprovementCandidate[] = [];

  protected onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.selectedFile.set(input.files?.[0] ?? null); this.analysis.set(null); this.candidates=[]; this.errorMessage.set('');
  }
  protected analyzeFile(): void {
    const file=this.selectedFile(); if(!file){this.errorMessage.set('Selecciona una planilla Excel antes de analizarla.');return;}
    const data=new FormData(); data.append('file',file); this.analyzing.set(true); this.errorMessage.set('');
    this.http.post<AnalysisResult>('/api/areas/mejoras/imports/analyze',data,{withCredentials:true}).subscribe({
      next: result => { this.analysis.set(result); this.candidates=result.candidates.map(c=>({...c,selected:!c.alreadyImported})); this.analyzing.set(false); },
      error: (error:HttpErrorResponse)=>{this.analyzing.set(false);this.errorMessage.set(error.error?.detail||error.error?.message||'No fue posible analizar la planilla.');}
    });
  }
  protected groups(): ImportGroup[] {
    const map=new Map<string,ImprovementCandidate[]>();
    for(const c of this.candidates){const key=`${c.sourceKind}|${c.sourceSheetName}`;const list=map.get(key)??[];list.push(c);map.set(key,list);}
    return [...map.entries()].map(([key,list])=>{
      const c=list[0]; return {key,kind:c.sourceKind,title:this.sectionTitle(c),subtitle:this.sectionSubtitle(c),icon:this.kindIcon(c.sourceKind),candidates:list,
        selected:list.filter(x=>x.selected&&!x.alreadyImported).length, imported:list.filter(x=>x.alreadyImported).length, completed:list.filter(x=>x.status==='COMPLETED').length};
    }).sort((a,b)=>this.kindOrder(a.kind)-this.kindOrder(b.kind)||a.title.localeCompare(b.title,'es-CL'));
  }
  protected groupSelected(group:ImportGroup):boolean {const eligible=group.candidates.filter(c=>!c.alreadyImported);return !!eligible.length&&eligible.every(c=>c.selected);}
  protected toggleGroup(group:ImportGroup):void {const on=!this.groupSelected(group);const keys=new Set(group.candidates.map(c=>c.sourceKey));this.candidates=this.candidates.map(c=>keys.has(c.sourceKey)&&!c.alreadyImported?{...c,selected:on}:c);}
  protected selectAll():void{this.candidates=this.candidates.map(c=>({...c,selected:!c.alreadyImported}));}
  protected clearSelection():void{this.candidates=this.candidates.map(c=>({...c,selected:false}));}
  protected selectedCount():number{return this.candidates.filter(c=>c.selected&&!c.alreadyImported).length;}
  protected importedCount():number{return this.candidates.filter(c=>c.alreadyImported).length;}
  protected importSelected(force=false):void{
    const info=this.analysis(), selected=this.candidates.filter(c=>c.selected&&!c.alreadyImported); if(!info||!selected.length){this.errorMessage.set('No hay registros seleccionados para incorporar.');return;}
    if(force){this.performImport(selected);return;}
    this.http.get<ExistingImprovement[]>('/api/work-items',{params:{area:'mejoras'},withCredentials:true}).subscribe({
      next:existing=>{
        const matches:ImprovementDuplicate[]=[];
        for(const incoming of selected){
          const found=existing.find(item=>this.sameImprovement(item,incoming));
          if(found)matches.push({existing:found,incoming});
        }
        if(matches.length){this.pendingCandidates=selected;this.duplicateDialog.set(matches.slice(0,20));return;}
        this.performImport(selected);
      },error:()=>this.performImport(selected)
    });
  }
  protected confirmDuplicates():void{const selected=this.pendingCandidates;this.pendingCandidates=[];this.duplicateDialog.set(null);this.performImport(selected);}
  protected cancelDuplicates():void{this.pendingCandidates=[];this.duplicateDialog.set(null);}
  protected viewDuplicate(match:ImprovementDuplicate):void{this.duplicateDialog.set(null);this.router.navigate(['/areas/mejoras'],{queryParams:{editar:match.existing.id}});}
  private performImport(selected:ImprovementCandidate[]):void{
    const info=this.analysis();if(!info||!selected.length)return;this.importing.set(true);this.errorMessage.set('');
    this.http.post<{created:number;skipped:number}>('/api/areas/mejoras/imports',{filename:info.filename,candidates:selected.map(({selected:_s,...c})=>c)},{withCredentials:true}).subscribe({
      next:r=>{this.importing.set(false);this.router.navigate(['/areas/mejoras'],{queryParams:{importados:r.created}});},
      error:(e:HttpErrorResponse)=>{this.importing.set(false);this.errorMessage.set(e.error?.detail||e.error?.message||'No fue posible incorporar la información.');}
    });
  }
  private sameImprovement(item:ExistingImprovement,c:ImprovementCandidate):boolean{
    if(item.workType==='IMPROVEMENT_GANTT'&&c.workType!=='IMPROVEMENT_GANTT')return false;
    if(item.workType!=='IMPROVEMENT_GANTT'&&c.workType==='IMPROVEMENT_GANTT')return false;
    const a=this.normalize(item.title),b=this.normalize(c.title);if(!a||!b)return false;
    const titleMatch=a===b||(a.length>=10&&b.length>=10&&(a.includes(b)||b.includes(a)));
    if(!titleMatch)return false;
    const la=this.normalize(item.location||''),lb=this.normalize(c.sector||'');
    return !la||!lb||la===lb||la.includes(lb)||lb.includes(la);
  }
  private normalize(value:string):string{return value.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('es-CL').replace(/[^a-z0-9]+/g,' ').trim().replace(/\s+/g,' ');}
  protected preview(group:ImportGroup):ImprovementCandidate[]{return group.candidates.slice(0,5);}
  protected formatMoney(value:number|null):string{return value==null?'Sin presupuesto':new Intl.NumberFormat('es-CL',{style:'currency',currency:'CLP',maximumFractionDigits:0}).format(value);}
  protected targetLabel(c:ImprovementCandidate):string{if(c.targetDate)return new Date(`${c.targetDate}T00:00:00`).toLocaleDateString('es-CL');if(c.targetYear&&c.targetMonth)return new Intl.DateTimeFormat('es-CL',{month:'long',year:'numeric'}).format(new Date(c.targetYear,c.targetMonth-1,1));if(c.targetYear)return String(c.targetYear);if(c.frequency)return c.frequency;return 'Sin fecha objetivo';}
  protected fileSizeLabel():string{const f=this.selectedFile();if(!f)return'';return f.size<1048576?`${Math.max(1,Math.round(f.size/1024))} KB`:`${(f.size/1048576).toFixed(1)} MB`;}
  protected kindLabel(kind:string):string{return kind==='POR_HACER'?'Proyectos y metas':kind==='ANNUAL_PLAN'?'Plan anual':kind==='GANTT'?'Carta Gantt':kind;}
  private sectionTitle(c:ImprovementCandidate):string{if(c.sourceKind==='ANNUAL_PLAN')return `Plan anual ${c.sourceSheetName}`;if(c.sourceKind==='GANTT')return 'Carta Gantt';const n=c.sourceSheetName.toLocaleLowerCase('es-CL');if(n.includes('proyectos pendientes'))return 'Proyectos Pendientes';if(n.includes('recepcion'))return 'Metas Recepción';if(n.includes('obras'))return 'Metas Obras';if(n.includes('jard'))return 'Metas Jardinería';if(n.includes('marketing'))return 'Metas Marketing';if(n.includes('oficina'))return 'Metas Oficina';return c.sourceSheetName;}
  private sectionSubtitle(c:ImprovementCandidate):string{if(c.sourceKind==='POR_HACER')return `Hoja ${c.sourceSheetName}. Sus registros conservarán la meta o subgrupo original.`;if(c.sourceKind==='ANNUAL_PLAN')return `Todo el año ${c.sourceSheetName}: Hotel, Centro de Eventos, áreas y meses se conservarán.`;return `Fases, tareas, responsables, fechas, avance y estado se incorporarán a la vista Gantt.`;}
  private kindIcon(kind:string):string{return kind==='GANTT'?'fa-solid fa-chart-gantt':kind==='ANNUAL_PLAN'?'fa-solid fa-calendar-days':'fa-solid fa-bullseye';}
  private kindOrder(kind:string):number{return kind==='POR_HACER'?0:kind==='ANNUAL_PLAN'?1:kind==='GANTT'?2:9;}
}
