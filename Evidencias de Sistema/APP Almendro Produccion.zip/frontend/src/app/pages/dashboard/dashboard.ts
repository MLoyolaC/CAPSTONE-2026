import {
  HttpClient
} from '@angular/common/http';

import {
  Component,
  OnDestroy,
  computed,
  inject,
  signal
} from '@angular/core';

import {
  Router
} from '@angular/router';

import {
  AppSidebarComponent
} from '../../shared/app-sidebar/app-sidebar';


import { ExpenseReport, formatCLP } from '../../core/expenses/expenses.models';
import { AppSettingsService } from '../../core/settings/app-settings.service';
import { SessionExperienceService } from '../../core/auth/session-experience.service';
import { ThemeService } from '../../core/auth/theme/theme.service';


/* ============================================================
   TIPOS
   ============================================================ */

interface AreaBackend {
  id: number;

  name: string;

  slug: string;

  description: string;

  sortOrder: number;

  documentCount: number;
}


interface WorkItem {
  id: string;

  areaSlug: string;

  areaName?: string;

  workType: string;

  title: string;

  description?: string | null;

  location?: string | null;

  responsibleName?: string | null;

  priority: string;

  status: string;

  scheduledStart: string | null;

  scheduledEnd: string | null;

  completedDate?: string | null;

  progressPercent?: number;

  plannedYear?: number | null;

  plannedMonth?: number | null;

  notes?: string | null;

  category?: string | null;

  assetName?: string | null;

  frequency?: string | null;

  season?: string | null;

  estimatedCost?: number | null;

  actualCost?: number | null;

  updatedAt?: string | null;

  operationalState: OperationalState;

  upcoming: boolean;
}


type OperationalState =
  'PENDING' |
  'IN_PROGRESS' |
  'OVERDUE' |
  'COMPLETED' |
  'CANCELLED' |
  'OTHER_OPEN';


interface AreaStats {
  active: number;

  pending: number;

  completed: number;

  overdue: number;

  total: number;

  open: number;

  upcoming: number;

  otherOpen: number;

  cancelled: number;
}


interface DashboardDimension {
  label: string;
  count: number;
}


interface DashboardAreaOverview {
  slug: string;
  name: string;
  open: number;
  pending: number;
  inProgress: number;
  overdue: number;
  upcoming: number;
  completed: number;
  cancelled: number;
  otherOpen: number;
  total: number;
  averageProgress: number | null;
  estimatedCost: number;
  actualCost: number;
  dimensionLabel: string;
  dimensions: DashboardDimension[];
}


interface DashboardOperationsResponse {
  asOf: string;
  upcomingDays: number;
  areas: DashboardAreaOverview[];
  items: WorkItem[];
}


interface AreaConfig {
  name: string;

  slug: string;

  workType: string;

  icon: string;

  description: string;

  bullets: string[];
}


interface SearchResult {
  documentId: string;

  documentName: string;

  fileType: string;

  areaSlug: string;

  areaName: string;

  matchCount: number;

  filenameMatch: boolean;

  locations: string[];
}

/* ============================================================
   CONFIGURACIÓN DE LAS 6 ÁREAS
   ============================================================ */

const AREA_CONFIGS: AreaConfig[] = [

  {
    name:
      'Mantención General',

    slug:
      'mantencion-general',

    workType:
      'GENERAL_MAINTENANCE',

    icon:
      'fa-solid fa-screwdriver-wrench',

    description:
      'Mantenciones rutinarias y programadas de habitaciones, pasillos, salones y espacios generales.',

    bullets: [
      'Mantenciones generales programadas.',
      'Habitaciones, pasillos y salones.',
      'Seguimiento de responsables y fechas.'
    ]
  },


  {
    name:
      'Mantención Reactiva',

    slug:
      'mantencion-reactiva',

    workType:
      'REACTIVE_MAINTENANCE',

    icon:
      'fa-solid fa-bolt',

    description:
      'Fallas o situaciones imprevistas que requieren atención y solución en el menor tiempo posible.',

    bullets: [
      'Emergencias y fallas imprevistas.',
      'Atención prioritaria.',
      'Registro de solución y responsable.'
    ]
  },


  {
    name:
      'Mejoras',

    slug:
      'mejoras',

    workType:
      'IMPROVEMENT',

    icon:
      'fa-solid fa-chart-line',

    description:
      'Proyectos y trabajos planificados para mejorar los espacios e instalaciones del hotel.',

    bullets: [
      'Proyectos nuevos.',
      'Mejoras de infraestructura.',
      'Seguimiento de avance y costos.'
    ]
  },


  {
    name:
      'Remodelación',

    slug:
      'remodelacion',

    workType:
      'REMODELING',

    icon:
      'fa-solid fa-building',

    description:
      'Renovación de espacios con control de actividades, materiales, responsables y avances.',

    bullets: [
      'Renovación de espacios.',
      'Control de materiales.',
      'Seguimiento de costos y avances.'
    ]
  },


  {
    name:
      'Mantención de Máquinas',

    slug:
      'mantencion-maquinas',

    workType:
      'MACHINE_MAINTENANCE',

    icon:
      'fa-solid fa-gears',

    description:
      'Control de revisiones y mantenciones periódicas de equipos y maquinaria del hotel.',

    bullets: [
      'Equipos y maquinaria.',
      'Mantenciones periódicas.',
      'Fechas y responsables.'
    ]
  },


  {
    name:
      'Mantención de Jardinería',

    slug:
      'mantencion-jardineria',

    workType:
      'GARDENING',

    icon:
      'fa-solid fa-leaf',

    description:
      'Planificación y seguimiento de labores relacionadas con jardines y espacios exteriores.',

    bullets: [
      'Jardines y áreas verdes.',
      'Trabajos por temporada.',
      'Planificación de labores.'
    ]
  },
  {
    name: 'Prevención de Riesgos',
    slug: 'prevencion-riesgos',
    workType: 'PREVENTION',
    icon: 'fa-solid fa-shield-heart',
    description: 'Planificación de inspecciones, medidas preventivas y cumplimiento de tareas.',
    bullets: [
      'Seguimiento de medidas preventivas.',
      'Planificación con Carta Gantt.',
      'Responsables y fechas de actividades.'
    ]
  }

];


/* ============================================================
   COMPONENTE
   ============================================================ */

@Component({
  selector:
    'app-dashboard',

  imports: [
    AppSidebarComponent
  ],

  templateUrl:
    './dashboard.html',

  styleUrl:
    './dashboard.scss'
})
export class DashboardComponent implements OnDestroy {

  /* =========================================================
     SERVICIOS
     ========================================================= */

  private readonly http =
    inject(HttpClient);


  private readonly router =
    inject(Router);

  private readonly appSettings = inject(AppSettingsService);
  private readonly sessionExperience = inject(SessionExperienceService);
  protected readonly theme = inject(ThemeService);


  private searchTimer:
    ReturnType<typeof setTimeout> | null =
    null;

  private operationalReady = false;
  private readonly initialLoadsPending = new Set([
    'areas',
    'operations',
    'expenses',
    'assets',
    'workers'
  ]);

  private finishInitialLoad(load: string): void {
    this.initialLoadsPending.delete(load);
    if (this.initialLoadsPending.size === 0) {
      this.sessionExperience.finishWelcomeWhenReady();
    }
  }


  /* =========================================================
     ÁREAS
     ========================================================= */

  protected readonly areas =
    signal<AreaBackend[]>([]);


  /* =========================================================
     ESTADÍSTICAS
     ========================================================= */

  protected readonly stats =
    signal<Record<string, AreaStats>>({});

  protected readonly operationalOverview =
    signal<DashboardOperationsResponse | null>(null);

  protected readonly selectedAreaSlug = signal<string | null>(null);

  protected readonly selectedOperationalState = signal<OperationalState | 'UPCOMING' | 'ATTENTION'>('ATTENTION');


  /* =========================================================
     CARGA
     ========================================================= */

  protected readonly loading =
    signal(true);


  protected readonly errorMessage =
    signal('');


  /* =========================================================
     COSTOS CONSOLIDADOS · DATOS REALES DE POSTGRESQL
     ========================================================= */
  protected readonly expensesReport = signal<ExpenseReport | null>(null);
  protected readonly expensesLoading = signal(true);
  protected readonly expensesError = signal(false);
  protected readonly formatCLP = formatCLP;

  protected readonly maxExpenseArea = computed(() => Math.max(
    1,
    ...(this.expensesReport()?.byArea.map(area => area.total) ?? [0])
  ));

  protected openExpenses(): void {
    this.router.navigate(['/gastos']);
  }

  protected openAreaExpenses(slug: string): void {
    this.router.navigate(['/gastos'], {queryParams:{area:slug}});
  }

  private loadExpenses(): void {
    this.http.get<ExpenseReport>('/api/expenses/summary', {
      withCredentials: true
    }).subscribe({
      next: data => {
        this.expensesReport.set(data);
        this.expensesError.set(false);
        this.expensesLoading.set(false);
        this.finishInitialLoad('expenses');
      },
      error: () => {
        this.expensesError.set(true);
        this.expensesLoading.set(false);
        this.finishInitialLoad('expenses');
      }
    });
  }


  protected readonly assetsCount = signal(0);
  protected readonly workersCount = signal(0);
  protected readonly documentsTotal = computed(() => this.areas().reduce((sum, area) => sum + (area.documentCount ?? 0), 0));

  protected openResources(route: 'activos' | 'trabajadores' | 'documentos'): void {
    this.router.navigate(['/', route]);
  }

  private loadResourceCounts(): void {
    this.http.get<unknown[]>('/api/assets', {withCredentials:true}).subscribe({
      next: rows => { this.assetsCount.set(rows.length); this.finishInitialLoad('assets'); },
      error: () => { this.assetsCount.set(0); this.finishInitialLoad('assets'); }
    });
    this.http.get<unknown[]>('/api/workers', {withCredentials:true}).subscribe({
      next: rows => { this.workersCount.set(rows.length); this.finishInitialLoad('workers'); },
      error: () => { this.workersCount.set(0); this.finishInitialLoad('workers'); }
    });
  }

  /* =========================================================
     BÚSQUEDA
     ========================================================= */

  protected readonly searchQuery =
    signal('');


  protected readonly searchResults =
    signal<SearchResult[]>([]);


  protected readonly searching =
    signal(false);


  protected readonly searchError =
    signal('');


  protected readonly searchActive =
    computed(() => {

      return (
        this.searchQuery()
          .trim()
          .length >= 2
      );
    });


  /* =========================================================
     TARJETAS DE ÁREAS
     ========================================================= */

  protected readonly areaCards =
    computed(() => {

      const backendAreas =
        this.areas();


      const allowed = new Set(this.operationalOverview()?.areas.map(area => area.slug) ?? []);

      return AREA_CONFIGS.filter(config => allowed.has(config.slug)).map(
        config => {

          const backendArea =
            backendAreas.find(
              area =>
                area.slug
                  === config.slug
            );


          return {
            ...config,

            documentCount:
              backendArea?.documentCount
              ?? 0,

            stats:
              this.getStats(
                config.slug
              )
          };

        }
      );
    });


  /* =========================================================
     RESUMEN GENERAL
     ========================================================= */

  protected readonly summary =
    computed(() => {

      const allStats =
        Object.values(
          this.stats()
        );


      return {

        open:
          allStats.reduce((total, item) => total + item.open, 0),


        active:
          allStats.reduce(
            (
              total,
              item
            ) =>
              total
              + item.active,

            0
          ),


        overdue:
          allStats.reduce(
            (
              total,
              item
            ) =>
              total
              + item.overdue,

            0
          ),


        completed:
          allStats.reduce(
            (
              total,
              item
            ) =>
              total
              + item.completed,

            0
          )

      };

    });


  // Panorama, agenda y carga operativa reales, obtenidos desde PostgreSQL.
  protected readonly allWork = signal<WorkItem[]>([]);
  protected readonly operationalAreas = computed(() =>
    [...(this.operationalOverview()?.areas ?? [])].sort((left, right) =>
      right.overdue - left.overdue || right.open - left.open || left.name.localeCompare(right.name, 'es-CL')
    )
  );
  protected readonly maxOperationalOpen = computed(() =>
    Math.max(1, ...this.operationalAreas().map(area => area.open))
  );
  protected readonly attentionArea = computed(() =>
    this.operationalAreas().find(area => area.overdue > 0) ??
    this.operationalAreas().find(area => area.open > 0) ??
    null
  );
  protected readonly selectedArea = computed(() =>
    this.operationalOverview()?.areas.find(area => area.slug === this.selectedAreaSlug()) ?? null
  );
  protected readonly selectedAreaConfig = computed(() =>
    AREA_CONFIGS.find(area => area.slug === this.selectedAreaSlug()) ?? null
  );
  protected readonly selectedAreaItems = computed(() => {
    const slug = this.selectedAreaSlug();
    const state = this.selectedOperationalState();
    const items = this.allWork().filter(item => item.areaSlug === slug);
    const filtered = state === 'ATTENTION'
      ? items.filter(item => item.operationalState === 'OVERDUE' || item.upcoming || item.operationalState === 'IN_PROGRESS')
      : state === 'UPCOMING'
        ? items.filter(item => item.upcoming)
        : items.filter(item => item.operationalState === state);
    const rank = (item: WorkItem): number => item.operationalState === 'OVERDUE' ? 0 : item.upcoming ? 1 : 2;
    return [...filtered].sort((left, right) =>
      rank(left) - rank(right) ||
      (left.scheduledEnd ?? left.scheduledStart ?? '9999').localeCompare(right.scheduledEnd ?? right.scheduledStart ?? '9999')
    ).slice(0, 8);
  });
  protected readonly maxSelectedDimension = computed(() =>
    Math.max(1, ...(this.selectedArea()?.dimensions.map(dimension => dimension.count) ?? [0]))
  );
  protected readonly operationalCount = computed(() => this.allWork().length);
  protected readonly todayIso = (()=>{ const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; })();
  protected readonly todayProgrammed = computed(() => this.allWork().filter(r => r.scheduledStart?.slice(0,10) === this.todayIso).length);
  protected readonly inProgress = computed(() => this.allWork().filter(r => r.status === 'IN_PROGRESS').length);
  protected readonly toReview = computed(() => this.operationalAreas().reduce(
    (total, area) => total + area.pending + area.overdue + area.otherOpen,
    0
  ));
  protected readonly recentlyCompleted = computed(() => this.allWork().filter(r => r.status === 'COMPLETED' && r.completedDate?.slice(0,10) === this.todayIso).length);
  protected readonly comingUp = computed(() => this.allWork()
    .filter(r => r.scheduledStart && r.scheduledStart.slice(0,10) >= this.todayIso && !['COMPLETED', 'CANCELLED'].includes(r.status))
    .sort((a,b) => (a.scheduledStart ?? '').localeCompare(b.scheduledStart ?? ''))
    .slice(0,5));
  protected readonly recentWork = computed(() => [...this.allWork()].sort((a,b) => (b.scheduledStart ?? '').localeCompare(a.scheduledStart ?? '')).slice(0,4));
  protected readonly maxAreaRecords = computed(() => Math.max(1,...this.areaCards().map(a => a.stats.total)));
  protected readonly workTotal = computed(() => Math.max(1, this.operationalCount()));
  protected readonly closedPercent = computed(() => {
    const completed = this.summary().completed;
    const relevant = completed + this.summary().open;
    return relevant ? Math.round(completed / relevant * 100) : 0;
  });
  protected readableDate(value?: string|null): string {
    if (!value) return 'Sin fecha';
    return new Date(value.slice(0,10)+'T12:00:00').toLocaleDateString('es-CL', {day:'2-digit',month:'short'});
  }
  protected areaName(slug: string): string {
    return AREA_CONFIGS.find(a => a.slug === slug)?.name ?? slug;
  }
  protected openAreaDetail(slug: string, state: OperationalState | 'UPCOMING' | 'ATTENTION' = 'ATTENTION'): void {
    if (!this.operationalOverview()?.areas.some(area => area.slug === slug)) return;
    this.selectedOperationalState.set(state);
    this.selectedAreaSlug.set(slug);
  }
  protected closeAreaDetail(): void {
    this.selectedAreaSlug.set(null);
    this.selectedOperationalState.set('ATTENTION');
  }
  protected selectOperationalState(state: OperationalState | 'UPCOMING' | 'ATTENTION'): void {
    this.selectedOperationalState.set(state);
  }
  protected stateLabel(state: OperationalState | 'UPCOMING' | 'ATTENTION'): string {
    return ({
      ATTENTION: 'Requieren atención',
      OVERDUE: 'Atrasadas',
      IN_PROGRESS: 'En curso',
      PENDING: 'Pendientes / planificadas',
      UPCOMING: 'Próximas 2 semanas',
      COMPLETED: 'Completadas',
      CANCELLED: 'Canceladas',
      OTHER_OPEN: 'Otros estados activos'
    } as Record<string, string>)[state];
  }
  protected dueDateLabel(item: WorkItem): string {
    return this.readableDate(item.scheduledEnd ?? item.scheduledStart);
  }
  protected detailContext(area: DashboardAreaOverview): string {
    if (area.slug === 'mantencion-reactiva') return 'Incidencias abiertas, prioridad y fechas registradas.';
    if (area.slug === 'mejoras') return 'Propuestas y proyectos según categoría, avance y costos persistidos.';
    if (area.slug === 'remodelacion') return 'Proyectos, zonas, avance y costos registrados.';
    if (area.slug === 'mantencion-maquinas') return 'Equipos y mantenimientos registrados en el módulo.';
    if (area.slug === 'mantencion-jardineria') return 'Labores y temporadas registradas para áreas verdes.';
    if (area.slug === 'prevencion-riesgos') return 'Actividades del calendario preventivo y sus vencimientos.';
    return 'Mantenciones abiertas, ubicaciones, responsables y fechas registradas.';
  }
  protected editWork(item: WorkItem): void {
    this.router.navigate(['/areas',item.areaSlug], {queryParams:{editar:item.id}});
  }
  protected openCalendar(): void { this.router.navigate(['/calendario']); }


  private dueDateForAlert(item: WorkItem): Date | null {
    if (['COMPLETED','CANCELLED'].includes(item.status)) return null;
    let raw: string | null | undefined = null;
    if (item.workType === 'IMPROVEMENT') raw = item.scheduledEnd;
    else if (item.workType === 'REACTIVE_MAINTENANCE') raw = item.scheduledEnd;
    else raw = item.scheduledEnd || item.scheduledStart;
    if (raw) {
      const date = new Date(`${raw.slice(0,10)}T12:00:00`);
      return Number.isNaN(date.getTime()) ? null : date;
    }
    if (item.workType === 'IMPROVEMENT' && item.plannedYear && item.plannedMonth) {
      return new Date(item.plannedYear, item.plannedMonth - 1, 15, 12, 0, 0);
    }
    return null;
  }

  private maybeShowLoginDeadlineAlert(): void {
    if (!this.operationalReady) return;
    if (!this.sessionExperience.consumeDeadlineAlertRequest()) return;
    if (!this.appSettings.monthlyAlerts()) return;
    this.showLoginDeadlineAlertFor(this.allWork());
  }

  private showLoginDeadlineAlertFor(items: WorkItem[]): void {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0).getTime();
    let overdue = 0;
    let thisMonth = 0;
    for (const item of items) {
      if (['COMPLETED','CANCELLED'].includes(item.status)) continue;
      if (item.workType === 'IMPROVEMENT' && !item.scheduledEnd && item.plannedYear && item.plannedMonth) {
        const targetKey = item.plannedYear * 100 + item.plannedMonth;
        const currentKey = now.getFullYear() * 100 + (now.getMonth() + 1);
        if (targetKey < currentKey) overdue += 1;
        else if (targetKey === currentKey) thisMonth += 1;
        continue;
      }
      const due = this.dueDateForAlert(item);
      if (!due) continue;
      const dueMidnight = new Date(due.getFullYear(), due.getMonth(), due.getDate()).getTime();
      if (dueMidnight < today) {
        overdue += 1;
      } else if (due.getFullYear() === now.getFullYear() && due.getMonth() === now.getMonth()) {
        thisMonth += 1;
      }
    }
    if (!overdue && !thisMonth) return;
    const parts: string[] = [];
    if (thisMonth) parts.push(`${thisMonth} actividad${thisMonth === 1 ? '' : 'es'} con fecha este mes`);
    if (overdue) parts.push(`${overdue} atrasada${overdue === 1 ? '' : 's'}`);
    this.sessionExperience.queueDeadlineAlert({thisMonth,overdue,message:`Tienes ${parts.join(' y ')}.`});
  }

  /* =========================================================
     CONSTRUCTOR
     ========================================================= */

  constructor() {
    this.loadAreas();

    this.loadOperationalStats();

    this.loadExpenses();
    this.loadResourceCounts();
  }


  /* =========================================================
     DESTROY
     ========================================================= */

  ngOnDestroy(): void {

    this.clearSearchTimer();
  }


  /* =========================================================
     CARGAR ÁREAS
     ========================================================= */

  private loadAreas(): void {

    this.loading.set(
      true
    );


    this.errorMessage.set(
      ''
    );


    this.http
      .get<AreaBackend[]>(
        '/api/areas',

        {
          withCredentials:
            true
        }
      )
      .subscribe({

        next: areas => {

          this.areas.set(
            areas
          );


          this.loading.set(
            false
          );
          this.finishInitialLoad('areas');

        },


        error: () => {

          this.errorMessage.set(
            'No fue posible cargar la información de las áreas.'
          );


          this.loading.set(
            false
          );
          this.finishInitialLoad('areas');

        }

      });
  }


  /* =========================================================
     CARGAR ESTADÍSTICAS DE LAS 6 ÁREAS
     ========================================================= */

  private loadOperationalStats(): void {

    this.http.get<DashboardOperationsResponse>('/api/dashboard/operations', {
      withCredentials: true
    }).subscribe({
      next: response => {
        this.operationalOverview.set(response);
        this.allWork.set(response.items);
        this.stats.set(Object.fromEntries(response.areas.map(area => [area.slug, {
          active: area.inProgress,
          pending: area.pending,
          completed: area.completed,
          overdue: area.overdue,
          total: area.total,
          open: area.open,
          upcoming: area.upcoming,
          otherOpen: area.otherOpen,
          cancelled: area.cancelled
        }])));
        this.operationalReady = true;
        this.finishInitialLoad('operations');
        this.maybeShowLoginDeadlineAlert();
      },
      error: () => {
        this.operationalOverview.set({asOf: this.todayIso, upcomingDays: 14, areas: [], items: []});
        this.allWork.set([]);
        this.stats.set({});
        this.operationalReady = true;
        this.errorMessage.set('No fue posible cargar la planificación operativa.');
        this.finishInitialLoad('operations');
      }
    });

  }



  /* =========================================================
     STATS VACÍAS
     ========================================================= */

  private emptyStats():
    AreaStats {

    return {
      active: 0,
      pending: 0,
      completed: 0,
      overdue: 0,
      total: 0,
      open: 0,
      upcoming: 0,
      otherOpen: 0,
      cancelled: 0
    };
  }


  /* =========================================================
     OBTENER STATS POR ÁREA
     ========================================================= */

  protected getStats(
    slug: string
  ): AreaStats {

    return (
      this.stats()[slug]
      ?? this.emptyStats()
    );
  }


  /* =========================================================
     BUSCADOR
     ========================================================= */

  protected onSearchInput(
    event: Event
  ): void {

    const input =
      event.target as HTMLInputElement;


    const value =
      input.value;


    this.searchQuery.set(
      value
    );


    this.searchError.set(
      ''
    );


    this.clearSearchTimer();


    if (
      value.trim().length < 2
    ) {

      this.searchResults.set(
        []
      );


      this.searching.set(
        false
      );


      return;
    }


    this.searching.set(
      true
    );


    this.searchTimer =
      setTimeout(
        () => {

          this.performSearch(
            value
          );

        },

        600
      );
  }


  /* =========================================================
     REALIZAR BÚSQUEDA
     ========================================================= */

  private performSearch(
    query: string
  ): void {

    const currentQuery =
      query.trim();


    this.http
      .get<SearchResult[]>(
        '/api/search',

        {
          params: {

            q:
              currentQuery

          },

          withCredentials:
            true
        }
      )
      .subscribe({

        next: results => {

          if (
            this.searchQuery()
              .trim()
              !== currentQuery
          ) {

            return;
          }


          this.searchResults.set(
            results
          );


          this.searching.set(
            false
          );

        },


        error: () => {

          this.searchResults.set(
            []
          );


          this.searchError.set(
            'No se pudo realizar la búsqueda.'
          );


          this.searching.set(
            false
          );

        }

      });
  }


  /* =========================================================
     LIMPIAR BÚSQUEDA
     ========================================================= */

  protected clearSearch(): void {

    this.clearSearchTimer();


    this.searchQuery.set(
      ''
    );


    this.searchResults.set(
      []
    );


    this.searchError.set(
      ''
    );


    this.searching.set(
      false
    );
  }


  /* =========================================================
     ABRIR RESULTADO
     ========================================================= */

  protected openSearchResult(
    result: SearchResult
  ): void {

    this.router.navigate(

      [
        '/areas',
        result.areaSlug,
        'documentos'
      ],

      {
        queryParams: {

          document:
            result.documentId

        }
      }

    );
  }


  /* =========================================================
     TEXTO DE COINCIDENCIAS
     ========================================================= */

  protected resultCountLabel(
    count: number
  ): string {

    return count === 1

      ? '1 coincidencia'

      : `${count} coincidencias`;
  }


  /* =========================================================
     LIMPIAR TIMER
     ========================================================= */

  private clearSearchTimer(): void {

    if (
      this.searchTimer === null
    ) {

      return;
    }


    clearTimeout(
      this.searchTimer
    );


    this.searchTimer =
      null;
  }


  /* =========================================================
     ABRIR ÁREA
     ========================================================= */

  protected openArea(
    slug: string
  ): void {

    this.router.navigate([
      '/areas',
      slug
    ]);
  }


  /* =========================================================
     HISTORIAL
     ========================================================= */

  protected openHistory(): void {

    this.router.navigate([
      '/historial'
    ]);
  }


  /* =========================================================
     NUEVA MANTENCIÓN DESDE DASHBOARD
     ========================================================= */

  protected openGeneralMaintenance(): void {

    this.router.navigate([
      '/areas',
      'mantencion-general'
    ]);
  }



}
