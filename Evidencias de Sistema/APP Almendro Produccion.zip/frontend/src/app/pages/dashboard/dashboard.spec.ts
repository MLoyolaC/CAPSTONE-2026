import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';

import { DashboardComponent } from './dashboard';
import { ThemeService } from '../../core/auth/theme/theme.service';

describe('DashboardComponent operational planning', () => {
  let http: HttpTestingController;

  const area = (overrides: Record<string, unknown> = {}) => ({
    slug: 'prevencion-riesgos',
    name: 'Prevención de Riesgos',
    open: 4,
    pending: 2,
    inProgress: 1,
    overdue: 1,
    upcoming: 2,
    completed: 3,
    cancelled: 0,
    otherOpen: 0,
    total: 7,
    averageProgress: 25,
    estimatedCost: 0,
    actualCost: 0,
    dimensionLabel: 'Calendario preventivo',
    dimensions: [{ label: 'Noviembre 2026', count: 4 }],
    ...overrides,
  });

  const item = (overrides: Record<string, unknown> = {}) => ({
    id: crypto.randomUUID(),
    areaSlug: 'prevencion-riesgos',
    areaName: 'Prevención de Riesgos',
    workType: 'PREVENTION',
    title: 'Revisión preventiva real',
    location: null,
    responsibleName: 'Encargado',
    priority: 'NORMAL',
    status: 'PENDING',
    operationalState: 'PENDING',
    scheduledStart: '2026-11-11',
    scheduledEnd: '2026-11-12',
    completedDate: null,
    progressPercent: 0,
    plannedYear: 2026,
    plannedMonth: 11,
    category: null,
    assetName: null,
    frequency: null,
    season: null,
    estimatedCost: null,
    actualCost: null,
    updatedAt: '2026-11-09T10:00:00-03:00',
    upcoming: true,
    ...overrides,
  });

  beforeEach(async () => {
    Object.defineProperty(window, 'matchMedia', {
      writable: true,
      value: (query: string): MediaQueryList => ({
        matches: false,
        media: query,
        onchange: null,
        addListener: () => undefined,
        removeListener: () => undefined,
        addEventListener: () => undefined,
        removeEventListener: () => undefined,
        dispatchEvent: () => false,
      }),
    });
    await TestBed.configureTestingModule({
      imports: [DashboardComponent],
      providers: [provideHttpClient(), provideHttpClientTesting(), provideRouter([])],
    }).compileComponents();
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  function flushInitial(areas: unknown[], items: unknown[] = []): void {
    http.expectOne('/api/areas').flush([]);
    http.expectOne('/api/dashboard/operations').flush({
      asOf: '2026-11-09',
      upcomingDays: 14,
      areas,
      items,
    });
    http.expectOne('/api/expenses/summary').flush({
      totalActual: 0,
      estimatedImprovements: 0,
      expenseCount: 0,
      byArea: [],
      expenses: [],
    });
    http.expectOne('/api/assets').flush([]);
    http.expectOne('/api/workers').flush([]);
  }

  it('renders real state counts and does not show an unauthorized area', () => {
    const fixture = TestBed.createComponent(DashboardComponent);
    fixture.detectChanges();
    flushInitial([area()], [item()]);
    fixture.detectChanges();

    const element = fixture.nativeElement as HTMLElement;
    expect(element.querySelectorAll('.workload-row')).toHaveLength(1);
    expect(element.querySelector('.workload-row')?.textContent).toContain('Prevención de Riesgos');
    expect(element.querySelector('.segment.overdue')?.textContent).toContain('1');
    expect(element.textContent).not.toContain('Mantención de Máquinas');
  });

  it('opens area analysis, filters upcoming records and navigates only from Ver área', () => {
    const router = TestBed.inject(Router);
    const navigate = vi.spyOn(router, 'navigate').mockResolvedValue(true);
    const fixture = TestBed.createComponent(DashboardComponent);
    fixture.detectChanges();
    flushInitial([area()], [item()]);
    fixture.detectChanges();

    (fixture.nativeElement as HTMLElement).querySelector<HTMLButtonElement>('.workload-area')?.click();
    fixture.detectChanges();
    expect(navigate).not.toHaveBeenCalled();
    expect((fixture.nativeElement as HTMLElement).querySelector('.area-analysis h2')?.textContent).toContain('Prevención');

    (fixture.componentInstance as any).selectOperationalState('UPCOMING');
    fixture.detectChanges();
    expect((fixture.nativeElement as HTMLElement).querySelectorAll('.attention-list > button')).toHaveLength(1);

    (fixture.nativeElement as HTMLElement).querySelector<HTMLButtonElement>('.analysis-footer button')?.click();
    expect(navigate).toHaveBeenCalledWith(['/areas', 'prevencion-riesgos']);
  });

  it('handles zero records without NaN or a broken bar', () => {
    const fixture = TestBed.createComponent(DashboardComponent);
    fixture.detectChanges();
    flushInitial([area({ open: 0, pending: 0, inProgress: 0, overdue: 0, upcoming: 0, completed: 0, total: 0, averageProgress: null, dimensions: [] })]);
    fixture.detectChanges();

    const element = fixture.nativeElement as HTMLElement;
    expect(element.querySelector('.workload-empty')?.textContent).toContain('Sin trabajo abierto');
    expect(element.textContent).not.toContain('NaN');
    expect(element.textContent).not.toContain('undefined');
  });

  it('keeps completed and legacy states available as context in the detail', () => {
    const fixture = TestBed.createComponent(DashboardComponent);
    fixture.detectChanges();
    flushInitial([
      area({ open: 1, pending: 0, inProgress: 0, overdue: 0, upcoming: 0, completed: 1, otherOpen: 1, total: 2 }),
    ], [
      item({ id: 'legacy', title: 'Registro legacy', status: 'LEGACY_ACTIVE', operationalState: 'OTHER_OPEN', upcoming: false, scheduledStart: null, scheduledEnd: null }),
      item({ id: 'done', title: 'Registro completado', status: 'COMPLETED', operationalState: 'COMPLETED', upcoming: false, completedDate: '2026-11-08' }),
    ]);
    fixture.detectChanges();

    (fixture.componentInstance as any).openAreaDetail('prevencion-riesgos', 'OTHER_OPEN');
    fixture.detectChanges();
    expect((fixture.nativeElement as HTMLElement).querySelector('.attention-list')?.textContent).toContain('Registro legacy');
    (fixture.componentInstance as any).selectOperationalState('COMPLETED');
    fixture.detectChanges();
    expect((fixture.nativeElement as HTMLElement).querySelector('.attention-list')?.textContent).toContain('Registro completado');
  });

  it('renders seven identifiable areas with representative operational states', () => {
    const fixture = TestBed.createComponent(DashboardComponent);
    fixture.detectChanges();
    const definitions = [
      ['mantencion-general', 'Mantención General'],
      ['mantencion-reactiva', 'Mantención Reactiva'],
      ['mejoras', 'Mejoras'],
      ['remodelacion', 'Remodelación'],
      ['mantencion-maquinas', 'Mantención de Máquinas'],
      ['mantencion-jardineria', 'Mantención de Jardinería'],
      ['prevencion-riesgos', 'Prevención de Riesgos'],
    ];
    flushInitial(definitions.map(([slug, name], index) => area({
      slug, name, open: index === 0 ? 0 : index + 2,
      pending: index === 0 ? 0 : index,
      inProgress: index === 0 ? 0 : 1,
      overdue: index === 0 ? 0 : 1,
      otherOpen: index === 0 ? 0 : 0,
      total: index === 0 ? 0 : index + 2,
    })));
    fixture.detectChanges();

    const element = fixture.nativeElement as HTMLElement;
    const areaIds = [...element.querySelectorAll<HTMLElement>('.workload-area .area-symbol')]
      .map(symbol => symbol.dataset['area']);
    expect(areaIds).toHaveLength(7);
    expect(new Set(areaIds).size).toBe(7);
    expect(element.querySelector('.workload-empty')?.textContent).toContain('Sin trabajo abierto');
    expect(element.querySelectorAll('.segment.overdue').length).toBeGreaterThan(0);
    expect(element.querySelectorAll('.segment.progress').length).toBeGreaterThan(0);
    expect(element.querySelectorAll('.segment.pending').length).toBeGreaterThan(0);
  });

  it('switches the operational palette immediately with the application theme', () => {
    const theme = TestBed.inject(ThemeService);
    theme.setTheme(false);
    const fixture = TestBed.createComponent(DashboardComponent);
    fixture.detectChanges();
    flushInitial([area()]);
    fixture.detectChanges();

    const planning = () => (fixture.nativeElement as HTMLElement).querySelector<HTMLElement>('.operational-planning');
    expect(planning()?.dataset['theme']).toBe('light');
    theme.setTheme(true);
    fixture.detectChanges();
    expect(planning()?.dataset['theme']).toBe('dark');
    expect(document.documentElement.classList.contains('dark-theme')).toBe(true);
    theme.setTheme(false);
  });
});
