import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, inject, signal } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { AppSidebarComponent } from '../../shared/app-sidebar/app-sidebar';

interface DuplicateRef { id:string; title:string; areaSlug:string; areaName:string; location:string|null; }
interface ProjectPreview { key:string; title:string; location:string|null; category:string|null; estimatedCost:number|null; actualCost:number|null; budgetLines:number; ganttTasks:number; sourceFiles:string[]; duplicates:DuplicateRef[]; }
interface AnalysisResult { filename:string; projectCount:number; ganttTaskCount:number; budgetLineCount:number; supportRecordCount:number; supportSheetCount:number; supportFiles:string[]; crossAreaFiles:string[]; projects:ProjectPreview[]; warnings:string[]; }
interface ImportResult { projectsCreated:number; ganttTasksCreated:number; supportItemsCreated:number; supportItemsUpdated:number; skipped:number; supportFiles:string[]; crossAreaFiles:string[]; }

@Component({
  selector:'app-remodelacion-import', standalone:true,
  imports:[RouterLink,AppSidebarComponent],
  templateUrl:'./remodelacion-import.html', styleUrl:'./remodelacion-import.scss'
})
export class RemodelacionImportComponent {
  private readonly http=inject(HttpClient); private readonly router=inject(Router); private readonly route=inject(ActivatedRoute);
  protected readonly file=signal<File|null>(null); protected readonly analysis=signal<AnalysisResult|null>(null);
  protected readonly analyzing=signal(false); protected readonly importing=signal(false); protected readonly errorMessage=signal('');
  protected readonly duplicateDialog=signal<DuplicateRef[]|null>(null);
  protected readonly returnView=this.route.snapshot.queryParamMap.get('vista')||'projects';
  protected onFile(event:Event):void{const input=event.target as HTMLInputElement;this.file.set(input.files?.[0]||null);this.analysis.set(null);this.errorMessage.set('');}
  protected analyze():void{const file=this.file();if(!file)return;this.analyzing.set(true);this.errorMessage.set('');const data=new FormData();data.append('file',file);this.http.post<AnalysisResult>('/api/remodeling-import/analyze',data,{withCredentials:true}).subscribe({next:r=>{this.analysis.set(r);this.analyzing.set(false);},error:e=>this.fail(e,'No se pudo analizar el archivo.')});}
  protected importAll(force=false):void{const file=this.file(),analysis=this.analysis();if(!file||!analysis)return;if(!force){const duplicates=analysis.projects.flatMap(p=>p.duplicates||[]);if(duplicates.length){const unique=[...new Map(duplicates.map(d=>[d.id,d])).values()];this.duplicateDialog.set(unique);return;}}this.importing.set(true);this.errorMessage.set('');const data=new FormData();data.append('file',file);this.http.post<ImportResult>(`/api/remodeling-import/commit?forceDuplicates=${force}`,data,{withCredentials:true}).subscribe({next:r=>{this.importing.set(false);this.duplicateDialog.set(null);const supportCount=(r.supportItemsCreated||0)+(r.supportItemsUpdated||0);this.router.navigate(['/areas/remodelacion'],{queryParams:{importados:r.projectsCreated,tareas:r.ganttTasksCreated,apoyos:supportCount,vista:supportCount>0?'projects':this.returnView}});},error:e=>{this.duplicateDialog.set(null);this.fail(e,'No se pudo incorporar la remodelación.');}});}
  protected confirmDuplicates():void{this.importAll(true);} protected cancelDuplicates():void{this.duplicateDialog.set(null);}
  protected viewDuplicate(d:DuplicateRef):void{this.duplicateDialog.set(null);this.router.navigate(['/areas',d.areaSlug],{queryParams:{editar:d.id}});}
  protected money(v:number|null):string{return new Intl.NumberFormat('es-CL',{style:'currency',currency:'CLP',maximumFractionDigits:0}).format(Number(v||0));}
  protected shortSource(path:string):string{const p=path.replaceAll('\\','/');return p.slice(p.lastIndexOf('/')+1);}
  private fail(error:HttpErrorResponse,fallback:string):void{this.analyzing.set(false);this.importing.set(false);this.errorMessage.set(error.error?.detail||error.error?.message||fallback);}
}
