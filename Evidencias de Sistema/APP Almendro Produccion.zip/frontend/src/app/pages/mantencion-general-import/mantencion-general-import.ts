import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AppSidebarComponent } from '../../shared/app-sidebar/app-sidebar';

interface ColumnAnalysis {
  index: number;
  key: string;
  label: string;
  semanticType: string;
}

interface SheetAnalysis {
  index: number;
  name: string;
  title: string;
  headerRowNumber: number;
  dataStartRow: number;
  columns: ColumnAnalysis[];
  rowCount: number;
  notes: string[];
  previewRows: Record<string, string>[];
  warnings: string[];
}

interface DuplicateImportInfo {
  batchId: string;
  filename: string;
  importedAt: string;
}

interface WorkbookAnalysis {
  filename: string;
  sheetCount: number;
  rowCount: number;
  noteCount: number;
  sheets: SheetAnalysis[];
  duplicate: DuplicateImportInfo | null;
}

interface ImportSummary {
  id: string;
  documentId: string;
  filename: string;
  sheetCount: number;
  rowCount: number;
  noteCount: number;
  createdAt: string;
}

interface ImportedColumn {
  key: string;
  label: string;
  semanticType: string;
}

interface ImportedRow {
  id: string;
  sourceRowNumber: number;
  values: Record<string, string>;
  warnings: string[];
}

interface ImportedNote {
  id: string;
  sourceRowNumber: number | null;
  text: string;
}

interface ImportedSheet {
  id: string;
  index: number;
  name: string;
  title: string;
  headerRowNumber: number;
  dataStartRow: number;
  rowCount: number;
  noteCount: number;
  columns: ImportedColumn[];
  rows: ImportedRow[];
  notes: ImportedNote[];
}

interface ImportDetail {
  summary: ImportSummary;
  sheets: ImportedSheet[];
}

interface ImportResult {
  batchId: string;
  documentId: string;
  filename: string;
  sheetCount: number;
  rowCount: number;
  noteCount: number;
}

@Component({
  selector: 'app-mantencion-general-import',
  imports: [
    FormsModule,
    RouterLink,
    AppSidebarComponent
  ],
  templateUrl: './mantencion-general-import.html',
  styleUrl: './mantencion-general-import.scss'
})
export class MantencionGeneralImportComponent {

  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);

  protected readonly selectedFile = signal<File | null>(null);
  protected readonly analysis = signal<WorkbookAnalysis | null>(null);
  protected readonly analyzing = signal(false);
  protected readonly importing = signal(false);
  protected readonly loadingImports = signal(false);
  protected readonly imports = signal<ImportSummary[]>([]);
  protected readonly selectedImport = signal<ImportDetail | null>(null);
  protected readonly selectedSheetId = signal<string | null>(null);
  protected readonly errorMessage = signal('');
  protected readonly successMessage = signal('');
  protected readonly editRowOpen = signal(false);
  protected readonly editingRowId = signal<string | null>(null);
  protected readonly editingSheetId = signal<string | null>(null);
  protected rowDraft: Record<string, string> = {};

  protected readonly selectedSheet = computed(() => {
    const detail = this.selectedImport();
    const id = this.selectedSheetId();

    if (!detail || !id) {
      return null;
    }

    return detail.sheets.find(sheet => sheet.id === id) ?? null;
  });

  constructor() {
    this.loadImports();
  }

  protected onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0] ?? null;

    this.selectedFile.set(file);
    this.analysis.set(null);
    this.errorMessage.set('');
    this.successMessage.set('');
  }

  protected analyzeFile(): void {
    const file = this.selectedFile();

    if (!file) {
      this.errorMessage.set('Selecciona una planilla Excel antes de analizarla.');
      return;
    }

    const data = new FormData();
    data.append('file', file);

    this.analyzing.set(true);
    this.errorMessage.set('');
    this.successMessage.set('');

    this.http.post<WorkbookAnalysis>(
      '/api/areas/mantencion-general/imports/analyze',
      data,
      { withCredentials: true }
    ).subscribe({
      next: result => {
        this.analysis.set(result);
        this.analyzing.set(false);
      },
      error: (error: HttpErrorResponse) => {
        this.analyzing.set(false);
        this.errorMessage.set(
          error.error?.detail
          || error.error?.message
          || 'No fue posible analizar la planilla seleccionada.'
        );
      }
    });
  }

  protected importFile(forceDuplicate = false): void {
    const file = this.selectedFile();
    const analysis = this.analysis();

    if (!file || !analysis) {
      this.errorMessage.set('Analiza la planilla antes de confirmar su importación.');
      return;
    }

    const data = new FormData();
    data.append('file', file);

    this.importing.set(true);
    this.errorMessage.set('');
    this.successMessage.set('');

    this.http.post<ImportResult>(
      '/api/areas/mantencion-general/imports',
      data,
      {
        params: { force: String(forceDuplicate) },
        withCredentials: true
      }
    ).subscribe({
      next: result => {
        this.importing.set(false);
        this.successMessage.set(
          `${result.filename} se incorporó a Mantención General con ${result.rowCount} registros.`
        );
        this.selectedFile.set(null);
        this.analysis.set(null);
        this.router.navigate(['/areas/mantencion-general'], {
          queryParams: { importados: result.rowCount }
        });
      },
      error: (error: HttpErrorResponse) => {
        this.importing.set(false);
        this.errorMessage.set(
          error.error?.detail
          || error.error?.message
          || 'No fue posible importar la planilla.'
        );
      }
    });
  }

  protected openImport(id: string): void {
    this.errorMessage.set('');

    this.http.get<ImportDetail>(
      `/api/areas/mantencion-general/imports/${id}`,
      { withCredentials: true }
    ).subscribe({
      next: detail => {
        this.selectedImport.set(detail);
        this.selectedSheetId.set(detail.sheets[0]?.id ?? null);
      },
      error: () => {
        this.errorMessage.set('No fue posible abrir los datos importados.');
      }
    });
  }

  protected integrateSelectedImport(): void {
    const detail = this.selectedImport();

    if (!detail) {
      return;
    }

    this.importing.set(true);
    this.errorMessage.set('');

    this.http.post<{ integrated: number }>(
      `/api/areas/mantencion-general/imports/${detail.summary.id}/integrate`,
      {},
      { withCredentials: true }
    ).subscribe({
      next: result => {
        this.importing.set(false);
        this.router.navigate(['/areas/mantencion-general'], {
          queryParams: { importados: result.integrated }
        });
      },
      error: (error: HttpErrorResponse) => {
        this.importing.set(false);
        this.errorMessage.set(
          error.error?.detail
          || error.error?.message
          || 'No fue posible incorporar los registros a Mantención General.'
        );
      }
    });
  }

  protected chooseSheet(id: string): void {
    this.selectedSheetId.set(id);
  }

  protected editRow(row: ImportedRow, sheet: ImportedSheet): void {
    this.editingRowId.set(row.id);
    this.editingSheetId.set(sheet.id);
    this.rowDraft = { ...row.values };
    this.editRowOpen.set(true);
    this.errorMessage.set('');
  }

  protected closeRowEditor(): void {
    this.editRowOpen.set(false);
    this.editingRowId.set(null);
    this.editingSheetId.set(null);
    this.rowDraft = {};
  }

  protected saveImportedRow(): void {
    const rowId = this.editingRowId();
    const sheetId = this.editingSheetId();
    const detail = this.selectedImport();

    if (!rowId || !sheetId || !detail) {
      return;
    }

    this.http.put<ImportedRow>(
      `/api/areas/mantencion-general/imports/rows/${rowId}`,
      this.rowDraft,
      { withCredentials: true }
    ).subscribe({
      next: saved => {
        const sheets = detail.sheets.map(sheet => {
          if (sheet.id !== sheetId) {
            return sheet;
          }

          return {
            ...sheet,
            rows: sheet.rows.map(row => row.id === saved.id ? saved : row)
          };
        });

        this.selectedImport.set({ ...detail, sheets });
        this.successMessage.set('Registro importado actualizado correctamente.');
        this.closeRowEditor();
      },
      error: (error: HttpErrorResponse) => {
        this.errorMessage.set(
          error.error?.detail
          || error.error?.message
          || 'No fue posible actualizar el registro importado.'
        );
      }
    });
  }

  protected displayValue(value: string, semanticType: string): string {
    if (!value) {
      return '—';
    }

    if (semanticType === 'DATE' && /^\d{4}-\d{2}-\d{2}$/.test(value)) {
      const [year, month, day] = value.split('-');
      return `${day}-${month}-${year}`;
    }

    return value;
  }

  protected formatDateTime(value: string): string {
    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
      return value;
    }

    return new Intl.DateTimeFormat('es-CL', {
      dateStyle: 'medium',
      timeStyle: 'short'
    }).format(date);
  }

  protected semanticLabel(type: string): string {
    const labels: Record<string, string> = {
      NUMBER: 'Número',
      NAME: 'Nombre',
      LOCATION: 'Ubicación',
      DATE: 'Fecha',
      RESPONSIBLE: 'Responsable',
      SUPPLIER: 'Proveedor',
      COST: 'Costo',
      STATUS: 'Estado',
      DETAIL: 'Detalle',
      CODE: 'Código',
      OTHER: 'Dato adicional'
    };

    return labels[type] ?? 'Dato adicional';
  }

  private loadImports(openId?: string): void {
    this.loadingImports.set(true);

    this.http.get<ImportSummary[]>(
      '/api/areas/mantencion-general/imports',
      { withCredentials: true }
    ).subscribe({
      next: imports => {
        this.imports.set(imports);
        this.loadingImports.set(false);

        const target = openId ?? this.selectedImport()?.summary.id;

        if (target) {
          this.openImport(target);
        } else if (imports.length && !this.selectedImport()) {
          this.openImport(imports[0].id);
        }
      },
      error: () => {
        this.loadingImports.set(false);
        this.errorMessage.set('No fue posible cargar el historial de importaciones.');
      }
    });
  }
}
