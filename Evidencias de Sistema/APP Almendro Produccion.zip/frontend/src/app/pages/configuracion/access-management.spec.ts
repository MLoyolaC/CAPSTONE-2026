import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { AuthService } from '../../core/auth/auth.service';
import { AccessManagementComponent } from './access-management';

describe('AccessManagementComponent', () => {
  let http: HttpTestingController;

  const primaryAdmin = {
    id: 1,
    fullName: 'Administrador principal',
    username: 'admin',
    email: null,
    role: 'ADMIN',
    status: 'ACTIVE',
    enabled: true,
    permissions: [],
    effectivePermissions: ['manage-access'],
    primaryAdministrator: true,
  };

  const deletableUser = {
    id: 11,
    fullName: 'Usuario modal temporal',
    username: 'omm_test_ui_target',
    email: 'ui-target@example.invalid',
    role: 'USER',
    status: 'PENDING_ACTIVATION',
    enabled: false,
    permissions: [],
    effectivePermissions: [],
    primaryAdministrator: false,
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AccessManagementComponent],
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        {
          provide: AuthService,
          useValue: { hasPermission: (permission: string) => permission === 'manage-access' },
        },
      ],
    }).compileComponents();

    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('opens and cancels the internal delete modal, then refreshes after deletion', () => {
    const fixture = TestBed.createComponent(AccessManagementComponent);
    fixture.detectChanges();

    http.expectOne('/api/admin/users').flush([primaryAdmin, deletableUser]);
    fixture.detectChanges();

    const element = fixture.nativeElement as HTMLElement;
    expect(element.querySelectorAll('.user-row')).toHaveLength(2);
    expect(element.querySelectorAll('.delete-user')).toHaveLength(1);

    element.querySelector<HTMLButtonElement>('.delete-user')?.click();
    fixture.detectChanges();

    const modal = element.querySelector('.delete-modal');
    expect(modal?.textContent).toContain('Eliminar usuario');
    expect(modal?.textContent).toContain('Usuario modal temporal');
    expect(modal?.textContent).toContain('omm_test_ui_target');
    expect(modal?.textContent).toContain('ui-target@example.invalid');
    expect(modal?.textContent).toContain('Esta acción eliminará permanentemente');
    expect(modal?.textContent).not.toContain('&#x4C;a');

    modal?.querySelector<HTMLButtonElement>('footer button:not(.danger-button)')?.click();
    fixture.detectChanges();
    expect(element.querySelector('.delete-modal')).toBeNull();
    expect(element.querySelectorAll('.user-row')).toHaveLength(2);

    element.querySelector<HTMLButtonElement>('.delete-user')?.click();
    fixture.detectChanges();
    element.querySelector<HTMLButtonElement>('.danger-button')?.click();

    http.expectOne('/api/admin/users/11').flush({ fullName: deletableUser.fullName });
    http.expectOne('/api/admin/users').flush([primaryAdmin]);
    fixture.detectChanges();

    expect(element.querySelectorAll('.user-row')).toHaveLength(1);
    expect(element.querySelector('.deleted-summary h2')?.textContent).toContain(
      'Usuario eliminado correctamente',
    );
    expect(element.querySelector('.deleted-summary p')?.textContent).toContain(
      'La cuenta de Usuario modal temporal y sus datos de acceso fueron eliminados.',
    );
  });

  it('edits a primary administrator without an email without allowing demotion', () => {
    const fixture = TestBed.createComponent(AccessManagementComponent);
    fixture.detectChanges();
    http.expectOne('/api/admin/users').flush([primaryAdmin]);
    fixture.detectChanges();

    const element = fixture.nativeElement as HTMLElement;
    element.querySelector<HTMLButtonElement>('button[title="Editar usuario"]')?.click();
    fixture.detectChanges();

    expect((fixture.componentInstance as any).editingPrimaryAdministrator()).toBe(true);
    expect(element.querySelector<HTMLInputElement>('input[type="email"]')?.value).toBe('');
    expect(element.querySelector<HTMLSelectElement>('select')?.disabled).toBe(true);
    expect(element.querySelector<HTMLInputElement>('.enabled input')?.disabled).toBe(true);
  });

  it('groups sensitive permissions, cancels without saving and restores the selection', () => {
    const fixture = TestBed.createComponent(AccessManagementComponent);
    fixture.detectChanges();
    http.expectOne('/api/admin/users').flush([primaryAdmin]);
    const component = fixture.componentInstance as any;
    component.create();
    component.form.fullName = 'Usuario de prueba';
    component.form.username = 'usuario.prueba';
    component.form.email = 'usuario@example.cl';
    component.setAll('management', true);
    component.save();
    fixture.detectChanges();

    expect(component.permissionWarning()).toHaveLength(5);
    expect(fixture.nativeElement.querySelector('.permission-warning')?.textContent).toContain('Administrar accesos');
    expect(fixture.nativeElement.querySelectorAll('.warning-permissions article')).toHaveLength(5);

    component.cancelPermissionWarning();
    expect(component.permissionWarning()).toHaveLength(0);
    expect(component.form.permissions.some((key: string) => ['create-edit','delete','import','history','manage-access'].includes(key))).toBe(false);
    http.expectNone('/api/admin/users');
  });

  it('persists sensitive permissions only after the internal confirmation', () => {
    const fixture = TestBed.createComponent(AccessManagementComponent);
    fixture.detectChanges();
    http.expectOne('/api/admin/users').flush([primaryAdmin]);
    const component = fixture.componentInstance as any;
    component.create();
    component.form.fullName = 'Usuario confirmado';
    component.form.username = 'usuario.confirmado';
    component.form.email = 'confirmado@example.cl';
    component.toggle('history', true);
    component.toggle('manage-access', true);
    component.save();
    http.expectNone('/api/admin/users');
    expect(component.permissionWarning().map((item: any) => item.key)).toEqual(['history', 'manage-access']);

    component.confirmPermissionWarning();
    const save = http.expectOne('/api/admin/users');
    expect(save.request.method).toBe('POST');
    expect(save.request.body.permissions).toEqual(expect.arrayContaining(['history', 'manage-access', 'configuracion']));
    save.flush({ user: { ...deletableUser, fullName: 'Usuario confirmado', permissions: save.request.body.permissions }, invitationSent: true, message: 'Invitación enviada.' });
    http.expectOne('/api/admin/users').flush([primaryAdmin]);
  });
});
