import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../core/auth/auth.service';
import { Observable } from 'rxjs';

type AccessRole = 'ADMIN' | 'USER';
type AccountStatus = 'PENDING_ACTIVATION' | 'ACTIVE' | 'DISABLED';
interface ManagedUser {
  id: number;
  fullName: string;
  username: string;
  email: string | null;
  role: AccessRole;
  status: AccountStatus;
  enabled: boolean;
  permissions: string[];
  effectivePermissions: string[];
  primaryAdministrator: boolean;
}
interface SaveResult {
  user: ManagedUser;
  invitationSent: boolean;
  message: string;
}
interface DeleteResult {
  fullName: string;
}
interface PermissionOption {
  key: string;
  title: string;
  description: string;
  icon: string;
  group: 'areas' | 'management';
}

@Component({
  selector: 'app-access-management',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './access-management.html',
  styleUrl: './access-management.scss',
})
export class AccessManagementComponent {
  private readonly http = inject(HttpClient);
  protected readonly auth = inject(AuthService);
  protected readonly users = signal<ManagedUser[]>([]);
  protected readonly loading = signal(false);
  protected readonly modalOpen = signal(false);
  protected readonly saving = signal(false);
  protected readonly error = signal('');
  protected readonly saved = signal<SaveResult | null>(null);
  protected readonly editingId = signal<number | null>(null);
  protected readonly editingPrimaryAdministrator = signal(false);
  protected readonly deleteTarget = signal<ManagedUser | null>(null);
  protected readonly deleting = signal(false);
  protected readonly deleteError = signal('');
  protected readonly deletedName = signal<string | null>(null);
  protected readonly permissionWarning = signal<PermissionOption[]>([]);
  private initialPermissions: string[] = [];
  private initialRole: AccessRole = 'USER';
  private sensitivePermissionsConfirmed = false;
  protected form = this.emptyForm();
  protected readonly permissions: PermissionOption[] = [
    {
      key: 'dashboard',
      title: 'Dashboard',
      description: 'Indicadores, alertas y resumen general.',
      icon: 'fa-solid fa-table-cells-large',
      group: 'areas',
    },
    {
      key: 'mantencion-general',
      title: 'Mantención General',
      description: 'Mantenciones preventivas y programadas.',
      icon: 'fa-solid fa-wrench',
      group: 'areas',
    },
    {
      key: 'mantencion-reactiva',
      title: 'Mantención Reactiva',
      description: 'Incidencias y trabajos reactivos.',
      icon: 'fa-solid fa-bolt',
      group: 'areas',
    },
    {
      key: 'mejoras',
      title: 'Mejoras',
      description: 'Metas, plan anual y mejoras.',
      icon: 'fa-solid fa-chart-line',
      group: 'areas',
    },
    {
      key: 'remodelacion',
      title: 'Remodelación',
      description: 'Proyectos, Gantt, costos y presupuesto.',
      icon: 'fa-solid fa-house-chimney',
      group: 'areas',
    },
    {
      key: 'maquinas',
      title: 'Máquinas',
      description: 'Mantenciones y activos de máquinas.',
      icon: 'fa-solid fa-gears',
      group: 'areas',
    },
    {
      key: 'jardineria',
      title: 'Jardinería',
      description: 'Labores y planificación de jardines.',
      icon: 'fa-solid fa-leaf',
      group: 'areas',
    },
    {
      key: 'prevencion',
      title: 'Prevención',
      description: 'Prevención de riesgos.',
      icon: 'fa-solid fa-shield-halved',
      group: 'areas',
    },
    {
      key: 'calendario',
      title: 'Calendario',
      description: 'Fechas e hitos de las áreas.',
      icon: 'fa-regular fa-calendar',
      group: 'areas',
    },
    {
      key: 'gastos',
      title: 'Gastos',
      description: 'Consolidado financiero.',
      icon: 'fa-solid fa-wallet',
      group: 'areas',
    },
    {
      key: 'documentos',
      title: 'Documentos',
      description: 'Documentación y archivos asociados.',
      icon: 'fa-regular fa-folder-open',
      group: 'areas',
    },
    {
      key: 'activos',
      title: 'Activos',
      description: 'Activos y ubicaciones.',
      icon: 'fa-solid fa-cubes',
      group: 'areas',
    },
    {
      key: 'trabajadores',
      title: 'Trabajadores',
      description: 'Fichas y documentos de trabajadores.',
      icon: 'fa-solid fa-id-card-clip',
      group: 'areas',
    },
    {
      key: 'configuracion',
      title: 'Configuración',
      description: 'Preferencias y configuración del sistema.',
      icon: 'fa-solid fa-gear',
      group: 'areas',
    },
    {
      key: 'create-edit',
      title: 'Crear y editar',
      description: 'Permite crear registros y modificar información operacional en las áreas habilitadas.',
      icon: 'fa-solid fa-pen-to-square',
      group: 'management',
    },
    {
      key: 'delete',
      title: 'Eliminar',
      description: 'Permite eliminar registros en las áreas habilitadas; las eliminaciones pueden ser permanentes.',
      icon: 'fa-regular fa-trash-can',
      group: 'management',
    },
    {
      key: 'import',
      title: 'Importar',
      description: 'Permite cargar planillas y crear o actualizar varios registros en áreas compatibles.',
      icon: 'fa-solid fa-file-arrow-up',
      group: 'management',
    },
    {
      key: 'history',
      title: 'Ver historial',
      description: 'Permite consultar la auditoría y los cambios autorizados. El historial siempre es de solo lectura.',
      icon: 'fa-solid fa-clock-rotate-left',
      group: 'management',
    },
    {
      key: 'manage-access',
      title: 'Administrar accesos',
      description: 'Permite crear usuarios y modificar sus permisos de acceso al sistema.',
      icon: 'fa-solid fa-users-gear',
      group: 'management',
    },
  ];
  protected readonly areas = computed(() => this.permissions.filter((p) => p.group === 'areas'));
  protected readonly actions = computed(() =>
    this.permissions.filter((p) => p.group === 'management'),
  );

  constructor() {
    if (this.auth.hasPermission('manage-access')) this.load();
  }
  protected create() {
    this.editingId.set(null);
    this.editingPrimaryAdministrator.set(false);
    this.form = this.emptyForm();
    this.initialPermissions = [];
    this.initialRole = 'USER';
    this.sensitivePermissionsConfirmed = false;
    this.error.set('');
    this.modalOpen.set(true);
  }
  protected edit(user: ManagedUser) {
    this.editingId.set(user.id);
    this.editingPrimaryAdministrator.set(user.primaryAdministrator);
    this.form = {
      fullName: user.fullName,
      username: user.username,
      email: user.email ?? '',
      role: user.role,
      enabled: user.enabled,
      status: user.status,
      permissions: [...user.permissions],
    };
    this.initialPermissions = [...user.permissions];
    this.initialRole = user.role;
    this.sensitivePermissionsConfirmed = false;
    this.error.set('');
    this.modalOpen.set(true);
  }
  protected close() {
    if (!this.saving()) this.modalOpen.set(false);
  }
  protected has(key: string) {
    return this.form.permissions.includes(key);
  }
  protected toggle(key: string, checked: boolean) {
    const set = new Set(this.form.permissions);
    checked ? set.add(key) : set.delete(key);
    if (key === 'manage-access' && checked) set.add('configuracion');
    if (key === 'configuracion' && !checked) set.delete('manage-access');
    this.form.permissions = [...set];
  }
  protected all(group: 'areas' | 'management') {
    return this.permissions.filter((p) => p.group === group).every((p) => this.has(p.key));
  }
  protected setAll(group: 'areas' | 'management', checked: boolean) {
    const set = new Set(this.form.permissions);
    this.permissions
      .filter((p) => p.group === group)
      .forEach((p) => (checked ? set.add(p.key) : set.delete(p.key)));
    if (group === 'management' && checked) set.add('configuracion');
    if (group === 'areas' && !checked) set.delete('manage-access');
    this.form.permissions = [...set];
  }
  protected onRoleChange(role: AccessRole) {
    this.form.role = role;
    if (role === 'ADMIN') {
      this.setAll('areas', true);
      this.setAll('management', true);
    }
  }
  protected save() {
    const fullName = this.form.fullName.trim(),
      username = this.form.username.trim().toLowerCase(),
      email = this.form.email.trim().toLowerCase();
    if (!fullName || !username || !email) {
      this.error.set('Completa nombre, usuario y correo electrónico.');
      return;
    }
    const newlyGranted = this.newlyGrantedSensitivePermissions();
    if (newlyGranted.length && !this.sensitivePermissionsConfirmed) {
      this.permissionWarning.set(newlyGranted);
      return;
    }
    this.persist(fullName, username, email);
  }
  protected cancelPermissionWarning() {
    const rejected = new Set(this.permissionWarning().map((permission) => permission.key));
    this.form.permissions = this.form.permissions.filter((key) => !rejected.has(key));
    if (this.form.role === 'ADMIN' && this.initialRole !== 'ADMIN') this.form.role = this.initialRole;
    this.permissionWarning.set([]);
    this.sensitivePermissionsConfirmed = false;
  }
  protected confirmPermissionWarning() {
    this.permissionWarning.set([]);
    this.sensitivePermissionsConfirmed = true;
    this.save();
  }
  private newlyGrantedSensitivePermissions(): PermissionOption[] {
    const initial = new Set(this.initialPermissions);
    if (this.form.role === 'ADMIN' && this.initialRole !== 'ADMIN') return this.actions();
    return this.actions().filter((permission) => this.has(permission.key) && !initial.has(permission.key));
  }
  private persist(fullName: string, username: string, email: string) {
    const id = this.editingId();
    const body = {
      fullName,
      username,
      email,
      role: this.form.role,
      enabled: this.form.enabled,
      permissions: this.form.permissions,
    };
    this.saving.set(true);
    this.error.set('');
    const req: Observable<ManagedUser | SaveResult> = id
      ? this.http.put<ManagedUser>(`/api/admin/users/${id}`, body, { withCredentials: true })
      : this.http.post<SaveResult>('/api/admin/users', body, { withCredentials: true });
    req.subscribe({
      next: (result) => {
        this.saving.set(false);
        this.modalOpen.set(false);
        this.sensitivePermissionsConfirmed = false;
        this.load();
        if (id)
          this.saved.set({
            user: result as ManagedUser,
            invitationSent: true,
            message: 'Perfil y permisos actualizados correctamente.',
          });
        else this.saved.set(result as SaveResult);
      },
      error: (e: HttpErrorResponse) => {
        this.saving.set(false);
        this.error.set(e.error?.message || 'No fue posible guardar el perfil.');
      },
    });
  }
  protected resend(user: ManagedUser) {
    this.http
      .post<SaveResult>(
        `/api/admin/users/${user.id}/resend-invitation`,
        {},
        { withCredentials: true },
      )
      .subscribe({
        next: (r) => this.saved.set(r),
        error: (e: HttpErrorResponse) =>
          this.error.set(e.error?.message || 'No fue posible reenviar la invitación.'),
      });
  }
  protected askDelete(user: ManagedUser) {
    if (user.primaryAdministrator) return;
    this.deleteError.set('');
    this.deleteTarget.set(user);
  }
  protected cancelDelete() {
    if (!this.deleting()) {
      this.deleteTarget.set(null);
      this.deleteError.set('');
    }
  }
  protected confirmDelete() {
    const user = this.deleteTarget();
    if (!user || this.deleting()) return;
    this.deleting.set(true);
    this.deleteError.set('');
    this.http
      .delete<DeleteResult>(`/api/admin/users/${user.id}`, { withCredentials: true })
      .subscribe({
        next: (r) => {
          this.deleting.set(false);
          this.deleteTarget.set(null);
          this.deletedName.set(r.fullName);
          this.load();
        },
        error: (e: HttpErrorResponse) => {
          this.deleting.set(false);
          this.deleteError.set(e.error?.message || 'No fue posible eliminar el usuario.');
        },
      });
  }
  protected status(user: ManagedUser) {
    return user.status === 'PENDING_ACTIVATION'
      ? 'Pendiente de activación'
      : user.status === 'ACTIVE'
        ? 'Cuenta activa'
        : 'Cuenta deshabilitada';
  }
  protected label(key: string) {
    return this.permissions.find((p) => p.key === key)?.title || key;
  }
  protected closeSummary() {
    this.saved.set(null);
  }
  protected closeDeleted() {
    this.deletedName.set(null);
  }
  private load() {
    this.loading.set(true);
    this.http.get<ManagedUser[]>('/api/admin/users', { withCredentials: true }).subscribe({
      next: (v) => {
        this.users.set(v);
        this.loading.set(false);
      },
      error: () => {
        this.loading.set(false);
        this.error.set('No fue posible cargar los usuarios.');
      },
    });
  }
  private emptyForm() {
    return {
      fullName: '',
      username: '',
      email: '',
      role: 'USER' as AccessRole,
      enabled: false,
      status: 'PENDING_ACTIVATION' as AccountStatus,
      permissions: [] as string[],
    };
  }
}
