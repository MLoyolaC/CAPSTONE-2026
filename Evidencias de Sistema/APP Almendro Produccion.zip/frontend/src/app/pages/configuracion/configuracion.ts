import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { AppSidebarComponent } from '../../shared/app-sidebar/app-sidebar';
import { AuthService } from '../../core/auth/auth.service';
import { ThemeService } from '../../core/auth/theme/theme.service';
import { AccessManagementComponent } from './access-management';
import {
  AccessProfile,
  AccessRole,
  AppSettingsService,
  FontSizePreference
} from '../../core/settings/app-settings.service';
import { BrandingService, BrandingState } from '../../core/settings/branding.service';
import { ConnectivityService } from '../../core/connectivity/connectivity.service';

type SettingsSection = 'account' | 'access' | 'appearance' | 'system' | 'integrations';

interface PermissionOption {
  key: string;
  title: string;
  description: string;
  icon: string;
  group: 'areas' | 'management';
}

interface SystemStatus { database: 'AVAILABLE' | 'UNAVAILABLE'; email: 'AVAILABLE' | 'CONFIGURATION_PENDING'; emailSender: string | null; }

@Component({
  selector: 'app-configuracion',
  standalone: true,
  imports: [FormsModule, AppSidebarComponent, AccessManagementComponent],
  templateUrl: './configuracion.html',
  styleUrl: './configuracion.scss'
})
export class ConfiguracionComponent {
  protected readonly auth = inject(AuthService);
  private readonly http = inject(HttpClient);
  private readonly route = inject(ActivatedRoute);
  protected readonly theme = inject(ThemeService);
  protected readonly settings = inject(AppSettingsService);
  protected readonly branding = inject(BrandingService);
  protected readonly connectivity = inject(ConnectivityService);

  protected readonly user = this.auth.currentUser;
  protected readonly section = signal<SettingsSection>('account');
  protected readonly toast = signal('');
  protected readonly accessModalOpen = signal(false);
  protected readonly deleteModalOpen = signal(false);
  protected readonly resetModalOpen = signal(false);
  protected readonly backupExporting = signal(false);
  protected readonly backupRestoring = signal(false);
  protected readonly restoreModalOpen = signal(false);
  protected readonly backupError = signal('');
  protected readonly backupRestored = signal(false);
  protected readonly accountSaving = signal(false);
  protected readonly accountError = signal('');
  protected readonly avatarUploading = signal(false);
  protected readonly avatarVersion = signal(Date.now());
  protected readonly identitySaving = signal(false);
  protected readonly identityError = signal('');
  protected readonly offlineTutorialOpen = signal(false);
  protected readonly systemStatus = signal<SystemStatus | null>(null);
  protected readonly lastBackupAt = signal(localStorage.getItem('omm-last-complete-backup-at'));
  protected backupPassword = '';
  protected backupPasswordConfirm = '';
  protected restorePassword = '';
  protected restoreConfirmation = '';
  protected restoreFile: File | null = null;
  protected accountEmail = this.user()?.email || '';
  protected readonly editingAccessId = signal<string | null>(null);
  protected readonly deleteAccessId = signal<string | null>(null);

  protected profileName = this.settings.displayName();
  protected profilePhone = this.settings.phone();
  protected hotelName = this.settings.hotelName();
  protected systemName = this.settings.systemName();
  protected fontSize: FontSizePreference = this.settings.fontSize();
  protected denseUi = this.settings.denseUi();
  protected highContrast = this.settings.highContrast();
  protected reduceMotion = this.settings.reduceMotion();
  protected enhancedFocus = this.settings.enhancedFocus();
  protected underlineLinks = this.settings.underlineLinks();
  protected notificationSound = this.settings.notificationSound();
  protected welcomeAnimation = this.settings.welcomeAnimation();
  protected monthlyAlerts = this.settings.monthlyAlerts();

  protected accessForm: AccessProfile = this.emptyAccessProfile();

  protected readonly avatarPresets = [
    { key: 'user', label: 'Usuario', icon: 'fa-solid fa-user' },
    { key: 'circle-user', label: 'Perfil', icon: 'fa-solid fa-circle-user' },
    { key: 'user-tie', label: 'Profesional', icon: 'fa-solid fa-user-tie' },
    { key: 'user-shield', label: 'Protegido', icon: 'fa-solid fa-user-shield' },
    { key: 'address-card', label: 'Credencial', icon: 'fa-solid fa-address-card' },
  ];
  protected readonly identityPresets: Array<{ key: BrandingState['preset']; label: string; icon: string }> = [
    { key: 'hotel', label: 'Hotel', icon: 'fa-solid fa-hotel' },
    { key: 'bell', label: 'Recepción', icon: 'fa-solid fa-bell-concierge' },
    { key: 'building', label: 'Edificio', icon: 'fa-solid fa-building' },
    { key: 'key', label: 'Llave', icon: 'fa-solid fa-key' },
    { key: 'landmark', label: 'Institución', icon: 'fa-solid fa-landmark' },
  ];

  protected readonly permissions: PermissionOption[] = [
    { key: 'dashboard', title: 'Dashboard', description: 'Indicadores, alertas y resumen general.', icon: 'fa-solid fa-table-cells-large', group: 'areas' },
    { key: 'mantencion-general', title: 'Mantención General', description: 'Consultar y gestionar mantenciones programadas.', icon: 'fa-solid fa-wrench', group: 'areas' },
    { key: 'mantencion-reactiva', title: 'Mantención Reactiva', description: 'Consultar y gestionar incidencias.', icon: 'fa-solid fa-bolt', group: 'areas' },
    { key: 'mejoras', title: 'Mejoras', description: 'Metas, plan anual y Gantt de mejoras.', icon: 'fa-solid fa-chart-line', group: 'areas' },
    { key: 'remodelacion', title: 'Remodelación', description: 'Proyectos, Gantt, costos y presupuesto.', icon: 'fa-solid fa-house-chimney', group: 'areas' },
    { key: 'maquinas', title: 'Máquinas', description: 'Mantenciones y activos asociados a máquinas.', icon: 'fa-solid fa-gears', group: 'areas' },
    { key: 'jardineria', title: 'Jardinería', description: 'Labores, temporadas y planificación.', icon: 'fa-solid fa-leaf', group: 'areas' },
    { key: 'prevencion', title: 'Prevención', description: 'Seguimiento del área de prevención de riesgos.', icon: 'fa-solid fa-shield-halved', group: 'areas' },
    { key: 'calendario', title: 'Calendario general', description: 'Fechas e hitos provenientes de todas las áreas.', icon: 'fa-regular fa-calendar', group: 'areas' },
    { key: 'gastos', title: 'Gastos', description: 'Consultar consolidado financiero.', icon: 'fa-solid fa-wallet', group: 'areas' },
    { key: 'documentos', title: 'Documentos', description: 'Consultar documentación y archivos asociados.', icon: 'fa-regular fa-folder-open', group: 'areas' },
    { key: 'activos', title: 'Activos', description: 'Consultar activos y ubicaciones.', icon: 'fa-solid fa-cubes', group: 'areas' },
    { key: 'trabajadores', title: 'Trabajadores', description: 'Consultar futuras carpetas de trabajadores.', icon: 'fa-solid fa-id-card-clip', group: 'areas' },
    { key: 'create-edit', title: 'Crear y editar registros', description: 'Permite modificar información operacional.', icon: 'fa-solid fa-pen-to-square', group: 'management' },
    { key: 'delete', title: 'Eliminar registros', description: 'Permite acciones destructivas con confirmación.', icon: 'fa-regular fa-trash-can', group: 'management' },
    { key: 'import', title: 'Importar planillas', description: 'Permite cargar Excel y ZIP a las áreas compatibles.', icon: 'fa-solid fa-file-arrow-up', group: 'management' },
    { key: 'history', title: 'Historial y auditoría', description: 'Permite revisar quién realizó cada cambio.', icon: 'fa-solid fa-clock-rotate-left', group: 'management' },
    { key: 'manage-access', title: 'Administrar accesos', description: 'Permite definir roles y permisos.', icon: 'fa-solid fa-users-gear', group: 'management' }
  ];

  protected readonly areaPermissions = computed(() => this.permissions.filter(item => item.group === 'areas'));
  protected readonly managementPermissions = computed(() => this.permissions.filter(item => item.group === 'management'));

  constructor() {
    this.branding.load();
    this.loadSystemStatus();
    this.route.queryParamMap.subscribe(params => {
      const requested = params.get('section');
      if (requested === 'appearance') this.section.set('appearance');
    });
  }

  protected setSection(section: SettingsSection): void {
    this.section.set(section);
  }

  protected accountDisplayName(): string {
    return this.settings.displayNameFor(this.user()?.username);
  }

  protected initials(): string {
    return this.accountDisplayName().split(/\s+/).filter(Boolean).slice(0, 2).map(part => part[0]).join('').toLocaleUpperCase('es-CL') || 'A';
  }

  protected roleLabel(): string { return this.user()?.role === 'ADMIN' ? 'Administrador' : 'Usuario'; }
  protected statusLabel(): string {
    return this.user()?.status === 'ACTIVE' ? 'Cuenta activa' : this.user()?.status === 'PENDING_ACTIVATION' ? 'Pendiente de activación' : 'Cuenta deshabilitada';
  }
  protected avatarIcon(): string {
    return this.avatarPresets.find(item => item.key === this.user()?.avatarPreset)?.icon || 'fa-solid fa-user';
  }
  protected avatarImageUrl(): string { return `/api/account/avatar?v=${this.avatarVersion()}`; }
  protected chooseAvatar(preset: string): void {
    this.accountError.set('');
    this.http.put('/api/account/avatar/preset', { preset }, { withCredentials: true }).subscribe({
      next: () => this.refreshCurrentUser('Avatar actualizado.'),
      error: (error: HttpErrorResponse) => this.accountError.set(error.error?.message || 'No fue posible actualizar el avatar.'),
    });
  }
  protected uploadAvatar(event: Event): void {
    const file = (event.target as HTMLInputElement).files?.item(0);
    if (!file) return;
    if (file.size > 1_048_576 || !/\.(png|jpe?g)$/i.test(file.name)) {
      this.accountError.set('Selecciona una imagen PNG, JPG o JPEG de hasta 1 MB.');
      return;
    }
    this.avatarUploading.set(true);
    this.accountError.set('');
    const data = new FormData(); data.append('file', file);
    this.http.post('/api/account/avatar/image', data, { withCredentials: true }).subscribe({
      next: () => { this.avatarUploading.set(false); this.avatarVersion.set(Date.now()); this.refreshCurrentUser('Imagen de perfil actualizada.'); },
      error: (error: HttpErrorResponse) => { this.avatarUploading.set(false); this.accountError.set(error.error?.message || 'La imagen no es válida.'); },
    });
  }
  protected saveEmail(): void {
    this.accountSaving.set(true); this.accountError.set('');
    this.http.patch<{ email: string }>('/api/account/email', { email: this.accountEmail }, { withCredentials: true }).subscribe({
      next: result => { this.accountEmail = result.email; this.accountSaving.set(false); this.refreshCurrentUser('Correo de recuperación actualizado.'); },
      error: (error: HttpErrorResponse) => { this.accountSaving.set(false); this.accountError.set(error.error?.message || 'No fue posible actualizar el correo.'); },
    });
  }
  private refreshCurrentUser(message: string): void {
    this.auth.loadCurrentUser().subscribe({ next: user => { this.accountEmail = user.email || ''; this.showToast(message); } });
  }

  protected saveAccount(): void {
    this.settings.updateProfile(this.profileName, this.profilePhone);
    this.profileName = this.settings.displayName();
    this.profilePhone = this.settings.phone();
    this.showToast('Datos visibles de la cuenta actualizados.');
  }

  protected onThemeChange(dark: boolean): void {
    this.theme.setTheme(dark);
    this.showToast(dark ? 'Modo oscuro activado.' : 'Modo claro activado.');
  }

  protected onFontSizeChange(value: FontSizePreference): void {
    this.fontSize = value;
    this.settings.setFontSize(value);
    this.showToast('Tamaño de texto actualizado.');
  }

  protected onDensityChange(value: boolean): void {
    this.denseUi = value;
    this.settings.setDenseUi(value);
    this.showToast(value ? 'Vista compacta activada.' : 'Vista cómoda activada.');
  }

  protected setAccessibility(option: 'highContrast' | 'reduceMotion' | 'enhancedFocus' | 'underlineLinks', value: boolean): void {
    this[option] = value;
    this.settings.setAccessibility(option, value);
    this.showToast('Preferencia de accesibilidad actualizada.');
  }

  protected chooseIdentity(preset: BrandingState['preset']): void {
    if (!this.auth.hasPermission('manage-access')) return;
    this.identitySaving.set(true); this.identityError.set('');
    this.branding.choosePreset(preset).subscribe({
      next: () => { this.identitySaving.set(false); this.showToast('Identidad visual actualizada.'); },
      error: (error: HttpErrorResponse) => { this.identitySaving.set(false); this.identityError.set(error.error?.message || 'No fue posible actualizar la identidad.'); },
    });
  }
  protected uploadIdentity(event: Event): void {
    if (!this.auth.hasPermission('manage-access')) return;
    const file = (event.target as HTMLInputElement).files?.item(0); if (!file) return;
    if (file.size > 1_048_576 || !/\.(png|jpe?g)$/i.test(file.name)) { this.identityError.set('Selecciona una imagen PNG, JPG o JPEG de hasta 1 MB.'); return; }
    this.identitySaving.set(true); this.identityError.set('');
    this.branding.upload(file).subscribe({
      next: () => { this.identitySaving.set(false); this.showToast('Imagen de identidad actualizada.'); },
      error: (error: HttpErrorResponse) => { this.identitySaving.set(false); this.identityError.set(error.error?.message || 'La imagen no es válida.'); },
    });
  }
  protected identityImageUrl(): string { return this.branding.imageUrl(); }

  protected toggleNotificationSound(value: boolean): void {
    this.notificationSound = value;
    this.settings.setNotificationSound(value);
    this.showToast(value ? 'Sonido de alertas activado.' : 'Sonido de alertas desactivado.');
  }

  protected toggleWelcome(value: boolean): void {
    this.welcomeAnimation = value;
    this.settings.setWelcomeAnimation(value);
    this.showToast(value ? 'Bienvenida de inicio activada.' : 'Bienvenida de inicio desactivada.');
  }

  protected toggleMonthlyAlerts(value: boolean): void {
    this.monthlyAlerts = value;
    this.settings.setMonthlyAlerts(value);
    this.showToast(value ? 'Resumen mensual de fechas activado.' : 'Resumen mensual de fechas desactivado.');
  }

  protected saveSystem(): void {
    this.settings.updateSystem(this.hotelName, this.systemName);
    this.hotelName = this.settings.hotelName();
    this.systemName = this.settings.systemName();
    this.showToast('Identidad del sistema actualizada.');
  }

  protected openCreateAccess(): void {
    this.editingAccessId.set(null);
    this.accessForm = this.emptyAccessProfile();
    this.applyRolePreset(this.accessForm.role);
    this.accessModalOpen.set(true);
  }

  protected openEditAccess(profile: AccessProfile): void {
    this.editingAccessId.set(profile.id);
    this.accessForm = { ...profile, permissions: [...profile.permissions] };
    this.accessModalOpen.set(true);
  }

  protected closeAccessModal(): void {
    this.accessModalOpen.set(false);
  }

  protected onRoleChange(role: AccessRole): void {
    this.accessForm.role = role;
    this.applyRolePreset(role);
  }

  protected togglePermission(key: string, checked: boolean): void {
    const permissions = new Set(this.accessForm.permissions);
    if (checked) permissions.add(key); else permissions.delete(key);
    this.accessForm.permissions = [...permissions];
  }

  protected hasPermission(key: string): boolean {
    return this.accessForm.permissions.includes(key);
  }

  protected saveAccessProfile(): void {
    const name = this.accessForm.name.trim();
    const username = this.accessForm.username.trim().toLowerCase();
    if (!name || !username) {
      this.showToast('Completa nombre y usuario del perfil.');
      return;
    }
    const id = this.editingAccessId() || `access-${Date.now()}`;
    this.settings.saveAccessProfile({
      ...this.accessForm,
      id,
      name,
      username,
      permissions: [...this.accessForm.permissions]
    });
    this.accessModalOpen.set(false);
    this.showToast(this.editingAccessId() ? 'Perfil de permisos actualizado.' : 'Perfil de permisos preparado.');
  }

  protected requestDeleteAccess(id: string): void {
    this.deleteAccessId.set(id);
    this.deleteModalOpen.set(true);
  }

  protected cancelDeleteAccess(): void {
    this.deleteModalOpen.set(false);
    this.deleteAccessId.set(null);
  }

  protected confirmDeleteAccess(): void {
    const id = this.deleteAccessId();
    if (!id) return;
    this.settings.deleteAccessProfile(id);
    this.cancelDeleteAccess();
    this.showToast('Perfil de permisos eliminado.');
  }

  protected profileRoleLabel(role: AccessRole): string {
    if (role === 'ADMIN') return 'Administrador';
    if (role === 'OPERATOR') return 'Operador';
    return 'Solo lectura';
  }

  protected permissionCount(profile: AccessProfile): number {
    return profile.permissions.length;
  }

  protected exportConfiguration(): void {
    const snapshot = this.settings.exportSnapshot(this.user()?.username, this.user()?.role);
    const blob = new Blob([snapshot], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `omm-configuracion-${new Date().toISOString().slice(0, 10)}.json`;
    anchor.click();
    URL.revokeObjectURL(url);
    this.showToast('Configuración exportada en JSON.');
  }

  protected exportCompleteBackup(): void {
    if (this.user()?.role !== 'ADMIN') return;
    if (this.backupPassword.length < 12) {
      this.backupError.set('Elige una contraseña de al menos 12 caracteres para cifrar el respaldo.');
      return;
    }
    if (this.backupPassword !== this.backupPasswordConfirm) {
      this.backupError.set('La confirmación de la contraseña no coincide.');
      return;
    }
    this.backupError.set('');
    this.backupExporting.set(true);
    const browserSettings = JSON.parse(this.settings.exportSnapshot(this.user()?.username, this.user()?.role));
    this.http.post('/api/admin/backup/export', {
      password: this.backupPassword,
      browserSettings
    }, { responseType: 'blob', withCredentials: true }).subscribe({
      next: blob => {
        this.backupExporting.set(false);
        this.backupPassword = '';
        this.backupPasswordConfirm = '';
        const exportedAt = new Date().toISOString();
        localStorage.setItem('omm-last-complete-backup-at', exportedAt);
        this.lastBackupAt.set(exportedAt);
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `omm-respaldo-completo-${new Date().toISOString().slice(0, 10)}.ommbackup`;
        document.body.appendChild(link);
        link.click();
        link.remove();
        window.setTimeout(() => URL.revokeObjectURL(url), 2000);
        this.showToast('Respaldo completo descargado y cifrado. Guarda también su contraseña.');
      },
      error: (error: HttpErrorResponse) => {
        this.backupExporting.set(false);
        this.readBackupError(error);
      }
    });
  }

  protected selectRestoreFile(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.restoreFile = input.files?.item(0) || null;
    this.backupError.set('');
  }

  protected openRestoreBackup(): void {
    if (this.user()?.role !== 'ADMIN') return;
    this.restorePassword = '';
    this.restoreConfirmation = '';
    this.backupError.set('');
    this.restoreModalOpen.set(true);
  }

  protected goToLoginAfterRestore(): void { window.location.assign('/login'); }

  protected closeRestoreBackup(): void {
    if (this.backupRestoring()) return;
    this.restoreModalOpen.set(false);
    this.restorePassword = '';
    this.restoreConfirmation = '';
    this.restoreFile = null;
    this.backupError.set('');
  }

  protected restoreCompleteBackup(): void {
    if (this.user()?.role !== 'ADMIN') return;
    if (!this.restoreFile || !this.restoreFile.name.toLowerCase().endsWith('.ommbackup')) {
      this.backupError.set('Selecciona un archivo .ommbackup válido.');
      return;
    }
    if (this.restorePassword.length < 12 || this.restoreConfirmation !== 'RESTAURAR') {
      this.backupError.set('Introduce la contraseña del respaldo y escribe RESTAURAR para confirmar.');
      return;
    }
    this.backupError.set('');
    this.backupRestoring.set(true);
    const formData = new FormData();
    formData.append('file', this.restoreFile);
    formData.append('password', this.restorePassword);
    formData.append('confirmation', this.restoreConfirmation);
    this.http.post<{status:string;message:string;browserSettings?:{theme?:string;settings?:unknown}}>(
      '/api/admin/backup/restore', formData, {withCredentials:true}
    ).subscribe({
      next: result => {
        this.backupRestoring.set(false);
        this.restorePassword = '';
        this.restoreModalOpen.set(false);
        // Estos ajustes pertenecen al navegador; los datos operacionales ya fueron restaurados en el servidor.
        if (result.browserSettings?.settings) {
          localStorage.setItem('omm-admin-settings-v1', JSON.stringify(result.browserSettings.settings));
        }
        if (result.browserSettings?.theme === 'light' || result.browserSettings?.theme === 'dark') {
          localStorage.setItem('omm-theme', result.browserSettings.theme);
        }
        this.backupRestored.set(true);
      },
      error: (error: HttpErrorResponse) => {
        this.backupRestoring.set(false);
        this.readBackupError(error);
      }
    });
  }

  private readBackupError(error: HttpErrorResponse): void {
    const body = error.error;
    if (body instanceof Blob) {
      body.text().then(text => {
        try { const parsed = JSON.parse(text); this.backupError.set(parsed.detail || parsed.message || 'No se pudo realizar la operación.'); }
        catch { this.backupError.set('Falló el respaldo. Comprueba la conexión con PostgreSQL y las herramientas pg_dump/pg_restore.'); }
      });
    } else {
      this.backupError.set(body?.detail || body?.message || 'No se pudo completar la operación.');
    }
  }

  protected openResetModal(): void {
    this.resetModalOpen.set(true);
  }

  protected backupDate(): string {
    const value = this.lastBackupAt();
    return value ? new Intl.DateTimeFormat('es-CL', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)) : 'Aún no registrado en este navegador';
  }
  protected openOfflineTutorial(): void { this.offlineTutorialOpen.set(true); }
  protected closeOfflineTutorial(): void { this.offlineTutorialOpen.set(false); }
  protected connectionLabel(): string {
    return this.connectivity.state() === 'online' ? 'Disponible' : this.connectivity.state() === 'offline' ? 'Sin conexión' : 'Intermitente';
  }
  protected statusClass(): string { return this.connectivity.state() === 'online' ? 'success' : this.connectivity.state() === 'offline' ? 'error' : 'pending'; }
  protected emailStatusLabel(): string { return this.systemStatus()?.email === 'AVAILABLE' ? 'Disponible' : 'Configuración pendiente'; }
  protected databaseStatusLabel(): string {
    if (this.connectivity.state() !== 'online') return this.connectionLabel();
    return this.systemStatus()?.database === 'AVAILABLE' ? 'Disponible' : 'No disponible';
  }
  private loadSystemStatus(): void {
    this.http.get<SystemStatus>('/api/system/status', { withCredentials: true }).subscribe({ next: status => this.systemStatus.set(status) });
  }

  protected cancelReset(): void {
    this.resetModalOpen.set(false);
  }

  protected confirmReset(): void {
    this.settings.resetPreferences();
    this.profileName = this.settings.displayName();
    this.profilePhone = this.settings.phone();
    this.hotelName = this.settings.hotelName();
    this.systemName = this.settings.systemName();
    this.fontSize = this.settings.fontSize();
    this.denseUi = this.settings.denseUi();
    this.highContrast = this.settings.highContrast();
    this.reduceMotion = this.settings.reduceMotion();
    this.enhancedFocus = this.settings.enhancedFocus();
    this.underlineLinks = this.settings.underlineLinks();
    this.notificationSound = this.settings.notificationSound();
    this.welcomeAnimation = this.settings.welcomeAnimation();
    this.monthlyAlerts = this.settings.monthlyAlerts();
    this.theme.setTheme(false);
    this.resetModalOpen.set(false);
    this.showToast('Preferencias visuales restablecidas.');
  }

  private emptyAccessProfile(): AccessProfile {
    return {
      id: '',
      name: '',
      username: '',
      role: 'OPERATOR',
      enabled: true,
      permissions: []
    };
  }

  private applyRolePreset(role: AccessRole): void {
    if (role === 'ADMIN') {
      this.accessForm.permissions = this.permissions.map(item => item.key);
      return;
    }
    if (role === 'READ_ONLY') {
      this.accessForm.permissions = this.permissions
        .filter(item => item.group === 'areas' || item.key === 'history')
        .map(item => item.key);
      return;
    }
    this.accessForm.permissions = this.permissions
      .filter(item => item.key !== 'delete' && item.key !== 'manage-access')
      .map(item => item.key);
  }

  private showToast(message: string): void {
    this.toast.set(message);
    window.setTimeout(() => {
      if (this.toast() === message) this.toast.set('');
    }, 2600);
  }
}
