import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { forkJoin, from, concatMap, toArray } from 'rxjs';
import { AuthService } from '../../core/auth/auth.service';
import { AppSidebarComponent } from '../../shared/app-sidebar/app-sidebar';
import { CountUpDirective } from '../../shared/count-up/count-up';
import { DisplayColorPickerComponent } from '../../shared/display-color-picker/display-color-picker';
import { activityTextColor as resolveActivityTextColor, normalizeDisplayColor, normalizeHexColor, OMM_DISPLAY_COLOR_PALETTE } from '../../core/colors/display-color';
import { dateOnlyKeyFromDay, dateOnlyToLocalDate, isDateOnlyWithinInclusiveRange, normalizeDateOnlyRange } from '../../core/dates/date-only';

type ViewMode='projects'|'gantt'|'calendar'|'costs';
type DetailTab='summary'|'costs'|'gantt';
type SummaryKind='ACTIVE'|'COMPLETED'|'ESTIMATED'|'ACTUAL';
interface WorkItem{
  id:string;areaSlug:string;areaName:string;workType:string;phase:string|null;title:string;description:string|null;
  location:string|null;responsibleName:string|null;priority:string;status:string;scheduledStart:string|null;scheduledEnd:string|null;displayColor:string|null;textColor:string|null;
  completedDate:string|null;progressPercent:number;notes:string|null;category:string|null;materials:string|null;supplierName:string|null;
  estimatedCost:number|null;actualCost:number|null;importSourceFilename:string|null;sourceSheetName:string|null;sourceRowNumber:number|null;
  importedData:string|null;createdAt:string;updatedAt:string;
}
interface DuplicateRef{ id:string;title:string;areaSlug:string;areaName:string;location:string|null;workType:string; }
interface BudgetLine{kind?:string;date?:string;category?:string;provider?:string;product?:string;quantity?:string;unitValue?:number;total?:number;sourceFile?:string;sourceSheet?:string;sourceRow?:number;}
interface SheetVatSummary{withVat?:number;withoutVat?:number;}
interface ProjectMeta{projectKey?:string;sourceFiles?:string[];budgetLines?:BudgetLine[];ganttTaskCount?:number;parentProjectId?:string;parentProjectKey?:string;sourceKind?:string;sourceFile?:string;sourceGroup?:string;supportType?:string;sheetNames?:string[];rows?:Record<string,unknown>[];sheetSummaries?:Record<string,SheetVatSummary>;vatRate?:number;}
interface BudgetLineForm{kind:'ESTIMATED'|'ACTUAL';date:string;category:string;provider:string;product:string;quantity:string;unitValue:number|null;total:number|null;sourceFile:string;sourceSheet:string;}
interface SupportRowForm{sheet:string;sheetTitle:string;fecha:string;categoria:string;proveedor:string;producto:string;cantidad:string;valorUnitario:number|null;valorTotal:number|null;destino:string;}
interface ProjectForm{title:string;location:string;responsibleName:string;phase:string;status:string;scheduledStart:string;scheduledEnd:string;displayColor:string|null;textColor:string|null;progressPercent:number;category:string;supplierName:string;materials:string;estimatedCost:number|null;actualCost:number|null;description:string;notes:string;}
interface TaskForm{title:string;responsibleName:string;phase:string;status:string;scheduledStart:string;scheduledEnd:string;displayColor:string|null;textColor:string|null;progressPercent:number;notes:string;}
interface CalendarDay{iso:string;day:number;inMonth:boolean;events:WorkItem[];}

@Component({
  selector:'app-remodelacion',standalone:true,
  imports:[FormsModule,RouterLink,AppSidebarComponent,CountUpDirective,DisplayColorPickerComponent],
  templateUrl:'./remodelacion.html',styleUrl:'./remodelacion.scss'
})
export class RemodelacionComponent{
  private readonly http=inject(HttpClient);private readonly auth=inject(AuthService);private readonly router=inject(Router);private readonly route=inject(ActivatedRoute);
  protected readonly user=this.auth.currentUser;
  protected readonly projects=signal<WorkItem[]>([]);protected readonly tasks=signal<WorkItem[]>([]);protected readonly supports=signal<WorkItem[]>([]);protected readonly loading=signal(true);
  protected readonly errorMessage=signal('');protected readonly successMessage=signal('');protected readonly view=signal<ViewMode>('projects');
  protected readonly search=signal('');protected readonly zoneFilter=signal('ALL');protected readonly selectedProjectId=signal<string|null>(null);protected readonly detailTab=signal<DetailTab>('summary');
  protected readonly expandedProjectFolders=signal<Set<string>>(new Set());protected readonly expandedProjectZones=signal<Set<string>>(new Set());
  protected readonly expandedSupportFiles=signal<Set<string>>(new Set());protected readonly expandedSupportSheets=signal<Set<string>>(new Set());
  protected readonly summaryDialog=signal<SummaryKind|null>(null);
  protected readonly ganttSearch=signal('');protected readonly ganttFolderFilter=signal('ALL');protected readonly ganttPhaseFilter=signal('ALL');
  protected readonly expandedGanttFolders=signal<Set<string>>(new Set());protected readonly expandedGanttSheets=signal<Set<string>>(new Set());
  protected readonly costSearch=signal('');protected readonly costFolderFilter=signal('ALL');protected readonly costKindFilter=signal<'ALL'|'ESTIMATED'|'ACTUAL'|'SUPPORT'>('ALL');
  protected readonly expandedCostFolders=signal<Set<string>>(new Set());protected readonly expandedCostProjects=signal<Set<string>>(new Set());
  protected readonly projectModalOpen=signal(false);protected readonly taskModalOpen=signal(false);protected readonly editingProjectId=signal<string|null>(null);protected readonly editingTaskId=signal<string|null>(null);
  protected readonly saving=signal(false);protected readonly deleteDialog=signal<{title:string;message:string;ids:string[]}|null>(null);
  protected readonly detailDeleteDialog=signal<{title:string;message:string}|null>(null);private pendingDetailDelete:(()=>void)|null=null;
  protected readonly duplicateDialog=signal<DuplicateRef[]|null>(null);private pendingSave:(()=>void)|null=null;
  protected readonly inventoryYearFilter=signal<string>('ALL');protected readonly inventorySheetFilter=signal<string>('ALL');
  protected readonly budgetLineModalOpen=signal(false);protected readonly supportRowModalOpen=signal(false);
  protected readonly editingBudgetLineIndex=signal<number|null>(null);protected readonly editingSupportRowIndex=signal<number|null>(null);
  protected readonly editingSupportId=signal<string|null>(null);
  protected readonly selectedGanttProject=signal<string>('ALL');protected readonly calendarMonth=signal(new Date(new Date().getFullYear(),new Date().getMonth(),1));
  protected readonly ivaRate=0.19;
  protected projectForm:ProjectForm=this.emptyProject();protected taskForm:TaskForm=this.emptyTask();
  protected budgetLineForm:BudgetLineForm=this.emptyBudgetLine();protected supportRowForm:SupportRowForm=this.emptySupportRow();

  protected readonly inventorySupports=computed(()=>this.supports().filter(item=>this.meta(item)?.supportType==='INVENTORY'));
  protected readonly projectFolderOptions=computed(()=>Array.from(new Set([
    ...this.projects().map(project=>this.projectFolder(project)),
    ...this.inventorySupports().map(()=> 'Bodegas')
  ])).sort((a,b)=>this.folderOrder(a)-this.folderOrder(b)||a.localeCompare(b,'es-CL',{numeric:true})));
  protected projectFolderCount(folder:string):number{return this.projects().filter(project=>this.projectFolder(project)===folder).length+(folder==='Bodegas'?this.inventorySupports().length:0);}
  protected readonly visibleProjects=computed(()=>{
    const q=this.search().trim().toLocaleLowerCase('es-CL');const folder=this.zoneFilter();
    return this.projects().filter(project=>folder==='ALL'||this.projectFolder(project)===folder).filter(project=>!q||[project.title,project.location,project.category,project.responsibleName,project.supplierName,this.projectFolder(project)].filter(Boolean).join(' ').toLocaleLowerCase('es-CL').includes(q)).sort((a,b)=>this.projectSort(a,b));
  });
  protected readonly visibleInventorySupports=computed(()=>{
    const q=this.search().trim().toLocaleLowerCase('es-CL');const folder=this.zoneFilter();
    if(folder!=='ALL'&&folder!=='Bodegas')return[];
    return this.inventorySupports().filter(item=>!q||[item.title,item.location,item.description,JSON.stringify(this.supportRows(item))].filter(Boolean).join(' ').toLocaleLowerCase('es-CL').includes(q));
  });
  protected readonly projectHierarchy=computed(()=>{
    const folders=new Map<string,{zones:Map<string,WorkItem[]>;supports:WorkItem[]}>();
    for(const project of this.visibleProjects()){
      const folder=this.projectFolder(project);const zone=project.location?.trim()||'Zona sin definir';
      if(!folders.has(folder))folders.set(folder,{zones:new Map(),supports:[]});
      const group=folders.get(folder)!;group.zones.set(zone,[...(group.zones.get(zone)||[]),project]);
    }
    for(const support of this.visibleInventorySupports()){
      const folder='Bodegas';
      if(!folders.has(folder))folders.set(folder,{zones:new Map(),supports:[]});
      folders.get(folder)!.supports.push(support);
    }
    return Array.from(folders,([name,group])=>({
      name,
      total:Array.from(group.zones.values()).reduce((sum,items)=>sum+items.length,0)+group.supports.length,
      zones:Array.from(group.zones,([name,items])=>({name,items:[...items].sort((a,b)=>this.projectSort(a,b))})).sort((a,b)=>a.name.localeCompare(b.name,'es-CL',{numeric:true})),
      supports:[...group.supports].sort((a,b)=>a.title.localeCompare(b.title,'es-CL',{numeric:true}))
    })).sort((a,b)=>this.folderOrder(a.name)-this.folderOrder(b.name)||a.name.localeCompare(b.name,'es-CL',{numeric:true}));
  });
  protected readonly selectedProject=computed(()=>this.projects().find(p=>p.id===this.selectedProjectId())||null);
  protected readonly selectedProjectMeta=computed(()=>this.meta(this.selectedProject()));
  protected readonly selectedProjectLines=computed(()=>this.selectedProjectMeta()?.budgetLines||[]);
  protected readonly selectedProjectTasks=computed(()=>{const p=this.selectedProject();if(!p)return[];const meta=this.meta(p);return this.tasks().filter(t=>{const tm=this.meta(t);return tm?.parentProjectId===p.id|| (!!meta?.projectKey&&tm?.parentProjectKey===meta.projectKey)||(!tm?.parentProjectId&&!tm?.parentProjectKey&&t.location&&p.location&&t.location===p.location);}).sort((a,b)=>(a.scheduledStart||'9999').localeCompare(b.scheduledStart||'9999')||a.title.localeCompare(b.title,'es-CL'));});
  protected readonly totalEstimated=computed(()=>this.projects().reduce((s,p)=>s+this.effectiveEstimated(p),0));
  protected readonly totalActual=computed(()=>this.projects().reduce((s,p)=>s+this.effectiveActual(p),0));
  protected readonly activeProjects=computed(()=>this.projects().filter(p=>!['COMPLETED','CANCELLED'].includes(p.status)).length);
  protected readonly completedProjects=computed(()=>this.projects().filter(p=>p.status==='COMPLETED').length);
  protected readonly summaryProjects=computed(()=>{
    const kind=this.summaryDialog();
    if(kind==='ACTIVE')return this.projects().filter(p=>!['COMPLETED','CANCELLED'].includes(p.status)).sort((a,b)=>this.projectSort(a,b));
    if(kind==='COMPLETED')return this.projects().filter(p=>p.status==='COMPLETED').sort((a,b)=>this.projectSort(a,b));
    if(kind==='ESTIMATED')return this.projects().filter(p=>this.effectiveEstimated(p)>0).sort((a,b)=>this.effectiveEstimated(b)-this.effectiveEstimated(a));
    if(kind==='ACTUAL')return this.projects().filter(p=>this.effectiveActual(p)>0).sort((a,b)=>this.effectiveActual(b)-this.effectiveActual(a));
    return [];
  });
  protected readonly ganttProjects=computed(()=>this.projects().filter(p=>this.tasksFor(p).length>0).sort((a,b)=>a.title.localeCompare(b.title,'es-CL',{numeric:true})));
  protected readonly ganttTasks=computed(()=>{
    const q=this.ganttSearch().trim().toLocaleLowerCase('es-CL'),folder=this.ganttFolderFilter(),phase=this.ganttPhaseFilter();
    return [...this.tasks()].filter(task=>{
      if(folder!=='ALL'&&this.taskFolder(task)!==folder)return false;
      if(phase!=='ALL'&&(task.phase||'Sin fase')!==phase)return false;
      const hay=[task.title,task.responsibleName,task.location,this.taskSourceLabel(task),task.phase].filter(Boolean).join(' ').toLocaleLowerCase('es-CL');
      return !q||hay.includes(q);
    }).sort((a,b)=>(a.scheduledStart||'9999').localeCompare(b.scheduledStart||'9999')||a.title.localeCompare(b.title,'es-CL'));
  });
  protected readonly ganttFolderOptions=computed(()=>Array.from(new Set(this.tasks().map(task=>this.taskFolder(task)))).sort((a,b)=>a.localeCompare(b,'es-CL',{numeric:true})));
  protected readonly ganttPhaseOptions=computed(()=>Array.from(new Set(this.tasks().map(task=>task.phase||'Sin fase'))).sort((a,b)=>a.localeCompare(b,'es-CL')));
  protected readonly ganttGroups=computed(()=>{
    const folders=new Map<string,Map<string,WorkItem[]>>();
    for(const task of this.ganttTasks()){
      const folder=this.taskFolder(task),sheet=this.taskSourceLabel(task);
      if(!folders.has(folder))folders.set(folder,new Map());
      const map=folders.get(folder)!;map.set(sheet,[...(map.get(sheet)||[]),task]);
    }
    return Array.from(folders,([name,sheets])=>({name,total:Array.from(sheets.values()).reduce((sum,tasks)=>sum+tasks.length,0),sheets:Array.from(sheets,([name,tasks])=>({name,tasks,timeline:this.buildTimeline(tasks)})).sort((a,b)=>a.name.localeCompare(b.name,'es-CL',{numeric:true}))})).sort((a,b)=>this.folderOrder(a.name)-this.folderOrder(b.name)||a.name.localeCompare(b.name,'es-CL'));
  });
  protected readonly ganttTimeline=computed(()=>this.buildTimeline(this.ganttTasks()));
  protected readonly calendarDays=computed<CalendarDay[]>(()=>{const month=this.calendarMonth(),start=new Date(month.getFullYear(),month.getMonth(),1),offset=(start.getDay()+6)%7;start.setDate(start.getDate()-offset);return Array.from({length:42},(_,i)=>{const d=new Date(start);d.setDate(start.getDate()+i);const iso=this.iso(d);return{iso,day:d.getDate(),inMonth:d.getMonth()===month.getMonth(),events:this.calendarEvents().filter(e=>isDateOnlyWithinInclusiveRange(iso,e.scheduledStart,e.scheduledEnd))}})});
  protected readonly monthLabel=computed(()=>new Intl.DateTimeFormat('es-CL',{month:'long',year:'numeric'}).format(this.calendarMonth()));
  protected readonly costRows=computed(()=>[...this.projects()].sort((a,b)=>this.effectiveActual(b)-this.effectiveActual(a)||this.effectiveEstimated(b)-this.effectiveEstimated(a)));
  protected readonly costFolderOptions=computed(()=>Array.from(new Set(this.projects().map(project=>this.projectFolder(project)))).sort((a,b)=>this.folderOrder(a)-this.folderOrder(b)||a.localeCompare(b,'es-CL')));
  protected readonly costGroups=computed(()=>{
    const q=this.costSearch().trim().toLocaleLowerCase('es-CL'),folder=this.costFolderFilter(),kind=this.costKindFilter();
    const projects=this.projects().filter(project=>{
      if(folder!=='ALL'&&this.projectFolder(project)!==folder)return false;
      if(kind==='ESTIMATED'&&this.effectiveEstimated(project)<=0)return false;
      if(kind==='ACTUAL'&&this.effectiveActual(project)<=0)return false;
      if(kind==='SUPPORT')return false;
      const hay=[project.title,project.location,project.category,project.supplierName,project.materials].filter(Boolean).join(' ').toLocaleLowerCase('es-CL');
      return !q||hay.includes(q);
    });
    const grouped=new Map<string,WorkItem[]>();
    for(const project of projects){const key=this.projectFolder(project);grouped.set(key,[...(grouped.get(key)||[]),project]);}
    return Array.from(grouped,([name,items])=>({name,items:[...items].sort((a,b)=>this.projectSort(a,b))})).sort((a,b)=>this.folderOrder(a.name)-this.folderOrder(b.name)||a.name.localeCompare(b.name,'es-CL'));
  });
  protected readonly visibleSupports=computed(()=>{
    const q=this.costSearch().trim().toLocaleLowerCase('es-CL'),kind=this.costKindFilter();
    if(!['ALL','SUPPORT'].includes(kind))return[];
    return this.supports().filter(item=>!q||[item.title,item.category,item.location,JSON.stringify(this.meta(item)?.rows||[])].join(' ').toLocaleLowerCase('es-CL').includes(q));
  });
  protected readonly selectedProjectCostGroups=computed(()=>{
    const groups=new Map<string,{line:BudgetLine;index:number}[]>();
    this.selectedProjectLines().forEach((line,index)=>{
      const key=this.shortFile(line.sourceFile)||line.category||'Detalle importado';
      groups.set(key,[...(groups.get(key)||[]),{line,index}]);
    });
    return Array.from(groups,([name,entries])=>{
      const lines=entries.map(entry=>entry.line);
      const total=lines.reduce((s,l)=>s+Number(l.total||0),0);
      return{name,kind:this.costSourceKind(name,lines),entries,total,net:this.netFromGross(total),vat:this.vatFromGross(total)};
    }).sort((a,b)=>a.kind.localeCompare(b.kind)||a.name.localeCompare(b.name,'es-CL'));
  });

  constructor(){this.load();}
  private load():void{const requestedView=this.route.snapshot.queryParamMap.get('vista');if(requestedView==='projects'||requestedView==='gantt'||requestedView==='calendar'||requestedView==='costs')this.view.set(requestedView);this.loading.set(true);forkJoin({projects:this.http.get<WorkItem[]>('/api/work-items',{params:{area:'remodelacion',type:'REMODELING'},withCredentials:true}),tasks:this.http.get<WorkItem[]>('/api/work-items',{params:{area:'remodelacion',type:'REMODELING_GANTT'},withCredentials:true}),supports:this.http.get<WorkItem[]>('/api/work-items',{params:{area:'remodelacion',type:'REMODELING_SUPPORT'},withCredentials:true})}).subscribe({next:({projects,tasks,supports})=>{this.projects.set(projects);this.tasks.set(tasks);this.supports.set(supports);this.loading.set(false);const imported=Number(this.route.snapshot.queryParamMap.get('importados')||0),ganttImported=Number(this.route.snapshot.queryParamMap.get('tareas')||0),supportImported=Number(this.route.snapshot.queryParamMap.get('apoyos')||0);if(imported||ganttImported||supportImported){const parts:string[]=[];if(imported)parts.push(`${imported} proyecto(s)`);if(ganttImported)parts.push(`${ganttImported} tarea(s) Gantt`);if(supportImported)parts.push(`${supportImported} recurso(s) de apoyo`);this.successMessage.set(`${parts.join(' y ')} fueron incorporados o actualizados correctamente.`);if(supportImported){this.zoneFilter.set('Bodegas');this.expandedProjectFolders.update(current=>new Set([...current,'Bodegas']));const inventory=supports.find(item=>this.meta(item)?.supportType==='INVENTORY');if(inventory)this.expandedSupportFiles.update(current=>new Set([...current,inventory.id]));}this.router.navigate([],{relativeTo:this.route,queryParams:{importados:null,tareas:null,apoyos:null},queryParamsHandling:'merge',replaceUrl:true});}const edit=this.route.snapshot.queryParamMap.get('editar');if(edit){const p=projects.find(x=>x.id===edit);if(p)this.openProject(p);else{const t=tasks.find(x=>x.id===edit);if(t)this.openTaskEdit(t);}this.router.navigate([],{relativeTo:this.route,queryParams:{editar:null},queryParamsHandling:'merge',replaceUrl:true});}},error:()=>{this.errorMessage.set('No se pudieron cargar los proyectos de Remodelación.');this.loading.set(false);}});}
  protected setView(v:ViewMode):void{this.view.set(v);}
  protected openSummary(kind:SummaryKind):void{this.summaryDialog.set(kind);}
  protected closeSummary():void{this.summaryDialog.set(null);}
  protected summaryTitle():string{return({ACTIVE:'Proyectos activos',COMPLETED:'Remodelaciones finalizadas',ESTIMATED:'Detalle de presupuesto estimado',ACTUAL:'Detalle de gasto real'} as Record<SummaryKind,string>)[this.summaryDialog()||'ACTIVE'];}
  protected summaryEmpty():string{const kind=this.summaryDialog();if(kind==='ACTIVE')return'No hay proyectos de remodelación activos.';if(kind==='COMPLETED')return'No hay remodelaciones finalizadas.';if(kind==='ESTIMATED')return'No hay remodelaciones con presupuesto estimado registrado.';return'No hay remodelaciones con gasto real registrado.';}
  protected summaryAmount(project:WorkItem):number|null{return this.summaryDialog()==='ESTIMATED'?this.effectiveEstimated(project):this.summaryDialog()==='ACTUAL'?this.effectiveActual(project):null;}
  protected openSummaryProject(project:WorkItem):void{const kind=this.summaryDialog();this.closeSummary();this.openProject(project);if(kind==='ESTIMATED'||kind==='ACTUAL')this.setDetailTab('costs');}
  protected openProject(p:WorkItem):void{this.selectedProjectId.set(p.id);this.detailTab.set('summary');}
  protected closeProject():void{this.selectedProjectId.set(null);}
  protected setDetailTab(t:DetailTab):void{this.detailTab.set(t);}
  protected openCreateProject():void{this.editingProjectId.set(null);this.projectForm=this.emptyProject();this.projectModalOpen.set(true);}
  protected openEditProject(p:WorkItem):void{this.editingProjectId.set(p.id);this.projectForm={title:p.title,location:p.location||'',responsibleName:p.responsibleName||'',phase:p.phase||'Diseño',status:p.status,scheduledStart:p.scheduledStart||'',scheduledEnd:p.scheduledEnd||'',displayColor:normalizeDisplayColor(p.displayColor),textColor:normalizeHexColor(p.textColor),progressPercent:Number(p.progressPercent||0),category:p.category||'',supplierName:p.supplierName||'',materials:p.materials||'',estimatedCost:p.estimatedCost,actualCost:p.actualCost,description:p.description||'',notes:p.notes||''};this.projectModalOpen.set(true);}
  protected closeProjectModal():void{this.projectModalOpen.set(false);this.editingProjectId.set(null);}
  protected saveProject(force=false):void{if(!this.projectForm.title.trim()){this.errorMessage.set('Debes ingresar un nombre para la remodelación.');return;}if(!force&&!this.editingProjectId()){this.checkDuplicates(this.projectForm.title,this.projectForm.location,()=>this.performProjectSave());return;}this.performProjectSave();}
  private performProjectSave():void{const id=this.editingProjectId();const payload={areaSlug:'remodelacion',workType:'REMODELING',phase:this.nullText(this.projectForm.phase),plannedYear:null,plannedMonth:null,title:this.projectForm.title.trim(),description:this.nullText(this.projectForm.description),location:this.nullText(this.projectForm.location),responsibleName:this.nullText(this.projectForm.responsibleName),priority:'NORMAL',status:this.projectForm.status,scheduledStart:this.projectForm.scheduledStart||null,scheduledEnd:this.projectForm.scheduledEnd||null,displayColor:normalizeDisplayColor(this.projectForm.displayColor),textColor:normalizeHexColor(this.projectForm.textColor),progressPercent:Number(this.projectForm.progressPercent||0),notes:this.nullText(this.projectForm.notes),category:this.nullText(this.projectForm.category),assetName:null,frequency:null,season:null,materials:this.nullText(this.projectForm.materials),supplierName:this.nullText(this.projectForm.supplierName),estimatedCost:this.projectForm.estimatedCost,actualCost:this.projectForm.actualCost,importedData:id?this.projects().find(p=>p.id===id)?.importedData||null:null};this.saving.set(true);const req=id?this.http.put<WorkItem>(`/api/work-items/${id}`,payload,{withCredentials:true}):this.http.post<WorkItem>('/api/work-items',payload,{withCredentials:true});req.subscribe({next:saved=>{this.projects.update(items=>id?items.map(x=>x.id===saved.id?saved:x):[saved,...items]);this.saving.set(false);this.projectModalOpen.set(false);this.successMessage.set(id?'Remodelación actualizada correctamente.':'Remodelación creada correctamente.');},error:e=>this.handleSaveError(e)});}
  protected openTaskCreate(project?:WorkItem|null):void{const p=project||this.selectedProject();if(!p)return;this.editingTaskId.set(null);this.taskForm=this.emptyTask();this.taskForm.scheduledStart=p.scheduledStart||'';this.taskForm.scheduledEnd=p.scheduledEnd||'';this.taskModalOpen.set(true);}
  protected openTaskEdit(t:WorkItem):void{this.editingTaskId.set(t.id);this.taskForm={title:t.title,responsibleName:t.responsibleName||'',phase:t.phase||'Obras',status:t.status,scheduledStart:t.scheduledStart||'',scheduledEnd:t.scheduledEnd||'',displayColor:normalizeDisplayColor(t.displayColor),textColor:normalizeHexColor(t.textColor),progressPercent:Number(t.progressPercent||0),notes:t.notes||''};const meta=this.meta(t);if(meta?.parentProjectId)this.selectedProjectId.set(meta.parentProjectId);this.taskModalOpen.set(true);}
  protected closeTaskModal():void{this.taskModalOpen.set(false);this.editingTaskId.set(null);}
  protected saveTask(force=false):void{const project=this.selectedProject();if(!project||!this.taskForm.title.trim())return;if(!force&&!this.editingTaskId()){this.checkDuplicates(this.taskForm.title,project.location||'',()=>this.performTaskSave(project));return;}this.performTaskSave(project);}
  private performTaskSave(project:WorkItem):void{const id=this.editingTaskId(),pm=this.meta(project);const meta={sourceKind:'REMODELING_GANTT',parentProjectId:project.id,parentProjectKey:pm?.projectKey||project.id};const payload={areaSlug:'remodelacion',workType:'REMODELING_GANTT',phase:this.nullText(this.taskForm.phase),plannedYear:null,plannedMonth:null,title:this.taskForm.title.trim(),description:null,location:project.location,responsibleName:this.nullText(this.taskForm.responsibleName),priority:'NORMAL',status:this.taskForm.status,scheduledStart:this.taskForm.scheduledStart||null,scheduledEnd:this.taskForm.scheduledEnd||null,displayColor:normalizeDisplayColor(this.taskForm.displayColor),textColor:normalizeHexColor(this.taskForm.textColor),progressPercent:Number(this.taskForm.progressPercent||0),notes:this.nullText(this.taskForm.notes),category:project.category,assetName:null,frequency:null,season:null,materials:null,supplierName:null,estimatedCost:null,actualCost:null,importedData:JSON.stringify(meta)};this.saving.set(true);const req=id?this.http.put<WorkItem>(`/api/work-items/${id}`,payload,{withCredentials:true}):this.http.post<WorkItem>('/api/work-items',payload,{withCredentials:true});req.subscribe({next:saved=>{this.tasks.update(items=>id?items.map(x=>x.id===saved.id?saved:x):[...items,saved]);this.saving.set(false);this.taskModalOpen.set(false);this.successMessage.set(id?'Tarea Gantt actualizada.':'Tarea Gantt creada.');},error:e=>this.handleSaveError(e)});}
  private checkDuplicates(title:string,location:string,continueSave:()=>void):void{let params=new HttpParams().set('title',title);if(location.trim())params=params.set('location',location.trim());this.http.get<DuplicateRef[]>('/api/work-items/duplicates',{params,withCredentials:true}).subscribe({next:matches=>{if(matches.length){this.pendingSave=continueSave;this.duplicateDialog.set(matches);}else continueSave();},error:()=>continueSave()});}
  protected confirmDuplicate():void{const fn=this.pendingSave;this.pendingSave=null;this.duplicateDialog.set(null);if(fn)fn();}
  protected cancelDuplicate():void{this.pendingSave=null;this.duplicateDialog.set(null);}
  protected viewDuplicate(d:DuplicateRef):void{this.duplicateDialog.set(null);this.pendingSave=null;this.projectModalOpen.set(false);this.taskModalOpen.set(false);if(d.areaSlug==='remodelacion'){const p=this.projects().find(x=>x.id===d.id);if(p){this.openProject(p);return;}}this.router.navigate(['/areas',d.areaSlug],{queryParams:{editar:d.id}});}
  protected requestDeleteProject(p:WorkItem):void{const ids=[...this.tasksFor(p).map(t=>t.id),p.id];this.deleteDialog.set({title:'Eliminar remodelación',message:`¿Estás seguro de eliminar «${p.title}»${ids.length>1?' y sus '+(ids.length-1)+' tarea(s) Gantt':''}? Esta acción quedará registrada en Historial.`,ids});}
  protected requestDeleteTask(t:WorkItem):void{this.deleteDialog.set({title:'Eliminar tarea',message:`¿Estás seguro de eliminar «${t.title}»?`,ids:[t.id]});}
  protected cancelDelete():void{this.deleteDialog.set(null);}
  protected confirmDelete():void{const dialog=this.deleteDialog();if(!dialog)return;const ids=dialog.ids;this.deleteDialog.set(null);from(ids).pipe(concatMap(id=>this.http.delete(`/api/work-items/${id}`,{withCredentials:true})),toArray()).subscribe({next:()=>{this.projects.update(x=>x.filter(i=>!ids.includes(i.id)));this.tasks.update(x=>x.filter(i=>!ids.includes(i.id)));this.supports.update(x=>x.filter(i=>!ids.includes(i.id)));if(this.selectedProjectId()&&ids.includes(this.selectedProjectId()!))this.selectedProjectId.set(null);this.successMessage.set('Registro(s) eliminado(s) correctamente.');},error:()=>this.errorMessage.set('No se pudieron eliminar todos los registros.')});}
  protected tasksFor(project:WorkItem|null):WorkItem[]{if(!project)return[];const pm=this.meta(project);return this.tasks().filter(t=>{const tm=this.meta(t);return tm?.parentProjectId===project.id|| (!!pm?.projectKey&&tm?.parentProjectKey===pm.projectKey)||(!tm?.parentProjectId&&!tm?.parentProjectKey&&t.location&&project.location&&t.location===project.location);});}
  protected phaseClass(phase:string|null):string{const n=(phase||'').toLowerCase();if(n.includes('hito'))return'hito';if(n.includes('compra')||n.includes('cotiza'))return'compras';if(n.includes('plan'))return'planificacion';if(n.includes('dise'))return'diseno';if(n.includes('recep')||n.includes('cierre'))return'cierre';if(n.includes('prueba'))return'pruebas';return'obras';}
  protected selectProjectFolder(folder:string):void{this.zoneFilter.set(folder);if(folder!=='ALL')this.expandedProjectFolders.update(current=>new Set([...current,folder]));}
  protected toggleProjectFolder(name:string):void{this.expandedProjectFolders.update(current=>{const next=new Set(current);next.has(name)?next.delete(name):next.add(name);return next;});}
  protected isProjectFolderOpen(name:string):boolean{return this.search().trim().length>0||this.zoneFilter()===name||this.expandedProjectFolders().has(name);}
  protected toggleProjectZone(key:string):void{this.expandedProjectZones.update(current=>{const next=new Set(current);next.has(key)?next.delete(key):next.add(key);return next;});}
  protected isProjectZoneOpen(key:string):boolean{return this.search().trim().length>0||this.expandedProjectZones().has(key);}
  protected toggleGanttFolder(name:string):void{this.expandedGanttFolders.update(current=>{const next=new Set(current);next.has(name)?next.delete(name):next.add(name);return next;});}
  protected isGanttFolderOpen(name:string):boolean{return this.expandedGanttFolders().has(name);}
  protected toggleGanttSheet(key:string):void{this.expandedGanttSheets.update(current=>{const next=new Set(current);next.has(key)?next.delete(key):next.add(key);return next;});}
  protected isGanttSheetOpen(key:string):boolean{return this.expandedGanttSheets().has(key);}
  protected toggleCostFolder(name:string):void{this.expandedCostFolders.update(current=>{const next=new Set(current);next.has(name)?next.delete(name):next.add(name);return next;});}
  protected isCostFolderOpen(name:string):boolean{return this.expandedCostFolders().has(name);}
  protected toggleCostProject(id:string):void{this.expandedCostProjects.update(current=>{const next=new Set(current);next.has(id)?next.delete(id):next.add(id);return next;});}
  protected isCostProjectOpen(id:string):boolean{return this.expandedCostProjects().has(id);}
  protected supportRows(item:WorkItem):Record<string,unknown>[] { return this.meta(item)?.rows||[]; }
  protected budgetLinesFor(project:WorkItem):BudgetLine[]{return this.meta(project)?.budgetLines||[];}
  protected supportTypeLabel(item:WorkItem):string{return this.meta(item)?.supportType==='PROVIDERS'?'Proveedores':'Inventario / bodega';}
  protected supportRowPrimary(row:Record<string,unknown>):string{return String(row['producto']||row['tipo de producto']||row['nombre proveedor']||row['proveedor']||row['categoria']||'Registro');}
  protected supportRowSecondary(row:Record<string,unknown>):string{return [row['fecha']?this.formatDate(String(row['fecha'])):null,row['proveedor'],row['categoria'],row['destino'],row['contacto'],row['tienda']].filter(Boolean).map(String).join(' · ');}
  protected supportYearOptions(item:WorkItem):string[]{return Array.from(new Set(this.supportRows(item).map(row=>String(row['fecha']||'').slice(0,4)).filter(year=>/^\d{4}$/.test(year)))).sort((a,b)=>Number(b)-Number(a));}
  protected supportSheetOptions(item:WorkItem):{name:string;title:string}[]{const seen=new Map<string,string>();for(const row of this.supportRows(item)){const name=String(row['_sheet']||'Hoja');if(!seen.has(name))seen.set(name,String(row['_sheetTitle']||name));}return Array.from(seen,([name,title])=>({name,title}));}
  protected supportVisibleRows(item:WorkItem):Record<string,unknown>[]{const year=this.inventoryYearFilter(),sheet=this.inventorySheetFilter();return this.supportRows(item).filter(row=>{const rowSheet=String(row['_sheet']||'Hoja');if(sheet!=='ALL'&&rowSheet!==sheet)return false;if(year==='ALL')return true;if(year==='UNDATED')return !row['fecha'];return String(row['fecha']||'').startsWith(year+'-');});}
  protected supportSheetGroups(item:WorkItem):{name:string;title:string;rows:Record<string,unknown>[];total:number;net:number;vat:number;dated:number;original?:SheetVatSummary}[]{
    const groups=new Map<string,{title:string;rows:Record<string,unknown>[]}>();const originals=this.meta(item)?.sheetSummaries||{};
    for(const row of this.supportVisibleRows(item)){const name=String(row['_sheet']||'Hoja');const title=String(row['_sheetTitle']||name);if(!groups.has(name))groups.set(name,{title,rows:[]});groups.get(name)!.rows.push(row);}
    return Array.from(groups,([name,group])=>{const total=group.rows.reduce((sum,row)=>sum+this.supportNumber(row['valorTotal']),0);return{name,title:group.title,rows:group.rows,total,net:this.netFromGross(total),vat:this.vatFromGross(total),dated:group.rows.filter(row=>!!row['fecha']).length,original:originals[name]};});
  }
  protected supportOverallTotals(item:WorkItem):{gross:number;net:number;vat:number;rows:number}{const rows=this.supportVisibleRows(item);const gross=rows.reduce((sum,row)=>sum+this.supportNumber(row['valorTotal']),0);return{gross,net:this.netFromGross(gross),vat:this.vatFromGross(gross),rows:rows.length};}
  protected supportNumber(value:unknown):number{const n=Number(value??0);return Number.isFinite(n)?n:0;}
  protected supportQuantity(row:Record<string,unknown>):string{return String(row['cantidad']??'—');}
  protected supportDate(row:Record<string,unknown>):string{return row['fecha']?this.formatDate(String(row['fecha'])):'Sin fecha';}
  protected originalVatLabel(item:WorkItem,sheetName:string):string{const original=this.meta(item)?.sheetSummaries?.[sheetName];if(!original)return'';const parts:string[]=[];if(Number(original.withVat||0)>0)parts.push(`Excel con IVA ${this.formatMoney(original.withVat)}`);if(Number(original.withoutVat||0)>0)parts.push(`sin IVA ${this.formatMoney(original.withoutVat)}`);return parts.join(' · ');}
  protected netFromGross(gross:number|null|undefined):number{return Math.round(Number(gross||0)/(1+this.ivaRate));}
  protected vatFromGross(gross:number|null|undefined):number{return Math.max(0,Number(gross||0)-this.netFromGross(gross));}
  protected toggleSupportFile(id:string):void{this.expandedSupportFiles.update(current=>{const next=new Set(current);next.has(id)?next.delete(id):next.add(id);return next;});}
  protected isSupportFileOpen(id:string):boolean{return this.expandedSupportFiles().has(id);}
  protected toggleSupportSheet(key:string):void{this.expandedSupportSheets.update(current=>{const next=new Set(current);next.has(key)?next.delete(key):next.add(key);return next;});}
  protected isSupportSheetOpen(key:string):boolean{return this.expandedSupportSheets().has(key);}
  protected requestDeleteSupport(item:WorkItem):void{this.deleteDialog.set({title:'Eliminar información de bodega',message:`¿Estás seguro de eliminar «${item.title}»? Esta acción quedará registrada en Historial.`,ids:[item.id]});}

  protected openSupportRowCreate(item:WorkItem,sheetName?:string,sheetTitle?:string):void{this.editingSupportId.set(item.id);this.editingSupportRowIndex.set(null);const first=this.supportSheetOptions(item)[0];this.supportRowForm=this.emptySupportRow();this.supportRowForm.sheet=sheetName||first?.name||'GENERAL';this.supportRowForm.sheetTitle=sheetTitle||first?.title||this.supportRowForm.sheet;this.supportRowModalOpen.set(true);}
  protected openSupportRowEdit(item:WorkItem,row:Record<string,unknown>):void{const index=this.findSupportRowIndex(item,row);if(index<0)return;this.editingSupportId.set(item.id);this.editingSupportRowIndex.set(index);this.supportRowForm={sheet:String(row['_sheet']||'GENERAL'),sheetTitle:String(row['_sheetTitle']||row['_sheet']||'GENERAL'),fecha:String(row['fecha']||''),categoria:String(row['categoria']||''),proveedor:String(row['proveedor']||''),producto:String(row['producto']||''),cantidad:String(row['cantidad']||''),valorUnitario:this.nullNumber(row['valorUnitario']),valorTotal:this.nullNumber(row['valorTotal']),destino:String(row['destino']||'')};this.supportRowModalOpen.set(true);}
  protected closeSupportRowModal():void{this.supportRowModalOpen.set(false);this.editingSupportId.set(null);this.editingSupportRowIndex.set(null);}
  protected saveSupportRow():void{const item=this.supports().find(value=>value.id===this.editingSupportId());if(!item||!this.supportRowForm.producto.trim()){this.errorMessage.set('Debes ingresar el producto o insumo.');return;}const meta={...(this.meta(item)||{})};const rows=[...(meta.rows||[])];const total=this.resolveLineTotal(this.supportRowForm.cantidad,this.supportRowForm.valorUnitario,this.supportRowForm.valorTotal);const record:Record<string,unknown>={fecha:this.supportRowForm.fecha||null,categoria:this.nullText(this.supportRowForm.categoria),proveedor:this.nullText(this.supportRowForm.proveedor),producto:this.supportRowForm.producto.trim(),cantidad:this.nullText(this.supportRowForm.cantidad),valorUnitario:this.supportRowForm.valorUnitario,valorTotal:total,destino:this.nullText(this.supportRowForm.destino),_sheet:this.supportRowForm.sheet||'GENERAL',_sheetTitle:this.supportRowForm.sheetTitle||this.supportRowForm.sheet||'GENERAL',_row:this.editingSupportRowIndex()===null?null:rows[this.editingSupportRowIndex()!]?.['_row'],_uid:this.editingSupportRowIndex()===null?`manual-${Date.now()}`:rows[this.editingSupportRowIndex()!]?.['_uid']};const index=this.editingSupportRowIndex();if(index===null)rows.push(record);else rows[index]=record;meta.rows=rows;meta.sheetNames=Array.from(new Set(rows.map(row=>String(row['_sheet']||'GENERAL'))));meta.vatRate=this.ivaRate;this.persistImportedData(item,meta,'SUPPORT',index===null?'Ítem de bodega agregado.':'Ítem de bodega actualizado.');}
  protected requestDeleteSupportRow(item:WorkItem,row:Record<string,unknown>):void{const index=this.findSupportRowIndex(item,row);if(index<0)return;this.pendingDetailDelete=()=>{const meta={...(this.meta(item)||{})};const rows=[...(meta.rows||[])];rows.splice(index,1);meta.rows=rows;this.persistImportedData(item,meta,'SUPPORT','Ítem de bodega eliminado.');};this.detailDeleteDialog.set({title:'Eliminar ítem de bodega',message:`¿Estás seguro de eliminar «${this.supportRowPrimary(row)}»?`});}

  protected openBudgetLineCreate(project:WorkItem):void{this.selectedProjectId.set(project.id);this.editingBudgetLineIndex.set(null);this.budgetLineForm=this.emptyBudgetLine();this.budgetLineModalOpen.set(true);}
  protected openBudgetLineEdit(project:WorkItem,index:number):void{const line=this.budgetLinesFor(project)[index];if(!line)return;this.selectedProjectId.set(project.id);this.editingBudgetLineIndex.set(index);this.budgetLineForm={kind:line.kind==='ESTIMATED'?'ESTIMATED':'ACTUAL',date:line.date||'',category:line.category||'',provider:line.provider||'',product:line.product||'',quantity:line.quantity||'',unitValue:line.unitValue??null,total:line.total??null,sourceFile:line.sourceFile||'Registro manual OMM',sourceSheet:line.sourceSheet||'Registro manual'};this.budgetLineModalOpen.set(true);}
  protected closeBudgetLineModal():void{this.budgetLineModalOpen.set(false);this.editingBudgetLineIndex.set(null);}
  protected saveBudgetLine():void{const project=this.selectedProject();if(!project||!this.budgetLineForm.product.trim()){this.errorMessage.set('Debes ingresar el nombre del ítem.');return;}const meta={...(this.meta(project)||{})};const lines=[...(meta.budgetLines||[])];const index=this.editingBudgetLineIndex();const line:BudgetLine={kind:this.budgetLineForm.kind,date:this.budgetLineForm.date||undefined,category:this.nullText(this.budgetLineForm.category)||undefined,provider:this.nullText(this.budgetLineForm.provider)||undefined,product:this.budgetLineForm.product.trim(),quantity:this.nullText(this.budgetLineForm.quantity)||undefined,unitValue:this.budgetLineForm.unitValue??undefined,total:this.resolveLineTotal(this.budgetLineForm.quantity,this.budgetLineForm.unitValue,this.budgetLineForm.total),sourceFile:this.budgetLineForm.sourceFile||'Registro manual OMM',sourceSheet:this.budgetLineForm.sourceSheet||'Registro manual'};if(index===null)lines.push(line);else lines[index]=line;meta.budgetLines=lines;this.persistImportedData(project,meta,'PROJECT',index===null?'Ítem financiero agregado.':'Ítem financiero actualizado.',lines);}
  protected requestDeleteBudgetLine(project:WorkItem,index:number,line:BudgetLine):void{this.pendingDetailDelete=()=>{const meta={...(this.meta(project)||{})};const lines=[...(meta.budgetLines||[])];lines.splice(index,1);meta.budgetLines=lines;this.persistImportedData(project,meta,'PROJECT','Ítem financiero eliminado.',lines);};this.detailDeleteDialog.set({title:'Eliminar ítem financiero',message:`¿Estás seguro de eliminar «${line.product||'este registro'}»?`});}
  protected cancelDetailDelete():void{this.pendingDetailDelete=null;this.detailDeleteDialog.set(null);}
  protected confirmDetailDelete():void{const fn=this.pendingDetailDelete;this.pendingDetailDelete=null;this.detailDeleteDialog.set(null);if(fn)fn();}

  private findSupportRowIndex(item:WorkItem,row:Record<string,unknown>):number{const rows=this.supportRows(item);if(row['_uid']){const idx=rows.findIndex(value=>value['_uid']===row['_uid']);if(idx>=0)return idx;}return rows.findIndex(value=>String(value['_sheet']||'')===String(row['_sheet']||'')&&String(value['_row']||'')===String(row['_row']||'')&&String(value['producto']||'')===String(row['producto']||'')&&String(value['proveedor']||'')===String(row['proveedor']||''));}
  private persistImportedData(item:WorkItem,meta:ProjectMeta,collection:'PROJECT'|'SUPPORT',success:string,lines?:BudgetLine[]):void{const totals=collection==='PROJECT'?this.recalculateProjectMoney(item,lines||meta.budgetLines||[]):{estimated:item.estimatedCost,actual:item.actualCost};const payload=this.itemPayload(item,JSON.stringify(meta),totals.estimated,totals.actual);this.saving.set(true);this.http.put<WorkItem>(`/api/work-items/${item.id}`,payload,{withCredentials:true}).subscribe({next:saved=>{if(collection==='PROJECT')this.projects.update(items=>items.map(value=>value.id===saved.id?saved:value));else this.supports.update(items=>items.map(value=>value.id===saved.id?saved:value));this.saving.set(false);this.budgetLineModalOpen.set(false);this.supportRowModalOpen.set(false);this.editingBudgetLineIndex.set(null);this.editingSupportRowIndex.set(null);this.editingSupportId.set(null);this.successMessage.set(success);},error:error=>this.handleSaveError(error)});}
  private recalculateProjectMoney(project:WorkItem,lines:BudgetLine[]):{estimated:number|null;actual:number|null}{const old=this.budgetLinesFor(project);const oldEstimated=old.filter(line=>line.kind==='ESTIMATED').reduce((sum,line)=>sum+Number(line.total||0),0),oldActual=old.filter(line=>line.kind==='ACTUAL').reduce((sum,line)=>sum+Number(line.total||0),0);const newEstimated=lines.filter(line=>line.kind==='ESTIMATED').reduce((sum,line)=>sum+Number(line.total||0),0),newActual=lines.filter(line=>line.kind==='ACTUAL').reduce((sum,line)=>sum+Number(line.total||0),0);const manualEstimated=Math.max(0,Number(project.estimatedCost||0)-oldEstimated),manualActual=Math.max(0,Number(project.actualCost||0)-oldActual);const estimated=manualEstimated+newEstimated,actual=manualActual+newActual;return{estimated:estimated>0?estimated:null,actual:actual>0?actual:null};}
  private itemPayload(item:WorkItem,importedData:string|null,estimatedCost:number|null=item.estimatedCost,actualCost:number|null=item.actualCost){return{areaSlug:item.areaSlug,workType:item.workType,phase:item.phase,plannedYear:null,plannedMonth:null,title:item.title,description:item.description,location:item.location,responsibleName:item.responsibleName,priority:item.priority,status:item.status,scheduledStart:item.scheduledStart,scheduledEnd:item.scheduledEnd,displayColor:normalizeDisplayColor(item.displayColor),textColor:normalizeHexColor(item.textColor),progressPercent:Number(item.progressPercent||0),notes:item.notes,category:item.category,assetName:null,frequency:null,season:null,materials:item.materials,supplierName:item.supplierName,estimatedCost,actualCost,importedData};}
  protected resolveLineTotal(quantity:string,unitValue:number|null,total:number|null):number{if(total!==null&&Number.isFinite(Number(total)))return Math.max(0,Number(total));const qty=Number(String(quantity||'').replace(',','.'));if(Number.isFinite(qty)&&qty>0&&unitValue!==null)return Math.max(0,Math.round(qty*Number(unitValue)));return Math.max(0,Number(unitValue||0));}
  private nullNumber(value:unknown):number|null{const n=Number(value);return Number.isFinite(n)?n:null;}
  protected projectFolder(project:WorkItem):string{return this.folderFor(project.location||project.category||project.title);}
  protected taskFolder(task:WorkItem):string{const sourceFolder=this.folderFor(this.taskSourceLabel(task));return sourceFolder!=='Otros'?sourceFolder:this.folderFor(task.location||'');}
  protected taskSourceLabel(task:WorkItem):string{const meta=this.meta(task);if(meta?.sourceGroup)return String(meta.sourceGroup);const file=this.shortFile(meta?.sourceFile);if(file){const n=file.replace(/\.xlsx$/i,'').replace(/^carta\s*gantt[-_ ]*/i,'').replace(/^remodelacion[-_ ]*/i,'').trim();if(n)return n;}return task.location||'Proyecto';}
  protected folderIcon(folder:string):string{if(folder==='Habitaciones')return'fa-solid fa-bed';if(folder==='Exterior')return'fa-solid fa-tree';if(folder==='Áreas comunes')return'fa-solid fa-building';if(folder==='Oficinas')return'fa-solid fa-briefcase';if(folder==='Bodegas')return'fa-solid fa-boxes-stacked';if(folder==='Cabañas')return'fa-solid fa-house';if(folder==='Centro de eventos')return'fa-solid fa-champagne-glasses';return'fa-solid fa-folder';}
  protected shortFile(value:string|null|undefined):string{if(!value)return'';const clean=value.replaceAll('\\','/');return clean.slice(clean.lastIndexOf('/')+1);}
  protected costSourceKind(name:string,lines:BudgetLine[]):string{const n=name.toLocaleLowerCase('es-CL');if(n.includes('insumo'))return'Insumos';if(n.includes('presu')||lines.every(l=>l.kind==='ESTIMATED'))return'Presupuesto';if(n.includes('gasto')||lines.some(l=>l.kind==='ACTUAL'))return'Gasto real';return'Detalle';}
  protected groupTimeline(tasks:WorkItem[]){return this.buildTimeline(tasks);}
  private folderFor(value:string):string{const n=value.toLocaleLowerCase('es-CL').normalize('NFD').replace(/\p{M}+/gu,'');if(/habitacion|\b10\d\b|\b20\d\b|\b30\d\b/.test(n))return'Habitaciones';if(/piscina|jardin|quincho|terraza|acopio|exterior/.test(n))return'Exterior';if(/cabana/.test(n))return'Cabañas';if(/cocina|comedor|pasillo|salon/.test(n))return'Áreas comunes';if(/oficina/.test(n))return'Oficinas';if(/bodega/.test(n))return'Bodegas';if(/stand|evento/.test(n))return'Centro de eventos';return'Otros';}
  private folderOrder(name:string):number{return['Habitaciones','Áreas comunes','Exterior','Cabañas','Oficinas','Bodegas','Centro de eventos','Otros'].indexOf(name)>=0?['Habitaciones','Áreas comunes','Exterior','Cabañas','Oficinas','Bodegas','Centro de eventos','Otros'].indexOf(name):99;}
  protected statusLabel(s:string):string{return({PLANNED:'Planificada',PENDING:'Pendiente',IN_PROGRESS:'En ejecución',COMPLETED:'Finalizada',OVERDUE:'Atrasada',CANCELLED:'Cancelada'} as Record<string,string>)[s]||s;}
  protected effectiveEstimated(project:WorkItem):number{const direct=Number(project.estimatedCost||0);if(direct>0)return direct;return (this.meta(project)?.budgetLines||[]).filter(line=>line.kind==='ESTIMATED').reduce((sum,line)=>sum+Number(line.total||0),0);}
  protected projectsEstimated(items:WorkItem[]):number{return items.reduce((sum,project)=>sum+this.effectiveEstimated(project),0);}
  protected projectsActual(items:WorkItem[]):number{return items.reduce((sum,project)=>sum+this.effectiveActual(project),0);}
  protected effectiveActual(project:WorkItem):number{const direct=Number(project.actualCost||0);if(direct>0)return direct;return (this.meta(project)?.budgetLines||[]).filter(line=>line.kind==='ACTUAL').reduce((sum,line)=>sum+Number(line.total||0),0);}
  protected formatMoney(v:number|null|undefined):string{return new Intl.NumberFormat('es-CL',{style:'currency',currency:'CLP',maximumFractionDigits:0}).format(Number(v||0));}
  protected formatDate(v:string|null|undefined):string{return v?new Date(v.slice(0,10)+'T12:00:00').toLocaleDateString('es-CL'):'Sin fecha';}
  protected formatProgress(v:number|null|undefined):number{return Math.max(0,Math.min(100,Math.round(Number(v||0))));}
  protected activityColor(item:WorkItem):string|null{return normalizeDisplayColor(item.displayColor);}
  protected activityTextColor(item:WorkItem):string{return resolveActivityTextColor(item.displayColor,item.textColor);}
  protected sourceName(line:BudgetLine):string{return [line.sourceFile,line.sourceSheet].filter(Boolean).join(' · ');}
  protected lineKindLabel(line:BudgetLine):string{return line.kind==='ESTIMATED'?'Presupuesto':'Gasto real';}
  protected shiftMonth(delta:number):void{const m=this.calendarMonth();this.calendarMonth.set(new Date(m.getFullYear(),m.getMonth()+delta,1));}
  protected goToday():void{const n=new Date();this.calendarMonth.set(new Date(n.getFullYear(),n.getMonth(),1));}
  protected openCalendarItem(item:WorkItem):void{if(item.workType==='REMODELING_GANTT')this.openTaskEdit(item);else this.openProject(item);}
  private calendarEvents():WorkItem[]{return [...this.projects(),...this.tasks()].filter(i=>normalizeDateOnlyRange(i.scheduledStart,i.scheduledEnd)!==null);}
  private projectSort(a:WorkItem,b:WorkItem):number{const closedA=['COMPLETED','CANCELLED'].includes(a.status),closedB=['COMPLETED','CANCELLED'].includes(b.status);if(closedA!==closedB)return closedA?1:-1;const ad=a.scheduledEnd||a.scheduledStart||'9999-99-99',bd=b.scheduledEnd||b.scheduledStart||'9999-99-99';return ad.localeCompare(bd)||a.title.localeCompare(b.title,'es-CL',{numeric:true});}
  private buildTimeline(items:WorkItem[]){
    const rows=items.map(item=>{const range=normalizeDateOnlyRange(item.scheduledStart,item.scheduledEnd);return range?{item,start:range.startDay,end:range.endDay}:null;})
      .filter((row):row is {item:WorkItem;start:number;end:number}=>row!==null)
      .sort((a,b)=>a.start-b.start||a.item.title.localeCompare(b.item.title,'es-CL'));
    if(!rows.length)return null;
    const first=Math.min(...rows.map(r=>r.start)),last=Math.max(...rows.map(r=>r.end));
    const days=Math.max(1,last-first+1);
    const labelCount=Math.min(10,Math.max(3,Math.ceil(days/7)+1));
    const labels=Array.from({length:labelCount},(_,i)=>{
      const offset=labelCount===1?0:Math.round((days-1)*i/(labelCount-1));
      return{left:days===1?0:offset/(days-1)*100,text:new Intl.DateTimeFormat('es-CL',{day:'2-digit',month:'short'}).format(dateOnlyToLocalDate(dateOnlyKeyFromDay(first+offset)))};
    });
    const rangeFmt=new Intl.DateTimeFormat('es-CL',{day:'2-digit',month:'short',year:'numeric'});
    return{
      labels,
      rangeLabel:`${rangeFmt.format(dateOnlyToLocalDate(dateOnlyKeyFromDay(first)))} — ${rangeFmt.format(dateOnlyToLocalDate(dateOnlyKeyFromDay(last)))}`,
      undatedCount:items.length-rows.length,
      rows:rows.map(r=>({item:r.item,left:(r.start-first)/days*100,width:Math.max(1.8,(r.end-r.start+1)/days*100),progress:this.formatProgress(r.item.progressPercent)}))
    };
  }
  private meta(item:WorkItem|null|undefined):ProjectMeta|null{if(!item?.importedData)return null;try{return JSON.parse(item.importedData) as ProjectMeta;}catch{return null;}}
  private emptyProject():ProjectForm{return{title:'',location:'',responsibleName:'',phase:'Diseño',status:'PLANNED',scheduledStart:'',scheduledEnd:'',displayColor:OMM_DISPLAY_COLOR_PALETTE[0],textColor:null,progressPercent:0,category:'',supplierName:'',materials:'',estimatedCost:null,actualCost:null,description:'',notes:''};}
  private emptyTask():TaskForm{return{title:'',responsibleName:'',phase:'Obras',status:'PLANNED',scheduledStart:'',scheduledEnd:'',displayColor:OMM_DISPLAY_COLOR_PALETTE[0],textColor:null,progressPercent:0,notes:''};}
  private emptyBudgetLine():BudgetLineForm{return{kind:'ACTUAL',date:'',category:'',provider:'',product:'',quantity:'',unitValue:null,total:null,sourceFile:'Registro manual OMM',sourceSheet:'Registro manual'};}
  private emptySupportRow():SupportRowForm{return{sheet:'GENERAL',sheetTitle:'GENERAL',fecha:'',categoria:'',proveedor:'',producto:'',cantidad:'',valorUnitario:null,valorTotal:null,destino:''};}
  private nullText(v:string):string|null{const t=v.trim();return t||null;}
  private handleSaveError(error:HttpErrorResponse):void{this.saving.set(false);this.errorMessage.set(error.error?.message||error.error?.detail||'No se pudo guardar el registro.');}
  private iso(d:Date):string{return`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
}
