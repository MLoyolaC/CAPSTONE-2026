import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnDestroy, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { switchMap } from 'rxjs';

import { AuthService } from '../../core/auth/auth.service';
import { passwordPolicyValidator } from '../../core/auth/password-policy';
import {
  SessionExperienceService,
  WELCOME_HOLD_MS,
} from '../../core/auth/session-experience.service';
import { AppSettingsService } from '../../core/settings/app-settings.service';
import { ThemeToggleComponent } from '../../shared/theme-toggle/theme-toggle';
import { PasswordRequirementsComponent } from '../../shared/password-requirements/password-requirements';

type ActivePanel =
  | 'login'
  | 'recovery-email'
  | 'recovery-code'
  | 'recovery-password'
  | 'recovery-success';
interface RecoveryRequestResponse { message: string; cooldownSeconds: number; }
interface VerificationResponse { resetToken: string; expiresAt: string; }

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule, ThemeToggleComponent, PasswordRequirementsComponent],
  templateUrl: './login.html',
  styleUrl: './login.scss',
})
export class LoginComponent implements OnDestroy {
  private readonly formBuilder = inject(FormBuilder);
  private readonly http = inject(HttpClient);
  private readonly authService = inject(AuthService);
  private readonly router = inject(Router);
  private readonly sessionExperience = inject(SessionExperienceService);
  protected readonly settings = inject(AppSettingsService);

  protected readonly loading = signal(false);
  protected readonly errorMessage = signal('');
  protected readonly activePanel = signal<ActivePanel>('login');
  protected readonly recoveryLoading = signal(false);
  protected readonly recoveryError = signal('');
  protected readonly recoveryMessage = signal('');
  protected readonly recoveryEmail = signal('');
  protected readonly cooldown = signal(0);
  protected readonly showNewPassword = signal(false);
  protected readonly showConfirmation = signal(false);
  private readonly resetToken = signal('');
  private cooldownTimer?: ReturnType<typeof setInterval>;

  protected readonly form = this.formBuilder.nonNullable.group({
    username: ['', [Validators.required, Validators.maxLength(50)]],
    password: ['', [Validators.required, Validators.maxLength(128)]],
  });

  protected readonly recoveryForm = this.formBuilder.nonNullable.group({
    email: ['', [Validators.required, Validators.email, Validators.maxLength(254)]],
  });

  protected readonly codeForm = this.formBuilder.nonNullable.group({
    code: ['', [Validators.required, Validators.pattern(/^\d{6}$/)]],
  });

  protected readonly passwordForm = this.formBuilder.nonNullable.group({
    password: ['', [Validators.required, passwordPolicyValidator]],
    confirmation: ['', [Validators.required, Validators.maxLength(128)]],
  });

  ngOnDestroy(): void {
    this.clearCooldown();
  }

  protected showRecovery(): void {
    this.errorMessage.set('');
    this.resetRecovery();
    this.activePanel.set('recovery-email');
  }

  protected showLogin(): void {
    this.resetRecovery();
    this.activePanel.set('login');
  }

  protected submitRecovery(): void {
    if (this.recoveryForm.invalid || this.recoveryLoading()) {
      this.recoveryForm.markAllAsTouched();
      return;
    }
    this.requestCode(this.recoveryForm.controls.email.value);
  }

  protected resendCode(): void {
    if (this.cooldown() > 0 || this.recoveryLoading()) return;
    this.requestCode(this.recoveryEmail());
  }

  protected verifyCode(): void {
    this.recoveryError.set('');
    if (this.codeForm.invalid || this.recoveryLoading()) {
      this.codeForm.markAllAsTouched();
      return;
    }
    this.recoveryLoading.set(true);
    this.authService.initializeCsrf().pipe(
      switchMap(() =>
        this.http.post<VerificationResponse>(
          '/api/auth/password-recovery/verify',
          { email: this.recoveryEmail(), code: this.codeForm.controls.code.value },
          { withCredentials: true },
        ),
      ),
    ).subscribe({
      next: response => {
        this.recoveryLoading.set(false);
        this.resetToken.set(response.resetToken);
        this.recoveryMessage.set('Código verificado. Crea una nueva contraseña.');
        this.activePanel.set('recovery-password');
      },
      error: (error: HttpErrorResponse) => {
        this.recoveryLoading.set(false);
        this.codeForm.controls.code.reset();
        this.recoveryError.set(error.error?.message || 'No fue posible verificar el código.');
      },
    });
  }

  protected resetPassword(): void {
    this.recoveryError.set('');
    if (this.passwordForm.invalid || this.recoveryLoading()) {
      this.passwordForm.markAllAsTouched();
      return;
    }
    const { password, confirmation } = this.passwordForm.getRawValue();
    if (password !== confirmation) {
      this.recoveryError.set('Las contraseñas no coinciden.');
      return;
    }
    this.recoveryLoading.set(true);
    this.authService.initializeCsrf().pipe(
      switchMap(() =>
        this.http.post(
          '/api/auth/password-recovery/reset',
          { resetToken: this.resetToken(), password, passwordConfirmation: confirmation },
          { withCredentials: true },
        ),
      ),
    ).subscribe({
      next: () => {
        this.recoveryLoading.set(false);
        this.passwordForm.reset();
        this.resetToken.set('');
        this.activePanel.set('recovery-success');
      },
      error: (error: HttpErrorResponse) => {
        this.recoveryLoading.set(false);
        this.recoveryError.set(
          error.error?.message || 'No fue posible restablecer la contraseña.',
        );
      },
    });
  }

  protected submit(): void {
    if (this.form.invalid || this.loading()) {
      this.form.markAllAsTouched();
      return;
    }
    this.loading.set(true);
    this.errorMessage.set('');
    const { username, password } = this.form.getRawValue();
    this.authService.login(username, password).subscribe({
      next: user => {
        this.sessionExperience.beginAuthenticatedSession();
        if (!this.settings.welcomeAnimation()) {
          void this.router.navigateByUrl(this.authService.firstAuthorizedRoute(user));
          return;
        }
        const displayName = this.settings.displayNameFor(user.username);
        this.sessionExperience.showWelcome(displayName);
        setTimeout(() => {
          this.sessionExperience.finishTransition();
          void this.router.navigateByUrl(this.authService.firstAuthorizedRoute(user));
        }, WELCOME_HOLD_MS);
      },
      error: (error: HttpErrorResponse) => {
        this.loading.set(false);
        this.form.controls.password.reset();
        if (error.status === 401) {
          this.errorMessage.set('Usuario o contraseña incorrectos.');
          return;
        }
        if (error.status === 403) {
          this.errorMessage.set(
            'No se pudo validar la solicitud de seguridad. Recarga la página e intenta nuevamente.',
          );
          return;
        }
        this.errorMessage.set('No se pudo conectar con el servidor.');
      },
    });
  }

  private requestCode(email: string): void {
    this.recoveryLoading.set(true);
    this.recoveryError.set('');
    this.authService.initializeCsrf().pipe(
      switchMap(() =>
        this.http.post<RecoveryRequestResponse>(
          '/api/auth/password-recovery/request',
          { email: email.trim().toLowerCase() },
          { withCredentials: true },
        ),
      ),
    ).subscribe({
      next: response => {
        this.recoveryLoading.set(false);
        this.recoveryEmail.set(email.trim().toLowerCase());
        this.recoveryMessage.set(response.message);
        this.codeForm.reset();
        this.activePanel.set('recovery-code');
        this.startCooldown(response.cooldownSeconds);
      },
      error: () => {
        this.recoveryLoading.set(false);
        this.recoveryError.set(
          'No fue posible solicitar la recuperación. Intenta nuevamente.',
        );
      },
    });
  }

  private startCooldown(seconds: number): void {
    this.clearCooldown();
    this.cooldown.set(Math.max(0, seconds));
    if (this.cooldown() === 0) return;
    this.cooldownTimer = setInterval(() => {
      this.cooldown.update(value => Math.max(0, value - 1));
      if (this.cooldown() === 0) this.clearCooldown();
    }, 1000);
  }

  private clearCooldown(): void {
    if (this.cooldownTimer) clearInterval(this.cooldownTimer);
    this.cooldownTimer = undefined;
  }

  private resetRecovery(): void {
    this.clearCooldown();
    this.recoveryForm.reset();
    this.codeForm.reset();
    this.passwordForm.reset();
    this.recoveryError.set('');
    this.recoveryMessage.set('');
    this.recoveryEmail.set('');
    this.resetToken.set('');
    this.cooldown.set(0);
    this.showNewPassword.set(false);
    this.showConfirmation.set(false);
  }
}
