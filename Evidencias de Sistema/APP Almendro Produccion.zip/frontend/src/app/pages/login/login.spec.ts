import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideRouter, Router } from '@angular/router';
import { of } from 'rxjs';

import { AuthService } from '../../core/auth/auth.service';
import { SessionExperienceService } from '../../core/auth/session-experience.service';
import { ThemeService } from '../../core/auth/theme/theme.service';
import { LoginComponent } from './login';

describe('LoginComponent', () => {
  let http: HttpTestingController;

  beforeEach(async () => {
    localStorage.clear();
    document.documentElement.classList.remove('dark-theme');

    Object.defineProperty(window, 'matchMedia', {
      writable: true,
      value: (query: string): MediaQueryList => ({
        matches: false,
        media: query,
        onchange: null,
        addListener: () => undefined,
        removeListener: () => undefined,
        addEventListener: () => undefined,
        removeEventListener: () => undefined,
        dispatchEvent: () => false
      })
    });

    await TestBed.configureTestingModule({
      imports: [LoginComponent],
      providers: [provideHttpClient(), provideHttpClientTesting(), provideRouter([])]
    }).compileComponents();
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    http.verify();
    vi.useRealTimers();
  });

  it('switches the logo with the existing theme class', () => {
    const theme = TestBed.inject(ThemeService);
    const fixture = TestBed.createComponent(LoginComponent);
    fixture.detectChanges();

    const element = fixture.nativeElement as HTMLElement;
    const lightThemeLogo = element.querySelector<HTMLImageElement>(
      '.hotel-logo-light'
    );
    const darkThemeLogo = element.querySelector<HTMLImageElement>(
      '.hotel-logo-dark'
    );

    expect(lightThemeLogo?.getAttribute('src')).toBe(
      '/assets/branding/hotel-logo-on-light.png'
    );
    expect(darkThemeLogo?.getAttribute('src')).toBe(
      '/assets/branding/hotel-logo-on-dark.png'
    );

    theme.setTheme(false);
    fixture.detectChanges();
    expect(document.documentElement.classList.contains('dark-theme')).toBe(false);
    expect(getComputedStyle(lightThemeLogo as HTMLImageElement).visibility).toBe(
      'visible'
    );
    expect(getComputedStyle(darkThemeLogo as HTMLImageElement).visibility).toBe(
      'hidden'
    );

    theme.setTheme(true);
    fixture.detectChanges();
    expect(document.documentElement.classList.contains('dark-theme')).toBe(true);
    expect(getComputedStyle(lightThemeLogo as HTMLImageElement).visibility).toBe(
      'hidden'
    );
    expect(getComputedStyle(darkThemeLogo as HTMLImageElement).visibility).toBe(
      'visible'
    );
  });

  it('completes the recovery steps with a neutral request response', () => {
    const auth = TestBed.inject(AuthService);
    vi.spyOn(auth, 'initializeCsrf').mockReturnValue(of(undefined));
    const fixture = TestBed.createComponent(LoginComponent);
    fixture.detectChanges();

    const element = fixture.nativeElement as HTMLElement;
    const forgotPassword = element.querySelector<HTMLButtonElement>(
      '.forgot-password'
    );

    expect(forgotPassword).not.toBeNull();
    forgotPassword?.click();
    fixture.detectChanges();

    expect(element.querySelector('h2')?.textContent).toContain('¿Has olvidado la contraseña?');

    const recoveryForm = element.querySelector<HTMLFormElement>('form');
    recoveryForm?.dispatchEvent(
      new Event('submit', { bubbles: true, cancelable: true })
    );
    fixture.detectChanges();

    expect(element.querySelector('.field-error')?.textContent).toContain('correo electrónico válido');

    const email = element.querySelector<HTMLInputElement>('#recovery-email');
    if (email) {
      email.value = 'persona@elalmendro.cl';
      email.dispatchEvent(new Event('input', { bubbles: true }));
    }
    fixture.detectChanges();

    recoveryForm?.dispatchEvent(
      new Event('submit', { bubbles: true, cancelable: true })
    );
    http.expectOne('/api/auth/password-recovery/request').flush({
      message: 'Si existe una cuenta activa asociada, recibirás un código.',
      cooldownSeconds: 60,
    });
    fixture.detectChanges();

    expect(element.querySelector('.field-error')).toBeNull();
    expect(element.querySelector('.info-message')?.textContent).toContain(
      'Si existe una cuenta activa'
    );

    const code = element.querySelector<HTMLInputElement>('#recovery-code');
    if (code) {
      code.value = '123456';
      code.dispatchEvent(new Event('input', { bubbles: true }));
    }
    element.querySelector<HTMLFormElement>('form')?.dispatchEvent(
      new Event('submit', { bubbles: true, cancelable: true }),
    );
    http.expectOne('/api/auth/password-recovery/verify').flush({
      resetToken: 'one-time-reset-token',
      expiresAt: '2026-11-09T15:30:00Z',
    });
    fixture.detectChanges();

    expect(element.querySelector('#new-password')).not.toBeNull();
    expect(element.textContent).toContain('Mínimo 12 caracteres');
    expect(element.textContent).toContain('Al menos una mayúscula');

    element.querySelector<HTMLButtonElement>('.password-toggle')?.click();
    fixture.detectChanges();
    expect(element.querySelector<HTMLInputElement>('#new-password')?.type).toBe('text');

    fixture.destroy();
  });

  it('shows the welcome before navigating to the dashboard', async () => {
    vi.useFakeTimers();
    const auth = TestBed.inject(AuthService);
    const router = TestBed.inject(Router);
    const experience = TestBed.inject(SessionExperienceService);
    vi.spyOn(auth, 'login').mockReturnValue(
      of({ id:1,username:'admin',fullName:'Admin',email:null,role:'ADMIN',status:'ACTIVE',permissions:['dashboard'] })
    );
    const navigate = vi.spyOn(router, 'navigateByUrl').mockResolvedValue(true);

    const fixture = TestBed.createComponent(LoginComponent);
    fixture.detectChanges();
    const element = fixture.nativeElement as HTMLElement;
    const username = element.querySelector<HTMLInputElement>('#username');
    const password = element.querySelector<HTMLInputElement>('#password');

    if (username && password) {
      username.value = 'admin';
      username.dispatchEvent(new Event('input', { bubbles: true }));
      password.value = 'secret';
      password.dispatchEvent(new Event('input', { bubbles: true }));
    }
    element.querySelector<HTMLFormElement>('form')?.dispatchEvent(
      new Event('submit', { bubbles: true, cancelable: true })
    );

    expect(experience.transition()).toEqual({ kind: 'welcome', name: 'Admin' });
    expect(navigate).not.toHaveBeenCalled();

    await vi.advanceTimersByTimeAsync(2499);
    expect(navigate).not.toHaveBeenCalled();

    await vi.advanceTimersByTimeAsync(1);
    expect(navigate).toHaveBeenCalledWith('/dashboard');
    expect(experience.transitionLeaving()).toBe(true);

    fixture.destroy();
  });
});
