import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { ActivatedRoute, convertToParamMap } from '@angular/router';
import { provideRouter } from '@angular/router';

import { OperationalImportComponent } from './operational-import';

describe('OperationalImportComponent', () => {
  beforeEach(() => {
    Object.defineProperty(window, 'matchMedia', {
      writable: true,
      value: (query: string): MediaQueryList => ({
        matches: false,
        media: query,
        onchange: null,
        addListener: () => undefined,
        removeListener: () => undefined,
        addEventListener: () => undefined,
        removeEventListener: () => undefined,
        dispatchEvent: () => false
      })
    });
  });

  async function setup(slug: string) {
    await TestBed.configureTestingModule({
      imports: [OperationalImportComponent],
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        provideRouter([]),
        { provide: ActivatedRoute, useValue: { snapshot: { paramMap: convertToParamMap({ slug }) } } }
      ]
    }).compileComponents();
    const fixture = TestBed.createComponent(OperationalImportComponent);
    return {
      component: fixture.componentInstance as any,
      http: TestBed.inject(HttpTestingController)
    };
  }

  it('configures and uploads a Reactiva workbook through the operational endpoint', async () => {
    const { component, http } = await setup('mantencion-reactiva');
    expect(component.title).toBe('Importar incidencias de Mantención Reactiva');
    expect(component.accept).toBe('.xlsx,.xls');

    component.file.set(new File(['excel'], 'reactiva.xlsx'));
    component.upload();
    const request = http.expectOne(req => req.url === '/api/operational-import/mantencion-reactiva');
    expect(request.request.params.get('forceDuplicates')).toBe('false');
    request.flush({ filename: 'reactiva.xlsx', areaSlug: 'mantencion-reactiva', batchId: 'batch', detected: 1, created: 1, skipped: 0, errors: 0, duplicateCount: 0, summary: 'ok', duplicates: [], warnings: [] });
    expect(component.result().created).toBe(1);
    http.verify();
  });

  it('allows a confirmed machine duplicate import without browser dialogs', async () => {
    const { component, http } = await setup('mantencion-maquinas');
    expect(component.title).toBe('Importar máquinas y mantenciones');

    component.file.set(new File(['excel'], 'maquinas.xls'));
    component.upload(true);
    const request = http.expectOne(req => req.url === '/api/operational-import/mantencion-maquinas');
    expect(request.request.params.get('forceDuplicates')).toBe('true');
    request.flush({ filename: 'maquinas.xls', areaSlug: 'mantencion-maquinas', batchId: 'batch', detected: 1, created: 1, skipped: 0, errors: 0, duplicateCount: 0, summary: 'ok', duplicates: [], warnings: [] });
    http.verify();
  });
});
