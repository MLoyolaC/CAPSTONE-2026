import { HttpClient, HttpParams } from '@angular/common/http';
import { Component, inject, signal } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { AppSidebarComponent } from '../../shared/app-sidebar/app-sidebar';

interface DuplicateWarning {
  incomingTitle: string;
  incomingLocation: string | null;
  existingId: string;
  existingTitle: string;
  existingLocation: string | null;
  areaSlug: string;
}

interface ImportResult {
  filename: string;
  areaSlug: string;
  batchId: string;
  detected: number;
  created: number;
  skipped: number;
  errors: number;
  duplicateCount: number;
  summary: string;
  duplicates: DuplicateWarning[];
  warnings: string[];
}

interface ImportConfig { title: string; accept: string; help: string; }

@Component({
  selector: 'app-operational-import',
  standalone: true,
  imports: [AppSidebarComponent, RouterLink],
  templateUrl: './operational-import.html',
  styleUrl: './operational-import.scss'
})
export class OperationalImportComponent {
  private readonly http = inject(HttpClient);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);

  protected readonly slug = this.route.snapshot.paramMap.get('slug') || '';
  protected readonly file = signal<File | null>(null);
  protected readonly busy = signal(false);
  protected readonly error = signal('');
  protected readonly result = signal<ImportResult | null>(null);

  protected get title(): string { return this.config.title; }
  protected get accept(): string { return this.config.accept; }
  protected get help(): string { return this.config.help; }

  protected choose(event: Event): void {
    this.file.set((event.target as HTMLInputElement).files?.[0] || null);
    this.result.set(null);
    this.error.set('');
  }

  protected upload(forceDuplicates = false): void {
    const file = this.file();
    if (!file) return;
    this.busy.set(true);
    this.error.set('');
    const body = new FormData();
    body.append('file', file);
    const params = new HttpParams().set('forceDuplicates', forceDuplicates);
    this.http.post<ImportResult>(`/api/operational-import/${this.slug}`, body, { withCredentials: true, params }).subscribe({
      next: result => { this.result.set(result); this.busy.set(false); },
      error: response => {
        this.busy.set(false);
        this.error.set(response?.error?.detail || response?.error?.message || 'No fue posible importar el archivo.');
      }
    });
  }

  protected viewDuplicate(duplicate: DuplicateWarning): void {
    this.router.navigate(['/areas', duplicate.areaSlug], { queryParams: { editar: duplicate.existingId } });
  }

  protected back(): void { this.router.navigate(['/areas', this.slug]); }

  private get config(): ImportConfig {
    const configs: Record<string, ImportConfig> = {
      'prevencion-riesgos': {
        title: 'Importar planificación de Prevención',
        accept: '.xlsx',
        help: 'Compatible con GANTT PREVENSION.xlsx. Se conservarán fechas, responsable y avance.'
      },
      'mantencion-jardineria': {
        title: 'Importar labores de Jardinería',
        accept: '.xlsx,.docx',
        help: 'Compatible con el Excel de trabajos por sectores y con Labores Jardineros.docx. Se conservarán sector, prioridad, temporada y frecuencia cuando existan.'
      },
      'mantencion-reactiva': {
        title: 'Importar incidencias de Mantención Reactiva',
        accept: '.xlsx,.xls',
        help: 'Reconoce encabezados habituales, omite filas vacías y conserva ubicación, fechas, responsable, estado, prioridad y observaciones.'
      },
      'mantencion-maquinas': {
        title: 'Importar máquinas y mantenciones',
        accept: '.xlsx,.xls',
        help: 'Reconoce encabezados habituales de equipos y mantenciones, incluyendo ubicación, fechas, estado, marca, modelo y frecuencia.'
      }
    };
    return configs[this.slug] || { title: 'Importar registros', accept: '.xlsx,.xls', help: 'Selecciona el archivo Excel que deseas incorporar.' };
  }
}
