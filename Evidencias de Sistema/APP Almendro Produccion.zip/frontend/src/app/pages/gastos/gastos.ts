import { HttpClient } from '@angular/common/http';
import { Component, computed, inject, signal } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth/auth.service';
import { ExpenseReport, formatCLP } from '../../core/expenses/expenses.models';
import { AppSidebarComponent } from '../../shared/app-sidebar/app-sidebar';
import { CountUpDirective } from '../../shared/count-up/count-up';
type DetailKind='REAL'|'COUNT'|'PROPOSALS'|null;
@Component({selector:'app-gastos',imports:[AppSidebarComponent,RouterLink,CountUpDirective],templateUrl:'./gastos.html',styleUrl:'./gastos.scss'})
export class GastosComponent{
 private http=inject(HttpClient);private router=inject(Router);private route=inject(ActivatedRoute);protected user=inject(AuthService).currentUser;protected report=signal<ExpenseReport|null>(null);protected loading=signal(true);protected error=signal('');protected areaFilter=signal('todas');protected query=signal('');protected year=signal<number|'ALL'>('ALL');protected detail=signal<DetailKind>(null);protected formatCLP=formatCLP;
 protected years=computed(()=>{const ys=new Set<number>();for(const e of this.report()?.expenses||[]){const d=e.operationDate||e.createdAt;if(d)ys.add(Number(d.slice(0,4)))}for(const p of this.report()?.proposals||[]){if(p.targetDate)ys.add(Number(p.targetDate.slice(0,4)));else if(p.plannedYear)ys.add(p.plannedYear)}return Array.from(ys).sort((a,b)=>b-a)});
 protected filteredExpenses=computed(()=>{const data=this.report()?.expenses||[],area=this.areaFilter(),q=this.query().trim().toLowerCase();return data.filter(e=>(area==='todas'||e.areaSlug===area)&&this.yearMatch(e.operationDate||e.createdAt)&&(!q||[e.title,e.areaName,e.supplierName,e.responsibleName].some(v=>(v||'').toLowerCase().includes(q))))});
 protected filteredTotal=computed(()=>this.filteredExpenses().reduce((s,e)=>s+Number(e.amount||0),0));
 protected detailExpenses=computed(()=>this.filteredExpenses());protected detailProposals=computed(()=>{const r=this.report()?.proposals||[];return r.filter(p=>(this.areaFilter()==='todas'||p.areaSlug===this.areaFilter())&&this.proposalYearMatch(p));});
 constructor(){const a=this.route.snapshot.queryParamMap.get('area');if(a)this.areaFilter.set(a);this.refresh();}
 protected refresh(){this.loading.set(true);this.http.get<ExpenseReport>('/api/expenses/summary',{withCredentials:true}).subscribe({next:r=>{this.report.set(r);this.loading.set(false)},error:()=>{this.loading.set(false);this.error.set('No fue posible consultar los gastos.')}})}
 protected setArea(e:Event){this.areaFilter.set((e.target as HTMLSelectElement).value)}protected setSearch(e:Event){this.query.set((e.target as HTMLInputElement).value)}protected setYear(e:Event){const v=(e.target as HTMLSelectElement).value;this.year.set(v==='ALL'?'ALL':Number(v))}protected openWork(slug:string,id:string){this.router.navigate(['/areas',slug],{queryParams:{editar:id}})}protected registeredDate(v:string|null){if(!v)return'Sin fecha';const d=new Date(v.length===10?v+'T12:00:00':v);return Number.isNaN(d.getTime())?'Sin fecha':new Intl.DateTimeFormat('es-CL',{day:'2-digit',month:'short',year:'numeric'}).format(d)}
 private yearMatch(v:string|null){return this.year()==='ALL'||!!v&&Number(v.slice(0,4))===this.year()}private proposalYearMatch(p:any){if(this.year()==='ALL')return true;const y=p.targetDate?Number(p.targetDate.slice(0,4)):p.plannedYear;return y===this.year()}
}
