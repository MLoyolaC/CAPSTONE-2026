import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth/auth.service';
import { passwordPolicyValidator } from '../../core/auth/password-policy';
import { PasswordRequirementsComponent } from '../../shared/password-requirements/password-requirements';
import { ThemeToggleComponent } from '../../shared/theme-toggle/theme-toggle';

interface InvitationView { fullName: string; email: string; username: string; expiresAt: string; }

@Component({
  selector: 'app-activar-cuenta', standalone: true,
  imports: [ReactiveFormsModule, RouterLink, ThemeToggleComponent, PasswordRequirementsComponent],
  templateUrl: './activar-cuenta.html', styleUrl: './activar-cuenta.scss'
})
export class ActivarCuentaComponent {
  private readonly http = inject(HttpClient);
  private readonly auth = inject(AuthService);
  private readonly route = inject(ActivatedRoute);
  private readonly fb = inject(FormBuilder);
  protected readonly loading = signal(true);
  protected readonly saving = signal(false);
  protected readonly invitation = signal<InvitationView | null>(null);
  protected readonly error = signal('');
  protected readonly activated = signal(false);
  protected readonly showPassword = signal(false);
  protected readonly showConfirmation = signal(false);
  private readonly token = this.route.snapshot.queryParamMap.get('token') ?? '';
  protected readonly form = this.fb.nonNullable.group({
    password: ['', [Validators.required, passwordPolicyValidator]],
    confirmation: ['', [Validators.required, Validators.maxLength(128)]]
  });

  constructor() {
    this.http.get<InvitationView>('/api/invitations/validate', {params: {token: this.token}}).subscribe({
      next: value => { this.invitation.set(value); this.loading.set(false); },
      error: (e: HttpErrorResponse) => { this.error.set(e.error?.message || 'El enlace de activación no es válido o expiró.'); this.loading.set(false); }
    });
  }

  protected submit(): void {
    if (this.form.invalid || this.saving()) { this.form.markAllAsTouched(); return; }
    const {password, confirmation} = this.form.getRawValue();
    if (password !== confirmation) { this.error.set('Las contraseñas no coinciden.'); return; }
    this.saving.set(true); this.error.set('');
    this.auth.initializeCsrf().subscribe({
      next: () => this.http.post('/api/invitations/activate', {
        token: this.token, password, passwordConfirmation: confirmation
      }).subscribe({
        next: () => { this.saving.set(false); this.activated.set(true); this.form.reset(); },
        error: (e: HttpErrorResponse) => { this.saving.set(false); this.error.set(e.error?.message || 'No fue posible activar la cuenta.'); }
      }),
      error: () => { this.saving.set(false); this.error.set('No fue posible iniciar la validación de seguridad.'); }
    });
  }
}
