import { Component, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { AppSidebarComponent } from '../../shared/app-sidebar/app-sidebar';
import { CountUpDirective } from '../../shared/count-up/count-up';

interface Area {id:number;name:string;slug:string;description:string;documentCount:number;}
interface WorkItem {id:string;title:string;location:string|null;status:string;scheduledStart:string|null;}
@Component({selector:'app-gestion-complementaria',standalone:true,imports:[AppSidebarComponent,RouterLink,CountUpDirective],templateUrl:'./gestion-complementaria.html',styleUrl:'./gestion-complementaria.scss'})
export class GestionComplementariaComponent {
  private readonly http=inject(HttpClient);
  private readonly route=inject(ActivatedRoute);
  private readonly router=inject(Router);
  protected readonly page=signal('documentos');
  protected readonly areas=signal<Area[]>([]);
  protected readonly machines=signal<WorkItem[]>([]);
  protected readonly selectedRoom=signal('');
  protected readonly rooms=computed(()=>{
    const grouped=new Map<string,WorkItem[]>();
    for(const item of this.machines()){const name=item.location?.trim()||'Ubicación sin registrar';grouped.set(name,[...(grouped.get(name)||[]),item]);}
    return Array.from(grouped,([name,items])=>({name,items})).sort((a,b)=>a.name.localeCompare(b.name,'es'));
  });
  protected readonly roomItems=computed(()=>this.rooms().find(r=>r.name===this.selectedRoom())?.items||[]);
  constructor(){this.route.url.subscribe(parts=>{
    const name=parts[0]?.path??'documentos';this.page.set(name);this.selectedRoom.set('');
    if(name==='documentos')this.loadDocuments();
    if(name==='activos')this.loadAssets();
  });}
  private loadDocuments():void {this.http.get<Area[]>('/api/areas',{withCredentials:true}).subscribe({next:areas=>this.areas.set(areas),error:()=>this.areas.set([])});}
  private loadAssets():void {this.http.get<WorkItem[]>('/api/work-items',{params:{area:'mantencion-maquinas',type:'MACHINE_MAINTENANCE'},withCredentials:true}).subscribe({next:items=>this.machines.set(items),error:()=>this.machines.set([])});}
  protected goMachine(item:WorkItem):void {this.router.navigate(['/areas','mantencion-maquinas'],{queryParams:{editar:item.id}});}
}
