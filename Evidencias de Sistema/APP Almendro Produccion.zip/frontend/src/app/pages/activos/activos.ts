import { Component, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AppSidebarComponent } from '../../shared/app-sidebar/app-sidebar';
import { CountUpDirective } from '../../shared/count-up/count-up';
type AssetStatus='OPERATIONAL'|'FAULT'|'OUT_OF_SERVICE';
interface Asset {id:string;areaSlug:string;code:string|null;name:string;category:string|null;location:string|null;description:string|null;notes:string|null;operationalStatus:AssetStatus;active:boolean;createdAt:string;updatedAt:string;linkedMachineCount:number;}
@Component({selector:'app-activos',standalone:true,imports:[AppSidebarComponent,FormsModule,CountUpDirective],templateUrl:'./activos.html',styleUrl:'./activos.scss'})
export class ActivosComponent{
 private http=inject(HttpClient);private router=inject(Router);
 protected items=signal<Asset[]>([]);protected loading=signal(true);protected query=signal('');protected location=signal('ALL');protected category=signal('ALL');protected status=signal<'ALL'|AssetStatus>('ALL');protected modal=signal(false);protected editing=signal<Asset|null>(null);protected detail=signal<Asset|null>(null);protected confirm=signal<Asset|null>(null);
 protected form:any={code:'',name:'',category:'',location:'',description:'',notes:'',operationalStatus:'OPERATIONAL',active:true};
 protected locations=computed(()=>Array.from(new Set(this.items().map(x=>x.location||'Sin ubicación'))).sort((a,b)=>a.localeCompare(b,'es')));
 protected categories=computed(()=>Array.from(new Set(this.items().map(x=>x.category||'Sin tipo'))).sort((a,b)=>a.localeCompare(b,'es')));
 protected criticalCount=computed(()=>this.items().filter(x=>x.operationalStatus!=='OPERATIONAL').length);
 protected filtered=computed(()=>{const q=this.query().trim().toLowerCase();return this.items().filter(x=>(this.location()==='ALL'||(x.location||'Sin ubicación')===this.location())&&(this.category()==='ALL'||(x.category||'Sin tipo')===this.category())&&(this.status()==='ALL'||x.operationalStatus===this.status())&&(!q||[x.name,x.code,x.category,x.location].some(v=>(v||'').toLowerCase().includes(q))));});
 protected grouped=computed(()=>{const m=new Map<string,Asset[]>();for(const a of this.filtered()){const k=a.location||'Sin ubicación';m.set(k,[...(m.get(k)||[]),a]);}return Array.from(m,([name,assets])=>({name,assets}));});
 constructor(){this.refresh();}
 protected refresh(){this.loading.set(true);this.http.get<Asset[]>('/api/assets',{withCredentials:true}).subscribe({next:x=>{this.items.set(x);this.loading.set(false)},error:()=>this.loading.set(false)});}
 protected newAsset(){this.editing.set(null);this.form={code:'',name:'',category:'',location:'',description:'',notes:'',operationalStatus:'OPERATIONAL',active:true};this.modal.set(true);}
 protected edit(a:Asset){this.detail.set(null);this.editing.set(a);this.form={code:a.code||'',name:a.name,category:a.category||'',location:a.location||'',description:a.description||'',notes:a.notes||'',operationalStatus:a.operationalStatus,active:a.active};this.modal.set(true);}
 protected save(){if(!this.form.name?.trim())return;const e=this.editing();const req=e?this.http.put<Asset>(`/api/assets/${e.id}`,{areaSlug:'mantencion-maquinas',...this.form},{withCredentials:true}):this.http.post<Asset>('/api/assets',{areaSlug:'mantencion-maquinas',...this.form},{withCredentials:true});req.subscribe(()=>{this.modal.set(false);this.refresh()});}
 protected doDelete(){const a=this.confirm();if(!a)return;this.http.delete(`/api/assets/${a.id}`,{withCredentials:true}).subscribe(()=>{this.confirm.set(null);this.refresh()});}
 protected maintenance(a:Asset){this.router.navigate(['/areas','mantencion-maquinas'],{queryParams:{crear:1,activoId:a.id,activo:a.name,ubicacion:a.location||''}});}
 protected statusLabel(value:AssetStatus){return value==='OPERATIONAL'?'Operativo':value==='FAULT'?'Con falla':'Fuera de servicio';}
}
