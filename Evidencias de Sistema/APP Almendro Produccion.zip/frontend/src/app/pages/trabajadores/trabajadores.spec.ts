import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideRouter } from '@angular/router';

import { TrabajadoresComponent } from './trabajadores';

describe('TrabajadoresComponent document replacement', () => {
  beforeEach(async () => {
    Object.defineProperty(window, 'matchMedia', {
      writable: true,
      value: (query: string): MediaQueryList => ({
        matches: false,
        media: query,
        onchange: null,
        addListener: () => undefined,
        removeListener: () => undefined,
        addEventListener: () => undefined,
        removeEventListener: () => undefined,
        dispatchEvent: () => false
      })
    });
    await TestBed.configureTestingModule({
      imports: [TrabajadoresComponent],
      providers: [provideHttpClient(), provideHttpClientTesting(), provideRouter([])]
    }).compileComponents();
  });

  it('closes immediately when no replacement was selected', () => {
    const fixture = TestBed.createComponent(TrabajadoresComponent);
    const http = TestBed.inject(HttpTestingController);
    http.expectOne('/api/workers').flush([]);
    http.expectOne('/api/workers/document-categories').flush([]);
    const component = fixture.componentInstance as any;
    const document = {...sampleDocument(), fileType: 'DOCX'};

    component.startDocumentUpdate(document);
    component.cancelDocumentUpdate();

    expect(component.updatingDocument()).toBeNull();
    expect(component.discardReplacement()).toBe(false);
  });

  it('asks before discarding a selected replacement and never calls the backend', () => {
    const fixture = TestBed.createComponent(TrabajadoresComponent);
    const http = TestBed.inject(HttpTestingController);
    http.expectOne('/api/workers').flush([]);
    http.expectOne('/api/workers/document-categories').flush([]);
    const component = fixture.componentInstance as any;
    const document = sampleDocument();
    const file = new File(['updated'], 'contrato-actualizado.pdf', { type: 'application/pdf' });

    component.startDocumentUpdate(document);
    component.onReplacementSelected({ target: { files: [file], value: 'selected' } } as unknown as Event);
    component.cancelDocumentUpdate();

    expect(component.discardReplacement()).toBe(true);
    expect(component.updatingDocument()).toEqual(document);
    http.verify();

    component.confirmDiscardReplacement();
    expect(component.updatingDocument()).toBeNull();
    expect(component.replacementFile()).toBeNull();
  });

  it('locks body scrolling while preview is open and restores it on close', () => {
    const fixture = TestBed.createComponent(TrabajadoresComponent);
    const http = TestBed.inject(HttpTestingController);
    http.expectOne('/api/workers').flush([]);
    http.expectOne('/api/workers/document-categories').flush([]);
    const component = fixture.componentInstance as any;
    const document = {...sampleDocument(), fileType: 'DOCX'};

    component.openPreview(document);
    expect(documentBodyOverflow()).toBe('hidden');
    http.expectOne(`/api/documents/${document.id}/docx-preview`).flush({filename:'contrato.docx',blocks:[]});
    component.closePreview();
    expect(documentBodyOverflow()).toBe('');
  });
});

function documentBodyOverflow(): string { return window.document.body.style.overflow; }

function sampleDocument() {
  return {
    id: '11111111-1111-1111-1111-111111111111',
    name: 'contrato.pdf',
    fileType: 'PDF',
    indexStatus: 'NOT_APPLICABLE',
    versionNumber: 1,
    sizeBytes: 10,
    originalFilename: 'contrato.pdf',
    createdAt: '2026-11-08T12:00:00Z',
    documentType: 'Contrato'
  };
}
