import { AppSidebarComponent } from '../../shared/app-sidebar/app-sidebar';
import { HttpClient, HttpParams } from '@angular/common/http';

import {
  Component,
  computed,
  inject,
  signal
} from '@angular/core';

import {
  ActivatedRoute,
  RouterLink
} from '@angular/router';
import {
  AuditChange,
  auditColor,
  formatAuditValue
} from '../../core/history/history-display';

interface Area {
  id: number;
  name: string;
  slug: string;
  description: string;
  sortOrder: number;
  documentCount: number;
}


interface HistoryEntry {
  id: string;

  documentId: string | null;

  documentName: string;

  fileType: string;

  areaSlug: string;

  areaName: string;

  username: string | null;

  role: string | null;

  action: string;

  versionNumber: number | null;

  createdAt: string;

  details: string | null;

  entryType: 'DOCUMENT' | 'WORK_ITEM' | 'SYSTEM';

  itemId: string | null;

  changes: AuditChange[];

  operationId: string | null;
}


interface ChileDateParts {
  year: number;

  month: number;

  day: number;

  date: string;
}


@Component({
  selector: 'app-historial',

  imports: [ AppSidebarComponent,
    RouterLink
  ],

  templateUrl: './historial.html',

  styleUrl: './historial.scss'
})
export class HistorialComponent {

  private readonly http =
    inject(HttpClient);


  private readonly route =
    inject(ActivatedRoute);


  private readonly requestedAreaSlug =
    this.route.snapshot.paramMap.get(
      'slug'
    );


  private readonly requestedDocumentId =
    this.route.snapshot.paramMap.get(
      'documentId'
    );


  /*
   * ============================================================
   * INFORMACIÓN DEL CONTEXTO
   * ============================================================
   */

  protected readonly areaSlug =
    signal(
      this.requestedAreaSlug ?? ''
    );


  protected readonly areaName =
    signal('');


  protected readonly documentName =
    signal('');


  /*
   * ============================================================
   * HISTORIAL
   * ============================================================
   */

  protected readonly history =
    signal<HistoryEntry[]>([]);


  protected readonly loading =
    signal(true);


  protected readonly errorMessage =
    signal('');


  /*
   * ============================================================
   * FILTROS
   * ============================================================
   */

  protected readonly selectedDate =
    signal('');


  protected readonly selectedYear =
    signal('');


  protected readonly selectedMonth =
    signal('');


  protected readonly selectedUsername =
    signal('');


  protected readonly selectedAction =
    signal('');


  protected readonly selectedArea =
    signal('');

  protected readonly selectedEntry =
    signal<HistoryEntry | null>(null);


  /*
   * ============================================================
   * TIPO DE HISTORIAL
   * ============================================================
   */

  protected readonly isGeneralHistory =
    computed(() => {

      return (
        !this.requestedAreaSlug
        && !this.requestedDocumentId
      );
    });


  protected readonly isAreaHistory =
    computed(() => {

      return (
        !!this.requestedAreaSlug
        && !this.requestedDocumentId
      );
    });


  protected readonly isDocumentHistory =
    computed(() => {

      return !!this.requestedDocumentId;
    });


  /*
   * ============================================================
   * TÍTULO
   * ============================================================
   */

  protected readonly title =
    computed(() => {

      if (this.isDocumentHistory()) {

        if (this.documentName()) {

          return (
            `Historial de ${this.documentName()}`
          );
        }

        return 'Historial del documento';
      }


      if (this.isAreaHistory()) {

        if (this.areaName()) {

          return (
            `Historial de ${this.areaName()}`
          );
        }

        return 'Historial del área';
      }


      return 'Historial general';
    });


  protected readonly subtitle =
    computed(() => {

      if (this.isDocumentHistory()) {

        return (
          'Registro de cambios realizados sobre este documento.'
        );
      }


      if (this.isAreaHistory()) {

        return (
          'Registro de cambios realizados dentro de esta área.'
        );
      }


      return (
        'Registro general de cambios realizados en todo el Sistema OMM.'
      );
    });


  /*
   * ============================================================
   * AÑOS DISPONIBLES
   * ============================================================
   */

  protected readonly years =
    computed(() => {

      const values =
        new Set<number>();


      for (
        const entry of this.history()
      ) {

        const chileDate =
          this.getChileDateParts(
            entry.createdAt
          );


        values.add(
          chileDate.year
        );
      }


      return Array
        .from(values)
        .sort(
          (a, b) => b - a
        );
    });


  /*
   * ============================================================
   * USUARIOS DISPONIBLES
   * ============================================================
   */

  protected readonly users =
    computed(() => {

      const values =
        new Set<string>();


      for (
        const entry of this.history()
      ) {

        if (entry.username) {

          values.add(
            entry.username
          );
        }
      }


      return Array
        .from(values)
        .sort(
          (a, b) =>
            a.localeCompare(
              b,
              'es'
            )
        );
    });


  /*
   * ============================================================
   * ACCIONES DISPONIBLES
   * ============================================================
   */

  protected readonly actions =
    computed(() => {

      const values =
        new Set<string>();


      for (
        const entry of this.history()
      ) {

        values.add(
          entry.action
        );
      }


      return Array
        .from(values)
        .sort();
    });


  /*
   * ============================================================
   * ÁREAS DISPONIBLES
   * ============================================================
   */

  protected readonly areas =
    computed(() => {

      const map =
        new Map<string, string>();


      for (
        const entry of this.history()
      ) {

        map.set(
          entry.areaSlug,
          entry.areaName
        );
      }


      return Array
        .from(
          map.entries()
        )
        .map(
          ([slug, name]) => ({
            slug,
            name
          })
        )
        .sort(
          (a, b) =>
            a.name.localeCompare(
              b.name,
              'es'
            )
        );
    });


  /*
   * ============================================================
   * MESES
   * ============================================================
   */

  protected readonly monthOptions = [

    {
      value: '1',
      label: 'Enero'
    },

    {
      value: '2',
      label: 'Febrero'
    },

    {
      value: '3',
      label: 'Marzo'
    },

    {
      value: '4',
      label: 'Abril'
    },

    {
      value: '5',
      label: 'Mayo'
    },

    {
      value: '6',
      label: 'Junio'
    },

    {
      value: '7',
      label: 'Julio'
    },

    {
      value: '8',
      label: 'Agosto'
    },

    {
      value: '9',
      label: 'Septiembre'
    },

    {
      value: '10',
      label: 'Octubre'
    },

    {
      value: '11',
      label: 'Noviembre'
    },

    {
      value: '12',
      label: 'Diciembre'
    }
  ];


  /*
   * ============================================================
   * HISTORIAL FILTRADO
   * ============================================================
   */

  protected readonly filteredHistory =
    computed(() => {

      return this.history().filter(
        entry => {

          const chileDate =
            this.getChileDateParts(
              entry.createdAt
            );


          /*
           * Fecha exacta
           */

          if (
            this.selectedDate()
            && chileDate.date !==
              this.selectedDate()
          ) {

            return false;
          }


          /*
           * Año
           */

          if (
            this.selectedYear()
            && chileDate.year.toString() !==
              this.selectedYear()
          ) {

            return false;
          }


          /*
           * Mes
           */

          if (
            this.selectedMonth()
            && chileDate.month.toString() !==
              this.selectedMonth()
          ) {

            return false;
          }


          /*
           * Usuario
           */

          if (
            this.selectedUsername()
            && entry.username !==
              this.selectedUsername()
          ) {

            return false;
          }


          /*
           * Acción
           */

          if (
            this.selectedAction()
            && entry.action !==
              this.selectedAction()
          ) {

            return false;
          }


          /*
           * Área
           */

          if (
            this.selectedArea()
            && entry.areaSlug !==
              this.selectedArea()
          ) {

            return false;
          }


          return true;
        }
      );
    });


  /*
   * ============================================================
   * CONSTRUCTOR
   * ============================================================
   */

  constructor() {

    this.loadHistory();


    if (this.requestedAreaSlug) {

      this.loadAreaInformation(
        this.requestedAreaSlug
      );
    }
  }


  /*
   * ============================================================
   * CARGAR HISTORIAL
   * ============================================================
   */

  private loadHistory(): void {

    this.loading.set(
      true
    );


    this.errorMessage.set(
      ''
    );


    let params =
      new HttpParams();


    /*
     * Historial específico de área
     */

    if (this.requestedAreaSlug) {

      params =
        params.set(
          'areaSlug',
          this.requestedAreaSlug
        );
    }


    /*
     * Historial específico de documento
     */

    if (this.requestedDocumentId) {

      params =
        params.set(
          'documentId',
          this.requestedDocumentId
        );
    }


    this.http
      .get<HistoryEntry[]>(
        '/api/history',
        {
          params,
          withCredentials: true
        }
      )
      .subscribe({

        next: entries => {

          this.history.set(
            entries
          );


          /*
           * Si estamos viendo historial de documento,
           * obtenemos su nombre y área desde el historial.
           */

          if (
            this.requestedDocumentId
            && entries.length > 0
          ) {

            const firstEntry =
              entries[0];


            this.documentName.set(
              firstEntry.documentName
            );


            this.areaSlug.set(
              firstEntry.areaSlug
            );


            this.areaName.set(
              firstEntry.areaName
            );
          }


          /*
           * Historial de área
           */

          if (
            this.requestedAreaSlug
            && entries.length > 0
            && !this.areaName()
          ) {

            this.areaName.set(
              entries[0].areaName
            );
          }


          this.loading.set(
            false
          );
        },


        error: () => {

          this.errorMessage.set(
            'No se pudo cargar el historial.'
          );


          this.loading.set(
            false
          );
        }
      });
  }


  /*
   * ============================================================
   * CARGAR INFORMACIÓN DEL ÁREA
   * ============================================================
   */

  private loadAreaInformation(
    slug: string
  ): void {

    this.http
      .get<Area[]>(
        '/api/areas',
        {
          withCredentials: true
        }
      )
      .subscribe({

        next: areas => {

          const area =
            areas.find(
              item =>
                item.slug === slug
            );


          if (!area) {
            return;
          }


          this.areaName.set(
            area.name
          );
        },


        error: () => {

          /*
           * No bloqueamos el historial si solamente
           * falla la obtención del nombre del área.
           */

        }
      });
  }


  /*
   * ============================================================
   * CAMBIO FILTRO FECHA
   * ============================================================
   */

  protected changeDate(
    event: Event
  ): void {

    this.selectedDate.set(
      this.inputValue(
        event
      )
    );
  }


  /*
   * ============================================================
   * CAMBIO FILTRO AÑO
   * ============================================================
   */

  protected changeYear(
    event: Event
  ): void {

    this.selectedYear.set(
      this.inputValue(
        event
      )
    );
  }


  /*
   * ============================================================
   * CAMBIO FILTRO MES
   * ============================================================
   */

  protected changeMonth(
    event: Event
  ): void {

    this.selectedMonth.set(
      this.inputValue(
        event
      )
    );
  }


  /*
   * ============================================================
   * CAMBIO FILTRO USUARIO
   * ============================================================
   */

  protected changeUser(
    event: Event
  ): void {

    this.selectedUsername.set(
      this.inputValue(
        event
      )
    );
  }


  /*
   * ============================================================
   * CAMBIO FILTRO ACCIÓN
   * ============================================================
   */

  protected changeAction(
    event: Event
  ): void {

    this.selectedAction.set(
      this.inputValue(
        event
      )
    );
  }


  /*
   * ============================================================
   * CAMBIO FILTRO ÁREA
   * ============================================================
   */

  protected changeArea(
    event: Event
  ): void {

    this.selectedArea.set(
      this.inputValue(
        event
      )
    );
  }


  /*
   * ============================================================
   * LIMPIAR FILTROS
   * ============================================================
   */

  protected clearFilters(): void {

    this.selectedDate.set(
      ''
    );


    this.selectedYear.set(
      ''
    );


    this.selectedMonth.set(
      ''
    );


    this.selectedUsername.set(
      ''
    );


    this.selectedAction.set(
      ''
    );


    this.selectedArea.set(
      ''
    );
  }


  /*
   * ============================================================
   * VERIFICAR SI EXISTEN FILTROS
   * ============================================================
   */

  protected hasFilters(): boolean {

    return !!(
      this.selectedDate()
      || this.selectedYear()
      || this.selectedMonth()
      || this.selectedUsername()
      || this.selectedAction()
      || this.selectedArea()
    );
  }


  /*
   * ============================================================
   * FORMATEAR FECHA Y HORA CHILE
   * ============================================================
   */

  protected formatDateTime(
    value: string
  ): string {

    const date =
      new Date(value);


    return new Intl.DateTimeFormat(
      'es-CL',
      {
        timeZone:
          'America/Santiago',

        year:
          'numeric',

        month:
          '2-digit',

        day:
          '2-digit',

        hour:
          '2-digit',

        minute:
          '2-digit',


        hour12:
          false
      }
    ).format(
      date
    );
  }


  /*
   * ============================================================
   * OBTENER FECHA CHILE PARA FILTROS
   * ============================================================
   */

  private getChileDateParts(
    value: string
  ): ChileDateParts {

    const date =
      new Date(value);


    const formatter =
      new Intl.DateTimeFormat(
        'en-US',
        {
          timeZone:
            'America/Santiago',

          year:
            'numeric',

          month:
            '2-digit',

          day:
            '2-digit'
        }
      );


    const parts =
      formatter.formatToParts(
        date
      );


    const year =
      Number(
        parts.find(
          part =>
            part.type === 'year'
        )?.value ?? 0
      );


    const month =
      Number(
        parts.find(
          part =>
            part.type === 'month'
        )?.value ?? 0
      );


    const day =
      Number(
        parts.find(
          part =>
            part.type === 'day'
        )?.value ?? 0
      );


    const monthText =
      month
        .toString()
        .padStart(
          2,
          '0'
        );


    const dayText =
      day
        .toString()
        .padStart(
          2,
          '0'
        );


    return {

      year,

      month,

      day,

      date:
        `${year}-${monthText}-${dayText}`
    };
  }


  /*
   * ============================================================
   * ETIQUETA DE ACCIÓN
   * ============================================================
   */

  protected actionLabel(
    action: string
  ): string {

    switch (action) {

      case 'CREATED':
        return 'Registro agregado';

      case 'UPDATED':
        return 'Registro editado';

      case 'STATUS_CHANGED':
        return 'Cambio de estado';

      case 'BULK_STATUS_CHANGED':
        return 'Cambio masivo de estado';

      case 'IMPORTED':
        return 'Registro importado';

      case 'UPLOADED':

        return 'Documento agregado';


      case 'REPLACED':

        return 'Documento editado';


      case 'DELETED':

        return 'Eliminado';


      case 'ARCHIVED':

        return 'Documento archivado';


      case 'RESTORED':

        return 'Documento restaurado';


      case 'EDIT_STARTED':

        return 'Edición iniciada';


      case 'EDIT_CANCELLED':

        return 'Edición cancelada';


      case 'OPENED':

        return 'Documento abierto';


      case 'DOWNLOADED':

        return 'Documento descargado';


      default:

        return action;
    }
  }

  protected openEntry(entry: HistoryEntry): void {
    this.selectedEntry.set(entry);
  }

  protected closeEntry(): void {
    this.selectedEntry.set(null);
  }

  protected auditValue(value: string | null, valueType: string): string {
    return formatAuditValue(value, valueType);
  }

  protected colorValue(value: string | null): string | null {
    return auditColor(value);
  }


  /*
   * ============================================================
   * ICONO DE ACCIÓN
   * ============================================================
   */

  protected actionIcon(
    action: string
  ): string {

    switch (action) {

      case 'CREATED':
        return 'fa-solid fa-plus';

      case 'UPDATED':
        return 'fa-solid fa-pen';

      case 'STATUS_CHANGED':
        return 'fa-solid fa-arrow-right-arrow-left';

      case 'BULK_STATUS_CHANGED':
        return 'fa-solid fa-layer-group';

      case 'IMPORTED':
        return 'fa-solid fa-file-import';

      case 'UPLOADED':

        return 'fa-solid fa-plus';


      case 'REPLACED':

        return 'fa-solid fa-pen';


      case 'DELETED':

        return 'fa-solid fa-trash';


      case 'RESTORED':

        return 'fa-solid fa-rotate-left';


      case 'ARCHIVED':

        return 'fa-solid fa-box-archive';


      case 'EDIT_STARTED':

        return 'fa-solid fa-pen-to-square';


      case 'EDIT_CANCELLED':

        return 'fa-solid fa-ban';


      case 'OPENED':

        return 'fa-solid fa-eye';


      case 'DOWNLOADED':

        return 'fa-solid fa-download';


      default:

        return 'fa-solid fa-clock-rotate-left';
    }
  }


  /*
   * ============================================================
   * CLASE CSS DE ACCIÓN
   * ============================================================
   */

  protected actionClass(
    action: string
  ): string {

    switch (action) {

      case 'CREATED':
        return 'added';

      case 'UPDATED':
        return 'edited';

      case 'STATUS_CHANGED':
      case 'BULK_STATUS_CHANGED':
        return 'edited';

      case 'IMPORTED':
        return 'imported';

      case 'UPLOADED':

        return 'added';


      case 'REPLACED':

        return 'edited';


      case 'DELETED':

        return 'deleted';


      default:

        return 'neutral';
    }
  }


  /*
   * ============================================================
   * ETIQUETA DE ROL
   * ============================================================
   */

  protected roleLabel(
    role: string | null
  ): string {

    if (role === 'ADMIN') {

      return 'Administrador';
    }


    if (role === 'USER') {

      return 'Usuario';
    }


    return role ?? 'Sin rol';
  }


  /*
   * ============================================================
   * RUTA PARA VOLVER
   * ============================================================
   */

  protected backRoute(): string[] {

    if (this.areaSlug()) {

      return [
        '/areas',
        this.areaSlug()
      ];
    }


    return [
      '/dashboard'
    ];
  }


  /*
   * ============================================================
   * OBTENER VALOR DE INPUT O SELECT
   * ============================================================
   */

  private inputValue(
    event: Event
  ): string {

    const target =
      event.target as
        | HTMLInputElement
        | HTMLSelectElement;


    return target.value;
  }
}
