import {
  HttpClient,
  HttpErrorResponse,
  HttpParams
} from '@angular/common/http';

import {
  Component,
  computed,
  inject,
  signal
} from '@angular/core';

import {
  FormsModule
} from '@angular/forms';

import {
  ActivatedRoute,
  Router,
  RouterLink
} from '@angular/router';

import { concatMap, forkJoin, from, toArray } from 'rxjs';

import {
  AuthService
} from '../../core/auth/auth.service';

import {
  dateOnlyDay,
  dateOnlyKeyFromDay,
  dateOnlyToLocalDate,
  isDateOnlyWithinInclusiveRange,
  normalizeDateOnlyRange
} from '../../core/dates/date-only';

import {
  activityTextColor as resolveActivityTextColor,
  normalizeHexColor,
  normalizeDisplayColor,
  OMM_DISPLAY_COLOR_PALETTE
} from '../../core/colors/display-color';

import { ExpenseReport } from '../../core/expenses/expenses.models';
import {
  WORK_STATUS_OPTIONS,
  WorkItemBulkStatusService
} from '../../core/work-items/work-item-bulk-status.service';
import { WorkItemSelection } from '../../core/work-items/work-item-selection';
import {
  mergeUpdatedWorkItems,
  WorkItemBulkStatusState
} from '../../core/work-items/work-item-bulk-state';

import {
  AppSidebarComponent
} from '../../shared/app-sidebar/app-sidebar';

import { CountUpDirective } from '../../shared/count-up/count-up';
import { DisplayColorPickerComponent } from '../../shared/display-color-picker/display-color-picker';


/* ============================================================
   TIPOS
   ============================================================ */

type WorkPriority =
  | 'LOW'
  | 'NORMAL'
  | 'HIGH'
  | 'URGENT';


type WorkStatus =
  | 'PLANNED'
  | 'PENDING'
  | 'IN_PROGRESS'
  | 'COMPLETED'
  | 'OVERDUE'
  | 'CANCELLED';

type SummaryKind =
  | 'ACTIVE'
  | 'UPCOMING'
  | 'OVERDUE'
  | 'COST'
  | 'REACTIVE_URGENT'
  | 'REACTIVE_ATTENTION'
  | 'REACTIVE_PENDING'
  | 'REACTIVE_RESOLVED'
  | 'IMPROVEMENT_ANALYSIS'
  | 'IMPROVEMENT_APPROVED'
  | 'IMPROVEMENT_WAITING'
  | 'IMPROVEMENT_UPCOMING';

type SortMode =
  | 'RECENT'
  | 'OLDEST'
  | 'AZ'
  | 'ZA';

type DestructiveDialog = {
  kind: 'single' | 'bulk' | 'clear';
  title: string;
  message: string;
  ids: string[];
  confirmLabel: string;
  requiresDelay: boolean;
};


interface WorkItem {

  id: string;

  areaSlug: string;

  areaName: string;

  workType: string;

  phase: string | null;

  plannedYear: number | null;

  plannedMonth: number | null;

  title: string;

  description: string | null;

  location: string | null;

  responsibleName: string | null;

  priority: WorkPriority;

  status: WorkStatus;

  scheduledStart: string | null;

  scheduledEnd: string | null;

  displayColor: string | null;

  textColor: string | null;

  completedDate: string | null;

  progressPercent: number;

  notes: string | null;


  /* CAMPOS ESPECÍFICOS */

  category: string | null;

  assetName: string | null;

  assetId: string | null;

  frequency: string | null;

  season: string | null;

  materials: string | null;

  supplierName: string | null;

  estimatedCost: number | null;

  actualCost: number | null;

  importSourceFilename: string | null;

  sourceSheetName: string | null;

  sourceRowNumber: number | null;

  importedData: string | null;


  createdAt: string;

  updatedAt: string;
}



interface DuplicateReference {
  id: string;
  title: string;
  areaSlug: string;
  areaName: string;
  location: string | null;
  workType: string;
}

interface LocationSuggestion {

  name: string;

  score: number;
}

interface MachineAsset {
  id: string;
  code: string | null;
  name: string;
  location: string | null;
  operationalStatus: 'OPERATIONAL' | 'FAULT' | 'OUT_OF_SERVICE';
  active: boolean;
}


interface OperationalForm {

  phase: string;

  title: string;

  description: string;

  location: string;

  responsibleName: string;

  priority: WorkPriority;

  status: WorkStatus;

  scheduledStart: string;

  scheduledEnd: string;

  displayColor: string | null;

  textColor: string | null;

  targetYear: string;

  targetMonth: string;

  progressPercent: number;

  notes: string;


  /* CAMPOS ESPECÍFICOS */

  category: string;

  assetName: string;

  assetId: string;

  frequency: string;

  season: string;

  materials: string;

  supplierName: string;

  estimatedCost: number | null;

  actualCost: number | null;

  importedData: Record<string, string>;

  importSourceFilename: string | null;

  sourceSheetName: string | null;

  sourceRowNumber: number | null;
}


/* ============================================================
   CONFIGURACIÓN DE CADA ÁREA
   ============================================================ */

interface AreaOperationalConfig {

  slug: string;

  name: string;

  workType: string;

  icon: string;

  headingDescription: string;

  newButtonLabel: string;

  newTitle: string;

  editTitle: string;

  panelTitle: string;

  emptyTitle: string;

  emptyDescription: string;

  nameLabel: string;

  namePlaceholder: string;

  tableColumnLabel: string;


  showCategory: boolean;

  categoryLabel: string;

  categoryPlaceholder: string;


  showAsset: boolean;

  assetLabel: string;

  assetPlaceholder: string;


  showFrequency: boolean;

  showSeason: boolean;

  showMaterials: boolean;

  showSupplier: boolean;

  showCosts: boolean;
}


const AREA_CONFIGS:
  Record<string, AreaOperationalConfig> = {


  /* ========================================================
     MANTENCIÓN GENERAL
     ======================================================== */

  'mantencion-general': {

    slug:
      'mantencion-general',

    name:
      'Mantención General',

    workType:
      'GENERAL_MAINTENANCE',

    icon:
      'fa-solid fa-screwdriver-wrench',

    headingDescription:
      'Registra, organiza y actualiza las mantenciones directamente dentro del sistema.',

    newButtonLabel:
      'Nueva mantención',

    newTitle:
      'Nueva mantención',

    editTitle:
      'Editar mantención',

    panelTitle:
      'Mantenciones registradas',

    emptyTitle:
      'No hay mantenciones registradas',

    emptyDescription:
      'Crea la primera mantención directamente desde el sistema.',

    nameLabel:
      'Nombre de la mantención *',

    namePlaceholder:
      'Ej: Reparación de luminarias pasillo norte',

    tableColumnLabel:
      'Mantención',

    showCategory:
      true,

    categoryLabel:
      'Tipo de mantención',

    categoryPlaceholder:
      'Ej: Electricidad, pintura, gasfitería',

    showAsset:
      false,

    assetLabel:
      'Equipo',

    assetPlaceholder:
      '',

    showFrequency:
      false,

    showSeason:
      false,

    showMaterials:
      false,

    showSupplier:
      false,

    showCosts:
      true
  },


  /* ========================================================
     MANTENCIÓN REACTIVA
     ======================================================== */

  'mantencion-reactiva': {

    slug:
      'mantencion-reactiva',

    name:
      'Mantención Reactiva',

    workType:
      'REACTIVE_MAINTENANCE',

    icon:
      'fa-solid fa-bolt',

    headingDescription:
      'Registra incidencias imprevistas que requieren reacción, prioriza su atención y conserva el seguimiento hasta su resolución.',

    newButtonLabel:
      'Nueva incidencia',

    newTitle:
      'Nueva incidencia',

    editTitle:
      'Editar incidencia',

    panelTitle:
      'Incidencias registradas',

    emptyTitle:
      'No hay incidencias registradas',

    emptyDescription:
      'Registra la primera incidencia imprevista para iniciar su seguimiento.',

    nameLabel:
      'Nombre de la incidencia *',

    namePlaceholder:
      'Ej: Fuga de agua habitación 204',

    tableColumnLabel:
      'Incidencia',

    showCategory:
      true,

    categoryLabel:
      'Tipo de falla',

    categoryPlaceholder:
      'Ej: Fuga, electricidad, calefacción',

    showAsset:
      false,

    assetLabel:
      'Equipo',

    assetPlaceholder:
      '',

    showFrequency:
      false,

    showSeason:
      false,

    showMaterials:
      false,

    showSupplier:
      true,

    showCosts:
      true
  },


  /* ========================================================
     MEJORAS
     ======================================================== */

  'mejoras': {

    slug:
      'mejoras',

    name:
      'Mejoras',

    workType:
      'IMPROVEMENT',

    icon:
      'fa-solid fa-chart-line',

    headingDescription:
      'Organiza ideas y proyectos futuros durante el año, define fechas objetivo, responsables, proveedores y presupuesto previsto.',

    newButtonLabel:
      'Nueva mejora',

    newTitle:
      'Nueva mejora',

    editTitle:
      'Editar mejora',

    panelTitle:
      'Mejoras registradas',

    emptyTitle:
      'No hay mejoras registradas',

    emptyDescription:
      'Crea la primera mejora o proyecto directamente desde el sistema.',

    nameLabel:
      'Nombre de la mejora *',

    namePlaceholder:
      'Ej: Nueva iluminación sector piscina',

    tableColumnLabel:
      'Mejora',

    showCategory:
      true,

    categoryLabel:
      'Tipo de mejora',

    categoryPlaceholder:
      'Ej: Infraestructura, iluminación, mobiliario',

    showAsset:
      false,

    assetLabel:
      'Equipo',

    assetPlaceholder:
      '',

    showFrequency:
      false,

    showSeason:
      false,

    showMaterials:
      true,

    showSupplier:
      true,

    showCosts:
      true
  },


  /* ========================================================
     REMODELACIÓN
     ======================================================== */

  'remodelacion': {

    slug:
      'remodelacion',

    name:
      'Remodelación',

    workType:
      'REMODELING',

    icon:
      'fa-solid fa-building',

    headingDescription:
      'Controla remodelaciones, materiales, proveedores, presupuesto y costo real.',

    newButtonLabel:
      'Nueva remodelación',

    newTitle:
      'Nueva remodelación',

    editTitle:
      'Editar remodelación',

    panelTitle:
      'Remodelaciones registradas',

    emptyTitle:
      'No hay remodelaciones registradas',

    emptyDescription:
      'Crea la primera remodelación directamente desde el sistema.',

    nameLabel:
      'Nombre de la remodelación *',

    namePlaceholder:
      'Ej: Remodelación salón principal',

    tableColumnLabel:
      'Remodelación',

    showCategory:
      true,

    categoryLabel:
      'Tipo de remodelación',

    categoryPlaceholder:
      'Ej: Habitación, salón, terraza',

    showAsset:
      false,

    assetLabel:
      'Equipo',

    assetPlaceholder:
      '',

    showFrequency:
      false,

    showSeason:
      false,

    showMaterials:
      true,

    showSupplier:
      true,

    showCosts:
      true
  },


  /* ========================================================
     MANTENCIÓN DE MÁQUINAS
     ======================================================== */

  'mantencion-maquinas': {

    slug:
      'mantencion-maquinas',

    name:
      'Mantención de Máquinas',

    workType:
      'MACHINE_MAINTENANCE',

    icon:
      'fa-solid fa-gears',

    headingDescription:
      'Controla equipos, fechas, frecuencia y mantenciones realizadas.',

    newButtonLabel:
      'Nueva mantención',

    newTitle:
      'Nueva mantención de máquina',

    editTitle:
      'Editar mantención de máquina',

    panelTitle:
      'Mantenciones de máquinas',

    emptyTitle:
      'No hay mantenciones de máquinas',

    emptyDescription:
      'Registra la primera mantención de un equipo.',

    nameLabel:
      'Nombre de la mantención *',

    namePlaceholder:
      'Ej: Mantención preventiva de caldera',

    tableColumnLabel:
      'Mantención',

    showCategory:
      false,

    categoryLabel:
      '',

    categoryPlaceholder:
      '',

    showAsset:
      true,

    assetLabel:
      'Máquina / equipo',

    assetPlaceholder:
      'Ej: Caldera principal',

    showFrequency:
      true,

    showSeason:
      false,

    showMaterials:
      false,

    showSupplier:
      true,

    showCosts:
      true
  },


  /* ========================================================
     JARDINERÍA
     ======================================================== */

  'mantencion-jardineria': {

    slug:
      'mantencion-jardineria',

    name:
      'Mantención de Jardinería',

    workType:
      'GARDENING',

    icon:
      'fa-solid fa-leaf',

    headingDescription:
      'Organiza las labores de jardinería, frecuencia, temporada y materiales utilizados.',

    newButtonLabel:
      'Nueva tarea',

    newTitle:
      'Nueva tarea de jardinería',

    editTitle:
      'Editar tarea de jardinería',

    panelTitle:
      'Tareas de jardinería',

    emptyTitle:
      'No hay tareas de jardinería',

    emptyDescription:
      'Registra la primera labor de jardinería directamente en el sistema.',

    nameLabel:
      'Nombre de la tarea *',

    namePlaceholder:
      'Ej: Poda sector piscina',

    tableColumnLabel:
      'Tarea',

    showCategory:
      false,

    categoryLabel:
      '',

    categoryPlaceholder:
      '',

    showAsset:
      false,

    assetLabel:
      '',

    assetPlaceholder:
      '',

    showFrequency:
      true,

    showSeason:
      true,

    showMaterials:
      true,

    showSupplier:
      false,

    showCosts:
      true
  },
  'prevencion-riesgos': {
    slug: 'prevencion-riesgos', name: 'Prevención de Riesgos',
    workType: 'PREVENTION', icon: 'fa-solid fa-shield-heart',
    headingDescription: 'Planifica y realiza seguimiento de inspecciones, medidas preventivas y tareas del área.',
    newButtonLabel: 'Nueva actividad preventiva',
    newTitle: 'Nueva actividad de prevención',
    editTitle: 'Editar actividad preventiva',
    panelTitle: 'Actividades de prevención',
    emptyTitle: 'No hay actividades de prevención',
    emptyDescription: 'Crea la primera actividad de prevención y asígnale fechas para la Carta Gantt.',
    nameLabel: 'Actividad preventiva *',
    namePlaceholder: 'Ej: Inspección de elementos de protección personal',
    tableColumnLabel: 'Actividad',
    showCategory: true, categoryLabel: 'Tipo de prevención',
    categoryPlaceholder: 'Ej: Inspección, capacitación, entrega de EPP',
    showAsset: false, assetLabel: 'Equipo', assetPlaceholder: '',
    showFrequency: true, showSeason: false,
    showMaterials: false, showSupplier: false, showCosts: true
  }

};


/* ============================================================
   COMPONENTE
   ============================================================ */

@Component({

  selector:
    'app-mantencion-general',

  imports: [
    FormsModule,
    RouterLink,
    AppSidebarComponent,
    CountUpDirective,
    DisplayColorPickerComponent
  ],

  templateUrl:
    './mantencion-general.html',

  styleUrl:
    './mantencion-general.scss'
})
export class MantencionGeneralComponent {


  private readonly http =
    inject(HttpClient);


  private readonly router =
    inject(Router);


  private readonly route =
    inject(ActivatedRoute);


  private readonly authService =
    inject(AuthService);

  private readonly bulkStatusService =
    inject(WorkItemBulkStatusService);

  private readonly improvementSelection =
    new WorkItemSelection();

  private readonly bulkStatusState =
    new WorkItemBulkStatusState();


  protected readonly user =
    this.authService.currentUser;


  protected readonly area =
    signal<AreaOperationalConfig>(
      AREA_CONFIGS['mantencion-general']
    );


  protected readonly items =
    signal<WorkItem[]>([]);

  protected readonly machineAssets = signal<MachineAsset[]>([]);


  protected readonly loading =
    signal(true);


  protected readonly saving =
    signal(false);


  protected readonly errorMessage =
    signal('');


  protected readonly successMessage =
    signal('');

  protected readonly duplicateReferences = signal<DuplicateReference[] | null>(null);


  protected readonly searchQuery =
    signal('');


  protected readonly statusFilter =
    signal('ALL');

  protected readonly locationFilter = signal('ALL');
  protected readonly responsibleFilter = signal('ALL');
  protected readonly priorityFilter = signal('ALL');
  protected readonly categoryFilter = signal('ALL');
  protected readonly targetYearFilter = signal('ALL');
  protected readonly improvementSectionFilter = signal('ALL');
  protected readonly improvementGoalSheetFilter = signal('ALL');
  protected readonly creatingGantt = signal(false);
  protected readonly expenseReport = signal<ExpenseReport | null>(null);
  protected readonly filterPanelOpen = signal(false);
  protected readonly groupByZone = signal(true);
  protected readonly expandedZoneGroups = signal<Set<string>>(new Set());
  protected readonly summaryKind = signal<SummaryKind | null>(null);
  protected readonly sortMode = signal<SortMode>('RECENT');
  protected readonly selectedImprovementIds = this.improvementSelection.ids;
  protected readonly bulkStatusDialog = this.bulkStatusState.dialog;
  protected readonly bulkStatusOptions = WORK_STATUS_OPTIONS;
  protected readonly destructiveDialog = signal<DestructiveDialog | null>(null);
  protected readonly destructiveCountdown = signal(0);
  private destructiveTimer: ReturnType<typeof setInterval> | null = null;


  // Vistas interactivas similares al mockup de Andrés.
  protected readonly moduleView = signal<'cards'|'table'|'calendar'|'goals'|'gantt'|'summary'>('cards');
  protected readonly calendarMonth = signal(new Date(new Date().getFullYear(),new Date().getMonth(),1));
  protected readonly annualYear = signal(new Date().getFullYear());
  protected readonly improvementBudgetYear = signal(new Date().getFullYear());
  protected readonly openedDate = signal<string|null>(null);
  protected readonly calendarMonthTitle = computed(() => new Intl.DateTimeFormat('es-CL',{month:'long',year:'numeric'}).format(this.calendarMonth()));
  protected readonly monthCells = computed(() => {
    const m=this.calendarMonth(),begin=new Date(m.getFullYear(),m.getMonth(),1),days=(begin.getDay()+6)%7;
    begin.setDate(begin.getDate()-days);
    const today=new Date(),todayKey=this.dateKey(today);
    return Array.from({length:42},(_,index)=>{const d=new Date(begin);d.setDate(begin.getDate()+index);const iso=this.dateKey(d);
      return {iso,number:d.getDate(),inMonth:d.getMonth()===m.getMonth(),today:iso===todayKey,items:this.filteredItems().filter(item=>this.calendarIncludesDate(item,iso))};
    });
  });
  protected readonly improvementAnnualItems = computed(() =>
    this.filteredItems().filter(item => {
      if (item.workType !== 'IMPROVEMENT') return false;
      const kind = String(this.importMeta(item)['sourceKind'] ?? '');
      if (kind !== 'POR_HACER') return true;
      const target = this.improvementTarget(item);
      return !!target.year && !!target.month;
    })
  );

  protected readonly annualMonths = computed(() => {
    const year = this.annualYear();
    return Array.from({ length: 12 }, (_, index) => {
      const month = index + 1;
      const items = this.improvementAnnualItems().filter(item => {
        const target = this.improvementTarget(item);
        return target.year === year && target.month === month;
      });
      items.sort((a,b) => this.compareImprovementByDue(a,b));
      const budget = items.reduce((sum, item) => sum + Number(item.estimatedCost ?? 0), 0);
      return {
        month,
        label: new Intl.DateTimeFormat('es-CL', { month: 'long' }).format(new Date(year, index, 1)),
        items,
        budget
      };
    });
  });

  protected readonly improvementAnnualItemCount = computed(() =>
    this.annualMonths().reduce((total, month) => total + month.items.length, 0)
  );

  protected readonly improvementUnscheduled = computed(() =>
    this.filteredItems().filter(item => {
      if (item.workType !== 'IMPROVEMENT') return false;
      if (String(this.importMeta(item)['sourceKind'] ?? '') === 'POR_HACER') return false;
      const target = this.improvementTarget(item);
      return !target.year || !target.month;
    }).sort((a,b) => this.compareImprovementByDue(a,b))
  );

  protected readonly improvementYearOptions = computed(() => {
    const years = new Set<number>([new Date().getFullYear(), this.annualYear()]);
    for (const item of this.items()) {
      if (item.workType !== 'IMPROVEMENT' || String(this.importMeta(item)['sourceKind'] ?? '') === 'POR_HACER') continue;
      const target = this.improvementTarget(item);
      if (target.year) years.add(target.year);
    }
    return Array.from(years).sort((a,b) => b-a);
  });

  protected readonly improvementBudgetYearOptions = computed(() => {
    const current = new Date().getFullYear();
    const years = new Set<number>([current, this.improvementBudgetYear()]);
    for (const item of this.improvementItems()) {
      const target = this.improvementTarget(item);
      if (target.year) years.add(target.year);
    }
    return Array.from(years).sort((a,b) => b-a);
  });

  protected readonly improvementBudgetTotal = computed(() => {
    const year = this.improvementBudgetYear();
    return this.improvementItems()
      .filter(item => item.status !== 'CANCELLED')
      .filter(item => this.improvementTarget(item).year === year)
      .reduce((sum,item) => sum + Number(item.estimatedCost ?? 0), 0);
  });

  protected setImprovementBudgetYear(value:number|string): void {
    const parsed = Number(value);
    if (Number.isFinite(parsed)) this.improvementBudgetYear.set(parsed);
  }

  protected daySelection=computed(()=>this.filteredItems().filter(item=>this.calendarIncludesDate(item,this.openedDate())));
  private dateKey(d:Date):string{return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');}
  protected shiftCalendarMonth(amount:number):void{const d=this.calendarMonth();this.calendarMonth.set(new Date(d.getFullYear(),d.getMonth()+amount,1));}
  protected calendarToday():void{const d=new Date();this.calendarMonth.set(new Date(d.getFullYear(),d.getMonth(),1));}
  protected shiftAnnualYear(amount:number):void{this.annualYear.update(year => year + amount);}
  protected annualToday():void{this.annualYear.set(new Date().getFullYear());}
  protected setAnnualYear(value:number|string):void{const parsed=Number(value);if(Number.isFinite(parsed))this.annualYear.set(parsed);}
  protected openCalendarDate(date:string):void{this.openedDate.set(date);}
  protected addOnSelectedDate():void{const date=this.openedDate();this.openedDate.set(null);this.openCreate();if(date)this.form.scheduledStart=date;}
  protected editFromCalendar(item:WorkItem):void{this.openedDate.set(null);this.openEdit(item);}

  // Vistas solicitadas el 16 de octubre: Carta Gantt y ubicación física.
  protected readonly showGantt = signal(true);
  protected readonly roomFilter = signal('todas');

  protected readonly isGanttArea = computed(() =>
    ['remodelacion', 'prevencion-riesgos'].includes(this.area().slug)
  );
  protected readonly isMachineArea = computed(() => this.area().slug === 'mantencion-maquinas');
  protected readonly isGardeningArea = computed(() => this.area().slug === 'mantencion-jardineria');
  protected readonly isLocationFolderArea = computed(() => this.isMachineArea() || this.isGardeningArea());


  protected readonly isReactiveArea = computed(() =>
    this.area().slug === 'mantencion-reactiva'
  );

  protected readonly isImprovementArea = computed(() =>
    this.area().slug === 'mejoras'
  );


  protected readonly improvementItems = computed(() =>
    this.items().filter(item => item.workType === 'IMPROVEMENT')
  );

  protected readonly improvementGanttItems = computed(() => {
    const query = this.searchQuery().trim().toLocaleLowerCase('es-CL');
    const responsible = this.responsibleFilter();
    const status = this.statusFilter();
    const year = this.targetYearFilter();

    return this.items()
      .filter(item => item.workType === 'IMPROVEMENT_GANTT')
      .filter(item => {
        if (responsible !== 'ALL' && (item.responsibleName?.trim() || '') !== responsible) return false;
        if (status !== 'ALL' && item.status !== status) return false;
        if (year !== 'ALL' && year !== 'UNSCHEDULED') {
          const itemYear = item.scheduledStart ? Number(item.scheduledStart.slice(0,4)) : null;
          if (itemYear !== Number(year)) return false;
        }
        if (!query) return true;
        return [item.phase,item.title,item.responsibleName,item.notes,item.status]
          .filter(Boolean).join(' ').toLocaleLowerCase('es-CL').includes(query);
      })
      .sort((a,b) => (a.scheduledStart || '').localeCompare(b.scheduledStart || '') || a.title.localeCompare(b.title,'es-CL'));
  });

  protected readonly improvementGanttTimeline = computed(() => {
    const dated = this.improvementGanttItems().filter(item => !!item.scheduledStart);
    if (!dated.length) return null;

    const rows = dated.map(item => {
      const range = normalizeDateOnlyRange(item.scheduledStart, item.scheduledEnd)!;
      return { item, start: range.startDay, end: range.endDay };
    });
    const first = Math.min(...rows.map(row => row.start));
    const last = Math.max(...rows.map(row => row.end));
    const totalDays = Math.max(1, last - first + 1);
    const labelCount = Math.min(totalDays, 8, Math.max(2, Math.ceil(totalDays/10)+1));
    const labels = Array.from({length:labelCount},(_,index) => {
      const offset = labelCount === 1 ? 0 : Math.round((totalDays-1)*index/(labelCount-1));
      const date = dateOnlyToLocalDate(dateOnlyKeyFromDay(first + offset));
      return {
        left: totalDays === 1 ? 0 : (offset/(totalDays-1))*100,
        text: new Intl.DateTimeFormat('es-CL',{day:'2-digit',month:'short'}).format(date)
      };
    });
    return {
      totalDays,
      minWidth: Math.max(920, 240 + totalDays * 18),
      startLabel: new Intl.DateTimeFormat('es-CL',{day:'2-digit',month:'short',year:'numeric'}).format(dateOnlyToLocalDate(dateOnlyKeyFromDay(first))),
      endLabel: new Intl.DateTimeFormat('es-CL',{day:'2-digit',month:'short',year:'numeric'}).format(dateOnlyToLocalDate(dateOnlyKeyFromDay(last))),
      labels,
      rows: rows.map(row => ({
        item: row.item,
        left: ((row.start-first)/totalDays)*100,
        width: ((row.end-row.start+1)/totalDays)*100,
        progress: Math.max(0,Math.min(100,Number(row.item.progressPercent ?? 0)))
      }))
    };
  });

  protected readonly isImprovementGanttForm = computed(() =>
    this.isImprovementArea() && (this.creatingGantt() || this.editingItem()?.workType === 'IMPROVEMENT_GANTT')
  );

  protected readonly improvementSectionOptions = computed(() => {
    const values = new Set<string>();
    for (const item of this.items()) {
      if (item.workType !== 'IMPROVEMENT') continue;
      const section = this.importMeta(item)['sourceSection'];
      if (section) values.add(String(section));
    }
    return Array.from(values).sort((a,b) => a.localeCompare(b,'es-CL'));
  });

  protected readonly improvementGoalSheetOptions = computed(() => {
    const preferred = ['Proyectos Pendientes','Metas Recepción','Metas Obras','Metas Jardinería','Metas Marketing','Metas Oficina'];
    const found = new Set<string>();
    for (const item of this.items()) {
      const meta = this.importMeta(item);
      if (item.workType !== 'IMPROVEMENT' || String(meta['sourceKind'] ?? '') !== 'POR_HACER') continue;
      found.add(this.goalGroupLabel(item.sourceSheetName || String(meta['sourceSection'] ?? 'Sin categoría')));
    }
    return [...found].sort((a,b) => {
      const ai = preferred.indexOf(a), bi = preferred.indexOf(b);
      if (ai >= 0 || bi >= 0) return (ai < 0 ? 99 : ai) - (bi < 0 ? 99 : bi);
      return a.localeCompare(b,'es-CL');
    });
  });

  protected readonly improvementGoalGroups = computed(() => {
    const groups = new Map<string, WorkItem[]>();
    const selectedSheet = this.improvementGoalSheetFilter();
    for (const item of this.filteredItems()) {
      const meta = this.importMeta(item);
      if (String(meta['sourceKind'] ?? '') !== 'POR_HACER') continue;
      const section = this.goalGroupLabel(item.sourceSheetName || String(meta['sourceSection'] ?? 'Sin categoría'));
      if (selectedSheet !== 'ALL' && section !== selectedSheet) continue;
      const list = groups.get(section) ?? [];
      list.push(item);
      groups.set(section, list);
    }
    return Array.from(groups.entries()).map(([name,items]) => ({
      name,
      items: [...items].sort((a,b) => this.compareImprovementByDue(a,b)),
      completed: items.filter(i => i.status === 'COMPLETED').length,
      pending: items.filter(i => i.status !== 'COMPLETED' && i.status !== 'CANCELLED').length
    })).sort((a,b) => {
      const order = ['Proyectos Pendientes','Metas Recepción','Metas Obras','Metas Jardinería','Metas Marketing','Metas Oficina'];
      const ai = order.indexOf(a.name), bi = order.indexOf(b.name);
      if (ai >= 0 || bi >= 0) return (ai < 0 ? 99 : ai) - (bi < 0 ? 99 : bi);
      return a.name.localeCompare(b.name,'es-CL');
    });
  });

  private improvementDueTime(item: WorkItem): number | null {
    if (item.scheduledEnd) {
      const value = new Date(`${item.scheduledEnd.slice(0,10)}T12:00:00`).getTime();
      return Number.isNaN(value) ? null : value;
    }
    const target = this.improvementTarget(item);
    if (target.year && target.month) {
      return new Date(target.year, target.month - 1, 1, 12, 0, 0).getTime();
    }
    if (item.scheduledStart) {
      const value = new Date(`${item.scheduledStart.slice(0,10)}T12:00:00`).getTime();
      return Number.isNaN(value) ? null : value;
    }
    return null;
  }

  private compareImprovementByDue(a: WorkItem, b: WorkItem): number {
    const closedA = ['COMPLETED','CANCELLED'].includes(a.status);
    const closedB = ['COMPLETED','CANCELLED'].includes(b.status);
    if (closedA !== closedB) return closedA ? 1 : -1;
    const now = new Date(); now.setHours(0,0,0,0);
    const nowMs = now.getTime();
    const aTime = this.improvementDueTime(a);
    const bTime = this.improvementDueTime(b);
    const bucket = (value: number | null) => value == null ? 2 : value < nowMs ? 0 : 1;
    const aBucket = bucket(aTime), bBucket = bucket(bTime);
    if (aBucket !== bBucket) return aBucket - bBucket;
    if (aTime != null && bTime != null) {
      if (aBucket === 0) return bTime - aTime; // vencidas: primero la más recientemente vencida
      if (aTime !== bTime) return aTime - bTime; // futuras: primero la más cercana
    }
    return a.title.localeCompare(b.title,'es-CL',{numeric:true});
  }

  protected readonly improvementSourceCounts = computed(() => ({
    porHacer: this.items().filter(i => i.workType === 'IMPROVEMENT' && this.importMeta(i)['sourceKind'] === 'POR_HACER').length,
    annual: this.items().filter(i => i.workType === 'IMPROVEMENT' && this.importMeta(i)['sourceKind'] === 'ANNUAL_PLAN').length,
    gantt: this.items().filter(i => i.workType === 'IMPROVEMENT_GANTT').length
  }));


  protected readonly improvementBudgetBySection = computed(() => {
    const totals = new Map<string,{total:number;records:number}>();
    const year = this.improvementBudgetYear();
    for (const item of this.items()) {
      if (item.workType !== 'IMPROVEMENT') continue;
      if (this.improvementTarget(item).year !== year) continue;
      const section = String(this.importMeta(item)['sourceSection'] ?? (item.importSourceFilename ? 'Excel importado' : 'Registros manuales'));
      const current = totals.get(section) ?? {total:0,records:0};
      current.total += Number(item.estimatedCost ?? 0); current.records += 1; totals.set(section,current);
    }
    return Array.from(totals.entries()).map(([section,data]) => ({section,...data})).sort((a,b)=>b.total-a.total||b.records-a.records);
  });


  protected readonly monthlyExpenseSummary = computed(() => {
    const year = this.annualYear();
    const months = Array.from({length:12},(_,i)=>({month:i+1,label:new Intl.DateTimeFormat('es-CL',{month:'short'}).format(new Date(year,i,1)),total:0,records:0}));
    for (const expense of this.expenseReport()?.expenses ?? []) {
      const raw = expense.operationDate || expense.createdAt;
      if (!raw) continue;
      const date = new Date(raw.length === 10 ? `${raw}T00:00:00` : raw);
      if (Number.isNaN(date.getTime()) || date.getFullYear() !== year) continue;
      months[date.getMonth()].total += Number(expense.amount ?? 0); months[date.getMonth()].records += 1;
    }
    const max = Math.max(1,...months.map(m=>m.total));
    return months.map(m=>({...m,percent:(m.total/max)*100}));
  });

  protected readonly machineRooms = computed(() => {
    const counts = new Map<string, number>();
    for (const item of this.items()) {
      const room = item.location?.trim() || 'Ubicación sin definir';
      counts.set(room, (counts.get(room) ?? 0) + 1);
    }
    return Array.from(counts.entries()).map(([name, count]) => ({name, count})).sort(
      (a,b) => a.name.localeCompare(b.name, 'es-CL')
    );
  });

  protected readonly ganttTimeline = computed(() => {
    const rows = this.filteredItems().filter(item => !!item.scheduledStart);
    if (!rows.length) return null;
    const timestamps = rows.flatMap(item => [
      dateOnlyDay(item.scheduledStart!)!,
      dateOnlyDay(item.scheduledEnd || item.scheduledStart!)!
    ]);
    const first = Math.min(...timestamps);
    const last = Math.max(...timestamps);
    const totalDays = Math.max(1, last - first + 1);
    const bars = rows.map(item => {
      const a = dateOnlyDay(item.scheduledStart!)!;
      const end = dateOnlyDay(item.scheduledEnd || item.scheduledStart!)!;
      const b = Math.max(a,end);
      return {
        id: item.id, title: item.title, status: item.status, item,
        responsible: item.responsibleName || 'Sin asignar',
        statusLabel: this.statusLabel(item),
        statusClass: this.statusClass(item),
        dates: `${this.formatDate(item.scheduledStart!)} → ${this.formatDate(item.scheduledEnd || item.scheduledStart!)}`,
        progress: Math.max(0, Math.min(100, item.progressPercent ?? 0)),
        left: ((a - first) / totalDays) * 100,
        width: ((b - a + 1) / totalDays) * 100
      };
    });
    const labelCount = Math.min(5, totalDays);
    const labels = Array.from({length: labelCount}, (_, index) => {
      const offset = labelCount === 1 ? 0 : Math.round((totalDays - 1) * index / (labelCount - 1));
      const day = dateOnlyToLocalDate(dateOnlyKeyFromDay(first + offset));
      return new Intl.DateTimeFormat('es-CL', {day:'2-digit', month:'short'}).format(day);
    });
    return { bars, labels, totalDays, minWidth: Math.max(650, 220 + totalDays * 18) };
  });

  protected toggleGantt(): void { this.showGantt.update(v => !v); }
  protected chooseRoom(value: string): void { this.roomFilter.set(value); }

  protected readonly locationSuggestions =
    signal<LocationSuggestion[]>([]);


  protected readonly locationSuggestionsOpen =
    signal(false);


  protected readonly modalOpen =
    signal(false);


  protected readonly editingId =
    signal<string | null>(null);

  protected readonly editingItem = computed(() => {
    const id = this.editingId();
    return id ? this.items().find(item => item.id === id) ?? null : null;
  });


  protected form:
    OperationalForm =
    this.emptyForm();


  /* ============================================================
     FILTROS
     ============================================================ */

  protected readonly locationOptions = computed(() => {
    const values: string[] = this.items()
      .map(item => this.effectiveItemLocationLabel(item))
      .filter(value => value.length > 0);

    return Array.from(new Set<string>(values))
      .sort((a, b) => a.localeCompare(b, 'es-CL', { numeric: true }));
  });

  protected readonly responsibleOptions = computed(() => {
    const values: string[] = this.items()
      .map(item => item.responsibleName?.trim() ?? '')
      .filter(value => value.length > 0);

    return Array.from(new Set<string>(values))
      .sort((a, b) => a.localeCompare(b, 'es-CL'));
  });

  protected readonly categoryOptions = computed(() => {
    const values = this.items().map(item => item.category?.trim() ?? '').filter(Boolean);
    return Array.from(new Set<string>(values)).sort((a,b) => a.localeCompare(b, 'es-CL'));
  });

  protected readonly targetYearOptions = computed(() => {
    const years = new Set<number>();
    for (const item of this.items()) {
      const target = this.improvementTarget(item);
      if (target.year) years.add(target.year);
    }
    return Array.from(years).sort((a,b) => b-a);
  });

  protected readonly activeFilterCount = computed(() => {
    let count = 0;
    if (this.locationFilter() !== 'ALL') count++;
    if (this.responsibleFilter() !== 'ALL') count++;
    if (!this.isImprovementArea() && this.priorityFilter() !== 'ALL') count++;
    if (this.isImprovementArea() && this.categoryFilter() !== 'ALL') count++;
    if (this.isImprovementArea() && this.targetYearFilter() !== 'ALL') count++;
    if (this.isImprovementArea() && this.improvementSectionFilter() !== 'ALL') count++;
    if (this.statusFilter() !== 'ALL') count++;
    return count;
  });

  protected readonly filteredItems =
    computed(() => {

      const query =
        this.searchQuery()
          .trim()
          .toLocaleLowerCase('es-CL');

      const status = this.statusFilter();
      const location = this.locationFilter();
      const responsible = this.responsibleFilter();
      const priority = this.priorityFilter();
      const category = this.categoryFilter();
      const targetYear = this.targetYearFilter();
      const sectionFilter = this.improvementSectionFilter();

      const matches = this.items()
        .filter(item => {

          if (this.isImprovementArea() && item.workType !== 'IMPROVEMENT') return false;

          if (this.isLocationFolderArea() && this.roomFilter() !== 'todas' &&
              (item.location?.trim() || 'Ubicación sin definir') !== this.roomFilter()) return false;

          if (status !== 'ALL') {
            if (this.isReactiveArea() || this.isImprovementArea()) {
              if (status === 'OVERDUE') {
                if (!this.isOverdue(item)) return false;
              } else if (item.status !== status) {
                return false;
              }
            } else if (status === 'OVERDUE') {
              if (!this.isOverdue(item)) return false;
            } else {
              if (this.isOverdue(item) || item.status !== status) return false;
            }
          }

          if (location !== 'ALL' &&
              this.locationComparisonKey(this.effectiveItemLocationLabel(item)) !== this.locationComparisonKey(location)) {
            return false;
          }

          if (responsible !== 'ALL' && (item.responsibleName?.trim() || '') !== responsible) {
            return false;
          }

          if (!this.isImprovementArea() && priority !== 'ALL' && item.priority !== priority) {
            return false;
          }

          if (this.isImprovementArea() && category !== 'ALL' && (item.category?.trim() || '') !== category) {
            return false;
          }

          if (this.isImprovementArea() && targetYear !== 'ALL') {
            const target = this.improvementTarget(item);
            if (targetYear === 'UNSCHEDULED') {
              if (target.year || target.month) return false;
            } else if (target.year !== Number(targetYear)) {
              return false;
            }
          }

          if (this.isImprovementArea() && sectionFilter !== 'ALL' && String(this.importMeta(item)['sourceSection'] ?? '') !== sectionFilter) return false;

          if (!query) {
            return true;
          }

          const searchable = [
            item.title,
            item.description,
            item.location,
            this.effectiveItemLocationLabel(item),
            item.responsibleName,
            item.category,
            item.assetName,
            item.frequency,
            item.season,
            item.materials,
            item.supplierName,
            item.notes,
            item.importedData
          ]
            .filter(Boolean)
            .join(' ')
            .toLocaleLowerCase('es-CL');

          return searchable.includes(query);
        });

      return [...matches].sort((a, b) => this.compareItems(a, b));
    });

  protected readonly groupedFilteredItems = computed(() => {
    if (!this.groupByZone() || this.area().slug !== 'mantencion-general') {
      return [{ name: '', items: this.filteredItems() }];
    }

    const groups = new Map<string, WorkItem[]>();

    for (const item of this.filteredItems()) {
      const groupName = this.zoneGroupLabel(item);
      const current = groups.get(groupName) ?? [];
      current.push(item);
      groups.set(groupName, current);
    }

    const result = Array.from(groups.entries())
      .map(([name, items]) => ({
        name,
        items: [...items].sort((a, b) => this.compareItems(a, b))
      }));

    const mode = this.sortMode();

    return result.sort((a, b) => {
      if (a.name === 'Sin zona definida') return 1;
      if (b.name === 'Sin zona definida') return -1;

      if (mode === 'RECENT' || mode === 'OLDEST') {
        const aTime = this.groupCreatedAt(a.items, mode === 'RECENT');
        const bTime = this.groupCreatedAt(b.items, mode === 'RECENT');
        if (aTime !== bTime) {
          return mode === 'RECENT' ? bTime - aTime : aTime - bTime;
        }
      }

      return a.name.localeCompare(b.name, 'es-CL');
    });
  });

  private compareItems(a: WorkItem, b: WorkItem): number {
    const mode = this.sortMode();

    if (mode === 'AZ') {
      return a.title.localeCompare(b.title, 'es-CL', { sensitivity: 'base' });
    }

    if (mode === 'ZA') {
      return b.title.localeCompare(a.title, 'es-CL', { sensitivity: 'base' });
    }

    const aTime = this.createdAtTime(a);
    const bTime = this.createdAtTime(b);

    if (aTime !== bTime) {
      return mode === 'OLDEST' ? aTime - bTime : bTime - aTime;
    }

    return a.title.localeCompare(b.title, 'es-CL', { sensitivity: 'base' });
  }

  private createdAtTime(item: WorkItem): number {
    const value = Date.parse(item.createdAt);
    return Number.isNaN(value) ? 0 : value;
  }

  private groupCreatedAt(items: WorkItem[], newest: boolean): number {
    if (!items.length) return 0;
    const values = items.map(item => this.createdAtTime(item));
    return newest ? Math.max(...values) : Math.min(...values);
  }



  /* ============================================================
     INDICADORES
     ============================================================ */

  protected readonly reactiveUrgentCount = computed(() =>
    this.items().filter(item =>
      item.priority === 'URGENT'
      && !['COMPLETED', 'CANCELLED'].includes(item.status)
    ).length
  );

  protected readonly reactiveAttentionCount = computed(() =>
    this.items().filter(item => item.status === 'IN_PROGRESS').length
  );

  protected readonly reactivePendingCount = computed(() =>
    this.items().filter(item => ['PLANNED', 'PENDING'].includes(item.status)).length
  );

  protected readonly reactiveResolvedCount = computed(() =>
    this.items().filter(item => item.status === 'COMPLETED').length
  );

  protected readonly improvementAnalysisCount = computed(() =>
    this.improvementItems().filter(item => item.status === 'PLANNED').length
  );

  protected readonly improvementApprovedCount = computed(() =>
    this.improvementItems().filter(item => item.status === 'PENDING').length
  );

  protected readonly improvementWaitingCount = computed(() =>
    this.improvementItems().filter(item => item.status === 'IN_PROGRESS').length
  );

  protected readonly improvementUpcomingCount = computed(() =>
    this.improvementItems().filter(item => this.isImprovementUpcoming(item)).length
  );

  protected readonly improvementAlerts = computed(() => {
    const alerts: Array<{kind:string;icon:string;title:string;message:string;item:WorkItem|null}> = [];
    const overdue = this.improvementItems().filter(item => this.isOverdue(item));
    for (const item of overdue.slice(0, 4)) {
      alerts.push({kind:'danger',icon:'fa-solid fa-triangle-exclamation',title:'Fecha objetivo vencida',message:item.title,item});
    }
    const upcoming = this.improvementItems().filter(item => this.isImprovementUpcoming(item)).slice(0,4);
    for (const item of upcoming) {
      alerts.push({kind:'warning',icon:'fa-solid fa-calendar-day',title:'Fecha objetivo próxima',message:item.title,item});
    }
    const today = this.startOfToday();
    const end = new Date(today.getFullYear(), 11, 31);
    const days = Math.ceil((end.getTime() - today.getTime()) / 86400000);
    const openThisYear = this.improvementItems().filter(item => {
      if (['COMPLETED','CANCELLED'].includes(item.status)) return false;
      const target = this.improvementTarget(item);
      return target.year === today.getFullYear();
    });
    if (days >= 0 && days <= 75) {
      const unscheduled = this.improvementItems().filter(item => {
        if (['COMPLETED','CANCELLED'].includes(item.status)) return false;
        const target = this.improvementTarget(item);
        return !target.year || !target.month;
      }).length;
      if (openThisYear.length || unscheduled) {
        const parts = [];
        if (openThisYear.length) parts.push(`${openThisYear.length} mejora(s) del año siguen abiertas`);
        if (unscheduled) parts.push(`${unscheduled} idea(s) continúan sin mes objetivo`);
        alerts.unshift({kind:'info',icon:'fa-solid fa-flag-checkered',title:'Revisión de cierre anual',message:parts.join(' · ') + '.',item:null});
      }
    }
    return alerts;
  });

  protected readonly activeCount =
    computed(() => {

      return this.items()
        .filter(item =>

          ![
            'COMPLETED',
            'CANCELLED'
          ].includes(
            item.status
          )

        )
        .length;
    });


  protected readonly upcomingCount =
    computed(() => {

      const today =
        this.startOfToday();


      const limit =
        new Date(today);


      limit.setDate(
        limit.getDate() + 30
      );


      return this.items()
        .filter(item => {

          if (
            !item.scheduledStart
            || [
              'COMPLETED',
              'CANCELLED'
            ].includes(
              item.status
            )
          ) {

            return false;
          }


          const date =
            this.parseDate(
              item.scheduledStart
            );


          return (
            date >= today
            && date <= limit
          );
        })
        .length;
    });


  protected readonly overdueCount =
    computed(() => {

      return this.items()
        .filter(item =>
          this.isOverdue(item)
        )
        .length;
    });


  protected readonly totalActualCost =
    computed(() => {

      if (this.area().slug === 'mejoras') return this.improvementBudgetTotal();
      return this.items()
        .filter(item => item.status !== 'CANCELLED')
        .reduce((total,item) => total + Number(item.actualCost ?? 0), 0);
    });


  protected readonly summaryItems = computed(() => {
    const kind = this.summaryKind();
    const today = this.startOfToday();
    const limit = new Date(today);
    limit.setDate(limit.getDate() + 30);

    if (kind === 'REACTIVE_URGENT') {
      return this.items().filter(item =>
        item.priority === 'URGENT'
        && !['COMPLETED', 'CANCELLED'].includes(item.status)
      );
    }

    if (kind === 'REACTIVE_ATTENTION') {
      return this.items().filter(item => item.status === 'IN_PROGRESS');
    }

    if (kind === 'REACTIVE_PENDING') {
      return this.items().filter(item => ['PLANNED', 'PENDING'].includes(item.status));
    }

    if (kind === 'REACTIVE_RESOLVED') {
      return this.items().filter(item => item.status === 'COMPLETED');
    }

    if (kind === 'IMPROVEMENT_ANALYSIS') {
      return this.improvementItems().filter(item => item.status === 'PLANNED');
    }

    if (kind === 'IMPROVEMENT_APPROVED') {
      return this.improvementItems().filter(item => item.status === 'PENDING');
    }

    if (kind === 'IMPROVEMENT_WAITING') {
      return this.improvementItems().filter(item => item.status === 'IN_PROGRESS');
    }

    if (kind === 'IMPROVEMENT_UPCOMING') {
      return this.improvementItems().filter(item => this.isImprovementUpcoming(item));
    }

    if (kind === 'ACTIVE') {
      return this.items().filter(item => !['COMPLETED', 'CANCELLED'].includes(item.status));
    }

    if (kind === 'UPCOMING') {
      return this.items().filter(item => {
        if (!item.scheduledStart || ['COMPLETED', 'CANCELLED'].includes(item.status)) return false;
        const date = this.parseDate(item.scheduledStart);
        return date >= today && date <= limit;
      });
    }

    if (kind === 'OVERDUE') {
      return this.items().filter(item => this.isOverdue(item));
    }

    if (kind === 'COST') {
      return this.items().filter(item => {
        const amount = this.area().slug === 'mejoras' ? item.estimatedCost : item.actualCost;
        if (item.status === 'CANCELLED' || Number(amount ?? 0) <= 0) return false;
        if (this.area().slug === 'mejoras') return this.improvementTarget(item).year === this.improvementBudgetYear();
        return true;
      });
    }

    return [];
  });

  protected readonly summaryTitle = computed(() => {
    if (this.summaryKind() === 'COST' && this.isImprovementArea()) return `Presupuestos previstos ${this.improvementBudgetYear()}`;
    const labels: Record<SummaryKind, string> = {
      ACTIVE: 'Mantenciones activas',
      UPCOMING: 'Mantenciones próximas',
      OVERDUE: 'Mantenciones atrasadas',
      COST: 'Detalle de costos reales',
      REACTIVE_URGENT: 'Incidencias urgentes',
      REACTIVE_ATTENTION: 'Incidencias en atención',
      REACTIVE_PENDING: 'Incidencias pendientes de revisión',
      REACTIVE_RESOLVED: 'Incidencias resueltas',
      IMPROVEMENT_ANALYSIS: 'Mejoras en análisis',
      IMPROVEMENT_APPROVED: 'Mejoras aprobadas',
      IMPROVEMENT_WAITING: 'Mejoras esperando ejecución',
      IMPROVEMENT_UPCOMING: 'Fechas objetivo próximas'
    };
    const kind = this.summaryKind();
    return kind ? labels[kind] : '';
  });

  protected readonly summaryEmptyText = computed(() => {
    if (this.summaryKind() === 'COST' && this.isImprovementArea()) return `No hay mejoras con presupuesto estimado para ${this.improvementBudgetYear()}.`;
    const labels: Record<SummaryKind, string> = {
      ACTIVE: 'No hay mantenciones activas registradas.',
      UPCOMING: 'No hay mantenciones programadas para los próximos 30 días.',
      OVERDUE: 'No hay mantenciones atrasadas.',
      COST: 'No hay mantenciones con costo real registrado.',
      REACTIVE_URGENT: 'No hay incidencias urgentes abiertas.',
      REACTIVE_ATTENTION: 'No hay incidencias actualmente en atención.',
      REACTIVE_PENDING: 'No hay incidencias pendientes de revisión.',
      REACTIVE_RESOLVED: 'Todavía no hay incidencias resueltas.',
      IMPROVEMENT_ANALYSIS: 'No hay mejoras en análisis.',
      IMPROVEMENT_APPROVED: 'No hay mejoras aprobadas.',
      IMPROVEMENT_WAITING: 'No hay mejoras esperando ejecución.',
      IMPROVEMENT_UPCOMING: 'No hay fechas objetivo dentro de los próximos 60 días.'
    };
    const kind = this.summaryKind();
    return kind ? labels[kind] : '';
  });

  protected readonly summaryCostTotal = computed(() =>
    this.summaryItems().reduce(
      (total, item) => total + Number(
        (this.area().slug === 'mejoras' ? item.estimatedCost : item.actualCost) ?? 0
      ),
      0
    )
  );

  /* ============================================================
     CONSTRUCTOR
     ============================================================ */

  constructor() {

    this.route
      .paramMap
      .subscribe(params => {

        const slug =
          params.get('slug');


        if (
          !slug
          || !AREA_CONFIGS[slug]
        ) {

          this.router.navigateByUrl(
            '/dashboard'
          );

          return;
        }


        this.changeArea(
          AREA_CONFIGS[slug]
        );
      });
  }


  /* ============================================================
     CAMBIAR ÁREA
     ============================================================ */

  private changeArea(
    config: AreaOperationalConfig
  ): void {

    this.area.set(
      config
    );


    this.items.set(
      []
    );


    this.searchQuery.set(
      ''
    );

    this.roomFilter.set('todas');
    this.showGantt.set(true);
    this.moduleView.set(config.slug === 'mejoras' ? 'goals' : 'cards');
    this.annualYear.set(new Date().getFullYear());
    this.openedDate.set(null);
    this.selectedImprovementIds.set(new Set());
    this.closeDestructiveDialog();


    this.statusFilter.set(
      'ALL'
    );
    this.locationFilter.set('ALL');
    this.responsibleFilter.set('ALL');
    this.priorityFilter.set('ALL');
    this.categoryFilter.set('ALL');
    this.targetYearFilter.set('ALL');
    this.improvementSectionFilter.set('ALL');
    this.improvementGoalSheetFilter.set('ALL');
    this.filterPanelOpen.set(false);
    this.groupByZone.set(true);
    this.expandedZoneGroups.set(new Set());
    this.summaryKind.set(null);


    this.modalOpen.set(
      false
    );


    this.editingId.set(
      null
    );


    this.errorMessage.set(
      ''
    );


    this.successMessage.set(
      ''
    );


    this.form =
      this.emptyForm();


    this.loadItems();
    if (config.slug === 'mantencion-maquinas') this.loadMachineAssets();
    else this.machineAssets.set([]);
  }

  private loadMachineAssets(): void {
    this.http.get<MachineAsset[]>('/api/assets', {params:{includeInactive:'true'},withCredentials:true}).subscribe({
      next: assets => this.machineAssets.set(assets),
      error: () => this.machineAssets.set([])
    });
  }

  protected selectMachineAsset(assetId: string): void {
    this.form.assetId = assetId;
    const asset = this.machineAssets().find(candidate => candidate.id === assetId);
    if (!asset) return;
    this.form.assetName = asset.name;
    this.form.location = asset.location ?? '';
  }

  protected assetStatusLabel(status: MachineAsset['operationalStatus']): string {
    return status === 'OPERATIONAL' ? 'Operativo' : status === 'FAULT' ? 'Con falla' : 'Fuera de servicio';
  }

  protected linkedAsset(item: WorkItem): MachineAsset | null {
    return item.assetId ? this.machineAssets().find(asset => asset.id === item.assetId) ?? null : null;
  }


  /* ============================================================
     CARGAR
     ============================================================ */

  private loadItems(): void {
    const currentArea = this.area();
    this.loading.set(true);
    if (this.isImprovementArea()) {
      forkJoin({
        improvements: this.http.get<WorkItem[]>('/api/work-items', {params:{area:currentArea.slug,type:'IMPROVEMENT'},withCredentials:true}),
        gantt: this.http.get<WorkItem[]>('/api/work-items', {params:{area:currentArea.slug,type:'IMPROVEMENT_GANTT'},withCredentials:true})
      }).subscribe({
        next: ({improvements,gantt}) => this.applyLoadedItems([...improvements,...gantt], currentArea),
        error: () => { this.errorMessage.set(`No se pudieron cargar los registros de ${currentArea.name}.`); this.loading.set(false); }
      });
      this.loadExpenseSummary();
      return;
    }
    this.http.get<WorkItem[]>('/api/work-items', {params:{area:currentArea.slug,type:currentArea.workType},withCredentials:true}).subscribe({
      next: items => this.applyLoadedItems(items, currentArea),
      error: () => { this.errorMessage.set(`No se pudieron cargar los registros de ${currentArea.name}.`); this.loading.set(false); }
    });
  }

  private applyLoadedItems(items: WorkItem[], currentArea: AreaOperationalConfig): void {
    this.items.set(items);
    if (this.isImprovementArea()) {
      const currentYear = new Date().getFullYear();
      const years = items
        .filter(item => item.workType === 'IMPROVEMENT')
        .map(item => this.improvementTarget(item).year)
        .filter((year): year is number => !!year);
      const initial = years.includes(currentYear) ? currentYear : (years.length ? Math.max(...years) : currentYear);
      this.improvementBudgetYear.set(initial);
    }
    const importedCount = this.route.snapshot.queryParamMap.get('importados');
    if (importedCount) {
      this.successMessage.set(this.isImprovementArea() ? `${importedCount} registro(s) del Excel fueron incorporados a Mejoras.` : `${importedCount} registros del Excel fueron incorporados a Mantención General.`);
      this.router.navigate([], {relativeTo:this.route,queryParams:{importados:null},queryParamsHandling:'merge',replaceUrl:true});
    }
    const editId = this.route.snapshot.queryParamMap.get('editar');
    const itemToEdit = editId ? items.find(item => item.id === editId) : null;
    if (itemToEdit) {
      this.openEdit(itemToEdit);
      this.router.navigate([], {relativeTo:this.route,queryParams:{editar:null},queryParamsHandling:'merge',replaceUrl:true});
    } else {
      const newDate = this.route.snapshot.queryParamMap.get('crearFecha');
      const newMonth = Number(this.route.snapshot.queryParamMap.get('crearMes') || 0);
      const newYear = Number(this.route.snapshot.queryParamMap.get('crearAnio') || 0);
      const newAsset = this.route.snapshot.queryParamMap.get('activo');
      const newAssetId = this.route.snapshot.queryParamMap.get('activoId');
      const newLocation = this.route.snapshot.queryParamMap.get('ubicacion');
      if (newDate && /^\d{4}-\d{2}-\d{2}$/.test(newDate)) {
        this.openCreate(); this.form.scheduledStart = newDate;
        this.router.navigate([], {relativeTo:this.route,queryParams:{crearFecha:null},queryParamsHandling:'merge',replaceUrl:true});
      } else if (newMonth >= 1 && newMonth <= 12 && newYear >= 2000) {
        this.openCreate(); this.form.scheduledStart = `${newYear}-${String(newMonth).padStart(2,'0')}-01`;
        this.router.navigate([], {relativeTo:this.route,queryParams:{crearMes:null,crearAnio:null},queryParamsHandling:'merge',replaceUrl:true});
      } else if (newAssetId || newAsset || newLocation) {
        this.openCreate(); if (newAssetId) this.selectMachineAsset(newAssetId); if (newAsset && !this.form.assetName) this.form.assetName = newAsset; if (newLocation && !this.form.location) this.form.location = newLocation;
        this.router.navigate([], {relativeTo:this.route,queryParams:{crear:null,activoId:null,activo:null,ubicacion:null},queryParamsHandling:'merge',replaceUrl:true});
      }
    }
    this.loading.set(false);
  }

  private loadExpenseSummary(): void {
    this.http.get<ExpenseReport>('/api/expenses/summary', {withCredentials:true}).subscribe({next: report => this.expenseReport.set(report), error: () => this.expenseReport.set(null)});
  }


  /* ============================================================
     BUSCADOR
     ============================================================ */

  protected onSearchInput(
    event: Event
  ): void {

    const input =
      event.target as HTMLInputElement;


    this.searchQuery.set(
      input.value
    );
  }


  protected onStatusFilterChange(
    event: Event
  ): void {

    const select =
      event.target as HTMLSelectElement;


    this.statusFilter.set(
      select.value
    );
  }


  protected toggleFilterPanel(): void {
    this.filterPanelOpen.update(value => !value);
  }

  protected changeSortMode(value: SortMode): void {
    this.sortMode.set(value);
  }

  protected changeTargetYearFilter(value: string): void {
    this.targetYearFilter.set(value);
    const year = Number(value);
    if (value !== 'ALL' && value !== 'UNSCHEDULED' && Number.isFinite(year)) {
      this.annualYear.set(year);
    }
  }

  protected clearFilters(): void {
    this.locationFilter.set('ALL');
    this.responsibleFilter.set('ALL');
    this.priorityFilter.set('ALL');
    this.categoryFilter.set('ALL');
    this.targetYearFilter.set('ALL');
    this.improvementSectionFilter.set('ALL');
    this.improvementGoalSheetFilter.set('ALL');
    this.statusFilter.set('ALL');
  }

  protected openSummary(kind: SummaryKind): void {
    this.summaryKind.set(kind);
  }

  protected closeSummary(): void {
    this.summaryKind.set(null);
  }

  protected openFromSummary(item: WorkItem): void {
    this.closeSummary();
    this.openEdit(item);
  }

  protected toggleGroupByZone(): void {
    this.groupByZone.update(value => !value);
    this.expandedZoneGroups.set(new Set());
  }

  protected isZoneGroupExpanded(name: string): boolean {
    return !name || this.expandedZoneGroups().has(name);
  }

  protected toggleZoneGroup(name: string): void {
    if (!name) return;

    this.expandedZoneGroups.update(current => {
      const next = new Set(current);
      if (next.has(name)) {
        next.delete(name);
      } else {
        next.add(name);
      }
      return next;
    });
  }

  private zoneGroupLabel(item: WorkItem): string {
    const value = this.effectiveItemLocationLabel(item);
    const normalized = this.normalizeText(value);

    if (!value) return 'Sin zona definida';
    if (/^habitacion\s+\d+/.test(normalized)) return 'Habitaciones';
    if (/^(b|bano)\s*publico/.test(normalized)) return 'Baños públicos';
    return value;
  }

  protected displayLocation(location: string | null): string {
    const value = this.canonicalLocationLabel(location);
    return value || 'Sin ubicación';
  }

  protected displayItemLocation(item: WorkItem): string {
    const value = this.effectiveItemLocationLabel(item);
    return value || 'Sin ubicación';
  }

  private effectiveItemLocationLabel(item: WorkItem): string {
    const directLocation = this.canonicalLocationLabel(item.location);
    const directKey = this.normalizeText(directLocation);

    if (/^habitacion\s+\d+/.test(directKey)) {
      return directLocation;
    }

    const titleKey = this.normalizeText(item.title || '');
    const roomFromTitle = titleKey.match(/^(?:habitacion|hab)?\s*(\d{2,4})$/);

    const genericHotelLocation =
      !directKey ||
      directKey === 'hotel' ||
      directKey === 'habitacion' ||
      directKey === 'habitaciones' ||
      directKey === 'hotel el almendro' ||
      directKey === 'el almendro';

    if (roomFromTitle && genericHotelLocation) {
      return `Habitación ${roomFromTitle[1]}`;
    }

    return directLocation;
  }

  private canonicalLocationLabel(location: string | null): string {
    const value = (location || '').trim();
    if (!value) return '';

    const normalized = this.normalizeText(value);

    if (/^\d{3}$/.test(normalized)) {
      return `Habitación ${normalized}`;
    }

    const roomMatch = normalized.match(/^(?:habitacion|hab)\s*(\d{2,4})$/);
    if (roomMatch) {
      return `Habitación ${roomMatch[1]}`;
    }

    return value;
  }

  private locationComparisonKey(location: string | null): string {
    return this.normalizeText(this.canonicalLocationLabel(location));
  }

  private normalizeText(value: string): string {
    return value
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLocaleLowerCase('es-CL')
      .replace(/[^a-z0-9]+/g, ' ')
      .trim()
      .replace(/\s+/g, ' ');
  }

  protected onLocationChange(value: string): void {

    this.form.location = value;

    if (!['mantencion-general', 'mantencion-reactiva'].includes(this.area().slug)) {
      return;
    }

    this.loadLocationSuggestions(value);
  }


  protected onLocationFocus(): void {

    if (!['mantencion-general', 'mantencion-reactiva'].includes(this.area().slug)) {
      return;
    }

    this.loadLocationSuggestions(this.form.location);
  }


  protected chooseLocation(name: string): void {

    this.form.location = name;
    this.locationSuggestions.set([]);
    this.locationSuggestionsOpen.set(false);
  }


  protected closeLocationSuggestions(): void {

    setTimeout(() => {
      this.locationSuggestionsOpen.set(false);
    }, 120);
  }


  private loadLocationSuggestions(query: string): void {

    this.http.get<LocationSuggestion[]>(
      `/api/areas/${this.area().slug}/locations`,
      {
        params: { q: query ?? '' },
        withCredentials: true
      }
    ).subscribe({
      next: suggestions => {
        this.locationSuggestions.set(suggestions);
        this.locationSuggestionsOpen.set(true);
      },
      error: () => {
        this.locationSuggestions.set([]);
        this.locationSuggestionsOpen.set(false);
      }
    });
  }


  /* ============================================================
     CREAR
     ============================================================ */

  protected openCreate(): void {

    this.creatingGantt.set(false);

    this.editingId.set(
      null
    );


    this.form =
      this.emptyForm();

    if (this.isReactiveArea()) {
      this.form.status = 'PLANNED';
      this.form.priority = 'NORMAL';
      this.form.scheduledStart = this.dateKey(new Date());
    }

    if (this.isImprovementArea()) {
      this.form.status = 'PLANNED';
      this.form.priority = 'NORMAL';
    }


    this.locationSuggestions.set([]);
    this.locationSuggestionsOpen.set(false);


    this.errorMessage.set(
      ''
    );


    this.successMessage.set(
      ''
    );


    this.modalOpen.set(
      true
    );
  }


  /* ============================================================
     EDITAR
     ============================================================ */

  protected openEdit(
    item: WorkItem
  ): void {

    this.creatingGantt.set(false);

    this.editingId.set(
      item.id
    );


    const parsedImportedData = this.parseImportedData(item.importedData);

    this.form = {

      phase: item.phase ?? '',

      title:
        item.title,

      description:
        item.description ?? '',

      location:
        item.location ?? '',

      responsibleName:
        item.responsibleName ?? '',

      priority:
        item.priority,

      status:
        item.status,

      scheduledStart:
        item.scheduledStart ?? '',

      scheduledEnd:
        item.scheduledEnd ?? '',

      displayColor:
        normalizeDisplayColor(item.displayColor),

      textColor:
        normalizeHexColor(item.textColor),

      targetYear:
        String(item.plannedYear ?? parsedImportedData['targetYear'] ?? ''),

      targetMonth:
        String(item.plannedMonth ?? parsedImportedData['targetMonth'] ?? ''),

      progressPercent:
        Number(
          item.progressPercent ?? 0
        ),

      notes:
        item.notes ?? '',


      category:
        item.category ?? '',

      assetName:
        item.assetName ?? '',

      assetId:
        item.assetId ?? '',

      frequency:
        item.frequency ?? '',

      season:
        item.season ?? '',

      materials:
        item.materials ?? '',

      supplierName:
        item.supplierName ?? '',

      estimatedCost:
        item.estimatedCost === null
          ? null
          : Number(
              item.estimatedCost
            ),

      actualCost:
        item.actualCost === null
          ? null
          : Number(
              item.actualCost
            ),

      importedData:
        parsedImportedData,

      importSourceFilename:
        item.importSourceFilename,

      sourceSheetName:
        item.sourceSheetName,

      sourceRowNumber:
        item.sourceRowNumber
    };


    this.locationSuggestions.set([]);
    this.locationSuggestionsOpen.set(false);


    this.errorMessage.set(
      ''
    );


    this.successMessage.set(
      ''
    );


    this.modalOpen.set(
      true
    );
  }


  /* ============================================================
     CERRAR MODAL
     ============================================================ */

  protected closeModal(): void {

    if (
      this.saving()
    ) {

      return;
    }


    this.modalOpen.set(
      false
    );
    this.creatingGantt.set(false);
  }


  /* ============================================================
     GUARDAR
     ============================================================ */

  protected save(forceDuplicate = false): void {

    const currentArea =
      this.area();


    const title =
      this.form.title
        .trim();


    if (!title) {

      this.errorMessage.set(
        'Debes ingresar un nombre para el registro.'
      );

      return;
    }


    if (
      this.form.scheduledStart
      && this.form.scheduledEnd
      && this.form.scheduledEnd
        < this.form.scheduledStart
    ) {

      this.errorMessage.set(
        'La fecha de término no puede ser anterior a la fecha de inicio.'
      );

      return;
    }


    if (
      this.form.estimatedCost !== null
      && this.form.estimatedCost < 0
    ) {

      this.errorMessage.set(
        'El presupuesto estimado no puede ser negativo.'
      );

      return;
    }


    if (
      this.form.actualCost !== null
      && this.form.actualCost < 0
    ) {

      this.errorMessage.set(
        'El costo real no puede ser negativo.'
      );

      return;
    }


    if (this.isImprovementArea()) {
      if (this.form.scheduledEnd) {
        const [targetYear, targetMonth] = this.form.scheduledEnd.slice(0, 10).split('-');
        this.form.importedData['targetYear'] = targetYear;
        this.form.importedData['targetMonth'] = String(Number(targetMonth));
      } else {
        if (this.form.targetYear.trim()) this.form.importedData['targetYear'] = this.form.targetYear.trim();
        else delete this.form.importedData['targetYear'];

        if (this.form.targetMonth.trim()) this.form.importedData['targetMonth'] = this.form.targetMonth.trim();
        else delete this.form.importedData['targetMonth'];
      }
    }

    const payload = {

      areaSlug:
        currentArea.slug,

      workType:
        this.isImprovementGanttForm() ? 'IMPROVEMENT_GANTT' : currentArea.workType,

      phase: this.isImprovementGanttForm() ? this.nullIfBlank(this.form.phase) : null,

      plannedYear: this.isImprovementArea() && !this.isImprovementGanttForm() && this.form.targetYear ? Number(this.form.targetYear) : null,

      plannedMonth: this.isImprovementArea() && !this.isImprovementGanttForm() && this.form.targetMonth ? Number(this.form.targetMonth) : null,

      title,

      description:
        this.nullIfBlank(
          this.form.description
        ),

      location:
        this.nullIfBlank(
          this.form.location
        ),

      responsibleName:
        this.nullIfBlank(
          this.form.responsibleName
        ),

      priority:
        this.form.priority,

      status:
        this.form.status,

      scheduledStart:
        this.form.scheduledStart
        || null,

      scheduledEnd:
        this.form.scheduledEnd
        || null,

      displayColor:
        normalizeDisplayColor(this.form.displayColor),

      textColor:
        normalizeHexColor(this.form.textColor),

      progressPercent:
        (['mantencion-general', 'mantencion-reactiva'].includes(currentArea.slug) || (currentArea.slug === 'mejoras' && !this.isImprovementGanttForm()))
          ? 0
          : Number(
              this.form.progressPercent
              || 0
            ),

      notes:
        this.nullIfBlank(
          this.form.notes
        ),


      /* CAMPOS ESPECÍFICOS */

      category:
        this.nullIfBlank(
          this.form.category
        ),

      assetName:
        this.nullIfBlank(
          this.form.assetName
        ),

      assetId:
        this.nullIfBlank(this.form.assetId),

      frequency:
        this.nullIfBlank(
          this.form.frequency
        ),

      season:
        this.nullIfBlank(
          this.form.season
        ),

      materials:
        this.nullIfBlank(
          this.form.materials
        ),

      supplierName:
        this.nullIfBlank(
          this.form.supplierName
        ),

      estimatedCost:
        this.form.estimatedCost,

      actualCost:
        currentArea.slug === 'mejoras' ? null : this.form.actualCost,

      importedData:
        Object.keys(this.form.importedData).length
          ? JSON.stringify(this.form.importedData)
          : null
    };


    const id = this.editingId();
    if (!id && !forceDuplicate) {
      let params = new HttpParams().set('title', title);
      const location = this.nullIfBlank(this.form.location);
      if (location) params = params.set('location', location);
      this.http.get<DuplicateReference[]>('/api/work-items/duplicates', {params, withCredentials:true}).subscribe({
        next: matches => {
          if (matches.length) this.duplicateReferences.set(matches);
          else this.save(true);
        },
        error: () => this.save(true)
      });
      return;
    }

    this.saving.set(
      true
    );


    this.errorMessage.set(
      ''
    );


    this.successMessage.set(
      ''
    );


    const request =
      id

        ? this.http.put<WorkItem>(
            `/api/work-items/${id}`,
            payload,
            {
              withCredentials:
                true
            }
          )

        : this.http.post<WorkItem>(
            '/api/work-items',
            payload,
            {
              withCredentials:
                true
            }
          );


    request.subscribe({

      next: saved => {

        if (id) {

          this.items.update(
            items =>

              items.map(item =>

                item.id === saved.id
                  ? saved
                  : item

              )
          );

        } else {

          this.items.update(
            items => [
              saved,
              ...items
            ]
          );
        }


        this.saving.set(
          false
        );


        this.modalOpen.set(
          false
        );
        this.creatingGantt.set(false);


        this.successMessage.set(

          id

            ? 'Registro actualizado correctamente.'

            : 'Registro creado correctamente.'

        );
      },


      error: (
        error: HttpErrorResponse
      ) => {

        this.saving.set(
          false
        );


        this.errorMessage.set(

          error.error?.message
          || 'No se pudo guardar el registro.'

        );
      }

    });
  }


  protected cancelDuplicateWarning(): void {
    this.duplicateReferences.set(null);
  }

  protected addDuplicateAnyway(): void {
    this.duplicateReferences.set(null);
    this.save(true);
  }

  protected viewDuplicateReference(item: DuplicateReference): void {
    this.duplicateReferences.set(null);
    this.modalOpen.set(false);
    this.router.navigate(['/areas', item.areaSlug], {queryParams:{editar:item.id}});
  }


  /* ============================================================
     FINALIZAR
     ============================================================ */

  protected markCompleted(
    item: WorkItem
  ): void {

    if (
      item.status === 'COMPLETED'
    ) {

      return;
    }


    const payload = {

      areaSlug:
        item.areaSlug,

      workType:
        item.workType,

      phase: item.phase,

      plannedYear: item.plannedYear,

      plannedMonth: item.plannedMonth,

      title:
        item.title,

      description:
        item.description,

      location:
        item.location,

      responsibleName:
        item.responsibleName,

      priority:
        item.priority,

      status:
        'COMPLETED',

      scheduledStart:
        item.scheduledStart,

      scheduledEnd:
        item.scheduledEnd,

      displayColor:
        normalizeDisplayColor(item.displayColor),

      textColor:
        normalizeHexColor(item.textColor),

      progressPercent:
        100,

      notes:
        item.notes,


      category:
        item.category,

      assetName:
        item.assetName,

      frequency:
        item.frequency,

      season:
        item.season,

      materials:
        item.materials,

      supplierName:
        item.supplierName,

      estimatedCost:
        item.estimatedCost,

      actualCost:
        item.actualCost,

      importedData:
        item.importedData
    };


    this.http
      .put<WorkItem>(
        `/api/work-items/${item.id}`,
        payload,
        {
          withCredentials:
            true
        }
      )
      .subscribe({

        next: saved => {

          this.items.update(
            items =>

              items.map(
                current =>

                  current.id === saved.id
                    ? saved
                    : current

              )
          );


          this.successMessage.set(
            this.isReactiveArea()
              ? 'Incidencia resuelta correctamente.'
              : this.isImprovementArea()
                ? 'Mejora marcada como realizada.'
                : 'Registro finalizado correctamente.'
          );
        },


        error: () => {

          this.errorMessage.set(
            this.isReactiveArea()
              ? 'No se pudo marcar la incidencia como resuelta.'
              : this.isImprovementArea()
                ? 'No se pudo marcar la mejora como realizada.'
                : 'No se pudo finalizar el registro.'
          );
        }

      });
  }


  /* ============================================================
     ESTADOS
     ============================================================ */

  protected statusLabel(
    item: WorkItem
  ): string {

    if (this.isReactiveArea()) {
      const reactiveLabels: Record<WorkStatus, string> = {
        PLANNED: 'Reportada',
        PENDING: 'Pendiente de revisión',
        IN_PROGRESS: 'En atención',
        COMPLETED: 'Resuelta',
        OVERDUE: 'Pendiente de revisión',
        CANCELLED: 'Cancelada'
      };
      return reactiveLabels[item.status];
    }

    if (this.isImprovementArea()) {
      const improvementLabels: Record<WorkStatus, string> = {
        PLANNED: 'En análisis',
        PENDING: 'Aprobada',
        IN_PROGRESS: 'Esperando ejecución',
        COMPLETED: 'Realizada',
        OVERDUE: 'Fecha objetivo vencida',
        CANCELLED: 'Descartada'
      };
      if (this.isOverdue(item) && !['COMPLETED','CANCELLED'].includes(item.status)) return 'Fecha objetivo vencida';
      return improvementLabels[item.status];
    }

    if (
      this.isOverdue(item)
      && item.status !== 'COMPLETED'
    ) {

      return 'Atrasada';
    }


    const labels:
      Record<WorkStatus, string> = {

      PLANNED:
        'Planificada',

      PENDING:
        'Pendiente',

      IN_PROGRESS:
        'En proceso',

      COMPLETED:
        'Finalizada',

      OVERDUE:
        'Atrasada',

      CANCELLED:
        'Cancelada'
    };


    return labels[
      item.status
    ];
  }


  protected statusClass(
    item: WorkItem
  ): string {

    if (this.isReactiveArea()) {
      return `status-${item.status.toLowerCase()}`;
    }

    if (
      this.isOverdue(item)
      && item.status !== 'COMPLETED'
    ) {

      return 'status-overdue';
    }


    return (
      `status-${item.status.toLowerCase()}`
    );
  }


  /* ============================================================
     PRIORIDAD
     ============================================================ */

  protected priorityLabel(
    priority: WorkPriority
  ): string {

    const labels:
      Record<WorkPriority, string> = {

      LOW:
        'Baja',

      NORMAL:
        'Normal',

      HIGH:
        'Alta',

      URGENT:
        'Urgente'
    };


    return labels[
      priority
    ];
  }


  protected priorityFieldLabel(): string {
    return this.isReactiveArea() ? 'Nivel de atención' : 'Prioridad';
  }

  protected startDateFieldLabel(): string {
    if (this.isReactiveArea()) return 'Fecha de reporte';
    if (this.isImprovementGanttForm()) return 'Fecha de inicio';
    if (this.isImprovementArea()) return 'Fecha de la idea / propuesta';
    return 'Fecha de inicio';
  }

  protected endDateFieldLabel(): string {
    if (this.isImprovementGanttForm()) return 'Fecha de término';
    return this.isImprovementArea() ? 'Fecha objetivo' : 'Fecha de término';
  }

  protected planningSectionLabel(): string {
    if (this.isReactiveArea()) return 'Atención y seguimiento';
    if (this.isImprovementGanttForm()) return 'Planificación de la tarea Gantt';
    if (this.isImprovementArea()) return 'Planificación anual y etapa';
    return 'Planificación y estado';
  }

  protected descriptionFieldLabel(): string {
    if (this.isReactiveArea()) return 'Qué ocurrió / descripción';
    if (this.isImprovementArea()) return 'Descripción / objetivo de la mejora';
    return 'Descripción';
  }

  protected descriptionPlaceholder(): string {
    if (this.isReactiveArea()) return 'Describe la incidencia, falla o situación que requiere atención';
    if (this.isImprovementArea()) return 'Explica qué se quiere mejorar, por qué y cuál sería el resultado esperado';
    return 'Describe el trabajo a realizar';
  }

  protected calendarDescription(): string {
    if (this.isReactiveArea()) {
      return 'Incidencias organizadas por la fecha en que fueron reportadas.';
    }
    if (this.isImprovementArea()) {
      return 'Plan anual de ideas y proyectos futuros organizado por su mes o fecha objetivo.';
    }
    return 'Agenda mensual de Mantención General. Muestra fechas programadas y, cuando no existe planificación, la fecha histórica registrada.';
  }

  /* ============================================================
     FECHA
     ============================================================ */

  protected isImported(item: WorkItem): boolean {
    return !!item.importSourceFilename;
  }


  protected primaryDate(item: WorkItem): string | null {
    if (this.isImprovementArea()) return item.scheduledEnd ?? item.scheduledStart ?? item.completedDate;
    return item.scheduledStart ?? item.completedDate;
  }


  protected primaryDateLabel(item: WorkItem): string {
    if (this.isReactiveArea()) {
      return item.scheduledStart ? 'Fecha de reporte' : item.completedDate ? 'Fecha de resolución' : 'Fecha';
    }
    if (this.isImprovementArea()) {
      return item.scheduledEnd ? 'Fecha objetivo' : item.scheduledStart ? 'Fecha de idea' : 'Sin fecha objetivo';
    }
    return item.scheduledStart ? 'Fecha programada' : item.completedDate ? 'Última mantención' : 'Fecha';
  }


  protected calendarDate(item: WorkItem): string | null {
    const value = this.isImprovementArea() ? (item.scheduledEnd ?? item.scheduledStart) : (item.scheduledStart ?? item.completedDate);
    return value ? value.slice(0, 10) : null;
  }

  protected activityColor(item: WorkItem): string | null {
    return normalizeDisplayColor(item.displayColor);
  }

  protected activityTextColor(item: WorkItem): string {
    return resolveActivityTextColor(item.displayColor, item.textColor);
  }

  private calendarIncludesDate(item: WorkItem, date: string | null): boolean {
    if (!date) return false;
    return isDateOnlyWithinInclusiveRange(date, item.scheduledStart ?? item.completedDate, item.scheduledEnd);
  }


  protected importedFieldEntries(): Array<{ key: string; value: string }> {
    return Object.entries(this.form.importedData).map(([key, value]) => ({ key, value }));
  }


  private parseImportedData(value: string | null): Record<string, string> {
    if (!value) {
      return {};
    }

    try {
      const parsed = JSON.parse(value);
      return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
    } catch {
      return {};
    }
  }


  protected formatDate(
    value: string | null
  ): string {

    if (!value) {

      return 'Sin fecha';
    }


    return this
      .parseDate(value)
      .toLocaleDateString(
        'es-CL',
        {
          day:
            '2-digit',

          month:
            '2-digit',

          year:
            'numeric'
        }
      );
  }


  protected formatAddedAt(value: string | null): string {
    if (!value) {
      return 'Sin registro';
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
      return 'Sin registro';
    }

    const datePart = new Intl.DateTimeFormat('es-CL', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);

    const timePart = new Intl.DateTimeFormat('es-CL', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    }).format(date);

    return `${datePart} · ${timePart}`;
  }


  /* ============================================================
     DINERO
     ============================================================ */

  protected formatMoney(
    value: number | null
  ): string {

    if (
      value === null
      || value === undefined
    ) {

      return 'Sin registrar';
    }


    return new Intl.NumberFormat(
      'es-CL',
      {
        style:
          'currency',

        currency:
          'CLP',

        maximumFractionDigits:
          0
      }
    )
      .format(value);
  }


  /* ============================================================
     FORM VACÍO
     ============================================================ */

  private emptyForm():
    OperationalForm {

    return {

      phase: '',

      title:
        '',

      description:
        '',

      location:
        '',

      responsibleName:
        '',

      priority:
        'NORMAL',

      status:
        'PENDING',

      scheduledStart:
        '',

      scheduledEnd:
        '',

      displayColor:
        OMM_DISPLAY_COLOR_PALETTE[0],

      textColor:
        null,

      targetYear:
        '',

      targetMonth:
        '',

      progressPercent:
        0,

      notes:
        '',


      category:
        '',

      assetName:
        '',

      assetId:
        '',

      frequency:
        '',

      season:
        '',

      materials:
        '',

      supplierName:
        '',

      estimatedCost:
        null,

      actualCost:
        null,

      importedData:
        {},

      importSourceFilename:
        null,

      sourceSheetName:
        null,

      sourceRowNumber:
        null
    };
  }


  private nullIfBlank(
    value: string
  ): string | null {

    const trimmed =
      value.trim();


    return trimmed
      ? trimmed
      : null;
  }


  private isOverdue(
    item: WorkItem
  ): boolean {

    if (
      [
        'COMPLETED',
        'CANCELLED'
      ].includes(
        item.status
      )
    ) {

      return false;
    }


    if (this.isImprovementArea()) {
      const target = this.improvementTarget(item);
      if (!target.year || !target.month) return false;
      const day = target.day ?? new Date(target.year, target.month, 0).getDate();
      const date = new Date(target.year, target.month - 1, day);
      return date < this.startOfToday();
    }

    const dateValue =
      item.scheduledEnd
      ?? item.scheduledStart;


    if (!dateValue) {

      return false;
    }


    return (
      this.parseDate(dateValue)
      < this.startOfToday()
    );
  }


  protected improvementTargetLabel(item: WorkItem): string {
    const target = this.improvementTarget(item);
    if (item.scheduledEnd) return this.formatDate(item.scheduledEnd);
    if (target.year && target.month) {
      return new Intl.DateTimeFormat('es-CL', { month: 'long', year: 'numeric' }).format(new Date(target.year, target.month - 1, 1));
    }
    if (target.year) return String(target.year);
    return 'Sin fecha objetivo';
  }

  protected improvementBudgetForYear(year:number): number {
    return this.improvementAnnualItems().filter(item => this.improvementTarget(item).year === year)
      .reduce((sum,item) => sum + Number(item.estimatedCost ?? 0), 0);
  }

  protected openImprovementAlert(item: WorkItem | null): void {
    if (item) this.openEdit(item);
  }

  private isImprovementUpcoming(item: WorkItem): boolean {
    if (!this.isImprovementArea() || ['COMPLETED','CANCELLED'].includes(item.status)) return false;
    const target = this.improvementTarget(item);
    if (!target.year || !target.month) return false;
    const day = target.day ?? new Date(target.year, target.month, 0).getDate();
    const date = new Date(target.year, target.month - 1, day);
    const today = this.startOfToday();
    const limit = new Date(today);
    limit.setDate(limit.getDate() + 60);
    return date >= today && date <= limit;
  }

  private improvementTarget(item: WorkItem): {year:number|null;month:number|null;day:number|null} {
    if (item.scheduledEnd) {
      const parts = item.scheduledEnd.slice(0,10).split('-').map(Number);
      return {year:parts[0] || null, month:parts[1] || null, day:parts[2] || null};
    }
    if (item.plannedYear || item.plannedMonth) return {year:item.plannedYear,month:item.plannedMonth,day:null};
    const data = this.parseImportedData(item.importedData);
    const year = Number(data['targetYear']);
    const month = Number(data['targetMonth']);
    return {
      year: Number.isFinite(year) && year > 0 ? year : null,
      month: Number.isFinite(month) && month >= 1 && month <= 12 ? month : null,
      day: null
    };
  }

  private importMeta(item: WorkItem): Record<string, unknown> { return this.parseImportedData(item.importedData); }

  protected openGanttCreate(): void {
    this.openCreate(); this.creatingGantt.set(true); this.form.phase = 'Planificación'; this.form.status = 'PENDING'; this.form.progressPercent = 0;
  }

  protected setModuleView(view: 'cards'|'table'|'calendar'|'goals'|'gantt'|'summary'): void {
    this.moduleView.set(view);
    this.selectedImprovementIds.set(new Set());
  }

  protected isImprovementSelected(item: WorkItem): boolean {
    return this.improvementSelection.has(item.id);
  }

  protected toggleImprovementSelection(item: WorkItem, checked?: boolean): void {
    this.improvementSelection.toggle(item.id, checked);
  }

  protected readonly improvementGoalViewItems = computed(() =>
    this.improvementGoalGroups().flatMap(group => group.items)
  );

  protected readonly improvementAnnualViewItems = computed(() => [
    ...this.annualMonths().flatMap(month => month.items),
    ...this.improvementUnscheduled()
  ]);

  protected currentImprovementViewItems(): WorkItem[] {
    if (this.moduleView() === 'goals') return this.improvementGoalViewItems();
    if (this.moduleView() === 'calendar' && this.isImprovementArea()) return this.improvementAnnualViewItems();
    if (this.moduleView() === 'gantt') return this.improvementGanttItems();
    if (this.moduleView() === 'cards' || this.moduleView() === 'table') return this.filteredItems();
    return [];
  }

  protected selectedInCurrentViewCount(): number {
    const selected = this.selectedImprovementIds();
    return this.currentImprovementViewItems().filter(item => selected.has(item.id)).length;
  }

  protected allCurrentViewSelected(): boolean {
    const items = this.currentImprovementViewItems();
    const selected = this.selectedImprovementIds();
    return items.length > 0 && items.every(item => selected.has(item.id));
  }

  protected toggleSelectAllCurrentView(): void {
    this.improvementSelection.toggleAll(this.currentImprovementViewItems().map(item => item.id));
  }

  protected requestBulkStatus(): void {
    const selected = this.selectedImprovementIds();
    const ids = this.currentImprovementViewItems()
      .filter(item => selected.has(item.id))
      .map(item => item.id);
    if (!ids.length) return;
    this.bulkStatusState.open(ids);
  }

  protected setBulkStatus(status: WorkStatus): void {
    this.bulkStatusState.setStatus(status);
  }

  protected cancelBulkStatus(): void {
    if (!this.saving()) this.bulkStatusState.cancel();
  }

  protected applyBulkStatus(): void {
    const dialog = this.bulkStatusDialog();
    if (!dialog || !dialog.ids.length || this.saving()) return;
    this.saving.set(true);
    this.bulkStatusService.update<WorkItem>(dialog.ids, this.area().slug, dialog.status).subscribe({
      next: response => {
        this.items.update(items => mergeUpdatedWorkItems(items, response.items));
        this.improvementSelection.clear();
        this.bulkStatusState.cancel();
        this.saving.set(false);
        this.successMessage.set(
          response.updatedCount === 1
            ? '1 actividad actualizada correctamente.'
            : `${response.updatedCount} actividades actualizadas correctamente.`
        );
      },
      error: () => {
        this.saving.set(false);
        this.bulkStatusState.cancel();
        this.loadItems();
        this.errorMessage.set('No se aplicó el cambio masivo. Los registros fueron recargados sin dejar cambios parciales.');
      }
    });
  }

  protected requestBulkDelete(): void {
    const selected = this.selectedImprovementIds();
    const ids = this.currentImprovementViewItems().filter(item => selected.has(item.id)).map(item => item.id);
    if (!ids.length) return;
    this.openDestructiveDialog({
      kind: 'bulk',
      title: `Eliminar ${ids.length} registro${ids.length === 1 ? '' : 's'}`,
      message: `Se eliminarán los ${ids.length} registros seleccionados de esta vista. La acción quedará registrada individualmente en el Historial.`,
      ids,
      confirmLabel: ids.length === 1 ? 'Eliminar registro' : `Eliminar ${ids.length} registros`,
      requiresDelay: false
    });
  }

  protected requestClearCurrentImprovementView(): void {
    let items: WorkItem[] = [];
    let label = '';
    if (this.moduleView() === 'goals') {
      items = this.items().filter(item => item.workType === 'IMPROVEMENT' && String(this.importMeta(item)['sourceKind'] ?? '') === 'POR_HACER');
      label = 'Metas';
    } else if (this.moduleView() === 'calendar') {
      items = this.items().filter(item => item.workType === 'IMPROVEMENT' && String(this.importMeta(item)['sourceKind'] ?? '') !== 'POR_HACER');
      label = 'Plan Anual';
    } else if (this.moduleView() === 'gantt') {
      items = this.items().filter(item => item.workType === 'IMPROVEMENT_GANTT');
      label = 'Gantt';
    }
    if (!items.length) return;
    this.openDestructiveDialog({
      kind: 'clear',
      title: `Vaciar ${label}`,
      message: `Esta acción eliminará ${items.length} registro${items.length === 1 ? '' : 's'} de ${label}. No afecta las otras vistas de Mejoras y cada eliminación quedará registrada en el Historial.`,
      ids: items.map(item => item.id),
      confirmLabel: `Vaciar ${label}`,
      requiresDelay: true
    });
  }

  private openDestructiveDialog(dialog: DestructiveDialog): void {
    this.stopDestructiveTimer();
    this.destructiveDialog.set(dialog);
    if (dialog.requiresDelay) {
      this.destructiveCountdown.set(5);
      this.destructiveTimer = setInterval(() => {
        const next = this.destructiveCountdown() - 1;
        this.destructiveCountdown.set(Math.max(0, next));
        if (next <= 0) this.stopDestructiveTimer();
      }, 1000);
    } else {
      this.destructiveCountdown.set(0);
    }
  }

  protected closeDestructiveDialog(): void {
    if (this.saving()) return;
    this.stopDestructiveTimer();
    this.destructiveCountdown.set(0);
    this.destructiveDialog.set(null);
  }

  private stopDestructiveTimer(): void {
    if (this.destructiveTimer) {
      clearInterval(this.destructiveTimer);
      this.destructiveTimer = null;
    }
  }

  protected confirmDestructiveDialog(): void {
    const dialog = this.destructiveDialog();
    if (!dialog || (dialog.requiresDelay && this.destructiveCountdown() > 0) || !dialog.ids.length) return;
    const ids = [...dialog.ids];
    this.saving.set(true);
    from(ids).pipe(
      concatMap(id => this.http.delete<void>(`/api/work-items/${id}`, {withCredentials:true})),
      toArray()
    ).subscribe({
      next: () => {
        const deleted = new Set(ids);
        this.items.update(items => items.filter(item => !deleted.has(item.id)));
        this.selectedImprovementIds.update(current => new Set([...current].filter(id => !deleted.has(id))));
        this.saving.set(false);
        if (this.editingId() && deleted.has(this.editingId()!)) this.closeModal();
        this.successMessage.set(dialog.kind === 'clear' ? 'La vista fue vaciada correctamente.' : `${ids.length} registro${ids.length === 1 ? '' : 's'} eliminado${ids.length === 1 ? '' : 's'}.`);
        this.closeDestructiveDialog();
      },
      error: () => {
        this.saving.set(false);
        this.closeDestructiveDialog();
        this.loadItems();
        this.errorMessage.set('La eliminación no pudo completarse por completo. Los datos fueron recargados para reflejar el estado real.');
      }
    });
  }

  protected deleteWorkItem(item: WorkItem): void {
    const label = item.workType === 'IMPROVEMENT_GANTT' ? 'la tarea Gantt' : 'el registro';
    this.openDestructiveDialog({
      kind: 'single',
      title: 'Confirmar eliminación',
      message: `¿Estás seguro de eliminar ${label} «${item.title}»? Esta acción quedará registrada en el Historial.`,
      ids: [item.id],
      confirmLabel: 'Eliminar',
      requiresDelay: false
    });
  }

  protected ganttPhaseLabel(item: WorkItem): string { return item.phase || 'Sin fase'; }
  protected ganttDates(item: WorkItem): string { const start=item.scheduledStart?this.formatDate(item.scheduledStart):'Sin inicio'; const end=item.scheduledEnd?this.formatDate(item.scheduledEnd):'Sin término'; return `${start} → ${end}`; }
  protected openExpenses(): void { this.router.navigate(['/gastos']); }
  protected openExpenseArea(areaSlug: string): void { this.router.navigate(['/gastos'], {queryParams:{area:areaSlug}}); }
  protected openImprovementSection(section: string): void { this.improvementSectionFilter.set(section); this.setModuleView('goals'); }
  protected sourceKindLabel(item: WorkItem): string { const meta=this.importMeta(item); const kind=String(meta['sourceKind'] ?? ''); if(kind==='ANNUAL_PLAN')return 'Plan anual'; if(kind==='POR_HACER')return String(meta['sourceSection'] ?? 'Metas / Proyectos'); return item.importSourceFilename?'Excel importado':'Registro manual'; }
  private goalGroupLabel(value: string): string { const n=value.toLocaleLowerCase('es-CL'); if(n.includes('proyectos pendientes'))return 'Proyectos Pendientes'; if(n.includes('recepcion'))return 'Metas Recepción'; if(n.includes('obras'))return 'Metas Obras'; if(n.includes('jard'))return 'Metas Jardinería'; if(n.includes('marketing'))return 'Metas Marketing'; if(n.includes('oficina'))return 'Metas Oficina'; return value; }

  private parseDate(
    value: string
  ): Date {

    return new Date(
      `${value.slice(0, 10)}T00:00:00`
    );
  }


  private startOfToday():
    Date {

    const today =
      new Date();


    today.setHours(
      0,
      0,
      0,
      0
    );


    return today;
  }

}
