import { Routes } from '@angular/router';

import {
  authGuard, permissionGuard
} from './core/auth/auth.guard';
import { ActivarCuentaComponent } from './pages/activar-cuenta/activar-cuenta';
import { AccessMessageComponent } from './pages/access-message/access-message';

import {
  LoginComponent
} from './pages/login/login';

import {
  DashboardComponent
} from './pages/dashboard/dashboard';

import { GastosComponent } from './pages/gastos/gastos';
import { CalendarioComponent } from './pages/calendario/calendario';
import { GestionComplementariaComponent } from './pages/gestion-complementaria/gestion-complementaria';
import { ConfiguracionComponent } from './pages/configuracion/configuracion';
import { OperationalImportComponent } from './pages/operational-import/operational-import';
import { ActivosComponent } from './pages/activos/activos';
import { TrabajadoresComponent } from './pages/trabajadores/trabajadores';

import {
  AreaDocumentosComponent
} from './pages/area-documentos/area-documentos';

import {
  HistorialComponent
} from './pages/historial/historial';

import {
  MantencionGeneralComponent
} from './pages/mantencion-general/mantencion-general';

import {
  MantencionGeneralImportComponent
} from './pages/mantencion-general-import/mantencion-general-import';

import {
  MejorasImportComponent
} from './pages/mejoras-import/mejoras-import';

import { RemodelacionComponent } from './pages/remodelacion/remodelacion';
import { RemodelacionImportComponent } from './pages/remodelacion-import/remodelacion-import';


export const routes: Routes = [

  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'login'
  },


  {
    path: 'login',
    component: LoginComponent
  },
  { path: 'activar-cuenta', component: ActivarCuentaComponent },
  { path: 'sin-accesos', component: AccessMessageComponent, canActivate: [authGuard], data: {noAccess: true} },
  { path: 'sin-permiso', component: AccessMessageComponent, canActivate: [authGuard] },


  {
    path: 'dashboard',

    component: DashboardComponent,

    canActivate: [
      authGuard, permissionGuard
    ], data: {permissions: ['dashboard']}
  },


  { path: 'gastos', component: GastosComponent, canActivate: [authGuard, permissionGuard], data:{permissions:['gastos']} },
  { path: 'calendario', component: CalendarioComponent, canActivate: [authGuard, permissionGuard], data:{permissions:['calendario']} },
  { path: 'activos', component: ActivosComponent, canActivate: [authGuard, permissionGuard], data:{permissions:['activos']} },
  { path: 'trabajadores', component: TrabajadoresComponent, canActivate: [authGuard, permissionGuard], data:{permissions:['trabajadores']} },
  { path: 'documentos', component: GestionComplementariaComponent, canActivate: [authGuard, permissionGuard], data:{permissions:['documentos']} },
  { path: 'configuracion', component: ConfiguracionComponent, canActivate: [authGuard, permissionGuard], data:{permissions:['configuracion']} },

  /*
   * ============================================================
   * HISTORIAL GENERAL
   * ============================================================
   */

  {
    path: 'historial',

    component: HistorialComponent,

    canActivate: [
      authGuard, permissionGuard
    ], data:{permissions:['history']}
  },


  /*
   * ============================================================
   * HISTORIAL POR ÁREA
   *
   * /areas/mantencion-general/historial
   * /areas/mantencion-reactiva/historial
   * /areas/mejoras/historial
   * etc.
   * ============================================================
   */

  {
    path: 'areas/:slug/historial',

    component: HistorialComponent,

    canActivate: [
      authGuard, permissionGuard
    ], data:{permissions:['history'], areaParam:'slug'}
  },


  /*
   * ============================================================
   * HISTORIAL DE DOCUMENTO
   * ============================================================
   */

  {
    path: 'documentos/:documentId/historial',

    component: HistorialComponent,

    canActivate: [
      authGuard, permissionGuard
    ], data:{permissions:['history']}
  },


  /*
   * ============================================================
   * DOCUMENTOS POR ÁREA
   *
   * Los documentos siguen existiendo,
   * pero ahora son apoyo documental.
   * ============================================================
   */

  {
    path: 'areas/:slug/documentos',

    component: AreaDocumentosComponent,

    canActivate: [
      authGuard, permissionGuard
    ], data:{areaParam:'slug',areaAlternative:'documentos'}
  },


  /*
   * ============================================================
   * FICHA OPERACIONAL
   *
   * LAS 6 ÁREAS UTILIZAN EXACTAMENTE
   * LA MISMA PANTALLA.
   *
   * /areas/mantencion-general
   * /areas/mantencion-reactiva
   * /areas/mejoras
   * /areas/remodelacion
   * /areas/mantencion-maquinas
   * /areas/mantencion-jardineria
   * ============================================================
   */

  {
    path: 'areas/mantencion-general/importar',

    component: MantencionGeneralImportComponent,

    canActivate: [
      authGuard, permissionGuard
    ], data:{permissions:['mantencion-general','import']}
  },

  {
    path: 'areas/mejoras/importar',

    component: MejorasImportComponent,

    canActivate: [
      authGuard, permissionGuard
    ], data:{permissions:['mejoras','import']}
  },

  {
    path: 'areas/remodelacion/importar',
    component: RemodelacionImportComponent,
    canActivate: [authGuard, permissionGuard], data:{permissions:['remodelacion','import']}
  },

  { path: 'areas/:slug/importar-operacional', component: OperationalImportComponent, canActivate: [authGuard, permissionGuard], data:{permissions:['import'],areaParam:'slug'} },

  {
    path: 'areas/remodelacion',
    component: RemodelacionComponent,
    canActivate: [authGuard, permissionGuard], data:{permissions:['remodelacion']}
  },


  {
    path: 'areas/:slug',

    component: MantencionGeneralComponent,

    canActivate: [
      authGuard, permissionGuard
    ], data:{areaParam:'slug'}
  },


  /*
   * ============================================================
   * NO ENCONTRADO
   * ============================================================
   */

  {
    path: '**',
    redirectTo: 'login'
  }

];
