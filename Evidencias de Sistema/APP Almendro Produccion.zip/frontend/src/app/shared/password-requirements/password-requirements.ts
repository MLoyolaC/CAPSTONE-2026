import { Component, Input } from '@angular/core';
import {
  PASSWORD_MIN_LENGTH,
  PASSWORD_MAX_LENGTH,
  evaluatePasswordPolicy,
  passwordsMatch,
} from '../../core/auth/password-policy';

@Component({
  selector: 'app-password-requirements',
  standalone: true,
  templateUrl: './password-requirements.html',
  styleUrl: './password-requirements.scss',
})
export class PasswordRequirementsComponent {
  @Input() password = '';
  @Input() confirmation = '';

  protected readonly minimum = PASSWORD_MIN_LENGTH;
  protected readonly maximum = PASSWORD_MAX_LENGTH;
  protected get state() { return evaluatePasswordPolicy(this.password); }
  protected get confirmationVisible() { return this.confirmation.length > 0; }
  protected get confirmationValid() { return passwordsMatch(this.password, this.confirmation); }
}
