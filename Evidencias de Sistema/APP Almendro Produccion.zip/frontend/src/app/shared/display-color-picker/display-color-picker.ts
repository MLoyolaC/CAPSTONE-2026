import { Component, EventEmitter, Input, OnChanges, Output } from '@angular/core';

import {
  activityTextColor,
  displayColorText,
  normalizeHexColor,
  normalizeDisplayColor,
  OMM_DISPLAY_COLOR_PALETTE
} from '../../core/colors/display-color';

@Component({
  selector: 'app-display-color-picker',
  templateUrl: './display-color-picker.html',
  styleUrl: './display-color-picker.scss'
})
export class DisplayColorPickerComponent implements OnChanges {
  @Input() value: string | null = null;
  @Output() readonly valueChange = new EventEmitter<string | null>();
  @Input() textValue: string | null = null;
  @Output() readonly textValueChange = new EventEmitter<string | null>();

  protected readonly palette = OMM_DISPLAY_COLOR_PALETTE;
  protected hexDraft = '';
  protected invalidHex = false;
  protected textHexDraft = '';
  protected invalidTextHex = false;
  protected customTextActive = false;

  ngOnChanges(): void {
    const color = normalizeDisplayColor(this.value);
    this.hexDraft = color ?? '';
    this.invalidHex = !!this.value && !color;
    const textColor = normalizeHexColor(this.textValue);
    this.textHexDraft = textColor ?? '';
    this.invalidTextHex = !!this.textValue && !textColor;
    this.customTextActive = !!textColor && !['#FFFFFF', '#000000'].includes(textColor);
  }

  protected select(color: string): void {
    this.commit(color);
  }

  protected selectCustom(event: Event): void {
    this.commit((event.target as HTMLInputElement).value);
  }

  protected updateHex(event: Event): void {
    this.hexDraft = (event.target as HTMLInputElement).value.toUpperCase();
    const normalized = normalizeDisplayColor(this.hexDraft);
    this.invalidHex = this.hexDraft.length > 0 && !normalized;
    if (normalized) this.commit(normalized);
  }

  protected useAutomatic(): void {
    this.hexDraft = '';
    this.invalidHex = false;
    this.valueChange.emit(null);
  }

  protected selected(color: string): boolean {
    return normalizeDisplayColor(this.value) === color;
  }

  protected previewTextColor(): string {
    return activityTextColor(this.value, this.textValue);
  }

  protected automaticTextColor(): string { return displayColorText(this.value); }

  protected selectTextAutomatic(): void {
    this.customTextActive = false;
    this.invalidTextHex = false;
    this.textValueChange.emit(null);
  }

  protected selectTextQuick(color: '#FFFFFF' | '#000000'): void {
    this.customTextActive = false;
    this.invalidTextHex = false;
    this.textValueChange.emit(color);
  }

  protected enableCustomText(): void {
    this.customTextActive = true;
    const current = normalizeHexColor(this.textValue);
    const draft = normalizeHexColor(this.textHexDraft);
    const customCurrent = current && !['#FFFFFF', '#000000'].includes(current) ? current : null;
    const customDraft = draft && !['#FFFFFF', '#000000'].includes(draft) ? draft : null;
    this.commitText(customCurrent ?? customDraft ?? '#F4F1E8');
  }

  protected selectCustomText(event: Event): void {
    this.customTextActive = true;
    this.commitText((event.target as HTMLInputElement).value);
  }

  protected updateTextHex(event: Event): void {
    this.customTextActive = true;
    this.textHexDraft = (event.target as HTMLInputElement).value.toUpperCase();
    const normalized = normalizeHexColor(this.textHexDraft);
    this.invalidTextHex = this.textHexDraft.length > 0 && !normalized;
    if (normalized) this.commitText(normalized);
  }

  protected textOptionSelected(option: 'automatic' | '#FFFFFF' | '#000000' | 'custom'): boolean {
    const current = normalizeHexColor(this.textValue);
    if (option === 'automatic') return !current;
    if (option === 'custom') return this.customTextActive || (!!current && !['#FFFFFF', '#000000'].includes(current));
    return !this.customTextActive && current === option;
  }

  protected previewBackground(): string { return normalizeDisplayColor(this.value) ?? OMM_DISPLAY_COLOR_PALETTE[0]; }

  protected contrastText(color: string): string {
    return displayColorText(color);
  }

  private commit(value: string): void {
    const normalized = normalizeDisplayColor(value);
    if (!normalized) return;
    this.hexDraft = normalized;
    this.invalidHex = false;
    this.valueChange.emit(normalized);
  }

  private commitText(value: string): void {
    const normalized = normalizeHexColor(value);
    if (!normalized) return;
    this.textHexDraft = normalized;
    this.invalidTextHex = false;
    this.textValueChange.emit(normalized);
  }
}
