import { TestBed } from '@angular/core/testing';

import { activityTextColor, displayColorText, normalizeDisplayColor, normalizeHexColor } from '../../core/colors/display-color';
import { DisplayColorPickerComponent } from './display-color-picker';

describe('DisplayColorPickerComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [DisplayColorPickerComponent] }).compileComponents();
  });

  it('emits a predefined palette color', () => {
    const fixture = TestBed.createComponent(DisplayColorPickerComponent);
    const emitted: Array<string | null> = [];
    fixture.componentInstance.valueChange.subscribe(value => emitted.push(value));
    fixture.detectChanges();
    (fixture.nativeElement.querySelector('.swatch') as HTMLButtonElement).click();
    expect(emitted.at(-1)).toBe('#4F8F72');
  });

  it('accepts the native custom color and valid manual HEX but rejects text', () => {
    const fixture = TestBed.createComponent(DisplayColorPickerComponent);
    const emitted: Array<string | null> = [];
    fixture.componentInstance.valueChange.subscribe(value => emitted.push(value));
    fixture.detectChanges();

    const color = fixture.nativeElement.querySelector('input[type=color]') as HTMLInputElement;
    color.value = '#3a7d5d';
    color.dispatchEvent(new Event('input'));
    expect(emitted.at(-1)).toBe('#3A7D5D');

    const hex = fixture.nativeElement.querySelector('input[type=text]') as HTMLInputElement;
    hex.value = '#4f8f72';
    hex.dispatchEvent(new Event('input'));
    expect(emitted.at(-1)).toBe('#4F8F72');
    const count = emitted.length;
    hex.value = 'rojo';
    hex.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    expect(emitted).toHaveLength(count);
    expect(hex.getAttribute('aria-invalid')).toBe('true');
  });

  it('supports automatic, white, black and custom text colors with live preview', () => {
    const fixture = TestBed.createComponent(DisplayColorPickerComponent);
    const emitted: Array<string | null> = [];
    fixture.componentRef.setInput('value', '#FF0000');
    fixture.componentInstance.textValueChange.subscribe(value => emitted.push(value));
    fixture.detectChanges();

    const options = fixture.nativeElement.querySelectorAll('.text-options button') as NodeListOf<HTMLButtonElement>;
    options[1].click();
    expect(emitted.at(-1)).toBe('#FFFFFF');
    options[2].click();
    expect(emitted.at(-1)).toBe('#000000');
    options[0].click();
    expect(emitted.at(-1)).toBeNull();

    options[3].click();
    expect(emitted.at(-1)).toBe('#F4F1E8');
    fixture.componentRef.setInput('textValue', '#F4F1E8');
    fixture.detectChanges();
    const customHex = fixture.nativeElement.querySelector('.text-custom-row input[type=text]') as HTMLInputElement;
    customHex.value = '#f4f1e8';
    customHex.dispatchEvent(new Event('input'));
    expect(emitted.at(-1)).toBe('#F4F1E8');
  });
});

describe('display color utilities', () => {
  it('normalizes only six-digit HEX values', () => {
    expect(normalizeDisplayColor('#4f8f72')).toBe('#4F8F72');
    expect(normalizeDisplayColor('red')).toBeNull();
    expect(normalizeDisplayColor('#FFF')).toBeNull();
    expect(normalizeHexColor('rgb(255,0,0)')).toBeNull();
  });

  it('chooses readable text for light and dark colors', () => {
    expect(displayColorText('#F5F5F5')).toBe('#000000');
    expect(displayColorText('#111111')).toBe('#FFFFFF');
    expect(displayColorText('#173B2B')).toBe('#FFFFFF');
  });

  it('prefers a valid manual text color over automatic contrast', () => {
    expect(activityTextColor('#111111', '#000000')).toBe('#000000');
    expect(activityTextColor('#F5F5F5', '#FFFFFF')).toBe('#FFFFFF');
    expect(activityTextColor('#FF0000', '#f4f1e8')).toBe('#F4F1E8');
    expect(activityTextColor('#111111', null)).toBe('#FFFFFF');
  });
});
