import { Component, signal } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { CountUpDirective } from './count-up';

@Component({
  imports: [CountUpDirective],
  template: `
    <strong [appCountUp]="value()" [countUpFormat]="format()"></strong>
  `
})
class CountUpHostComponent {
  value = signal(85000);
  format = signal<'number' | 'currency' | 'percentage'>('currency');
}

describe('CountUpDirective', () => {
  let fixture: ComponentFixture<CountUpHostComponent>;

  beforeEach(async () => {
    Object.defineProperty(window, 'matchMedia', {
      writable: true,
      value: (query: string): MediaQueryList => ({
        matches: query.includes('prefers-reduced-motion'),
        media: query,
        onchange: null,
        addListener: () => undefined,
        removeListener: () => undefined,
        addEventListener: () => undefined,
        removeEventListener: () => undefined,
        dispatchEvent: () => false
      })
    });

    await TestBed.configureTestingModule({
      imports: [CountUpHostComponent]
    }).compileComponents();
    fixture = TestBed.createComponent(CountUpHostComponent);
  });

  it('formats Chilean currency without decimals', () => {
    fixture.detectChanges();
    const value = fixture.nativeElement.querySelector('strong') as HTMLElement;
    expect(value.textContent).toBe('$85.000');
    expect(value.getAttribute('aria-label')).toBe('$85.000');
  });

  it('supports quantities and percentages', () => {
    fixture.componentInstance.value.set(128);
    fixture.componentInstance.format.set('number');
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('strong')?.textContent).toBe('128');

    fixture.componentInstance.value.set(75);
    fixture.componentInstance.format.set('percentage');
    fixture.detectChanges();
    const directive = fixture.debugElement.query(By.directive(CountUpDirective)).injector.get(CountUpDirective);
    expect(directive.appCountUp).toBe(75);
    expect(directive.countUpFormat).toBe('percentage');
    expect(fixture.nativeElement.querySelector('strong')?.textContent).toBe('75%');
  });
});
