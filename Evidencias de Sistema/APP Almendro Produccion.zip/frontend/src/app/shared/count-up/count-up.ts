import {
  Directive,
  ElementRef,
  inject,
  Input,
  NgZone,
  OnChanges,
  OnDestroy,
  SimpleChanges
} from '@angular/core';

export type CountUpFormat = 'number' | 'currency' | 'percentage';

@Directive({
  selector: '[appCountUp]'
})
export class CountUpDirective implements OnChanges, OnDestroy {
  private readonly element = inject(ElementRef<HTMLElement>);
  private readonly zone = inject(NgZone);
  private readonly numberFormatter = new Intl.NumberFormat('es-CL', {
    maximumFractionDigits: 0
  });
  private readonly currencyFormatter = new Intl.NumberFormat('es-CL', {
    style: 'currency',
    currency: 'CLP',
    maximumFractionDigits: 0
  });

  @Input() appCountUp: number | null | undefined = 0;
  @Input() countUpFormat: CountUpFormat = 'number';
  @Input() countUpDuration = 1000;

  private animationFrame: number | null = null;
  private displayedValue = 0;
  private initialized = false;

  ngOnChanges(changes: SimpleChanges): void {
    if (!changes['appCountUp'] && !changes['countUpFormat']) return;

    const target = this.normalize(this.appCountUp);
    this.element.nativeElement.setAttribute(
      'aria-label',
      this.format(target)
    );

    if (this.prefersReducedMotion() || this.countUpDuration <= 0) {
      this.cancelAnimation();
      this.render(target);
      this.initialized = true;
      return;
    }

    const start = this.initialized ? this.displayedValue : 0;
    this.initialized = true;
    this.animate(start, target);
  }

  ngOnDestroy(): void {
    this.cancelAnimation();
  }

  private animate(start: number, target: number): void {
    this.cancelAnimation();

    if (start === target) {
      this.render(target);
      return;
    }

    this.zone.runOutsideAngular(() => {
      let startedAt: number | null = null;

      const step = (timestamp: number): void => {
        startedAt ??= timestamp;
        const progress = Math.min(
          (timestamp - startedAt) / this.countUpDuration,
          1
        );
        const eased = 1 - Math.pow(1 - progress, 3);
        this.render(Math.round(start + (target - start) * eased));

        if (progress < 1) {
          this.animationFrame = requestAnimationFrame(step);
        } else {
          this.animationFrame = null;
          this.render(target);
        }
      };

      this.animationFrame = requestAnimationFrame(step);
    });
  }

  private render(value: number): void {
    this.displayedValue = value;
    this.element.nativeElement.textContent = this.format(value);
  }

  private format(value: number): string {
    if (this.countUpFormat === 'currency') {
      return this.currencyFormatter.format(value);
    }
    if (this.countUpFormat === 'percentage') {
      return `${this.numberFormatter.format(value)}%`;
    }
    return this.numberFormatter.format(value);
  }

  private normalize(value: number | null | undefined): number {
    const parsed = Number(value ?? 0);
    return Number.isFinite(parsed) ? Math.round(parsed) : 0;
  }

  private prefersReducedMotion(): boolean {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  }

  private cancelAnimation(): void {
    if (this.animationFrame === null) return;
    cancelAnimationFrame(this.animationFrame);
    this.animationFrame = null;
  }
}
