import { Component, inject } from '@angular/core';
import { ConnectivityService } from '../../core/connectivity/connectivity.service';

@Component({
  selector: 'app-connectivity-banner',
  standalone: true,
  template: `
    @if (connectivity.state() === 'offline') {
      <div class="connection-banner offline" role="status"><i class="fa-solid fa-wifi"></i><strong>Modo sin conexión</strong><span>Las consultas y cambios del servidor no están disponibles.</span></div>
    } @else if (connectivity.state() === 'intermittent') {
      <div class="connection-banner intermittent" role="status"><i class="fa-solid fa-triangle-exclamation"></i><strong>Servicio temporalmente no disponible</strong><span>Tu red está activa, pero OMM no puede confirmar el servidor.</span></div>
    } @else if (connectivity.restored()) {
      <div class="connection-banner restored" role="status"><i class="fa-solid fa-circle-check"></i><strong>Conexión restablecida</strong></div>
    }
  `,
  styles: [`
    :host{position:fixed;z-index:2200;left:50%;bottom:18px;transform:translateX(-50%);width:min(680px,calc(100vw - 24px));pointer-events:none}
    .connection-banner{display:flex;align-items:center;justify-content:center;gap:8px;padding:11px 14px;border:1px solid;border-radius:12px;box-shadow:0 12px 35px rgba(0,0,0,.2);font-size:11px;background:var(--surface);color:var(--text)}
    .connection-banner span{color:var(--text-muted)}.offline{border-color:#b45a53}.offline i{color:#b45a53}.intermittent{border-color:#b68a35}.intermittent i{color:#b68a35}.restored{border-color:#4e8a68}.restored i{color:#4e8a68}
    @media(max-width:600px){.connection-banner{align-items:flex-start;flex-wrap:wrap;text-align:center}.connection-banner span{width:100%}}
  `],
})
export class ConnectivityBannerComponent { protected readonly connectivity = inject(ConnectivityService); }
