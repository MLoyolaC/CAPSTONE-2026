import { Component, effect, inject } from '@angular/core';
import { Router } from '@angular/router';

import { SessionExperienceService } from '../../core/auth/session-experience.service';
import { AppSettingsService } from '../../core/settings/app-settings.service';

@Component({
  selector: 'app-session-experience',
  templateUrl: './session-experience.html',
  styleUrl: './session-experience.scss'
})
export class SessionExperienceComponent {
  private readonly router = inject(Router);
  private readonly settings = inject(AppSettingsService);
  private soundedAlert: object | null = null;
  protected readonly experience = inject(SessionExperienceService);

  constructor() {
    effect(() => {
      const alert = this.experience.deadlineAlert();
      if (alert && alert !== this.soundedAlert) {
        this.soundedAlert = alert;
        if (this.settings.notificationSound()) this.playNotificationSound();
      }
    });
  }

  protected dismissDeadlineAlert(): void {
    this.experience.dismissDeadlineAlert();
  }

  protected openCalendar(): void {
    void this.router.navigateByUrl('/calendario');
  }

  private playNotificationSound(): void {
    try {
      const AudioContextClass = window.AudioContext || (window as typeof window & {webkitAudioContext?: typeof AudioContext}).webkitAudioContext;
      if (!AudioContextClass) return;
      const context = new AudioContextClass();
      const gain = context.createGain();
      gain.gain.setValueAtTime(0.0001, context.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.025, context.currentTime + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + 0.42);
      gain.connect(context.destination);
      const oscillator = context.createOscillator();
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(620, context.currentTime);
      oscillator.frequency.setValueAtTime(780, context.currentTime + 0.16);
      oscillator.connect(gain);
      oscillator.start();
      oscillator.stop(context.currentTime + 0.43);
      oscillator.addEventListener('ended', () => void context.close());
    } catch {
      return;
    }
  }
}
