import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { provideRouter, Router } from '@angular/router';
import { of } from 'rxjs';

import { AuthService } from '../../core/auth/auth.service';
import { SessionExperienceService } from '../../core/auth/session-experience.service';
import { AppSidebarComponent } from './app-sidebar';

describe('AppSidebarComponent', () => {
  let permissions: Set<string>;

  beforeEach(async () => {
    permissions = new Set(['dashboard']);
    Object.defineProperty(window, 'matchMedia', {
      writable: true,
      value: (query: string): MediaQueryList => ({
        matches: false,
        media: query,
        onchange: null,
        addListener: () => undefined,
        removeListener: () => undefined,
        addEventListener: () => undefined,
        removeEventListener: () => undefined,
        dispatchEvent: () => false
      })
    });

    await TestBed.configureTestingModule({
      imports: [AppSidebarComponent],
      providers: [
        provideRouter([]),
        {
          provide: AuthService,
          useValue: {
            currentUser: signal({ id:1,username:'admin',fullName:'Admin',email:null,role:'ADMIN',status:'ACTIVE',permissions:['dashboard'] }).asReadonly(),
            hasPermission: (permission: string) => permissions.has(permission),
            logout: vi.fn(() => of(undefined))
          }
        }
      ]
    }).compileComponents();
  });

  afterEach(() => vi.useRealTimers());

  it('invalidates the session immediately and delays only the login navigation', async () => {
    vi.useFakeTimers();
    const auth = TestBed.inject(AuthService);
    const router = TestBed.inject(Router);
    const experience = TestBed.inject(SessionExperienceService);
    const navigate = vi.spyOn(router, 'navigateByUrl').mockResolvedValue(true);
    const fixture = TestBed.createComponent(AppSidebarComponent);
    const component = fixture.componentInstance as unknown as { logout(): void };

    component.logout();

    expect(auth.logout).toHaveBeenCalledOnce();
    expect(experience.transition()).toEqual({ kind: 'logout' });
    expect(navigate).not.toHaveBeenCalled();

    await vi.advanceTimersByTimeAsync(1699);
    expect(navigate).not.toHaveBeenCalled();

    await vi.advanceTimersByTimeAsync(1);
    expect(navigate).toHaveBeenCalledWith('/login');
    expect(experience.transitionLeaving()).toBe(true);
  });

  it('shows the history shortcut only with the history permission', () => {
    let fixture = TestBed.createComponent(AppSidebarComponent);
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('a[href="/historial"]')).toBeNull();

    permissions.add('history');
    fixture = TestBed.createComponent(AppSidebarComponent);
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('a[href="/historial"]')).not.toBeNull();
  });

  it('does not render a language selector', () => {
    const fixture = TestBed.createComponent(AppSidebarComponent);
    fixture.detectChanges();

    expect(fixture.nativeElement.querySelector('.omm-language')).toBeNull();
    expect(fixture.nativeElement.textContent).not.toContain('English');
  });
});
