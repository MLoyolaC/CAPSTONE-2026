import { Component, computed, inject, signal } from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { forkJoin, timer } from 'rxjs';
import { AuthService } from '../../core/auth/auth.service';
import { LOGOUT_HOLD_MS, SessionExperienceService } from '../../core/auth/session-experience.service';
import { AppSettingsService } from '../../core/settings/app-settings.service';
import { ThemeToggleComponent } from '../theme-toggle/theme-toggle';
import { BrandingService } from '../../core/settings/branding.service';

@Component({selector:'app-sidebar', imports:[RouterLink,RouterLinkActive,ThemeToggleComponent], templateUrl:'./app-sidebar.html', styleUrl:'./app-sidebar.scss'})
export class AppSidebarComponent {
  private readonly authService=inject(AuthService); private readonly router=inject(Router);
  private readonly sessionExperience=inject(SessionExperienceService);
  protected readonly settings=inject(AppSettingsService); protected readonly user=this.authService.currentUser;
  protected readonly branding=inject(BrandingService);
  protected readonly loggingOut=signal(false);
  protected readonly notificationsOpen=signal(false);
  protected readonly canViewHistory=computed(()=>this.authService.hasPermission('history'));
  protected toggleNotifications(){this.notificationsOpen.update(open=>!open)}
  protected displayName(username?:string|null){return this.settings.displayNameFor(username)}
  protected avatarIcon(preset?:string){return `fa-solid fa-${({user:'user','circle-user':'circle-user','user-tie':'user-tie','user-shield':'user-shield','address-card':'address-card'} as Record<string,string>)[preset || 'user'] || 'user'}`}
  protected avatarUrl(){return '/api/account/avatar'}
  private readonly allLinks=[
    {permission:'dashboard',label:'Dashboard',path:'/dashboard',icon:'fa-solid fa-table-cells-large',category:'dashboard'},
    {permission:'mantencion-general',label:'M. General',path:'/areas/mantencion-general',icon:'fa-solid fa-wrench',category:'general'},
    {permission:'mantencion-reactiva',label:'M. Reactiva',path:'/areas/mantencion-reactiva',icon:'fa-solid fa-bolt',category:'reactiva'},
    {permission:'mejoras',label:'Mejoras',path:'/areas/mejoras',icon:'fa-solid fa-chart-line',category:'mejoras'},
    {permission:'remodelacion',label:'Remodelación',path:'/areas/remodelacion',icon:'fa-solid fa-house-chimney',category:'remodelacion'},
    {permission:'maquinas',label:'Máquinas',path:'/areas/mantencion-maquinas',icon:'fa-solid fa-gears',category:'maquinas'},
    {permission:'jardineria',label:'Jardinería',path:'/areas/mantencion-jardineria',icon:'fa-solid fa-leaf',category:'jardineria'},
    {permission:'prevencion',label:'Prevención',path:'/areas/prevencion-riesgos',icon:'fa-solid fa-shield-halved',category:'prevencion'},
    {permission:'calendario',label:'Calendario',path:'/calendario',icon:'fa-regular fa-calendar',category:'calendario'},
    {permission:'gastos',label:'Gastos',path:'/gastos',icon:'fa-solid fa-wallet',category:'gastos'},
    {permission:'documentos',label:'Documentos',path:'/documentos',icon:'fa-regular fa-folder-open',category:'documentos'},
    {permission:'activos',label:'Activos',path:'/activos',icon:'fa-solid fa-cubes',category:'activos'},
    {permission:'trabajadores',label:'Trabajadores',path:'/trabajadores',icon:'fa-solid fa-id-card-clip',category:'trabajadores'},
    {permission:'configuracion',label:'Configuración',path:'/configuracion',icon:'fa-solid fa-gear',category:'configuracion'}
  ];
  protected readonly links=computed(()=>this.allLinks.filter(link=>this.authService.hasPermission(link.permission)));
  protected logout(){if(this.loggingOut())return;this.loggingOut.set(true);this.sessionExperience.showLogout();forkJoin({logout:this.authService.logout(),minimumDelay:timer(LOGOUT_HOLD_MS)}).subscribe({next:async()=>{this.sessionExperience.endAuthenticatedSession();await this.router.navigateByUrl('/login');this.sessionExperience.finishTransition()},error:()=>{this.loggingOut.set(false);this.sessionExperience.cancelTransition()}})}
}
