ALTER TABLE work_item
    ADD COLUMN display_color VARCHAR(7);

ALTER TABLE work_item
    ADD CONSTRAINT ck_work_item_display_color
    CHECK (display_color IS NULL OR display_color ~ '^#[0-9A-F]{6}$');
