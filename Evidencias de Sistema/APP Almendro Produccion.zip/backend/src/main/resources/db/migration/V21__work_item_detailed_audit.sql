-- V21: auditoría estructurada y trazabilidad de operaciones masivas en WorkItem.

ALTER TABLE work_item_activity
    ADD COLUMN operation_id UUID,
    ADD COLUMN changes JSONB NOT NULL DEFAULT '[]'::jsonb;

CREATE INDEX idx_work_item_activity_operation
    ON work_item_activity(operation_id)
    WHERE operation_id IS NOT NULL;

CREATE INDEX idx_work_item_activity_changes
    ON work_item_activity USING GIN(changes);
