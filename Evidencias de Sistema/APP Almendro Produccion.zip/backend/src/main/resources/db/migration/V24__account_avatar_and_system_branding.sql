ALTER TABLE app_user
    ADD COLUMN avatar_preset VARCHAR(30) NOT NULL DEFAULT 'user',
    ADD COLUMN avatar_image BYTEA,
    ADD COLUMN avatar_mime VARCHAR(30);

ALTER TABLE app_user
    ADD CONSTRAINT chk_app_user_avatar_preset
        CHECK (avatar_preset IN ('user', 'circle-user', 'user-tie', 'user-shield', 'address-card')),
    ADD CONSTRAINT chk_app_user_avatar_payload
        CHECK ((avatar_image IS NULL AND avatar_mime IS NULL)
            OR (avatar_image IS NOT NULL AND avatar_mime IN ('image/png', 'image/jpeg')));

CREATE TABLE system_branding (
    id SMALLINT PRIMARY KEY CHECK (id = 1),
    icon_preset VARCHAR(30) NOT NULL DEFAULT 'hotel'
        CHECK (icon_preset IN ('hotel', 'bell', 'building', 'key', 'landmark')),
    custom_image BYTEA,
    custom_mime VARCHAR(30),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_by VARCHAR(50),
    CONSTRAINT chk_system_branding_payload
        CHECK ((custom_image IS NULL AND custom_mime IS NULL)
            OR (custom_image IS NOT NULL AND custom_mime IN ('image/png', 'image/jpeg')))
);

INSERT INTO system_branding (id, icon_preset) VALUES (1, 'hotel');
