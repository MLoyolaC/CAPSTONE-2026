ALTER TABLE document_activity
DROP CONSTRAINT ck_activity_action;

ALTER TABLE document_activity
ADD CONSTRAINT ck_activity_action
CHECK (
    action IN (
        'UPLOADED',
        'OPENED',
        'DOWNLOADED',
        'EDIT_STARTED',
        'REPLACED',
        'EDIT_CANCELLED',
        'ARCHIVED',
        'RESTORED',
        'DELETED'
    )
);