ALTER TABLE asset
    ADD COLUMN IF NOT EXISTS operational_status VARCHAR(30) NOT NULL DEFAULT 'OPERATIONAL';

ALTER TABLE asset
    DROP CONSTRAINT IF EXISTS chk_asset_operational_status;

ALTER TABLE asset
    ADD CONSTRAINT chk_asset_operational_status
    CHECK (operational_status IN ('OPERATIONAL', 'FAULT', 'OUT_OF_SERVICE'));

CREATE INDEX IF NOT EXISTS idx_asset_operational_status
    ON asset(operational_status) WHERE active = TRUE;
