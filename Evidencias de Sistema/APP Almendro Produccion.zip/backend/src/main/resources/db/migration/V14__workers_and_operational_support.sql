-- Trabajadores y soporte documental final OMM.
INSERT INTO area (name, slug, description, sort_order, active)
VALUES ('Trabajadores', 'trabajadores', 'Carpetas de trabajadores y documentación asociada.', 8, TRUE)
ON CONFLICT (slug) DO NOTHING;

CREATE TABLE IF NOT EXISTS worker (
    id UUID PRIMARY KEY,
    full_name VARCHAR(250) NOT NULL,
    rut VARCHAR(30),
    position VARCHAR(180),
    department VARCHAR(180),
    phone VARCHAR(80),
    email VARCHAR(320),
    notes TEXT,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_by BIGINT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_worker_created_by FOREIGN KEY (created_by) REFERENCES app_user(id)
);

CREATE INDEX IF NOT EXISTS idx_worker_name ON worker(full_name);
CREATE INDEX IF NOT EXISTS idx_worker_active ON worker(active);

CREATE TABLE IF NOT EXISTS worker_document (
    worker_id UUID NOT NULL,
    document_id UUID NOT NULL UNIQUE,
    document_type VARCHAR(120),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (worker_id, document_id),
    CONSTRAINT fk_worker_document_worker FOREIGN KEY (worker_id) REFERENCES worker(id) ON DELETE CASCADE,
    CONSTRAINT fk_worker_document_document FOREIGN KEY (document_id) REFERENCES document(id) ON DELETE CASCADE
);

-- Auditoría transversal para entidades que no son work_item ni documentos.
CREATE TABLE IF NOT EXISTS system_activity (
    id UUID PRIMARY KEY,
    area_slug VARCHAR(100) NOT NULL,
    area_name VARCHAR(180) NOT NULL,
    item_id VARCHAR(120),
    item_name VARCHAR(300) NOT NULL,
    item_type VARCHAR(80) NOT NULL,
    username_snapshot VARCHAR(100),
    role_snapshot VARCHAR(30),
    action VARCHAR(30) NOT NULL,
    details TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_system_activity_area_created
    ON system_activity(area_slug, created_at DESC);
