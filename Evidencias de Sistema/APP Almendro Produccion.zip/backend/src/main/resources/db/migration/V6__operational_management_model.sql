/*
 * ============================================================
 * V6 - MODELO OPERACIONAL OMM
 * Hotel El Almendro
 *
 * Objetivo:
 *
 * - mantener los documentos Excel/Word/PDF como fuente original;
 * - almacenar información operacional estructurada;
 * - permitir histórico;
 * - costos;
 * - mantenciones;
 * - próximas mantenciones;
 * - planificación;
 * - dashboard;
 * - alertas futuras.
 *
 * IMPORTANTE:
 * Esta migración NO modifica las tablas existentes.
 * Solamente agrega nuevas tablas relacionadas con:
 *
 * area
 * document
 * document_version
 * ============================================================
 */


/*
 * ============================================================
 * 1. PROVEEDORES
 * ============================================================
 *
 * Basado principalmente en:
 * PROVEEDORES REMODELACIONES.xlsx
 *
 * Ejemplos reales:
 * - Easy
 * - Budnik
 * - Ducasse
 * - Fanaloza
 * - Mimet
 * - Cosmoplas
 * etc.
 * ============================================================
 */

CREATE TABLE supplier (

    id UUID PRIMARY KEY,

    name VARCHAR(200) NOT NULL,

    products_services TEXT,

    contact_name VARCHAR(200),

    email VARCHAR(320),

    phone VARCHAR(100),

    address TEXT,

    website TEXT,

    comments TEXT,

    active BOOLEAN NOT NULL DEFAULT TRUE,

    source_document_id UUID,

    source_version_id UUID,

    source_sheet_name VARCHAR(255),

    source_key VARCHAR(500),

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,


    CONSTRAINT fk_supplier_source_document

        FOREIGN KEY (
            source_document_id
        )

        REFERENCES document(id)

        ON DELETE SET NULL,


    CONSTRAINT fk_supplier_source_version

        FOREIGN KEY (
            source_version_id
        )

        REFERENCES document_version(id)

        ON DELETE SET NULL
);


CREATE INDEX idx_supplier_name
    ON supplier(name);


CREATE INDEX idx_supplier_active
    ON supplier(active);


/*
 * ============================================================
 * 2. ACTIVOS / EQUIPOS / ELEMENTOS MANTENIBLES
 * ============================================================
 *
 * Basado principalmente en:
 * LISTA DE MANTENCIONES.xlsx
 *
 * Ejemplos:
 *
 * - Calderas
 * - Bombas
 * - Secadoras
 * - Lavadoras
 * - Refrigeradores
 * - Congeladores
 * - Radiadores
 * - Cámaras
 * - Paneles solares
 * - Extintores
 *
 * También puede utilizarse para elementos no mecánicos
 * que necesitan mantención.
 * ============================================================
 */

CREATE TABLE asset (

    id UUID PRIMARY KEY,

    area_id BIGINT NOT NULL,

    supplier_id UUID,

    code VARCHAR(100),

    name VARCHAR(300) NOT NULL,

    category VARCHAR(150),

    location VARCHAR(300),

    description TEXT,

    notes TEXT,

    active BOOLEAN NOT NULL DEFAULT TRUE,

    source_document_id UUID,

    source_version_id UUID,

    source_sheet_name VARCHAR(255),

    source_key VARCHAR(500),

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,


    CONSTRAINT fk_asset_area

        FOREIGN KEY (
            area_id
        )

        REFERENCES area(id)

        ON DELETE RESTRICT,


    CONSTRAINT fk_asset_supplier

        FOREIGN KEY (
            supplier_id
        )

        REFERENCES supplier(id)

        ON DELETE SET NULL,


    CONSTRAINT fk_asset_source_document

        FOREIGN KEY (
            source_document_id
        )

        REFERENCES document(id)

        ON DELETE SET NULL,


    CONSTRAINT fk_asset_source_version

        FOREIGN KEY (
            source_version_id
        )

        REFERENCES document_version(id)

        ON DELETE SET NULL
);


CREATE INDEX idx_asset_area
    ON asset(area_id);


CREATE INDEX idx_asset_supplier
    ON asset(supplier_id);


CREATE INDEX idx_asset_name
    ON asset(name);


CREATE INDEX idx_asset_location
    ON asset(location);


CREATE INDEX idx_asset_active
    ON asset(active);


/*
 * ============================================================
 * 3. TRABAJOS / TAREAS / ACTIVIDADES
 * ============================================================
 *
 * Esta es la tabla operacional principal.
 *
 * Sirve para:
 *
 * - Mantención General
 * - Mantención Reactiva
 * - Mejoras
 * - Remodelación
 * - Mantención de Máquinas
 * - Jardinería
 *
 * También representa tareas provenientes de:
 *
 * - Carta Gantt
 * - Plan Anual de Trabajo
 * - trabajos históricos
 *
 * ============================================================
 */

CREATE TABLE work_item (

    id UUID PRIMARY KEY,

    area_id BIGINT NOT NULL,

    parent_work_item_id UUID,

    asset_id UUID,

    supplier_id UUID,


    /*
     * Tipo de trabajo.
     */

    work_type VARCHAR(40) NOT NULL DEFAULT 'OTHER',


    /*
     * Fase de proyecto.
     *
     * Ejemplos:
     * Planificación
     * Obras
     * Diseño
     * Desarrollo
     * Cierre
     */

    phase VARCHAR(200),


    /*
     * Nombre de la tarea.
     */

    title VARCHAR(500) NOT NULL,

    description TEXT,


    /*
     * Ubicación física dentro del hotel.
     */

    location VARCHAR(300),


    /*
     * Responsable.
     *
     * Se mantiene como texto inicialmente porque
     * las planillas históricas contienen personas
     * que no necesariamente son usuarios del sistema.
     */

    responsible_name VARCHAR(300),


    /*
     * PRIORIDAD
     */

    priority VARCHAR(20) NOT NULL DEFAULT 'NORMAL',


    /*
     * ESTADO
     */

    status VARCHAR(30) NOT NULL DEFAULT 'PENDING',


    /*
     * PLANIFICACIÓN
     */

    scheduled_start DATE,

    scheduled_end DATE,

    completed_date DATE,


    /*
     * Para planes anuales que indican un mes
     * pero no una fecha específica.
     */

    planned_year SMALLINT,

    planned_month SMALLINT,


    /*
     * Avance 0 - 100.
     */

    progress_percent NUMERIC(5,2) NOT NULL DEFAULT 0,


    /*
     * Observaciones.
     */

    notes TEXT,


    /*
     * Origen documental.
     */

    source_document_id UUID,

    source_version_id UUID,

    source_sheet_name VARCHAR(255),

    source_row_number INTEGER,

    source_cell_reference VARCHAR(100),

    source_key VARCHAR(500),


    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,


    /*
     * ========================================================
     * RELACIONES
     * ========================================================
     */

    CONSTRAINT fk_work_item_area

        FOREIGN KEY (
            area_id
        )

        REFERENCES area(id)

        ON DELETE RESTRICT,


    CONSTRAINT fk_work_item_parent

        FOREIGN KEY (
            parent_work_item_id
        )

        REFERENCES work_item(id)

        ON DELETE SET NULL,


    CONSTRAINT fk_work_item_asset

        FOREIGN KEY (
            asset_id
        )

        REFERENCES asset(id)

        ON DELETE SET NULL,


    CONSTRAINT fk_work_item_supplier

        FOREIGN KEY (
            supplier_id
        )

        REFERENCES supplier(id)

        ON DELETE SET NULL,


    CONSTRAINT fk_work_item_source_document

        FOREIGN KEY (
            source_document_id
        )

        REFERENCES document(id)

        ON DELETE SET NULL,


    CONSTRAINT fk_work_item_source_version

        FOREIGN KEY (
            source_version_id
        )

        REFERENCES document_version(id)

        ON DELETE SET NULL,


    /*
     * ========================================================
     * VALIDACIONES
     * ========================================================
     */

    CONSTRAINT ck_work_item_type

        CHECK (
            work_type IN (
                'GENERAL_MAINTENANCE',
                'REACTIVE_MAINTENANCE',
                'IMPROVEMENT',
                'REMODELING',
                'MACHINE_MAINTENANCE',
                'GARDENING',
                'PREVENTION',
                'OTHER'
            )
        ),


    CONSTRAINT ck_work_item_priority

        CHECK (
            priority IN (
                'LOW',
                'NORMAL',
                'HIGH',
                'URGENT'
            )
        ),


    CONSTRAINT ck_work_item_status

        CHECK (
            status IN (
                'PLANNED',
                'PENDING',
                'IN_PROGRESS',
                'COMPLETED',
                'OVERDUE',
                'CANCELLED'
            )
        ),


    CONSTRAINT ck_work_item_progress

        CHECK (
            progress_percent >= 0

            AND progress_percent <= 100
        ),


    CONSTRAINT ck_work_item_year

        CHECK (
            planned_year IS NULL

            OR planned_year BETWEEN 2000 AND 2100
        ),


    CONSTRAINT ck_work_item_month

        CHECK (
            planned_month IS NULL

            OR planned_month BETWEEN 1 AND 12
        ),


    CONSTRAINT ck_work_item_dates

        CHECK (
            scheduled_start IS NULL

            OR scheduled_end IS NULL

            OR scheduled_end >= scheduled_start
        )
);


CREATE INDEX idx_work_item_area
    ON work_item(area_id);


CREATE INDEX idx_work_item_status
    ON work_item(status);


CREATE INDEX idx_work_item_priority
    ON work_item(priority);


CREATE INDEX idx_work_item_type
    ON work_item(work_type);


CREATE INDEX idx_work_item_asset
    ON work_item(asset_id);


CREATE INDEX idx_work_item_supplier
    ON work_item(supplier_id);


CREATE INDEX idx_work_item_scheduled_start
    ON work_item(scheduled_start);


CREATE INDEX idx_work_item_scheduled_end
    ON work_item(scheduled_end);


CREATE INDEX idx_work_item_planned_year
    ON work_item(planned_year);


CREATE INDEX idx_work_item_planned_year_month
    ON work_item(
        planned_year,
        planned_month
    );


CREATE INDEX idx_work_item_source_document
    ON work_item(source_document_id);


/*
 * Evita importar dos veces exactamente el mismo
 * registro desde la misma fuente.
 */

CREATE UNIQUE INDEX uq_work_item_source_key

    ON work_item(
        source_document_id,
        source_key
    )

    WHERE
        source_document_id IS NOT NULL
        AND source_key IS NOT NULL;


/*
 * ============================================================
 * 4. REGISTRO HISTÓRICO DE MANTENCIONES
 * ============================================================
 *
 * Muy importante.
 *
 * LISTA DE MANTENCIONES.xlsx tiene estructuras como:
 *
 * EQUIPO
 * FECHA 1
 * QUIÉN LO HIZO
 * DETALLE
 * FECHA 2
 * QUIÉN LO HIZO
 * DETALLE
 * ...
 *
 * En PostgreSQL NO almacenaremos esas fechas
 * horizontalmente.
 *
 * Cada mantención será una fila independiente.
 *
 * Ejemplo:
 *
 * Caldera
 * ├── 2021 → limpieza
 * ├── 2022 → cambio bomba
 * └── 2024 → mantención
 *
 * Esto permitirá tener el histórico solicitado
 * por el cliente.
 * ============================================================
 */

CREATE TABLE maintenance_record (

    id UUID PRIMARY KEY,

    area_id BIGINT NOT NULL,

    asset_id UUID,

    work_item_id UUID,

    supplier_id UUID,


    maintenance_type VARCHAR(30) NOT NULL DEFAULT 'PREVENTIVE',


    performed_on DATE NOT NULL,


    /*
     * Persona o empresa que ejecutó la mantención.
     */

    performed_by VARCHAR(300),


    details TEXT,


    /*
     * Puede almacenarse el costo conocido
     * de una mantención individual.
     */

    cost_amount NUMERIC(16,2),

    currency VARCHAR(3) NOT NULL DEFAULT 'CLP',


    /*
     * Origen documental.
     */

    source_document_id UUID,

    source_version_id UUID,

    source_sheet_name VARCHAR(255),

    source_row_number INTEGER,

    source_cell_reference VARCHAR(100),

    source_key VARCHAR(500),


    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,


    CONSTRAINT fk_maintenance_record_area

        FOREIGN KEY (
            area_id
        )

        REFERENCES area(id)

        ON DELETE RESTRICT,


    CONSTRAINT fk_maintenance_record_asset

        FOREIGN KEY (
            asset_id
        )

        REFERENCES asset(id)

        ON DELETE SET NULL,


    CONSTRAINT fk_maintenance_record_work_item

        FOREIGN KEY (
            work_item_id
        )

        REFERENCES work_item(id)

        ON DELETE SET NULL,


    CONSTRAINT fk_maintenance_record_supplier

        FOREIGN KEY (
            supplier_id
        )

        REFERENCES supplier(id)

        ON DELETE SET NULL,


    CONSTRAINT fk_maintenance_record_source_document

        FOREIGN KEY (
            source_document_id
        )

        REFERENCES document(id)

        ON DELETE SET NULL,


    CONSTRAINT fk_maintenance_record_source_version

        FOREIGN KEY (
            source_version_id
        )

        REFERENCES document_version(id)

        ON DELETE SET NULL,


    CONSTRAINT ck_maintenance_record_type

        CHECK (
            maintenance_type IN (
                'PREVENTIVE',
                'CORRECTIVE',
                'REACTIVE',
                'INSPECTION',
                'CLEANING',
                'OTHER'
            )
        ),


    CONSTRAINT ck_maintenance_record_cost

        CHECK (
            cost_amount IS NULL

            OR cost_amount >= 0
        )
);


CREATE INDEX idx_maintenance_record_area
    ON maintenance_record(area_id);


CREATE INDEX idx_maintenance_record_asset
    ON maintenance_record(asset_id);


CREATE INDEX idx_maintenance_record_date
    ON maintenance_record(performed_on);


CREATE INDEX idx_maintenance_record_supplier
    ON maintenance_record(supplier_id);


CREATE INDEX idx_maintenance_record_source_document
    ON maintenance_record(source_document_id);


CREATE UNIQUE INDEX uq_maintenance_record_source_key

    ON maintenance_record(
        source_document_id,
        source_key
    )

    WHERE
        source_document_id IS NOT NULL
        AND source_key IS NOT NULL;


/*
 * ============================================================
 * 5. PROGRAMACIÓN DE MANTENCIONES
 * ============================================================
 *
 * Esta tabla permitirá posteriormente:
 *
 * - próximas mantenciones;
 * - alertas;
 * - mantenciones vencidas;
 * - calendario de máquinas;
 * - campana de notificaciones.
 *
 * ============================================================
 */

CREATE TABLE maintenance_schedule (

    id UUID PRIMARY KEY,

    area_id BIGINT NOT NULL,

    asset_id UUID,

    supplier_id UUID,


    title VARCHAR(500) NOT NULL,

    description TEXT,


    /*
     * Frecuencia.
     *
     * Ejemplos:
     *
     * 1 YEAR
     * 6 MONTH
     * 15 DAY
     */

    frequency_value INTEGER,

    frequency_unit VARCHAR(20),


    last_maintenance_date DATE,

    next_maintenance_date DATE,


    /*
     * Cuántos días antes mostrar alerta.
     */

    reminder_days INTEGER NOT NULL DEFAULT 7,


    active BOOLEAN NOT NULL DEFAULT TRUE,


    source_document_id UUID,

    source_version_id UUID,

    source_sheet_name VARCHAR(255),

    source_row_number INTEGER,

    source_key VARCHAR(500),


    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,


    CONSTRAINT fk_maintenance_schedule_area

        FOREIGN KEY (
            area_id
        )

        REFERENCES area(id)

        ON DELETE RESTRICT,


    CONSTRAINT fk_maintenance_schedule_asset

        FOREIGN KEY (
            asset_id
        )

        REFERENCES asset(id)

        ON DELETE SET NULL,


    CONSTRAINT fk_maintenance_schedule_supplier

        FOREIGN KEY (
            supplier_id
        )

        REFERENCES supplier(id)

        ON DELETE SET NULL,


    CONSTRAINT fk_maintenance_schedule_source_document

        FOREIGN KEY (
            source_document_id
        )

        REFERENCES document(id)

        ON DELETE SET NULL,


    CONSTRAINT fk_maintenance_schedule_source_version

        FOREIGN KEY (
            source_version_id
        )

        REFERENCES document_version(id)

        ON DELETE SET NULL,


    CONSTRAINT ck_maintenance_schedule_frequency_value

        CHECK (
            frequency_value IS NULL

            OR frequency_value >= 1
        ),


    CONSTRAINT ck_maintenance_schedule_frequency_unit

        CHECK (
            frequency_unit IS NULL

            OR frequency_unit IN (
                'DAY',
                'WEEK',
                'MONTH',
                'YEAR',
                'SEASONAL',
                'ON_DEMAND'
            )
        ),


    CONSTRAINT ck_maintenance_schedule_reminder_days

        CHECK (
            reminder_days >= 0
        )
);


CREATE INDEX idx_maintenance_schedule_area
    ON maintenance_schedule(area_id);


CREATE INDEX idx_maintenance_schedule_asset
    ON maintenance_schedule(asset_id);


CREATE INDEX idx_maintenance_schedule_next_date
    ON maintenance_schedule(next_maintenance_date);


CREATE INDEX idx_maintenance_schedule_active
    ON maintenance_schedule(active);


CREATE UNIQUE INDEX uq_maintenance_schedule_source_key

    ON maintenance_schedule(
        source_document_id,
        source_key
    )

    WHERE
        source_document_id IS NOT NULL
        AND source_key IS NOT NULL;


/*
 * ============================================================
 * 6. COSTOS
 * ============================================================
 *
 * Basado principalmente en las planillas
 * de Remodelación.
 *
 * Ejemplo:
 *
 * CATEGORIA
 * TIPO DE PRODUCTO
 * CANTIDAD
 * VALOR CON IVA
 *
 * También existen hojas:
 *
 * estimado
 * Real
 *
 * Por eso diferenciamos:
 *
 * ESTIMATED
 * ACTUAL
 * ============================================================
 */

CREATE TABLE cost_entry (

    id UUID PRIMARY KEY,

    area_id BIGINT NOT NULL,

    work_item_id UUID,

    asset_id UUID,

    supplier_id UUID,


    cost_type VARCHAR(20) NOT NULL,


    category VARCHAR(200),

    item_name VARCHAR(500) NOT NULL,

    description TEXT,


    quantity NUMERIC(14,3),

    unit VARCHAR(100),


    /*
     * Algunos Excel no indican claramente
     * costo unitario y solo tienen valor total.
     *
     * Por eso ambos son opcionales.
     */

    unit_cost NUMERIC(16,2),

    total_cost NUMERIC(16,2),


    currency VARCHAR(3) NOT NULL DEFAULT 'CLP',

    tax_included BOOLEAN NOT NULL DEFAULT TRUE,


    entry_date DATE,


    notes TEXT,


    source_document_id UUID,

    source_version_id UUID,

    source_sheet_name VARCHAR(255),

    source_row_number INTEGER,

    source_cell_reference VARCHAR(100),

    source_key VARCHAR(500),


    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,


    CONSTRAINT fk_cost_entry_area

        FOREIGN KEY (
            area_id
        )

        REFERENCES area(id)

        ON DELETE RESTRICT,


    CONSTRAINT fk_cost_entry_work_item

        FOREIGN KEY (
            work_item_id
        )

        REFERENCES work_item(id)

        ON DELETE SET NULL,


    CONSTRAINT fk_cost_entry_asset

        FOREIGN KEY (
            asset_id
        )

        REFERENCES asset(id)

        ON DELETE SET NULL,


    CONSTRAINT fk_cost_entry_supplier

        FOREIGN KEY (
            supplier_id
        )

        REFERENCES supplier(id)

        ON DELETE SET NULL,


    CONSTRAINT fk_cost_entry_source_document

        FOREIGN KEY (
            source_document_id
        )

        REFERENCES document(id)

        ON DELETE SET NULL,


    CONSTRAINT fk_cost_entry_source_version

        FOREIGN KEY (
            source_version_id
        )

        REFERENCES document_version(id)

        ON DELETE SET NULL,


    CONSTRAINT ck_cost_entry_type

        CHECK (
            cost_type IN (
                'ESTIMATED',
                'ACTUAL'
            )
        ),


    CONSTRAINT ck_cost_entry_quantity

        CHECK (
            quantity IS NULL

            OR quantity >= 0
        ),


    CONSTRAINT ck_cost_entry_unit_cost

        CHECK (
            unit_cost IS NULL

            OR unit_cost >= 0
        ),


    CONSTRAINT ck_cost_entry_total_cost

        CHECK (
            total_cost IS NULL

            OR total_cost >= 0
        )
);


CREATE INDEX idx_cost_entry_area
    ON cost_entry(area_id);


CREATE INDEX idx_cost_entry_work_item
    ON cost_entry(work_item_id);


CREATE INDEX idx_cost_entry_supplier
    ON cost_entry(supplier_id);


CREATE INDEX idx_cost_entry_type
    ON cost_entry(cost_type);


CREATE INDEX idx_cost_entry_date
    ON cost_entry(entry_date);


CREATE INDEX idx_cost_entry_source_document
    ON cost_entry(source_document_id);


CREATE UNIQUE INDEX uq_cost_entry_source_key

    ON cost_entry(
        source_document_id,
        source_key
    )

    WHERE
        source_document_id IS NOT NULL
        AND source_key IS NOT NULL;


/*
 * ============================================================
 * 7. ÍNDICES ADICIONALES DE TRAZABILIDAD
 * ============================================================
 */

CREATE INDEX idx_supplier_source_document
    ON supplier(source_document_id);


CREATE INDEX idx_asset_source_document
    ON asset(source_document_id);


CREATE INDEX idx_work_item_source_version
    ON work_item(source_version_id);


CREATE INDEX idx_maintenance_record_source_version
    ON maintenance_record(source_version_id);


CREATE INDEX idx_maintenance_schedule_source_version
    ON maintenance_schedule(source_version_id);


CREATE INDEX idx_cost_entry_source_version
    ON cost_entry(source_version_id);