ALTER TABLE account_invitation
    ALTER COLUMN token_hash TYPE VARCHAR(64);
