ALTER TABLE work_item
    ADD COLUMN category VARCHAR(120),
    ADD COLUMN asset_name VARCHAR(300),
    ADD COLUMN frequency VARCHAR(120),
    ADD COLUMN season VARCHAR(120),
    ADD COLUMN materials TEXT,
    ADD COLUMN supplier_name VARCHAR(300),
    ADD COLUMN estimated_cost NUMERIC(14, 2),
    ADD COLUMN actual_cost NUMERIC(14, 2);