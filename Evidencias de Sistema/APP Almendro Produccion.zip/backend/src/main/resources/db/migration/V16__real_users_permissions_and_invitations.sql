ALTER TABLE app_user
    ADD COLUMN full_name VARCHAR(120),
    ADD COLUMN email VARCHAR(254),
    ADD COLUMN account_status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    ADD COLUMN updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE app_user ALTER COLUMN password_hash DROP NOT NULL;

UPDATE app_user
SET full_name = username,
    account_status = CASE WHEN enabled THEN 'ACTIVE' ELSE 'DISABLED' END
WHERE full_name IS NULL;

ALTER TABLE app_user
    ADD CONSTRAINT ck_app_user_account_status
        CHECK (account_status IN ('PENDING_ACTIVATION', 'ACTIVE', 'DISABLED'));

CREATE UNIQUE INDEX uq_app_user_email_lower
    ON app_user (LOWER(email))
    WHERE email IS NOT NULL;

CREATE TABLE app_user_permission (
    user_id BIGINT NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    permission VARCHAR(60) NOT NULL,
    PRIMARY KEY (user_id, permission),
    CONSTRAINT ck_app_user_permission CHECK (permission IN (
        'dashboard', 'mantencion-general', 'mantencion-reactiva', 'mejoras',
        'remodelacion', 'maquinas', 'jardineria', 'prevencion', 'calendario',
        'gastos', 'documentos', 'activos', 'trabajadores', 'configuracion',
        'create-edit', 'delete', 'import', 'history', 'manage-access'
    ))
);

CREATE TABLE account_invitation (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    token_hash CHAR(64) NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    used_at TIMESTAMP WITH TIME ZONE,
    invalidated_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_account_invitation_token_hash UNIQUE (token_hash)
);

CREATE INDEX ix_account_invitation_user ON account_invitation(user_id);
CREATE INDEX ix_account_invitation_validity ON account_invitation(token_hash, expires_at)
    WHERE used_at IS NULL AND invalidated_at IS NULL;
