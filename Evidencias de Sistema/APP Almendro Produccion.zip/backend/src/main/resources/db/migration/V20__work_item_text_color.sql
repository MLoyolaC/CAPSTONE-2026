ALTER TABLE work_item
    ADD COLUMN text_color VARCHAR(7);

ALTER TABLE work_item
    ADD CONSTRAINT ck_work_item_text_color
    CHECK (text_color IS NULL OR text_color ~ '^#[0-9A-F]{6}$');
