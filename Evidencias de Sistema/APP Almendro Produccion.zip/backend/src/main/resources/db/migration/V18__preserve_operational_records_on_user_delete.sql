ALTER TABLE project ALTER COLUMN created_by DROP NOT NULL;
ALTER TABLE project DROP CONSTRAINT fk_project_user;
ALTER TABLE project ADD CONSTRAINT fk_project_user
    FOREIGN KEY (created_by) REFERENCES app_user(id) ON DELETE SET NULL;

ALTER TABLE document ALTER COLUMN created_by DROP NOT NULL;
ALTER TABLE document DROP CONSTRAINT fk_document_user;
ALTER TABLE document ADD CONSTRAINT fk_document_user
    FOREIGN KEY (created_by) REFERENCES app_user(id) ON DELETE SET NULL;

ALTER TABLE document_version ALTER COLUMN uploaded_by DROP NOT NULL;
ALTER TABLE document_version DROP CONSTRAINT fk_version_user;
ALTER TABLE document_version ADD CONSTRAINT fk_version_user
    FOREIGN KEY (uploaded_by) REFERENCES app_user(id) ON DELETE SET NULL;

ALTER TABLE document_activity ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE document_activity DROP CONSTRAINT fk_activity_user;
ALTER TABLE document_activity ADD CONSTRAINT fk_activity_user
    FOREIGN KEY (user_id) REFERENCES app_user(id) ON DELETE SET NULL;

ALTER TABLE worker DROP CONSTRAINT fk_worker_created_by;
ALTER TABLE worker ADD CONSTRAINT fk_worker_created_by
    FOREIGN KEY (created_by) REFERENCES app_user(id) ON DELETE SET NULL;
