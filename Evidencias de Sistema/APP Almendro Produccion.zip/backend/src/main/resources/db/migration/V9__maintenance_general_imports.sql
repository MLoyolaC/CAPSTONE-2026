CREATE TABLE location_catalog (
    id UUID PRIMARY KEY,
    area_id BIGINT NOT NULL,
    canonical_name VARCHAR(300) NOT NULL,
    normalized_key VARCHAR(300) NOT NULL,
    usage_count INTEGER NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_location_catalog_area
        FOREIGN KEY (area_id)
        REFERENCES area(id)
        ON DELETE CASCADE,

    CONSTRAINT uq_location_catalog_area_key
        UNIQUE (area_id, normalized_key),

    CONSTRAINT ck_location_catalog_usage
        CHECK (usage_count >= 0)
);

CREATE INDEX idx_location_catalog_area
    ON location_catalog(area_id);

CREATE INDEX idx_location_catalog_name
    ON location_catalog(canonical_name);


CREATE TABLE mg_import_batch (
    id UUID PRIMARY KEY,
    area_id BIGINT NOT NULL,
    document_id UUID NOT NULL,
    document_version_id UUID,
    original_filename VARCHAR(255) NOT NULL,
    imported_by BIGINT,
    sheet_count INTEGER NOT NULL DEFAULT 0,
    row_count INTEGER NOT NULL DEFAULT 0,
    note_count INTEGER NOT NULL DEFAULT 0,
    status VARCHAR(20) NOT NULL DEFAULT 'COMPLETED',
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_mg_import_batch_area
        FOREIGN KEY (area_id)
        REFERENCES area(id)
        ON DELETE RESTRICT,

    CONSTRAINT fk_mg_import_batch_document
        FOREIGN KEY (document_id)
        REFERENCES document(id)
        ON DELETE CASCADE,

    CONSTRAINT fk_mg_import_batch_version
        FOREIGN KEY (document_version_id)
        REFERENCES document_version(id)
        ON DELETE SET NULL,

    CONSTRAINT fk_mg_import_batch_user
        FOREIGN KEY (imported_by)
        REFERENCES app_user(id)
        ON DELETE SET NULL,

    CONSTRAINT uq_mg_import_batch_document
        UNIQUE (document_id),

    CONSTRAINT ck_mg_import_batch_status
        CHECK (status IN ('COMPLETED', 'ERROR'))
);

CREATE INDEX idx_mg_import_batch_area
    ON mg_import_batch(area_id);

CREATE INDEX idx_mg_import_batch_created
    ON mg_import_batch(created_at DESC);


CREATE TABLE mg_import_sheet (
    id UUID PRIMARY KEY,
    batch_id UUID NOT NULL,
    sheet_index INTEGER NOT NULL,
    sheet_name VARCHAR(255) NOT NULL,
    title_text TEXT,
    header_row_number INTEGER NOT NULL,
    data_start_row INTEGER NOT NULL,
    row_count INTEGER NOT NULL DEFAULT 0,
    note_count INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_mg_import_sheet_batch
        FOREIGN KEY (batch_id)
        REFERENCES mg_import_batch(id)
        ON DELETE CASCADE,

    CONSTRAINT uq_mg_import_sheet_index
        UNIQUE (batch_id, sheet_index)
);

CREATE INDEX idx_mg_import_sheet_batch
    ON mg_import_sheet(batch_id);


CREATE TABLE mg_import_column (
    id UUID PRIMARY KEY,
    sheet_id UUID NOT NULL,
    column_index INTEGER NOT NULL,
    column_key VARCHAR(120) NOT NULL,
    original_label VARCHAR(500) NOT NULL,
    semantic_type VARCHAR(30) NOT NULL DEFAULT 'OTHER',
    display_order INTEGER NOT NULL,

    CONSTRAINT fk_mg_import_column_sheet
        FOREIGN KEY (sheet_id)
        REFERENCES mg_import_sheet(id)
        ON DELETE CASCADE,

    CONSTRAINT uq_mg_import_column_key
        UNIQUE (sheet_id, column_key),

    CONSTRAINT ck_mg_import_column_semantic
        CHECK (semantic_type IN (
            'NUMBER',
            'NAME',
            'LOCATION',
            'DATE',
            'RESPONSIBLE',
            'SUPPLIER',
            'COST',
            'STATUS',
            'DETAIL',
            'CODE',
            'OTHER'
        ))
);

CREATE INDEX idx_mg_import_column_sheet
    ON mg_import_column(sheet_id);


CREATE TABLE mg_import_row (
    id UUID PRIMARY KEY,
    sheet_id UUID NOT NULL,
    source_row_number INTEGER NOT NULL,
    data JSONB NOT NULL,
    validation_warnings JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_mg_import_row_sheet
        FOREIGN KEY (sheet_id)
        REFERENCES mg_import_sheet(id)
        ON DELETE CASCADE,

    CONSTRAINT uq_mg_import_row_source
        UNIQUE (sheet_id, source_row_number)
);

CREATE INDEX idx_mg_import_row_sheet
    ON mg_import_row(sheet_id);

CREATE INDEX idx_mg_import_row_data_gin
    ON mg_import_row
    USING GIN (data);


CREATE TABLE mg_import_note (
    id UUID PRIMARY KEY,
    sheet_id UUID NOT NULL,
    source_row_number INTEGER,
    note_text TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_mg_import_note_sheet
        FOREIGN KEY (sheet_id)
        REFERENCES mg_import_sheet(id)
        ON DELETE CASCADE
);

CREATE INDEX idx_mg_import_note_sheet
    ON mg_import_note(sheet_id);
