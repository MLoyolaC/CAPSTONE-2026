CREATE TABLE document_search_fragment (
    id UUID PRIMARY KEY,

    document_id UUID NOT NULL,

    document_version_id UUID NOT NULL,

    source_type VARCHAR(30) NOT NULL,

    sheet_name VARCHAR(255),

    cell_reference VARCHAR(50),

    content TEXT NOT NULL,

    normalized_content TEXT NOT NULL,

    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_search_fragment_document
        FOREIGN KEY (document_id)
        REFERENCES document(id)
        ON DELETE CASCADE,

    CONSTRAINT fk_search_fragment_version
        FOREIGN KEY (document_version_id)
        REFERENCES document_version(id)
        ON DELETE CASCADE,

    CONSTRAINT ck_search_fragment_source_type
        CHECK (
            source_type IN (
                'FILENAME',
                'SHEET',
                'CELL',
                'COMMENT',
                'WORD_PARAGRAPH',
                'WORD_TABLE'
            )
        )
);


CREATE INDEX idx_search_fragment_document
    ON document_search_fragment(document_id);


CREATE INDEX idx_search_fragment_version
    ON document_search_fragment(document_version_id);


CREATE INDEX idx_search_fragment_document_version
    ON document_search_fragment(
        document_id,
        document_version_id
    );