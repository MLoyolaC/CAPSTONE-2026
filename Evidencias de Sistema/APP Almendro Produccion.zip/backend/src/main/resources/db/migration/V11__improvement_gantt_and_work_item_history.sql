-- V11: Carta Gantt de Mejoras + historial de registros operacionales

ALTER TABLE work_item
    DROP CONSTRAINT IF EXISTS ck_work_item_type;

ALTER TABLE work_item
    ADD CONSTRAINT ck_work_item_type
    CHECK (
        work_type IN (
            'GENERAL_MAINTENANCE',
            'REACTIVE_MAINTENANCE',
            'IMPROVEMENT',
            'IMPROVEMENT_GANTT',
            'REMODELING',
            'MACHINE_MAINTENANCE',
            'GARDENING',
            'PREVENTION',
            'OTHER'
        )
    );

CREATE TABLE work_item_activity (
    id UUID PRIMARY KEY,
    work_item_id UUID,
    area_id BIGINT NOT NULL,
    user_id BIGINT,
    username_snapshot VARCHAR(50),
    role_snapshot VARCHAR(20),
    work_type VARCHAR(40) NOT NULL,
    item_title VARCHAR(500) NOT NULL,
    action VARCHAR(30) NOT NULL,
    details TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_work_item_activity_item
        FOREIGN KEY (work_item_id)
        REFERENCES work_item(id)
        ON DELETE SET NULL,

    CONSTRAINT fk_work_item_activity_area
        FOREIGN KEY (area_id)
        REFERENCES area(id)
        ON DELETE RESTRICT,

    CONSTRAINT fk_work_item_activity_user
        FOREIGN KEY (user_id)
        REFERENCES app_user(id)
        ON DELETE SET NULL
);

CREATE INDEX idx_work_item_activity_item
    ON work_item_activity(work_item_id);

CREATE INDEX idx_work_item_activity_area
    ON work_item_activity(area_id);

CREATE INDEX idx_work_item_activity_created
    ON work_item_activity(created_at DESC);
