-- V13: permitir los tipos operacionales propios de Remodelación.
-- REMODELING_GANTT guarda tareas/hitos de Carta Gantt.
-- REMODELING_SUPPORT conserva directorios/proveedores/inventario de apoyo sin tratarlos como proyectos.

ALTER TABLE work_item
    DROP CONSTRAINT IF EXISTS ck_work_item_type;

ALTER TABLE work_item
    ADD CONSTRAINT ck_work_item_type
    CHECK (
        work_type IN (
            'GENERAL_MAINTENANCE',
            'REACTIVE_MAINTENANCE',
            'IMPROVEMENT',
            'IMPROVEMENT_GANTT',
            'REMODELING',
            'REMODELING_GANTT',
            'REMODELING_SUPPORT',
            'MACHINE_MAINTENANCE',
            'GARDENING',
            'PREVENTION',
            'OTHER'
        )
    );
