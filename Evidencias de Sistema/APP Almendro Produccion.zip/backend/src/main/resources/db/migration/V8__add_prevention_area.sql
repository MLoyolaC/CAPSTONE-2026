-- Prevención de Riesgos: área solicitada por la contraparte el 16 de octubre.
-- Reutiliza work_item y su historial, no cambia los datos de otras áreas.
INSERT INTO area (name, slug, description, sort_order, active)
VALUES ('Prevención de Riesgos', 'prevencion-riesgos',
        'Planificación y seguimiento de tareas de prevención.', 7, TRUE)
ON CONFLICT (slug) DO NOTHING;
