-- V12: alinear tipos de planificación anual con el modelo JPA.
-- planned_year y planned_month fueron creados originalmente como SMALLINT,
-- mientras WorkItem los representa como Integer. Hibernate 7 valida el tipo
-- de forma estricta, por lo que se amplían a INTEGER sin pérdida de datos.

ALTER TABLE work_item
    ALTER COLUMN planned_year TYPE INTEGER USING planned_year::INTEGER,
    ALTER COLUMN planned_month TYPE INTEGER USING planned_month::INTEGER;
