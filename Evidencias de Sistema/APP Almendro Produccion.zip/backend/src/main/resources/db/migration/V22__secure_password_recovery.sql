CREATE TABLE password_recovery_request (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    code_hash VARCHAR(255) NOT NULL,
    reset_token_hash CHAR(64),
    failed_attempts INTEGER NOT NULL DEFAULT 0,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    verified_at TIMESTAMP WITH TIME ZONE,
    used_at TIMESTAMP WITH TIME ZONE,
    invalidated_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_password_recovery_failed_attempts CHECK (failed_attempts >= 0),
    CONSTRAINT uq_password_recovery_reset_token UNIQUE (reset_token_hash)
);

CREATE INDEX ix_password_recovery_user_created
    ON password_recovery_request(user_id, created_at DESC);

CREATE INDEX ix_password_recovery_open
    ON password_recovery_request(user_id, expires_at)
    WHERE used_at IS NULL AND invalidated_at IS NULL;
