ALTER TABLE work_item
    ADD COLUMN IF NOT EXISTS import_source_filename VARCHAR(255),
    ADD COLUMN IF NOT EXISTS imported_data TEXT;

ALTER TABLE mg_import_row
    ADD COLUMN IF NOT EXISTS work_item_id UUID;

ALTER TABLE mg_import_row
    ADD CONSTRAINT fk_mg_import_row_work_item
        FOREIGN KEY (work_item_id)
        REFERENCES work_item(id)
        ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_mg_import_row_work_item
    ON mg_import_row(work_item_id);
