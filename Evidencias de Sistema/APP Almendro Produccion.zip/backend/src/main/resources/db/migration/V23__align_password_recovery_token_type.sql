ALTER TABLE password_recovery_request
    ALTER COLUMN reset_token_hash TYPE VARCHAR(64);
