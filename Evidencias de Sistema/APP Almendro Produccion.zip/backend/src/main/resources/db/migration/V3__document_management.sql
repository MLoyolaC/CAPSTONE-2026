-- =====================================================
-- ÁREAS / TARJETAS PRINCIPALES
-- =====================================================

CREATE TABLE area (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    slug VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(255),
    sort_order SMALLINT NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT ck_area_sort_order
        CHECK (sort_order > 0)
);

-- =====================================================
-- PROYECTOS
-- =====================================================

CREATE TABLE project (
    id UUID PRIMARY KEY,
    area_id BIGINT NOT NULL,
    name VARCHAR(160) NOT NULL,
    description TEXT,

    status VARCHAR(30) NOT NULL DEFAULT 'PLANNING',

    start_date DATE,
    end_date DATE,

    created_by BIGINT NOT NULL,

    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    archived_at TIMESTAMP WITH TIME ZONE,

    CONSTRAINT fk_project_area
        FOREIGN KEY (area_id)
        REFERENCES area(id),

    CONSTRAINT fk_project_user
        FOREIGN KEY (created_by)
        REFERENCES app_user(id),

    CONSTRAINT ck_project_status
        CHECK (
            status IN (
                'PLANNING',
                'IN_PROGRESS',
                'COMPLETED',
                'ON_HOLD',
                'ARCHIVED'
            )
        )
);

-- =====================================================
-- DOCUMENTOS
-- =====================================================

CREATE TABLE document (
    id UUID PRIMARY KEY,

    area_id BIGINT NOT NULL,
    project_id UUID,

    name VARCHAR(255) NOT NULL,

    file_type VARCHAR(10) NOT NULL,

    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',

    current_version_id UUID,

    index_status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    last_indexed_at TIMESTAMP WITH TIME ZONE,

    created_by BIGINT NOT NULL,

    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_document_area
        FOREIGN KEY (area_id)
        REFERENCES area(id),

    CONSTRAINT fk_document_project
        FOREIGN KEY (project_id)
        REFERENCES project(id),

    CONSTRAINT fk_document_user
        FOREIGN KEY (created_by)
        REFERENCES app_user(id),

    CONSTRAINT ck_document_file_type
        CHECK (file_type IN ('XLSX', 'DOCX', 'PDF')),

    CONSTRAINT ck_document_status
        CHECK (status IN ('ACTIVE', 'ARCHIVED', 'DELETED')),

    CONSTRAINT ck_document_index_status
        CHECK (
            index_status IN (
                'PENDING',
                'INDEXED',
                'ERROR',
                'NOT_APPLICABLE'
            )
        )
);

-- =====================================================
-- VERSIONES DE ARCHIVOS
-- =====================================================

CREATE TABLE document_version (
    id UUID PRIMARY KEY,

    document_id UUID NOT NULL,

    version_number INTEGER NOT NULL,

    original_filename VARCHAR(255) NOT NULL,
    mime_type VARCHAR(150) NOT NULL,

    size_bytes BIGINT NOT NULL,
    sha256 CHAR(64) NOT NULL,

    local_storage_path TEXT,
    cloud_storage_path TEXT,

    sync_status VARCHAR(30) NOT NULL DEFAULT 'LOCAL_ONLY',

    source VARCHAR(20) NOT NULL,

    uploaded_by BIGINT NOT NULL,

    notes TEXT,

    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_version_document
        FOREIGN KEY (document_id)
        REFERENCES document(id),

    CONSTRAINT fk_version_user
        FOREIGN KEY (uploaded_by)
        REFERENCES app_user(id),

    CONSTRAINT uq_document_version
        UNIQUE (document_id, version_number),

    CONSTRAINT ck_version_number
        CHECK (version_number > 0),

    CONSTRAINT ck_version_size
        CHECK (size_bytes >= 0),

    CONSTRAINT ck_version_sync
        CHECK (
            sync_status IN (
                'LOCAL_ONLY',
                'PENDING_CLOUD',
                'SYNCED',
                'ERROR'
            )
        ),

    CONSTRAINT ck_version_source
        CHECK (
            source IN (
                'ORIGINAL',
                'REPLACEMENT',
                'EDIT'
            )
        )
);

ALTER TABLE document
ADD CONSTRAINT fk_document_current_version
FOREIGN KEY (current_version_id)
REFERENCES document_version(id);

-- =====================================================
-- ÍNDICE DE BÚSQUEDA
-- =====================================================

CREATE TABLE document_search_entry (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,

    document_id UUID NOT NULL,
    document_version_id UUID NOT NULL,

    source_type VARCHAR(30) NOT NULL,

    sheet_name VARCHAR(255),
    cell_reference VARCHAR(30),

    text_original TEXT NOT NULL,
    text_normalized TEXT NOT NULL,

    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_search_document
        FOREIGN KEY (document_id)
        REFERENCES document(id)
        ON DELETE CASCADE,

    CONSTRAINT fk_search_version
        FOREIGN KEY (document_version_id)
        REFERENCES document_version(id)
        ON DELETE CASCADE,

    CONSTRAINT ck_search_source
        CHECK (
            source_type IN (
                'FILE_NAME',
                'SHEET_NAME',
                'CELL',
                'CELL_NOTE',
                'DOCX_PARAGRAPH',
                'DOCX_TABLE'
            )
        )
);

CREATE INDEX idx_search_document
ON document_search_entry(document_id);

CREATE INDEX idx_search_normalized_trgm
ON document_search_entry
USING GIN (text_normalized gin_trgm_ops);

CREATE INDEX idx_search_full_text
ON document_search_entry
USING GIN (to_tsvector('simple', text_normalized));

-- =====================================================
-- HISTORIAL / AUDITORÍA
-- =====================================================

CREATE TABLE document_activity (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,

    document_id UUID NOT NULL,
    document_version_id UUID,

    user_id BIGINT NOT NULL,

    action VARCHAR(30) NOT NULL,

    details JSONB NOT NULL DEFAULT '{}'::jsonb,

    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_activity_document
        FOREIGN KEY (document_id)
        REFERENCES document(id),

    CONSTRAINT fk_activity_version
        FOREIGN KEY (document_version_id)
        REFERENCES document_version(id),

    CONSTRAINT fk_activity_user
        FOREIGN KEY (user_id)
        REFERENCES app_user(id),

    CONSTRAINT ck_activity_action
        CHECK (
            action IN (
                'UPLOADED',
                'OPENED',
                'DOWNLOADED',
                'EDIT_STARTED',
                'REPLACED',
                'EDIT_CANCELLED',
                'ARCHIVED',
                'RESTORED'
            )
        )
);

-- =====================================================
-- SESIÓN "EDITAR EN EXCEL"
-- =====================================================

CREATE TABLE document_edit_session (
    id UUID PRIMARY KEY,

    document_id UUID NOT NULL,

    base_version_id UUID NOT NULL,
    result_version_id UUID,

    user_id BIGINT NOT NULL,

    status VARCHAR(30) NOT NULL DEFAULT 'WAITING_CHANGES',

    started_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP WITH TIME ZONE,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,

    CONSTRAINT fk_edit_document
        FOREIGN KEY (document_id)
        REFERENCES document(id),

    CONSTRAINT fk_edit_base_version
        FOREIGN KEY (base_version_id)
        REFERENCES document_version(id),

    CONSTRAINT fk_edit_result_version
        FOREIGN KEY (result_version_id)
        REFERENCES document_version(id),

    CONSTRAINT fk_edit_user
        FOREIGN KEY (user_id)
        REFERENCES app_user(id),

    CONSTRAINT ck_edit_status
        CHECK (
            status IN (
                'WAITING_CHANGES',
                'COMPLETED',
                'CANCELLED',
                'EXPIRED'
            )
        )
);

CREATE UNIQUE INDEX uq_document_active_edit
ON document_edit_session(document_id)
WHERE status = 'WAITING_CHANGES';

-- =====================================================
-- ÁREAS INICIALES DEL SISTEMA OMM
-- =====================================================

INSERT INTO area (
    name,
    slug,
    description,
    sort_order
)
VALUES
(
    'Mantención General',
    'mantencion-general',
    'Mantenciones preventivas y planificadas.',
    1
),
(
    'Mantención Reactiva',
    'mantencion-reactiva',
    'Problemas y mantenciones que requieren atención inmediata.',
    2
),
(
    'Mejoras',
    'mejoras',
    'Proyectos futuros y mejoras del hotel.',
    3
),
(
    'Remodelación',
    'remodelacion',
    'Proyectos de renovación y remodelación.',
    4
),
(
    'Mantención de Máquinas',
    'mantencion-maquinas',
    'Mantención y seguimiento de equipos y máquinas.',
    5
),
(
    'Mantención de Jardinería',
    'mantencion-jardineria',
    'Trabajos y planificación de jardines y áreas exteriores.',
    6
);

CREATE INDEX idx_project_area
ON project(area_id);

CREATE INDEX idx_document_area
ON document(area_id);

CREATE INDEX idx_document_project
ON document(project_id);

CREATE INDEX idx_version_document
ON document_version(document_id);

CREATE INDEX idx_activity_document
ON document_activity(document_id);