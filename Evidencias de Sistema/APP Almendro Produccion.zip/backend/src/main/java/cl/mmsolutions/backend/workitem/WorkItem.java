package cl.mmsolutions.backend.workitem;

import cl.mmsolutions.backend.area.Area;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;


@Entity
@Table(name = "work_item")
public class WorkItem {

    @Id
    private UUID id;


    @ManyToOne(
            fetch = FetchType.EAGER,
            optional = false
    )
    @JoinColumn(
            name = "area_id",
            nullable = false
    )
    private Area area;


    @Column(
            name = "work_type",
            nullable = false,
            length = 40
    )
    private String workType;


    @Column(
            length = 200
    )
    private String phase;


    @Column(
            name = "planned_year"
    )
    private Integer plannedYear;


    @Column(
            name = "planned_month"
    )
    private Integer plannedMonth;


    @Column(
            nullable = false,
            length = 500
    )
    private String title;


    @Column(
            columnDefinition = "TEXT"
    )
    private String description;


    @Column(
            length = 300
    )
    private String location;


    @Column(
            name = "responsible_name",
            length = 300
    )
    private String responsibleName;


    @Column(
            nullable = false,
            length = 20
    )
    private String priority;


    @Column(
            nullable = false,
            length = 30
    )
    private String status;


    @Column(
            name = "scheduled_start"
    )
    private LocalDate scheduledStart;


    @Column(
            name = "scheduled_end"
    )
    private LocalDate scheduledEnd;

    @Column(
            name = "display_color",
            length = 7
    )
    private String displayColor;

    @Column(
            name = "text_color",
            length = 7
    )
    private String textColor;


    @Column(
            name = "completed_date"
    )
    private LocalDate completedDate;


    @Column(
            name = "progress_percent",
            nullable = false,
            precision = 5,
            scale = 2
    )
    private BigDecimal progressPercent;


    @Column(
            columnDefinition = "TEXT"
    )
    private String notes;


    /*
     * ============================================================
     * CAMPOS ESPECÍFICOS DE CADA ÁREA
     * ============================================================
     */


    /*
     * Tipo o categoría.
     *
     * Ejemplos:
     * - Electricidad
     * - Gasfitería
     * - Fuga
     * - Pintura
     * - Ampliación
     */
    @Column(
            length = 120
    )
    private String category;


    /*
     * Máquina o equipo relacionado.
     */
    @Column(
            name = "asset_name",
            length = 300
    )
    private String assetName;

    @Column(name = "asset_id")
    private UUID assetId;


    /*
     * Periodicidad.
     *
     * Ej:
     * Semanal
     * Mensual
     * Trimestral
     * Anual
     */
    @Column(
            length = 120
    )
    private String frequency;


    /*
     * Temporada.
     *
     * Principalmente para jardinería.
     */
    @Column(
            length = 120
    )
    private String season;


    /*
     * Materiales asociados.
     */
    @Column(
            columnDefinition = "TEXT"
    )
    private String materials;


    /*
     * Proveedor asociado.
     */
    @Column(
            name = "supplier_name",
            length = 300
    )
    private String supplierName;


    /*
     * Presupuesto / costo estimado.
     */
    @Column(
            name = "estimated_cost",
            precision = 14,
            scale = 2
    )
    private BigDecimal estimatedCost;


    /*
     * Costo finalmente pagado.
     */
    @Column(
            name = "actual_cost",
            precision = 14,
            scale = 2
    )
    private BigDecimal actualCost;


    @Column(name = "source_document_id")
    private UUID sourceDocumentId;

    @Column(name = "source_version_id")
    private UUID sourceVersionId;

    @Column(name = "source_sheet_name", length = 255)
    private String sourceSheetName;

    @Column(name = "source_row_number")
    private Integer sourceRowNumber;

    @Column(name = "source_key", length = 500)
    private String sourceKey;

    @Column(name = "import_source_filename", length = 255)
    private String importSourceFilename;

    @Column(name = "imported_data", columnDefinition = "TEXT")
    private String importedData;

    @Column(
            name = "created_at",
            nullable = false
    )
    private OffsetDateTime createdAt;


    @Column(
            name = "updated_at",
            nullable = false
    )
    private OffsetDateTime updatedAt;


    protected WorkItem() {
    }


    public WorkItem(
            Area area,
            String workType,
            String title
    ) {

        this.area = area;

        this.workType = workType;

        this.title = title;

        this.priority = "NORMAL";

        this.status = "PENDING";

        this.progressPercent =
                BigDecimal.ZERO;
    }


    /* ============================================================
       CICLO DE VIDA
       ============================================================ */

    @PrePersist
    void prePersist() {

        if (id == null) {

            id = UUID.randomUUID();
        }


        if (
                priority == null
                || priority.isBlank()
        ) {

            priority = "NORMAL";
        }


        if (
                status == null
                || status.isBlank()
        ) {

            status = "PENDING";
        }


        if (
                progressPercent == null
        ) {

            progressPercent =
                    BigDecimal.ZERO;
        }


        OffsetDateTime now =
                OffsetDateTime.now();


        if (
                createdAt == null
        ) {

            createdAt = now;
        }


        updatedAt = now;
    }


    @PreUpdate
    void preUpdate() {

        updatedAt =
                OffsetDateTime.now();
    }


    /* ============================================================
       GETTERS
       ============================================================ */

    public UUID getId() {

        return id;
    }


    public Area getArea() {

        return area;
    }


    public String getWorkType() {

        return workType;
    }


    public String getPhase() {

        return phase;
    }


    public Integer getPlannedYear() {

        return plannedYear;
    }


    public Integer getPlannedMonth() {

        return plannedMonth;
    }


    public String getTitle() {

        return title;
    }


    public String getDescription() {

        return description;
    }


    public String getLocation() {

        return location;
    }


    public String getResponsibleName() {

        return responsibleName;
    }


    public String getPriority() {

        return priority;
    }


    public String getStatus() {

        return status;
    }


    public LocalDate getScheduledStart() {

        return scheduledStart;
    }


    public LocalDate getScheduledEnd() {

        return scheduledEnd;
    }

    public String getDisplayColor() {
        return displayColor;
    }

    public void setDisplayColor(String displayColor) {
        this.displayColor = displayColor;
    }

    public String getTextColor() {
        return textColor;
    }

    public void setTextColor(String textColor) {
        this.textColor = textColor;
    }


    public LocalDate getCompletedDate() {

        return completedDate;
    }


    public BigDecimal getProgressPercent() {

        return progressPercent;
    }


    public String getNotes() {

        return notes;
    }


    public String getCategory() {

        return category;
    }


    public String getAssetName() {

        return assetName;
    }

    public UUID getAssetId() { return assetId; }

    public void setAssetReference(UUID assetId, String assetName) {
        this.assetId = assetId;
        this.assetName = assetName;
    }


    public String getFrequency() {

        return frequency;
    }


    public String getSeason() {

        return season;
    }


    public String getMaterials() {

        return materials;
    }


    public String getSupplierName() {

        return supplierName;
    }


    public BigDecimal getEstimatedCost() {

        return estimatedCost;
    }


    public BigDecimal getActualCost() {

        return actualCost;
    }


    public UUID getSourceDocumentId() {
        return sourceDocumentId;
    }

    public UUID getSourceVersionId() {
        return sourceVersionId;
    }

    public String getSourceSheetName() {
        return sourceSheetName;
    }

    public Integer getSourceRowNumber() {
        return sourceRowNumber;
    }

    public String getSourceKey() {
        return sourceKey;
    }

    public String getImportSourceFilename() {
        return importSourceFilename;
    }

    public String getImportedData() {
        return importedData;
    }

    public void setImportSource(
            String importSourceFilename,
            String sourceSheetName,
            Integer sourceRowNumber,
            String sourceKey
    ) {
        this.importSourceFilename = importSourceFilename;
        this.sourceSheetName = sourceSheetName;
        this.sourceRowNumber = sourceRowNumber;
        this.sourceKey = sourceKey;
    }

    public OffsetDateTime getCreatedAt() {

        return createdAt;
    }


    public OffsetDateTime getUpdatedAt() {

        return updatedAt;
    }


    public void setPlanningMetadata(
            String phase,
            Integer plannedYear,
            Integer plannedMonth
    ) {

        this.phase = phase;
        this.plannedYear = plannedYear;
        this.plannedMonth = plannedMonth;
    }


    public void setImportedCompletedDate(LocalDate completedDate) {
        this.completedDate = completedDate;
    }


    /* ============================================================
       ACTUALIZAR
       ============================================================ */

    public void update(
            String title,
            String description,
            String location,
            String responsibleName,
            String priority,
            String status,
            LocalDate scheduledStart,
            LocalDate scheduledEnd,
            BigDecimal progressPercent,
            String notes,
            String category,
            String assetName,
            String frequency,
            String season,
            String materials,
            String supplierName,
            BigDecimal estimatedCost,
            BigDecimal actualCost,
            String importedData
    ) {

        this.title = title;

        this.description = description;

        this.location = location;

        this.responsibleName =
                responsibleName;

        this.priority = priority;

        this.status = status;

        this.scheduledStart =
                scheduledStart;

        this.scheduledEnd =
                scheduledEnd;

        this.progressPercent =
                progressPercent;

        this.notes = notes;


        /*
         * Campos específicos.
         */

        this.category =
                category;

        this.assetName =
                assetName;

        this.frequency =
                frequency;

        this.season =
                season;

        this.materials =
                materials;

        this.supplierName =
                supplierName;

        this.estimatedCost =
                estimatedCost;

        this.actualCost =
                actualCost;

        this.importedData = importedData;
        changeStatus(status);


        /*
         * Si se finaliza, se registra
         * automáticamente la fecha.
         */

    }

    public void changeStatus(String status) {
        this.status = status;

        if ("COMPLETED".equals(status)) {

            if (
                    this.completedDate == null
            ) {

                this.completedDate =
                        LocalDate.now();
            }


            this.progressPercent =
                    BigDecimal.valueOf(
                            100
                    );

        } else if (area != null && "mantencion-reactiva".equals(area.getSlug())) {

            this.completedDate = null;
            this.progressPercent = BigDecimal.ZERO;

        } else if (area == null || !"mantencion-general".equals(area.getSlug())) {

            this.completedDate = null;
        }
    }
}
