package cl.mmsolutions.backend.invitation;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/invitations")
public class InvitationController {
    private final InvitationService service;

    public InvitationController(InvitationService service) { this.service = service; }

    @GetMapping("/validate")
    public InvitationService.InvitationView validate(@RequestParam String token) {
        return service.validate(token);
    }

    @PostMapping("/activate")
    public ResponseEntity<Map<String, String>> activate(@Valid @RequestBody ActivationRequest request) {
        service.activate(request.token(), request.password(), request.passwordConfirmation());
        return ResponseEntity.ok(Map.of("message", "Cuenta activada correctamente."));
    }

    public record ActivationRequest(@NotBlank String token,
                                    @NotBlank @Size(max = 128) String password,
                                    @NotBlank @Size(max = 128) String passwordConfirmation) {}
}
