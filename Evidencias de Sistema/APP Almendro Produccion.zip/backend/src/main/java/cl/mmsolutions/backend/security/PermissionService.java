package cl.mmsolutions.backend.security;

import cl.mmsolutions.backend.user.AppUser;
import cl.mmsolutions.backend.user.AppUserRepository;
import cl.mmsolutions.backend.user.Role;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.Set;
import java.util.UUID;

@Service("permissionService")
public class PermissionService {
    private final AppUserRepository users;
    private final JdbcTemplate jdbc;

    public PermissionService(AppUserRepository users, JdbcTemplate jdbc) { this.users = users; this.jdbc = jdbc; }

    @Transactional(readOnly = true)
    public Set<String> permissionsFor(String username) {
        return users.findByUsernameIgnoreCase(username)
                .filter(AppUser::isEnabled)
                .map(user -> user.getRole() == Role.ADMIN ? Permissions.ALL : Set.copyOf(user.getPermissions()))
                .orElse(Set.of());
    }

    @Transactional(readOnly = true)
    public boolean has(Authentication authentication, String permission) {
        if (authentication == null || !authentication.isAuthenticated()) return false;
        return permissionsFor(authentication.getName()).contains(permission);
    }

    public boolean hasArea(Authentication authentication, String areaSlug) {
        return has(authentication, Permissions.forAreaSlug(areaSlug));
    }

    @Transactional(readOnly = true)
    public boolean isAdmin(Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) return false;
        return users.findByUsernameIgnoreCase(authentication.getName())
                .map(user -> user.getRole() == Role.ADMIN && user.isEnabled())
                .orElse(false);
    }

    public boolean hasAreaOrDocuments(Authentication authentication, String areaSlug) {
        if ("trabajadores".equals(Permissions.forAreaSlug(areaSlug))) {
            return hasArea(authentication, areaSlug);
        }
        return has(authentication, "documentos") || hasArea(authentication, areaSlug);
    }

    public boolean hasWorkItem(Authentication authentication, UUID id) {
        String slug = jdbc.queryForObject("SELECT a.slug FROM work_item w JOIN area a ON a.id=w.area_id WHERE w.id=?",
                String.class, id);
        return hasArea(authentication, slug);
    }

    public boolean hasDocument(Authentication authentication, UUID id) {
        String slug = jdbc.queryForObject("SELECT a.slug FROM document d JOIN area a ON a.id=d.area_id WHERE d.id=?",
                String.class, id);
        return hasAreaOrDocuments(authentication, slug);
    }
}
