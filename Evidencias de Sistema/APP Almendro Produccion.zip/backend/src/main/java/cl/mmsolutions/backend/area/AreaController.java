package cl.mmsolutions.backend.area;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/areas")
public class AreaController {

    private final AreaRepository areaRepository;

    public AreaController(
            AreaRepository areaRepository
    ) {
        this.areaRepository = areaRepository;
    }

    @GetMapping
    public List<AreaResponse> getAreas() {

        return areaRepository
                .findAllActiveWithDocumentCount()
                .stream()
                .map(area -> new AreaResponse(
                        area.getId(),
                        area.getName(),
                        area.getSlug(),
                        area.getDescription(),
                        area.getSortOrder(),
                        area.getDocumentCount()
                ))
                .toList();
    }

    public record AreaResponse(
            Long id,
            String name,
            String slug,
            String description,
            Short sortOrder,
            Long documentCount
    ) {
    }
}