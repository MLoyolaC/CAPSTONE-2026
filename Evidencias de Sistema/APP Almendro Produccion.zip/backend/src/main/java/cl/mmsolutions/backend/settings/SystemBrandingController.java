package cl.mmsolutions.backend.settings;

import org.springframework.http.CacheControl;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.concurrent.TimeUnit;

@RestController
@RequestMapping("/api/settings/branding")
public class SystemBrandingController {
    private final SystemBrandingService service;

    public SystemBrandingController(SystemBrandingService service) { this.service = service; }

    @GetMapping
    public SystemBrandingService.BrandingState state() { return service.state(); }

    @PutMapping("/preset")
    @PreAuthorize("@permissionService.has(authentication, 'manage-access')")
    public SystemBrandingService.BrandingState preset(@RequestBody PresetRequest request, Authentication auth) {
        return service.choosePreset(request.preset(), auth.getName());
    }

    @PostMapping(path = "/image", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @PreAuthorize("@permissionService.has(authentication, 'manage-access')")
    public SystemBrandingService.BrandingState image(@RequestPart("file") MultipartFile file, Authentication auth) {
        return service.upload(file, auth.getName());
    }

    @GetMapping("/image")
    public ResponseEntity<byte[]> image() {
        AccountSettingsService.StoredImage image = service.image();
        return ResponseEntity.ok().contentType(MediaType.parseMediaType(image.mime()))
                .cacheControl(CacheControl.maxAge(5, TimeUnit.MINUTES).cachePrivate())
                .body(image.bytes());
    }

    public record PresetRequest(String preset) {}
}
