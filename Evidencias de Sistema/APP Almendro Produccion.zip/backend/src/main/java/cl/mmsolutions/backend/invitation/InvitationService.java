package cl.mmsolutions.backend.invitation;

import cl.mmsolutions.backend.user.AccountStatus;
import cl.mmsolutions.backend.user.AppUser;
import cl.mmsolutions.backend.user.AppUserRepository;
import cl.mmsolutions.backend.security.PasswordPolicy;
import org.springframework.beans.factory.annotation.Value;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.OffsetDateTime;
import java.util.Base64;
import java.util.HexFormat;

@Service
public class InvitationService {
    private static final Logger log = LoggerFactory.getLogger(InvitationService.class);
    private final AccountInvitationRepository invitations;
    private final AppUserRepository users;
    private final PasswordEncoder passwordEncoder;
    private final SecureRandom random = new SecureRandom();
    private final long expirationHours;

    public InvitationService(AccountInvitationRepository invitations, AppUserRepository users,
            PasswordEncoder passwordEncoder,
            @Value("${app.invitation.expiration-hours:24}") long expirationHours) {
        this.invitations = invitations;
        this.users = users;
        this.passwordEncoder = passwordEncoder;
        this.expirationHours = Math.max(1, expirationHours);
        log.info("Account invitation expiration configured to {} hours", this.expirationHours);
    }

    @Transactional
    public IssuedInvitation issue(Long userId) {
        AppUser user = users.findByIdForUpdate(userId).orElseThrow();
        if (user.getAccountStatus() != AccountStatus.PENDING_ACTIVATION) {
            throw new InvitationException("La cuenta ya fue activada.");
        }
        OffsetDateTime now = OffsetDateTime.now();
        invitations.invalidateOpenForUser(userId, now);
        byte[] bytes = new byte[48];
        random.nextBytes(bytes);
        String token = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
        invitations.save(new AccountInvitation(user, hash(token), now.plusHours(expirationHours)));
        return new IssuedInvitation(user, token, expirationHours);
    }

    @Transactional(readOnly = true)
    public InvitationView validate(String token) {
        AccountInvitation invitation = find(token);
        if (!invitation.isUsable(OffsetDateTime.now())) {
            throw new InvitationException("El enlace de activación expiró o ya fue utilizado.");
        }
        AppUser user = invitation.getUser();
        return new InvitationView(user.getFullName(), user.getEmail(), user.getUsername(), invitation.getExpiresAt());
    }

    @Transactional
    public void activate(String token, String password, String confirmation) {
        try {
            PasswordPolicy.validate(password, confirmation);
        } catch (PasswordPolicy.PasswordPolicyException ex) {
            throw new InvitationException(ex.getMessage());
        }
        AccountInvitation invitation = findForUpdate(token);
        OffsetDateTime now = OffsetDateTime.now();
        if (!invitation.isUsable(now)) {
            throw new InvitationException("El enlace de activación expiró o ya fue utilizado.");
        }
        AppUser user = invitation.getUser();
        if (user.getAccountStatus() != AccountStatus.PENDING_ACTIVATION) {
            throw new InvitationException("La cuenta ya fue activada.");
        }
        user.activate(passwordEncoder.encode(password));
        invitation.use(now);
        users.save(user);
        invitations.save(invitation);
    }

    private AccountInvitation find(String token) {
        if (token == null || token.isBlank() || token.length() > 200) {
            throw new InvitationException("El enlace de activación no es válido.");
        }
        return invitations.findByTokenHash(hash(token)).orElseThrow(() ->
                new InvitationException("El enlace de activación no es válido."));
    }

    private AccountInvitation findForUpdate(String token) {
        if (token == null || token.isBlank() || token.length() > 200) {
            throw new InvitationException("El enlace de activación no es válido.");
        }
        return invitations.findByTokenHashForUpdate(hash(token)).orElseThrow(() ->
                new InvitationException("El enlace de activación no es válido."));
    }

    private static String hash(String value) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256")
                    .digest(value.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException ex) {
            throw new IllegalStateException(ex);
        }
    }

    public record IssuedInvitation(AppUser user, String rawToken, long expirationHours) {}
    public record InvitationView(String fullName, String email, String username, OffsetDateTime expiresAt) {}
    public static class InvitationException extends RuntimeException {
        public InvitationException(String message) { super(message); }
    }
}
