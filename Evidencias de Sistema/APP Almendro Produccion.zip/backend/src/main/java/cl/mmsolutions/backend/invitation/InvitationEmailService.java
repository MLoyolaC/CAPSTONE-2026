package cl.mmsolutions.backend.invitation;

import cl.mmsolutions.backend.user.AppUser;
import com.resend.Resend;
import com.resend.core.exception.ResendException;
import com.resend.services.emails.model.CreateEmailOptions;
import com.resend.services.emails.model.CreateEmailResponse;
import com.resend.services.emails.model.Template;
import org.springframework.beans.factory.annotation.Value;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@Service
public class InvitationEmailService {
    private static final Logger log = LoggerFactory.getLogger(InvitationEmailService.class);
    private final String apiKey;
    private final String fromEmail;
    private final String templateId;
    private final String publicUrl;
    private final Resend resend;

    public InvitationEmailService(
            @Value("${app.resend.api-key:}") String apiKey,
            @Value("${app.resend.from-email:}") String fromEmail,
            @Value("${app.resend.template-id:}") String templateId,
            @Value("${app.public-url:}") String publicUrl) {
        this.apiKey = apiKey;
        this.fromEmail = fromEmail;
        this.templateId = templateId;
        this.publicUrl = publicUrl;
        this.resend = apiKey.isBlank() ? null : new Resend(apiKey);
        log.info("Invitation email configuration loaded: apiKeyPresent={}, fromEmail={}, templateIdConfigured={}, publicUrl={}",
                !apiKey.isBlank(), safeLogValue(fromEmail), !templateId.isBlank(), safeLogValue(publicUrl));
    }

    public String sendActivation(AppUser user, String rawToken, long expirationHours) {
        if (apiKey.isBlank() || fromEmail.isBlank() || templateId.isBlank() || publicUrl.isBlank()) {
            log.error("Invitation email configuration is incomplete: apiKeyPresent={}, fromEmailPresent={}, templateIdPresent={}, publicUrlPresent={}",
                    !apiKey.isBlank(), !fromEmail.isBlank(), !templateId.isBlank(), !publicUrl.isBlank());
            throw new EmailDeliveryException("La integración de correo no está configurada.");
        }
        String base = publicUrl.endsWith("/") ? publicUrl.substring(0, publicUrl.length() - 1) : publicUrl;
        String activationUrl = base + "/activar-cuenta?token=" +
                URLEncoder.encode(rawToken, StandardCharsets.UTF_8);
        Template template = Template.builder()
                .id(templateId)
                .addVariable("NOMBRE", user.getFullName())
                .addVariable("USUARIO", user.getUsername())
                .addVariable("URL_ACTIVACION", activationUrl)
                .addVariable("HORAS_EXPIRACION", expirationHours)
                .build();
        CreateEmailOptions options = CreateEmailOptions.builder()
                .from(fromEmail)
                .to(user.getEmail())
                .template(template)
                .build();
        try {
            log.info("Submitting account invitation with Resend Template for userId={}, templateId={}",
                    user.getId(), templateId);
            CreateEmailResponse response = resend.emails().send(options);
            if (response == null || response.getId() == null || response.getId().isBlank()) {
                log.error("Resend returned no email identifier for userId={}", user.getId());
                throw new EmailDeliveryException("Resend no confirmó el envío de la invitación.");
            }
            log.info("Account invitation accepted by Resend for userId={}, resendEmailId={}",
                    user.getId(), response.getId());
            return response.getId();
        } catch (ResendException ex) {
            log.error("Resend rejected account invitation for userId={}: exceptionType={}, httpStatus={}, errorCode={}, reason={}",
                    user.getId(), ex.getClass().getSimpleName(), ex.getStatusCode(),
                    safeLogValue(ex.getErrorName()), safeLogValue(ex.getMessage()));
            throw new EmailDeliveryException("Resend rechazó o no pudo procesar la invitación.", ex);
        } catch (RuntimeException | LinkageError ex) {
            log.error("Resend client failed before receiving a response for userId={}: exceptionType={}, reason={}",
                    user.getId(), ex.getClass().getSimpleName(), safeLogValue(ex.getMessage()));
            throw new EmailDeliveryException("No fue posible ejecutar la solicitud de invitación a Resend.", ex);
        }
    }

    public String sendPasswordRecovery(AppUser user, String code, int expirationMinutes) {
        if (apiKey.isBlank() || fromEmail.isBlank()) {
            log.error("Password recovery email configuration is incomplete: apiKeyPresent={}, fromEmailPresent={}",
                    !apiKey.isBlank(), !fromEmail.isBlank());
            throw new EmailDeliveryException("La integración de correo no está configurada.");
        }
        String html = """
                <div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;color:#292929">
                  <h2>Restablecer contraseña · Sistema OMM</h2>
                  <p>Hola %s:</p>
                  <p>Usa este código para restablecer la contraseña de tu cuenta:</p>
                  <p style="font-size:30px;font-weight:700;letter-spacing:8px">%s</p>
                  <p>El código vence en %d minutos y sólo puede utilizarse una vez.</p>
                  <p>Si no solicitaste este cambio, puedes ignorar este correo.</p>
                </div>
                """.formatted(escapeHtml(user.getFullName()), code, expirationMinutes);
        CreateEmailOptions options = CreateEmailOptions.builder()
                .from(fromEmail)
                .to(user.getEmail())
                .subject("Código para restablecer tu contraseña · Sistema OMM")
                .html(html)
                .build();
        try {
            log.info("Submitting password recovery email to Resend for userId={}", user.getId());
            CreateEmailResponse response = resend.emails().send(options);
            if (response == null || response.getId() == null || response.getId().isBlank()) {
                log.error("Resend returned no password recovery email identifier for userId={}", user.getId());
                throw new EmailDeliveryException("Resend no confirmó el envío de recuperación.");
            }
            log.info("Password recovery email accepted by Resend for userId={}, resendEmailId={}",
                    user.getId(), response.getId());
            return response.getId();
        } catch (ResendException ex) {
            log.error("Resend rejected password recovery for userId={}: exceptionType={}, httpStatus={}, errorCode={}",
                    user.getId(), ex.getClass().getSimpleName(), ex.getStatusCode(), safeLogValue(ex.getErrorName()));
            throw new EmailDeliveryException("Resend rechazó o no pudo procesar la recuperación.", ex);
        } catch (RuntimeException | LinkageError ex) {
            log.error("Resend client failed during password recovery for userId={}, exceptionType={}",
                    user.getId(), ex.getClass().getSimpleName());
            throw new EmailDeliveryException("No fue posible solicitar el correo de recuperación a Resend.", ex);
        }
    }

    private static String escapeHtml(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }

    private static String safeLogValue(String value) {
        if (value == null || value.isBlank()) return "not-provided";
        String singleLine = value.replaceAll("[\\r\\n\\t]+", " ");
        singleLine = singleLine.replaceAll("(?i)(token=)[^&\\s\"']+", "$1[redacted]");
        return singleLine.length() > 500 ? singleLine.substring(0, 500) : singleLine;
    }

    public static class EmailDeliveryException extends RuntimeException {
        public EmailDeliveryException(String message) { super(message); }
        public EmailDeliveryException(String message, Throwable cause) { super(message, cause); }
    }
}
