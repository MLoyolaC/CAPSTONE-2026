package cl.mmsolutions.backend.backup;

import cl.mmsolutions.backend.document.DocumentStorageProvider;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.json.JsonMapper;
import tools.jackson.databind.node.NullNode;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.Mac;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

@Service
public class CompleteBackupService {
    private static final Logger LOGGER = LoggerFactory.getLogger(CompleteBackupService.class);
    private static final byte[] MAGIC = "OMM_BACKUP_V1".getBytes(StandardCharsets.US_ASCII);
    private static final int SALT_LENGTH = 16;
    private static final int IV_LENGTH = 16;
    private static final int MAC_LENGTH = 32;
    private static final int PBKDF_ITERATIONS = 260_000;
    private static final long MAX_ENCRYPTED = 512L * 1024 * 1024;
    private static final long MAX_UNPACKED = 1_500L * 1024 * 1024;
    private static final int MAX_ENTRIES = 30_000;
    private static final SecureRandom RANDOM = new SecureRandom();

    private final JsonMapper mapper = JsonMapper.builder().build();
    private final String jdbcUrl;
    private final String dbUser;
    private final String dbPassword;
    private final String pgBinDir;
    private final ReentrantLock backupLock = new ReentrantLock();
    private final Path storageParent;
    private final DocumentStorageProvider documentStorage;

    public CompleteBackupService(
            @Value("${spring.datasource.url}") String jdbcUrl,
            @Value("${spring.datasource.username}") String dbUser,
            @Value("${spring.datasource.password}") String dbPassword,
            @Value("${app.backup.pg-bin-dir:}") String pgBinDir,
            @Value("${app.backup.work-path:storage}") String backupWorkPath,
            DocumentStorageProvider documentStorage) {
        this.jdbcUrl = jdbcUrl;
        this.dbUser = dbUser;
        this.dbPassword = dbPassword;
        this.pgBinDir = pgBinDir;
        this.storageParent = Path.of(backupWorkPath).toAbsolutePath().normalize();
        this.documentStorage = documentStorage;
    }

    public Path exportBackup(String passphrase, JsonNode browserSettings) {
        checkPassword(passphrase);
        if (!backupLock.tryLock()) throw new ResponseStatusException(HttpStatus.CONFLICT, "Hay una operación de respaldo en curso.");
        Path temporary = null;
        try {
            temporary = Files.createTempDirectory("omm-export-");
            Path output = temporary.resolve("respaldo.ommbackup");
            createEncryptedBackup(output, passphrase, browserSettings);
            if (Files.size(output) > MAX_ENCRYPTED) throw new IOException("El respaldo supera 512 MB.");
            // El controlador borra el archivo temporal después de transmitirlo.
            return output;
        } catch (Exception e) {
            deleteTreeQuietly(temporary);
            throw failure("No se pudo generar el respaldo completo", e);
        } finally {
            backupLock.unlock();
        }
    }

    public RestoreResult restoreBackup(MultipartFile uploaded, String passphrase, String confirmation) {
        checkPassword(passphrase);
        if (!documentStorage.supportsFullRestore()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "La restauración completa está bloqueada para Supabase para evitar inconsistencias entre Storage y PostgreSQL.");
        }
        if (!"RESTAURAR".equals(confirmation)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Debes confirmar escribiendo RESTAURAR.");
        }
        if (uploaded.isEmpty() || uploaded.getSize() > MAX_ENCRYPTED) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El respaldo está vacío o supera el límite de 512 MB.");
        }
        if (!backupLock.tryLock()) throw new ResponseStatusException(HttpStatus.CONFLICT, "Hay otra operación de respaldo en curso.");
        Path staging = null;
        Path uploadedFile = null;
        try {
            Files.createDirectories(storageParent);
            staging = Files.createTempDirectory(storageParent, "omm-import-");
            uploadedFile = staging.resolve("uploaded.ommbackup");
            uploaded.transferTo(uploadedFile);
            if (Files.size(uploadedFile) > MAX_ENCRYPTED) throw new IOException("El respaldo supera el límite.");
            // Verificación MAC antes de extraer o modificar ningún dato existente.
            VerifiedArchive verified = verifyEncryptedArchive(uploadedFile, passphrase);
            extractVerifiedArchive(uploadedFile, staging.resolve("extracted"), verified);
            Path extracted = staging.resolve("extracted");
            JsonNode manifest = mapper.readTree(Files.readString(extracted.resolve("manifest.json")));
            if (!"OMM_COMPLETE_BACKUP_V1".equals(manifest.path("format").asString())) {
                throw new IOException("El archivo no corresponde a una versión compatible de respaldo OMM.");
            }
            Path databaseDump = extracted.resolve("database.dump");
            if (!Files.isRegularFile(databaseDump) ||
                    !manifest.path("databaseSha256").asString().equalsIgnoreCase(sha256(databaseDump))) {
                throw new IOException("El respaldo de PostgreSQL no pasó la validación.");
            }
            try (InputStream in = Files.newInputStream(databaseDump)) {
                byte[] signature = in.readNBytes(5);
                if (!Arrays.equals(signature, "PGDMP".getBytes(StandardCharsets.US_ASCII))) {
                    throw new IOException("La base de datos del respaldo tiene un formato inválido.");
                }
            }
            Path nextDocuments = extracted.resolve("documents");
            Files.createDirectories(nextDocuments);

            // Antes de reemplazar datos, conserva un respaldo de recuperación cifrado en el volumen persistente.
            Path safetyDir = storageParent.resolve("safety-backups");
            Files.createDirectories(safetyDir);
            Path safetyFile = safetyDir.resolve("antes-restaurar-" + System.currentTimeMillis() + ".ommbackup");
            createEncryptedBackup(safetyFile, passphrase, NullNode.getInstance());

            // Sustituir documentos primero: si la restauración de PostgreSQL falla,
            // pg_restore --single-transaction revierte la BD y se recolocan los documentos anteriores.
            // Se debe realizar esta operación sin otros usuarios editando la aplicación.
            List<DocumentStorageProvider.RestoreObject> restoreObjects = new ArrayList<>();
            try (Stream<Path> files = Files.walk(nextDocuments)) {
                for (Path entry : (Iterable<Path>) files.filter(Files::isRegularFile)::iterator) {
                    String relative = nextDocuments.relativize(entry).toString().replace('\\', '/');
                    restoreObjects.add(new DocumentStorageProvider.RestoreObject(
                            relative, Files.size(entry), () -> Files.newInputStream(entry)));
                }
            }
            DocumentStorageProvider.StorageReplacement replacement = null;
            try {
                replacement = documentStorage.replaceAll(restoreObjects);
                restorePostgres(databaseDump);
            } catch (Exception restoreError) {
                if (replacement != null) {
                    try { replacement.rollback(); }
                    catch (RuntimeException rollbackError) { restoreError.addSuppressed(rollbackError); }
                }
                throw new IOException("Restauración detenida; se intentó conservar los documentos previos. Respaldo automático: " + safetyFile.getFileName(), restoreError);
            }
            try {
                replacement.commit();
            } catch (RuntimeException cleanupError) {
                // PostgreSQL y el nuevo storage ya quedaron confirmados. Una falla al
                // limpiar la copia anterior no debe intentar revertir solo storage.
                LOGGER.error("Restauración completada, pero no fue posible limpiar la copia documental anterior; requiere reconciliación manual.", cleanupError);
            }
            JsonNode browser = Files.isRegularFile(extracted.resolve("browser-settings.json"))
                    ? mapper.readTree(Files.readString(extracted.resolve("browser-settings.json")))
                    : NullNode.getInstance();
            return new RestoreResult("OK", "Datos restaurados. Vuelve a iniciar sesión con la contraseña que utilizabas en el equipo original.", browser, safetyFile.getFileName().toString());
        } catch (Exception ex) {
            throw failure("No se pudo restaurar el respaldo", ex);
        } finally {
            deleteTreeQuietly(staging);
            backupLock.unlock();
        }
    }

    public void removeExport(Path file) {
        if (file == null) return;
        deleteTreeQuietly(file.getParent());
    }

    private void createEncryptedBackup(Path encryptedOutput, String passphrase, JsonNode browserSettings) throws Exception {
        Path tmp = Files.createTempFile("omm-postgres-", ".dump");
        try {
            dumpPostgres(tmp);
            String digest = sha256(tmp);
            byte[] salt = randomBytes(SALT_LENGTH);
            byte[] iv = randomBytes(IV_LENGTH);
            DerivedKeys keys = deriveKeys(passphrase, salt);
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(keys.macKey, "HmacSHA256"));
            Cipher cipher = Cipher.getInstance("AES/CTR/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(keys.encKey, "AES"), new IvParameterSpec(iv));

            Map<String, Object> metadata = new LinkedHashMap<>();
            metadata.put("format", "OMM_COMPLETE_BACKUP_V1");
            metadata.put("createdAt", Instant.now().toString());
            metadata.put("databaseSha256", digest);
            metadata.put("includes", List.of("PostgreSQL (todas las tablas y usuarios)", "Documentos almacenados", "Preferencias locales del navegador"));

            Files.createDirectories(encryptedOutput.getParent());
            try (OutputStream file = new BufferedOutputStream(Files.newOutputStream(encryptedOutput))) {
                byte[] header = concat(MAGIC, salt, iv);
                file.write(header);
                mac.update(header);
                try (ZipOutputStream zip = new ZipOutputStream(new CipherOutputStream(new MacTeeStream(file, mac), cipher))) {
                    addBytes(zip, "manifest.json", mapper.writeValueAsBytes(metadata));
                    addPath(zip, "database.dump", tmp);
                    if (browserSettings != null && !browserSettings.isNull()) {
                        byte[] local = mapper.writeValueAsBytes(browserSettings);
                        if (local.length > 1024 * 1024) throw new IOException("Preferencias locales demasiado grandes.");
                        addBytes(zip, "browser-settings.json", local);
                    }
                    for (DocumentStorageProvider.StoredObject object : documentStorage.list()) {
                        String relative = documentStorage.backupPath(object.key());
                        if (relative.isBlank() || relative.startsWith("/") || relative.contains("../")) {
                            throw new IOException("Clave documental insegura durante el respaldo.");
                        }
                        try (InputStream input = documentStorage.open(object.key())) {
                            addStream(zip, "documents/" + relative, input);
                        }
                    }
                }
                file.write(mac.doFinal());
            }
        } finally {
            Files.deleteIfExists(tmp);
        }
    }

    private VerifiedArchive verifyEncryptedArchive(Path encrypted, String passphrase) throws Exception {
        long fileSize = Files.size(encrypted);
        int headerSize = MAGIC.length + SALT_LENGTH + IV_LENGTH;
        if (fileSize <= headerSize + MAC_LENGTH) throw new IOException("Respaldo incompleto.");
        byte[] header = new byte[headerSize];
        byte[] expected = new byte[MAC_LENGTH];
        try (InputStream in = new BufferedInputStream(Files.newInputStream(encrypted))) {
            if (in.readNBytes(header, 0, header.length) != header.length) throw new IOException("Cabecera inválida.");
            if (!Arrays.equals(Arrays.copyOfRange(header, 0, MAGIC.length), MAGIC)) throw new IOException("No es un respaldo OMM válido.");
            byte[] salt = Arrays.copyOfRange(header, MAGIC.length, MAGIC.length + SALT_LENGTH);
            DerivedKeys keys = deriveKeys(passphrase, salt);
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(keys.macKey, "HmacSHA256"));
            mac.update(header);
            long remaining = fileSize - headerSize - MAC_LENGTH;
            byte[] buffer = new byte[64 * 1024];
            while (remaining > 0) {
                int chunk = (int) Math.min(buffer.length, remaining);
                int n = in.read(buffer, 0, chunk);
                if (n == -1) throw new IOException("Respaldo truncado.");
                mac.update(buffer, 0, n);
                remaining -= n;
            }
            if (in.readNBytes(expected, 0, expected.length) != MAC_LENGTH || !MessageDigest.isEqual(expected, mac.doFinal())) {
                throw new IOException("Contraseña incorrecta o archivo modificado.");
            }
            byte[] iv = Arrays.copyOfRange(header, MAGIC.length + SALT_LENGTH, header.length);
            return new VerifiedArchive(keys.encKey, iv, fileSize - headerSize - MAC_LENGTH);
        }
    }

    private void extractVerifiedArchive(Path encrypted, Path target, VerifiedArchive verified) throws Exception {
        Files.createDirectories(target);
        Cipher cipher = Cipher.getInstance("AES/CTR/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(verified.key, "AES"), new IvParameterSpec(verified.iv));
        try (InputStream in = new BufferedInputStream(Files.newInputStream(encrypted))) {
            long headerLength = MAGIC.length + SALT_LENGTH + IV_LENGTH;
            in.skipNBytes(headerLength);
            try (ZipInputStream zip = new ZipInputStream(new CipherInputStream(new LimitedInputStream(in, verified.ciphertextLength), cipher))) {
                ZipEntry entry;
                long unpackedBytes = 0;
                int entries = 0;
                while ((entry = zip.getNextEntry()) != null) {
                    if (++entries > MAX_ENTRIES) throw new IOException("Demasiados elementos dentro del respaldo.");
                    String name = entry.getName();
                    if (!(name.equals("manifest.json") || name.equals("database.dump") || name.equals("browser-settings.json") || name.startsWith("documents/"))) {
                        throw new IOException("Elemento no permitido dentro del respaldo.");
                    }
                    Path file = target.resolve(name).normalize();
                    if (!file.startsWith(target)) throw new IOException("Ruta insegura dentro del respaldo.");
                    if (entry.isDirectory()) { Files.createDirectories(file); continue; }
                    Files.createDirectories(file.getParent());
                    if (Files.exists(file)) throw new IOException("Elemento duplicado en respaldo.");
                    try (OutputStream out = Files.newOutputStream(file, StandardOpenOption.CREATE_NEW)) {
                        byte[] buffer = new byte[64 * 1024];
                        int len;
                        while ((len = zip.read(buffer)) != -1) {
                            unpackedBytes += len;
                            if (unpackedBytes > MAX_UNPACKED) throw new IOException("El respaldo descomprimido supera el límite de seguridad.");
                            out.write(buffer, 0, len);
                        }
                    }
                    zip.closeEntry();
                }
            }
        }
    }

    private void dumpPostgres(Path output) throws Exception {
        DatabaseAddress db = address();
        List<String> args = new ArrayList<>(List.of(executable("pg_dump"), "--format=custom", "--no-owner", "--no-acl", "--file", output.toString(), "--host", db.host, "--port", String.valueOf(db.port), "--username", dbUser, db.database));
        runDatabaseCommand(args, db);
    }

    private void restorePostgres(Path dump) throws Exception {
        DatabaseAddress db = address();
        List<String> args = List.of(executable("pg_restore"), "--clean", "--if-exists", "--no-owner", "--no-acl", "--single-transaction", "--exit-on-error", "--host", db.host, "--port", String.valueOf(db.port), "--username", dbUser, "--dbname", db.database, dump.toString());
        runDatabaseCommand(args, db);
    }

    private void runDatabaseCommand(List<String> arguments, DatabaseAddress db) throws Exception {
        Path log = Files.createTempFile("omm-postgres-log-", ".txt");
        try {
            ProcessBuilder builder = new ProcessBuilder(arguments);
            builder.environment().put("PGPASSWORD", dbPassword);
            if (db.sslMode != null) builder.environment().put("PGSSLMODE", db.sslMode);
            builder.redirectErrorStream(true);
            builder.redirectOutput(log.toFile());
            Process process;
            try { process = builder.start(); }
            catch (IOException missing) { throw new IOException("No se encontró " + arguments.get(0) + ". Instala PostgreSQL client o configura PG_BIN_DIR.", missing); }
            if (!process.waitFor(10, TimeUnit.MINUTES)) {
                process.destroyForcibly();
                throw new IOException("Se superó el tiempo máximo para operar sobre PostgreSQL.");
            }
            if (process.exitValue() != 0) {
                String description = Files.readString(log);
                if (description.length() > 2000) description = description.substring(description.length() - 2000);
                throw new IOException("PostgreSQL rechazó la operación: " + description);
            }
        } finally { Files.deleteIfExists(log); }
    }

    private DatabaseAddress address() throws Exception {
        if (!jdbcUrl.startsWith("jdbc:postgresql:")) throw new IOException("Se requiere PostgreSQL para respaldos completos.");
        URI uri = URI.create(jdbcUrl.substring(5));
        String host = uri.getHost();
        String database = uri.getPath() == null ? "" : uri.getPath().replaceFirst("^/", "");
        if (host == null || database.isBlank()) throw new IOException("DB_URL no tiene host o nombre de base de datos.");
        String ssl = null;
        if (uri.getQuery() != null) for (String component : uri.getQuery().split("&")) {
            if (component.startsWith("sslmode=")) ssl = component.substring("sslmode=".length());
        }
        return new DatabaseAddress(host, uri.getPort() < 0 ? 5432 : uri.getPort(), database, ssl);
    }

    private String executable(String name) {
        if (pgBinDir != null && !pgBinDir.isBlank()) return Path.of(pgBinDir, name + (System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win") ? ".exe" : "")).toString();
        return name;
    }

    private void checkPassword(String password) {
        if (password == null || password.length() < 12 || password.length() > 256) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "La contraseña del respaldo debe tener entre 12 y 256 caracteres.");
        }
    }

    private DerivedKeys deriveKeys(String password, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, PBKDF_ITERATIONS, 512);
        try {
            byte[] derived = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            return new DerivedKeys(Arrays.copyOfRange(derived, 0, 32), Arrays.copyOfRange(derived, 32, 64));
        } finally { spec.clearPassword(); }
    }

    private String sha256(Path path) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream in = Files.newInputStream(path)) { byte[] data = new byte[64 * 1024]; int n; while ((n = in.read(data)) != -1) digest.update(data, 0, n); }
        return HexFormat.of().formatHex(digest.digest());
    }

    private void addBytes(ZipOutputStream zip, String name, byte[] data) throws IOException {
        zip.putNextEntry(new ZipEntry(name)); zip.write(data); zip.closeEntry();
    }
    private void addPath(ZipOutputStream zip, String name, Path source) throws IOException {
        zip.putNextEntry(new ZipEntry(name)); Files.copy(source, zip); zip.closeEntry();
    }
    private void addStream(ZipOutputStream zip, String name, InputStream source) throws IOException {
        zip.putNextEntry(new ZipEntry(name)); source.transferTo(zip); zip.closeEntry();
    }
    private byte[] randomBytes(int size) { byte[] bytes = new byte[size]; RANDOM.nextBytes(bytes); return bytes; }
    private byte[] concat(byte[]... pieces) { ByteArrayOutputStream out = new ByteArrayOutputStream(); for (byte[] piece : pieces) out.writeBytes(piece); return out.toByteArray(); }
    private ResponseStatusException failure(String message, Exception ex) {
        if (ex instanceof ResponseStatusException response) return response;
        String reason = ex.getMessage() == null ? message : message + ": " + ex.getMessage();
        return new ResponseStatusException(HttpStatus.BAD_REQUEST, reason, ex);
    }
    private void deleteTreeQuietly(Path directory) {
        if (directory == null || !Files.exists(directory)) return;
        try (Stream<Path> paths = Files.walk(directory)) {
            for (Path path : (Iterable<Path>) paths.sorted(Comparator.reverseOrder())::iterator) Files.deleteIfExists(path);
        } catch (IOException ignored) { }
    }

    public record RestoreResult(String status, String message, JsonNode browserSettings, String safetyBackupFile) { }
    private record DerivedKeys(byte[] encKey, byte[] macKey) { }
    private record VerifiedArchive(byte[] key, byte[] iv, long ciphertextLength) { }
    private record DatabaseAddress(String host, int port, String database, String sslMode) { }

    private static final class MacTeeStream extends FilterOutputStream {
        private final Mac mac;
        private MacTeeStream(OutputStream target, Mac mac) { super(target); this.mac = mac; }
        @Override public void write(int one) throws IOException { out.write(one); mac.update((byte) one); }
        @Override public void write(byte[] data, int offset, int length) throws IOException { out.write(data, offset, length); mac.update(data, offset, length); }
        @Override public void close() throws IOException { flush(); }
    }
    private static final class LimitedInputStream extends FilterInputStream {
        private long remaining;
        private LimitedInputStream(InputStream inner, long remaining) { super(inner); this.remaining = remaining; }
        @Override public int read() throws IOException { if (remaining <= 0) return -1; int v = in.read(); if (v != -1) remaining--; return v; }
        @Override public int read(byte[] b, int off, int len) throws IOException { if (remaining <= 0) return -1; int n = in.read(b, off, (int) Math.min(len, remaining)); if (n > 0) remaining -= n; return n; }
    }
}
