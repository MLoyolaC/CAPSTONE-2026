package cl.mmsolutions.backend.search;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.security.access.prepost.PreAuthorize;

import java.util.List;


@RestController
@RequestMapping("/api/search")
public class DocumentSearchController {

    private final DocumentSearchService searchService;


    public DocumentSearchController(
            DocumentSearchService searchService
    ) {

        this.searchService =
                searchService;
    }


    /*
     * ============================================================
     * BÚSQUEDA
     *
     * Ejemplos:
     *
     * Búsqueda global:
     * /api/search?q=tineta
     *
     * Búsqueda solo Remodelación:
     * /api/search?q=tineta&areaSlug=remodelacion
     * ============================================================
     */

    @GetMapping
    @PreAuthorize("(#areaSlug != null and @permissionService.hasAreaOrDocuments(authentication, #areaSlug)) or (#areaSlug == null and @permissionService.has(authentication, 'documentos'))")
    public List<DocumentSearchService.SearchResult>
    search(
            @RequestParam("q")
            String query,

            @RequestParam(
                    required = false
            )
            String areaSlug
    ) {

        return searchService.search(
                query,
                areaSlug
        );
    }
}
