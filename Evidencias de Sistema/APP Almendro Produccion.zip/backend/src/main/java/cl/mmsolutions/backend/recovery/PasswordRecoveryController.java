package cl.mmsolutions.backend.recovery;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth/password-recovery")
public class PasswordRecoveryController {
    private final PasswordRecoveryService service;

    public PasswordRecoveryController(PasswordRecoveryService service) {
        this.service = service;
    }

    @PostMapping("/request")
    public PasswordRecoveryService.RequestResult request(@Valid @RequestBody RecoveryRequest request) {
        return service.request(request.email());
    }

    @PostMapping("/verify")
    public PasswordRecoveryService.VerificationResult verify(@Valid @RequestBody VerificationRequest request) {
        return service.verify(request.email(), request.code());
    }

    @PostMapping("/reset")
    public ResponseEntity<Map<String, String>> reset(@Valid @RequestBody ResetRequest request) {
        service.reset(request.resetToken(), request.password(), request.passwordConfirmation());
        return ResponseEntity.ok(Map.of("message", "Contraseña restablecida correctamente."));
    }

    public record RecoveryRequest(@NotBlank @Email @Size(max = 254) String email) {}
    public record VerificationRequest(
            @NotBlank @Email @Size(max = 254) String email,
            @NotBlank @Pattern(regexp = "\\d{6}") String code) {}
    public record ResetRequest(
            @NotBlank @Size(max = 200) String resetToken,
            @NotBlank @Size(max = 128) String password,
            @NotBlank @Size(max = 128) String passwordConfirmation) {}
}
