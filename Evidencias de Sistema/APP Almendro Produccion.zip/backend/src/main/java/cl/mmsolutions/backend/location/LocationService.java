package cl.mmsolutions.backend.location;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

@Service
public class LocationService {

    private static final Pattern DIACRITICS = Pattern.compile("\\p{M}+");
    private static final Pattern NON_ALPHANUMERIC = Pattern.compile("[^a-z0-9]+");

    private final JdbcTemplate jdbcTemplate;

    public LocationService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<LocationSuggestion> suggest(String areaSlug, String query) {
        Long areaId = findAreaId(areaSlug);
        String normalizedQuery = normalize(query);

        Map<String, String> values = new LinkedHashMap<>();

        List<Map<String, Object>> catalogRows = jdbcTemplate.queryForList(
                """
                SELECT canonical_name, normalized_key
                FROM location_catalog
                WHERE area_id = ?
                ORDER BY usage_count DESC, canonical_name ASC
                LIMIT 300
                """,
                areaId
        );

        for (Map<String, Object> row : catalogRows) {
            String normalizedKey = String.valueOf(row.get("normalized_key"));
            String canonicalName = String.valueOf(row.get("canonical_name"));
            values.putIfAbsent(normalizedKey, canonicalName);
        }

        List<Map<String, Object>> workItemRows = jdbcTemplate.queryForList(
                """
                SELECT DISTINCT location
                FROM work_item wi
                INNER JOIN area a ON a.id = wi.area_id
                WHERE a.slug = ?
                  AND wi.location IS NOT NULL
                  AND BTRIM(wi.location) <> ''
                ORDER BY location
                LIMIT 300
                """,
                areaSlug
        );

        for (Map<String, Object> row : workItemRows) {
            Object rawLocation = row.get("location");
            if (rawLocation == null) {
                continue;
            }

            String name = cleanDisplay(String.valueOf(rawLocation));
            values.putIfAbsent(normalize(name), name);
        }

        List<LocationSuggestion> result = new ArrayList<>();

        for (Map.Entry<String, String> entry : values.entrySet()) {
            double score = score(normalizedQuery, entry.getKey());

            if (normalizedQuery.isBlank() || score >= 0.36d) {
                result.add(new LocationSuggestion(entry.getValue(), score));
            }
        }

        result.sort(
                Comparator.comparingDouble(LocationSuggestion::score)
                        .reversed()
                        .thenComparing(LocationSuggestion::name)
        );

        return result.stream()
                .limit(8)
                .toList();
    }

    public String canonicalizeOrRegister(String areaSlug, String value) {
        if (value == null || value.isBlank()) {
            return null;
        }

        Long areaId = findAreaId(areaSlug);
        String proposed = cleanDisplay(value);
        String key = normalize(proposed);

        if (key.isBlank()) {
            return null;
        }

        List<String> exact = jdbcTemplate.query(
                """
                SELECT canonical_name
                FROM location_catalog
                WHERE area_id = ?
                  AND normalized_key = ?
                LIMIT 1
                """,
                (rs, rowNum) -> rs.getString("canonical_name"),
                areaId,
                key
        );

        if (!exact.isEmpty()) {
            jdbcTemplate.update(
                    """
                    UPDATE location_catalog
                    SET usage_count = usage_count + 1,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE area_id = ?
                      AND normalized_key = ?
                    """,
                    areaId,
                    key
            );

            return exact.getFirst();
        }

        String canonical = canonicalDisplay(proposed, key);

        jdbcTemplate.update(
                """
                INSERT INTO location_catalog (
                    id,
                    area_id,
                    canonical_name,
                    normalized_key,
                    usage_count
                )
                VALUES (?, ?, ?, ?, 1)
                ON CONFLICT (area_id, normalized_key)
                DO UPDATE SET
                    usage_count = location_catalog.usage_count + 1,
                    updated_at = CURRENT_TIMESTAMP
                """,
                UUID.randomUUID(),
                areaId,
                canonical,
                key
        );

        return canonical;
    }

    public void registerImported(String areaSlug, String value) {
        canonicalizeOrRegister(areaSlug, value);
    }

    public String normalize(String value) {
        if (value == null) {
            return "";
        }

        String normalized = Normalizer.normalize(
                value.trim().toLowerCase(Locale.ROOT),
                Normalizer.Form.NFD
        );

        normalized = DIACRITICS.matcher(normalized).replaceAll("");
        normalized = normalized.replace('ñ', 'n');
        normalized = NON_ALPHANUMERIC.matcher(normalized).replaceAll(" ");

        return normalized.trim().replaceAll("\\s+", " ");
    }

    private String cleanDisplay(String value) {
        if (value == null) {
            return "";
        }

        return value.trim().replaceAll("\\s+", " ");
    }

    private String canonicalDisplay(String proposed, String normalizedKey) {
        String number = normalizedKey.replaceAll("^[^0-9]*", "");

        if (normalizedKey.startsWith("habitacion")) {
            return number.isBlank() ? "Habitación" : "Habitación " + number;
        }

        if (normalizedKey.startsWith("cabana")) {
            String tail = proposed.replaceFirst("(?i)^caba[nñ]a\\s*", "").trim();
            return tail.isBlank() ? "Cabaña" : "Cabaña " + titleCase(tail);
        }

        if (normalizedKey.startsWith("lavanderia")) {
            return "Lavandería";
        }

        if (normalizedKey.startsWith("sala ")) {
            return "Sala " + titleCase(proposed.replaceFirst("(?i)^sala\\s+", ""));
        }

        if (normalizedKey.startsWith("bodega ")) {
            return "Bodega " + titleCase(proposed.replaceFirst("(?i)^bodega\\s+", ""));
        }

        if (normalizedKey.startsWith("pasillo ")) {
            return "Pasillo " + titleCase(proposed.replaceFirst("(?i)^pasillo\\s+", ""));
        }

        return proposed;
    }

    private String titleCase(String value) {
        if (value == null || value.isBlank()) {
            return "";
        }

        String[] parts = value.trim().toLowerCase(Locale.ROOT).split("\\s+");
        StringBuilder result = new StringBuilder();

        for (String part : parts) {
            if (part.isBlank()) {
                continue;
            }

            if (!result.isEmpty()) {
                result.append(' ');
            }

            result.append(Character.toUpperCase(part.charAt(0)));

            if (part.length() > 1) {
                result.append(part.substring(1));
            }
        }

        return result.toString();
    }

    private double score(String query, String candidate) {
        if (query == null || query.isBlank()) {
            return 1d;
        }

        if (candidate.equals(query)) {
            return 1d;
        }

        if (candidate.startsWith(query)) {
            return 0.94d;
        }

        if (candidate.contains(query)) {
            return 0.82d;
        }

        if (query.contains(candidate) && candidate.length() >= 4) {
            return 0.76d;
        }

        int distance = levenshtein(query, candidate);
        int max = Math.max(query.length(), candidate.length());

        if (max == 0) {
            return 1d;
        }

        return 1d - ((double) distance / max);
    }

    private int levenshtein(String left, String right) {
        int[] previous = new int[right.length() + 1];
        int[] current = new int[right.length() + 1];

        for (int j = 0; j <= right.length(); j++) {
            previous[j] = j;
        }

        for (int i = 1; i <= left.length(); i++) {
            current[0] = i;

            for (int j = 1; j <= right.length(); j++) {
                int cost = left.charAt(i - 1) == right.charAt(j - 1) ? 0 : 1;

                current[j] = Math.min(
                        Math.min(current[j - 1] + 1, previous[j] + 1),
                        previous[j - 1] + cost
                );
            }

            int[] swap = previous;
            previous = current;
            current = swap;
        }

        return previous[right.length()];
    }

    private Long findAreaId(String areaSlug) {
        return jdbcTemplate.query(
                        """
                        SELECT id
                        FROM area
                        WHERE slug = ?
                          AND active = TRUE
                        LIMIT 1
                        """,
                        (rs, rowNum) -> rs.getLong("id"),
                        areaSlug
                )
                .stream()
                .findFirst()
                .orElseThrow(() ->
                        new IllegalArgumentException("Área no encontrada: " + areaSlug)
                );
    }

    public record LocationSuggestion(
            String name,
            double score
    ) {
    }
}
