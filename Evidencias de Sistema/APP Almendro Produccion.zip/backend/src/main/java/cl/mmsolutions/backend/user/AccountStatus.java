package cl.mmsolutions.backend.user;

public enum AccountStatus {
    PENDING_ACTIVATION,
    ACTIVE,
    DISABLED
}
