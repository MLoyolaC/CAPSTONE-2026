package cl.mmsolutions.backend.workitem;

import cl.mmsolutions.backend.area.Area;
import cl.mmsolutions.backend.area.AreaRepository;
import cl.mmsolutions.backend.asset.AssetLinkService;
import cl.mmsolutions.backend.location.LocationService;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

@Service
public class WorkItemService {
    private static final Set<String> ALLOWED_TYPES = Set.of(
            "GENERAL_MAINTENANCE", "REACTIVE_MAINTENANCE", "IMPROVEMENT",
            "IMPROVEMENT_GANTT", "REMODELING", "REMODELING_GANTT", "REMODELING_SUPPORT", "MACHINE_MAINTENANCE",
            "GARDENING", "PREVENTION", "OTHER"
    );
    private static final Set<String> ALLOWED_PRIORITIES = Set.of("LOW", "NORMAL", "HIGH", "URGENT");
    private static final Set<String> ALLOWED_STATUSES = Set.of(
            "PLANNED", "PENDING", "IN_PROGRESS", "COMPLETED", "OVERDUE", "CANCELLED"
    );
    private static final Set<String> STATUS_SIDE_EFFECT_FIELDS = Set.of("status", "completedDate", "progressPercent");

    private final WorkItemRepository workItemRepository;
    private final AreaRepository areaRepository;
    private final LocationService locationService;
    private final WorkItemActivityService activityService;
    private final AssetLinkService assetLinkService;

    public WorkItemService(
            WorkItemRepository workItemRepository,
            AreaRepository areaRepository,
            LocationService locationService,
            WorkItemActivityService activityService,
            AssetLinkService assetLinkService
    ) {
        this.workItemRepository = workItemRepository;
        this.areaRepository = areaRepository;
        this.locationService = locationService;
        this.activityService = activityService;
        this.assetLinkService = assetLinkService;
    }

    @Transactional(readOnly = true)
    public List<WorkItem> list(String areaSlug, String workType) {
        validateType(workType);
        return workItemRepository.findByArea_SlugAndWorkTypeOrderByScheduledStartAscCreatedAtDesc(areaSlug, workType);
    }

    @Transactional(readOnly = true)
    public List<WorkItem> findDuplicates(String title, String location, UUID excludeId) {
        String wantedTitle = normalizeComparable(title);
        String wantedLocation = normalizeComparable(location);
        if (wantedTitle.isBlank()) return List.of();

        return workItemRepository.findAll().stream()
                .filter(item -> excludeId == null || !item.getId().equals(excludeId))
                .filter(item -> {
                    String otherTitle = normalizeComparable(item.getTitle());
                    String otherLocation = normalizeComparable(item.getLocation());
                    if (otherTitle.isBlank()) return false;
                    boolean exact = otherTitle.equals(wantedTitle);
                    boolean contains = Math.min(otherTitle.length(), wantedTitle.length()) >= 8
                            && (otherTitle.contains(wantedTitle) || wantedTitle.contains(otherTitle));
                    double overlap = tokenOverlap(wantedTitle, otherTitle);
                    boolean sameLocation = !wantedLocation.isBlank() && !otherLocation.isBlank()
                            && wantedLocation.equals(otherLocation);
                    return exact || overlap >= 0.82d || (sameLocation && (contains || overlap >= 0.50d));
                })
                .sorted((a, b) -> {
                    boolean aLoc = normalizeComparable(a.getLocation()).equals(wantedLocation);
                    boolean bLoc = normalizeComparable(b.getLocation()).equals(wantedLocation);
                    if (aLoc != bLoc) return aLoc ? -1 : 1;
                    return a.getTitle().compareToIgnoreCase(b.getTitle());
                })
                .limit(8)
                .toList();
    }

    @Transactional
    public WorkItem create(WorkItemController.WorkItemRequest request, String username) {
        validateRequest(request);
        Area area = findArea(request.areaSlug());
        WorkItem item = new WorkItem(area, request.workType(), request.title().trim());
        applyRequest(item, request);
        WorkItem saved = workItemRepository.saveAndFlush(item);
        activityService.record(
                saved,
                username,
                "CREATED",
                "Creó el registro «" + saved.getTitle() + "».",
                initialChanges(snapshot(saved)),
                null
        );
        return saved;
    }

    @Transactional
    public WorkItem update(UUID id, WorkItemController.WorkItemRequest request, String username) {
        validateRequest(request);
        WorkItem item = getRequired(id);

        if (!item.getArea().getSlug().equals(request.areaSlug())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No se puede cambiar el área de un registro existente.");
        }
        if (!item.getWorkType().equals(request.workType())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No se puede cambiar el tipo de un registro existente.");
        }

        AuditSnapshot before = snapshot(item);
        applyRequest(item, request);
        WorkItem saved = workItemRepository.save(item);
        List<WorkItemAuditChange> changes = compare(before, snapshot(saved));
        if (!changes.isEmpty()) {
            boolean statusChange = changes.stream().anyMatch(change -> "status".equals(change.field()));
            boolean onlyStatusEffects = changes.stream().allMatch(change -> STATUS_SIDE_EFFECT_FIELDS.contains(change.field()));
            String action = statusChange && onlyStatusEffects ? "STATUS_CHANGED" : "UPDATED";
            String details = statusChange && onlyStatusEffects
                    ? "Cambió el estado de «" + saved.getTitle() + "»."
                    : "Actualizó " + changes.size() + " campo(s) de «" + saved.getTitle() + "».";
            activityService.record(saved, username, action, details, changes, null);
        }
        return saved;
    }

    @Transactional
    public BulkStatusResult bulkUpdateStatus(
            List<UUID> ids,
            String areaSlug,
            String status,
            String username
    ) {
        validateBulkRequest(ids, areaSlug, status);
        List<UUID> distinctIds = ids.stream().distinct().toList();
        List<WorkItem> items = workItemRepository.findAllByIdInForUpdate(distinctIds);
        if (items.size() != distinctIds.size()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Uno o más registros seleccionados ya no existen.");
        }
        if (items.stream().anyMatch(item -> !areaSlug.equals(item.getArea().getSlug()))) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "La selección contiene registros de otra área.");
        }

        UUID operationId = UUID.randomUUID();
        List<WorkItem> updated = new ArrayList<>();
        for (WorkItem item : items) {
            AuditSnapshot before = snapshot(item);
            item.changeStatus(status);
            List<WorkItemAuditChange> changes = compare(before, snapshot(item));
            if (changes.isEmpty()) continue;
            WorkItem saved = workItemRepository.save(item);
            activityService.record(
                    saved,
                    username,
                    "BULK_STATUS_CHANGED",
                    "Cambió el estado mediante una operación masiva.",
                    changes,
                    operationId
            );
            updated.add(saved);
        }
        workItemRepository.flush();
        return new BulkStatusResult(operationId, updated);
    }

    @Transactional
    public void delete(UUID id, String username) {
        WorkItem item = getRequired(id);
        activityService.record(item, username, "DELETED", "Eliminó el registro «" + item.getTitle() + "».");
        workItemRepository.delete(item);
    }

    private WorkItem getRequired(UUID id) {
        return workItemRepository.findById(id).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Registro no encontrado.")
        );
    }

    private Area findArea(String slug) {
        return areaRepository.findAll().stream()
                .filter(area -> area.isActive() && area.getSlug().equals(slug))
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Área no encontrada."));
    }

    private void applyRequest(WorkItem item, WorkItemController.WorkItemRequest request) {
        BigDecimal progress = request.progressPercent() == null ? BigDecimal.ZERO : request.progressPercent();
        String location = clean(request.location());
        if ("mantencion-general".equals(request.areaSlug()) || "mantencion-reactiva".equals(request.areaSlug())) {
            progress = BigDecimal.ZERO;
            location = locationService.canonicalizeOrRegister(request.areaSlug(), location);
        }
        if ("mejoras".equals(request.areaSlug()) && "IMPROVEMENT".equals(request.workType())) {
            progress = BigDecimal.ZERO;
        }
        String assetName = clean(request.assetName());
        UUID assetId = request.assetId();
        if (assetId != null) {
            if (!"mantencion-maquinas".equals(request.areaSlug()) || !"MACHINE_MAINTENANCE".equals(request.workType())) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El vínculo con activos sólo corresponde a Mantenimiento de Máquinas.");
            }
            AssetLinkService.AssetReference asset = Objects.equals(item.getAssetId(), assetId)
                    ? assetLinkService.requireExisting(assetId)
                    : assetLinkService.requireActive(assetId);
            assetName = asset.name();
            location = asset.location();
        }

        item.update(
                request.title().trim(), clean(request.description()), location,
                clean(request.responsibleName()), request.priority(), request.status(),
                request.scheduledStart(), request.scheduledEnd(), progress,
                clean(request.notes()), clean(request.category()), assetName,
                clean(request.frequency()), clean(request.season()), clean(request.materials()),
                clean(request.supplierName()), request.estimatedCost(), request.actualCost(), clean(request.importedData())
        );
        item.setDisplayColor(DisplayColorValidator.normalize(request.displayColor()));
        item.setTextColor(DisplayColorValidator.normalize(request.textColor()));
        item.setPlanningMetadata(clean(request.phase()), validateYear(request.plannedYear()), validateMonth(request.plannedMonth()));
        item.setAssetReference(assetId, assetName);
    }

    private AuditSnapshot snapshot(WorkItem item) {
        return new AuditSnapshot(
                item.getTitle(), item.getDescription(), item.getLocation(), item.getResponsibleName(),
                item.getPriority(), item.getStatus(), text(item.getScheduledStart()), text(item.getScheduledEnd()),
                item.getDisplayColor(), item.getTextColor(), text(item.getCompletedDate()), text(item.getProgressPercent()),
                item.getNotes(), item.getCategory(), item.getAssetName(), text(item.getAssetId()), item.getFrequency(), item.getSeason(),
                item.getMaterials(), item.getSupplierName(), text(item.getEstimatedCost()), text(item.getActualCost()),
                item.getPhase(), text(item.getPlannedYear()), text(item.getPlannedMonth()), item.getImportedData()
        );
    }

    private List<WorkItemAuditChange> compare(AuditSnapshot before, AuditSnapshot after) {
        List<WorkItemAuditChange> changes = new ArrayList<>();
        addChange(changes, "title", "Nombre", before.title(), after.title(), "TEXT");
        addChange(changes, "description", "Descripción", before.description(), after.description(), "TEXT");
        addChange(changes, "location", "Ubicación / zona", before.location(), after.location(), "TEXT");
        addChange(changes, "responsibleName", "Responsable", before.responsibleName(), after.responsibleName(), "TEXT");
        addChange(changes, "priority", "Prioridad", before.priority(), after.priority(), "PRIORITY");
        addChange(changes, "status", "Estado", before.status(), after.status(), "STATUS");
        addChange(changes, "scheduledStart", "Fecha de inicio", before.scheduledStart(), after.scheduledStart(), "DATE");
        addChange(changes, "scheduledEnd", "Fecha de término", before.scheduledEnd(), after.scheduledEnd(), "DATE");
        addChange(changes, "displayColor", "Color de actividad", before.displayColor(), after.displayColor(), "COLOR");
        addChange(changes, "textColor", "Color del texto", before.textColor(), after.textColor(), "TEXT_COLOR");
        addChange(changes, "completedDate", "Fecha de finalización", before.completedDate(), after.completedDate(), "DATE");
        addChange(changes, "progressPercent", "Avance", before.progressPercent(), after.progressPercent(), "PERCENT");
        addChange(changes, "notes", "Observaciones", before.notes(), after.notes(), "TEXT");
        addChange(changes, "category", "Tipo / categoría", before.category(), after.category(), "TEXT");
        addChange(changes, "assetName", "Equipo", before.assetName(), after.assetName(), "TEXT");
        addChange(changes, "assetId", "Activo relacionado", before.assetId(), after.assetId(), "TEXT");
        addChange(changes, "frequency", "Periodicidad", before.frequency(), after.frequency(), "TEXT");
        addChange(changes, "season", "Temporada", before.season(), after.season(), "TEXT");
        addChange(changes, "materials", "Materiales", before.materials(), after.materials(), "TEXT");
        addChange(changes, "supplierName", "Proveedor", before.supplierName(), after.supplierName(), "TEXT");
        addChange(changes, "estimatedCost", "Presupuesto estimado", before.estimatedCost(), after.estimatedCost(), "MONEY");
        addChange(changes, "actualCost", "Costo real", before.actualCost(), after.actualCost(), "MONEY");
        addChange(changes, "phase", "Fase", before.phase(), after.phase(), "TEXT");
        addChange(changes, "plannedYear", "Año objetivo", before.plannedYear(), after.plannedYear(), "NUMBER");
        addChange(changes, "plannedMonth", "Mes objetivo", before.plannedMonth(), after.plannedMonth(), "MONTH");
        return changes;
    }

    private List<WorkItemAuditChange> initialChanges(AuditSnapshot current) {
        AuditSnapshot empty = new AuditSnapshot(
                null, null, null, null, null, null, null, null, null, null, null, null,
                null, null, null, null, null, null, null, null, null, null, null, null, null, null
        );
        return compare(empty, current).stream()
                .filter(change -> change.newValue() != null && !change.newValue().isBlank())
                .toList();
    }

    private void addChange(
            List<WorkItemAuditChange> changes,
            String field,
            String label,
            String before,
            String after,
            String valueType
    ) {
        String normalizedBefore = normalizeAuditValue(before);
        String normalizedAfter = normalizeAuditValue(after);
        if (!Objects.equals(normalizedBefore, normalizedAfter)) {
            changes.add(new WorkItemAuditChange(field, label, normalizedBefore, normalizedAfter, valueType));
        }
    }

    private String normalizeAuditValue(String value) {
        if (value == null) return null;
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    private String text(Object value) {
        return value == null ? null : value.toString();
    }

    private void validateBulkRequest(List<UUID> ids, String areaSlug, String status) {
        if (ids == null || ids.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Debes seleccionar al menos un registro.");
        }
        if (ids.size() > 500) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "La selección no puede superar 500 registros.");
        }
        if (ids.stream().anyMatch(Objects::isNull)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "La selección contiene un identificador inválido.");
        }
        if (areaSlug == null || areaSlug.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El área es obligatoria.");
        }
        if (!ALLOWED_STATUSES.contains(status)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Estado inválido.");
        }
    }

    private void validateRequest(WorkItemController.WorkItemRequest request) {
        if (request == null) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Solicitud inválida.");
        if (request.areaSlug() == null || request.areaSlug().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El área es obligatoria.");
        }
        if (request.title() == null || request.title().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El nombre del registro es obligatorio.");
        }
        validateType(request.workType());
        if (!ALLOWED_PRIORITIES.contains(request.priority())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Prioridad inválida.");
        }
        if (!ALLOWED_STATUSES.contains(request.status())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Estado inválido.");
        }
        if (request.scheduledStart() != null && request.scheduledEnd() != null
                && request.scheduledEnd().isBefore(request.scheduledStart())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "La fecha de término no puede ser anterior a la fecha de inicio.");
        }
        if (request.progressPercent() != null
                && (request.progressPercent().compareTo(BigDecimal.ZERO) < 0
                || request.progressPercent().compareTo(BigDecimal.valueOf(100)) > 0)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El avance debe estar entre 0 y 100.");
        }
        validateMoney(request.estimatedCost(), "El presupuesto estimado");
        validateMoney(request.actualCost(), "El costo real");
        validateYear(request.plannedYear());
        validateMonth(request.plannedMonth());
        DisplayColorValidator.normalize(request.displayColor());
        DisplayColorValidator.normalize(request.textColor());
    }

    private void validateType(String workType) {
        if (workType == null || !ALLOWED_TYPES.contains(workType)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Tipo de trabajo inválido.");
        }
    }

    private void validateMoney(BigDecimal value, String fieldName) {
        if (value != null && value.compareTo(BigDecimal.ZERO) < 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, fieldName + " no puede ser negativo.");
        }
    }

    private Integer validateYear(Integer value) {
        if (value == null) return null;
        if (value < 2000 || value > 2200) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Año objetivo inválido.");
        }
        return value;
    }

    private Integer validateMonth(Integer value) {
        if (value == null) return null;
        if (value < 1 || value > 12) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Mes objetivo inválido.");
        }
        return value;
    }

    private double tokenOverlap(String a, String b) {
        Set<String> left = new HashSet<>(List.of(a.split("\\s+")));
        Set<String> right = new HashSet<>(List.of(b.split("\\s+")));
        left.removeIf(token -> token.length() < 3);
        right.removeIf(token -> token.length() < 3);
        if (left.isEmpty() || right.isEmpty()) return 0d;
        long common = left.stream().filter(right::contains).count();
        return (double) common / Math.max(left.size(), right.size());
    }

    private String normalizeComparable(String value) {
        if (value == null) return "";
        String normalized = Normalizer.normalize(value, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .toLowerCase(java.util.Locale.ROOT)
                .replaceAll("[^a-z0-9]+", " ")
                .trim();
        return normalized.replaceAll("\\s+", " ");
    }

    private String clean(String value) {
        if (value == null) return null;
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    public record BulkStatusResult(UUID operationId, List<WorkItem> items) {
    }

    private record AuditSnapshot(
            String title,
            String description,
            String location,
            String responsibleName,
            String priority,
            String status,
            String scheduledStart,
            String scheduledEnd,
            String displayColor,
            String textColor,
            String completedDate,
            String progressPercent,
            String notes,
            String category,
            String assetName,
            String assetId,
            String frequency,
            String season,
            String materials,
            String supplierName,
            String estimatedCost,
            String actualCost,
            String phase,
            String plannedYear,
            String plannedMonth,
            String importedData
    ) {
    }
}
