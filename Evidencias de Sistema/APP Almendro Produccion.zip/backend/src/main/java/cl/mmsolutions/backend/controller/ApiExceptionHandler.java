package cl.mmsolutions.backend.controller;

import cl.mmsolutions.backend.invitation.InvitationService;
import cl.mmsolutions.backend.recovery.PasswordRecoveryService;
import cl.mmsolutions.backend.user.UserAdministrationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;

@RestControllerAdvice
public class ApiExceptionHandler {
    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<Map<String, String>> responseStatus(ResponseStatusException ex) {
        String message = ex.getReason() == null || ex.getReason().isBlank()
                ? "No fue posible completar la operación."
                : ex.getReason();
        return ResponseEntity.status(ex.getStatusCode()).body(Map.of("message", message));
    }

    @ExceptionHandler(UserAdministrationService.DuplicateUserException.class)
    public ResponseEntity<Map<String, String>> duplicate(RuntimeException ex) {
        return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("message", ex.getMessage()));
    }

    @ExceptionHandler(UserAdministrationService.UserNotFoundException.class)
    public ResponseEntity<Map<String, String>> notFound() {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("message", "Usuario no encontrado."));
    }

    @ExceptionHandler(UserAdministrationService.ProtectedUserException.class)
    public ResponseEntity<Map<String, String>> protectedUser(UserAdministrationService.ProtectedUserException ex) {
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(Map.of("message", ex.getMessage()));
    }

    @ExceptionHandler(UserAdministrationService.UserDeletionException.class)
    public ResponseEntity<Map<String, String>> userDeletion() {
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(Map.of("message", "No fue posible eliminar el usuario."));
    }

    @ExceptionHandler(InvitationService.InvitationException.class)
    public ResponseEntity<Map<String, String>> invitation(RuntimeException ex) {
        return ResponseEntity.badRequest().body(Map.of("message", ex.getMessage()));
    }

    @ExceptionHandler(PasswordRecoveryService.RecoveryException.class)
    public ResponseEntity<Map<String, String>> recovery(RuntimeException ex) {
        return ResponseEntity.badRequest().body(Map.of("message", ex.getMessage()));
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, String>> illegalArgument(IllegalArgumentException ex) {
        return ResponseEntity.badRequest().body(Map.of("message", ex.getMessage()));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> invalid(MethodArgumentNotValidException ex) {
        return ResponseEntity.badRequest().body(Map.of("message", "Revisa los datos ingresados."));
    }
}
