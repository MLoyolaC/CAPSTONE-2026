package cl.mmsolutions.backend.controller;

import cl.mmsolutions.backend.security.PermissionService;
import cl.mmsolutions.backend.user.AppUser;
import cl.mmsolutions.backend.user.AppUserRepository;
import cl.mmsolutions.backend.settings.AccountSettingsService;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Set;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AppUserRepository users;
    private final PermissionService permissions;
    private final AccountSettingsService accountSettings;

    public AuthController(AppUserRepository users, PermissionService permissions,
                          AccountSettingsService accountSettings) {
        this.users = users;
        this.permissions = permissions;
        this.accountSettings = accountSettings;
    }

    @GetMapping("/csrf")
    public void csrf(CsrfToken csrfToken) {
        csrfToken.getToken();
    }

    @GetMapping("/me")
    public CurrentUserResponse currentUser(Authentication authentication) {

        AppUser user = users.findByUsernameIgnoreCase(authentication.getName())
                .filter(AppUser::isEnabled)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED));
        AccountSettingsService.AvatarState avatar = accountSettings.avatarState(user.getUsername());
        return new CurrentUserResponse(user.getId(), user.getUsername(), user.getFullName(), user.getEmail(),
                user.getRole().name(),
                user.getAccountStatus().name(), permissions.permissionsFor(user.getUsername()),
                avatar.preset(), avatar.customImage());
    }

    public record CurrentUserResponse(Long id, String username, String fullName, String email, String role,
                                      String status, Set<String> permissions, String avatarPreset,
                                      boolean customAvatar) {}
}
