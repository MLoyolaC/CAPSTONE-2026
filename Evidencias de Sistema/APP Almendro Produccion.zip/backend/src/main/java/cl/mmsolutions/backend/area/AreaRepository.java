package cl.mmsolutions.backend.area;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface AreaRepository
        extends JpaRepository<Area, Long> {

    @Query(
        value = """
            SELECT
                a.id AS id,
                a.name AS name,
                a.slug AS slug,
                a.description AS description,
                a.sort_order AS sortOrder,
                COUNT(d.id) AS documentCount
            FROM area a
            LEFT JOIN document d
                ON d.area_id = a.id
                AND d.status = 'ACTIVE'
            WHERE a.active = TRUE
            GROUP BY
                a.id,
                a.name,
                a.slug,
                a.description,
                a.sort_order
            ORDER BY a.sort_order ASC
            """,
        nativeQuery = true
    )
    List<AreaSummaryProjection>
    findAllActiveWithDocumentCount();

    interface AreaSummaryProjection {

        Long getId();

        String getName();

        String getSlug();

        String getDescription();

        Short getSortOrder();

        Long getDocumentCount();
    }
}