package cl.mmsolutions.backend.remodeling;

import cl.mmsolutions.backend.area.Area;
import cl.mmsolutions.backend.area.AreaRepository;
import cl.mmsolutions.backend.workitem.WorkItem;
import cl.mmsolutions.backend.importing.ExcelDateSupport;
import cl.mmsolutions.backend.workitem.WorkItemActivityService;
import cl.mmsolutions.backend.workitem.WorkItemRepository;
import cl.mmsolutions.backend.workitem.WorkItemService;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import tools.jackson.databind.json.JsonMapper;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.Normalizer;
import java.time.LocalDate;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

@Service
public class RemodelingImportService {
    private static final Pattern ROOM = Pattern.compile("(?<!\\d)(\\d{3})(?:\\s*(?:y|e|-|/)\\s*(\\d{3}))?(?!\\d)", Pattern.CASE_INSENSITIVE);
    private final AreaRepository areaRepository;
    private final WorkItemRepository repository;
    private final WorkItemActivityService activityService;
    private final WorkItemService workItemService;
    private final JsonMapper json = JsonMapper.builder().build();

    public RemodelingImportService(AreaRepository areaRepository, WorkItemRepository repository,
                                   WorkItemActivityService activityService, WorkItemService workItemService) {
        this.areaRepository = areaRepository;
        this.repository = repository;
        this.activityService = activityService;
        this.workItemService = workItemService;
    }

    public AnalysisResult analyze(MultipartFile upload) {
        ParsedBundle parsed = parse(upload);
        List<ProjectPreview> previews = parsed.projects.values().stream()
                .map(project -> preview(project, false))
                .sorted(Comparator.comparing(ProjectPreview::location, Comparator.nullsLast(String.CASE_INSENSITIVE_ORDER))
                        .thenComparing(ProjectPreview::title, String.CASE_INSENSITIVE_ORDER))
                .toList();
        int tasks = parsed.projects.values().stream().mapToInt(p -> p.tasks.size()).sum();
        int lines = parsed.projects.values().stream().mapToInt(p -> p.lines.size()).sum();
        int supportRecords = parsed.supports.values().stream().mapToInt(p -> p.rows.size()).sum();
        int supportSheets = parsed.supports.values().stream().mapToInt(p -> p.sheetNames.size()).sum();
        return new AnalysisResult(clean(upload.getOriginalFilename()), previews.size(), tasks, lines, supportRecords, supportSheets,
                parsed.supportFiles, parsed.crossAreaFiles, previews, parsed.warnings);
    }

    @Transactional
    public ImportResult commit(MultipartFile upload, boolean forceDuplicates, String username) {
        ParsedBundle parsed = parse(upload);
        Area area = areaRepository.findAll().stream()
                .filter(a -> a.isActive() && "remodelacion".equals(a.getSlug())).findFirst()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Área Remodelación no encontrada."));

        List<ProjectAggregate> ordered = parsed.projects.values().stream()
                .sorted(Comparator.comparing(p -> p.location == null ? "" : p.location))
                .toList();
        List<ProjectPreview> conflicts = ordered.stream().map(p -> preview(p, true))
                .filter(p -> !p.duplicates().isEmpty()).toList();
        if (!forceDuplicates && !conflicts.isEmpty()) {
            String names = conflicts.stream().limit(4).map(ProjectPreview::title).reduce((a,b) -> a + ", " + b).orElse("");
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Se detectaron proyectos similares ya registrados: " + names + ". Revisa la advertencia antes de importar de todas formas.");
        }

        int projectsCreated = 0, tasksCreated = 0, supportCreated = 0, supportUpdated = 0, skipped = 0;
        String uploadName = clean(upload.getOriginalFilename());
        for (ProjectAggregate project : ordered) {
            String projectSourceKey = "remodeling-project:" + normalize(uploadName) + ":" + project.key;
            WorkItem saved = findExistingProjectForGantt(project);

            if (saved != null) {
                saved = mergeExistingProject(saved, project, uploadName, username);
            }

            if (saved == null) {
                if (repository.existsBySourceKey(projectSourceKey)) { skipped++; continue; }

                Map<String,Object> meta = new LinkedHashMap<>();
                meta.put("sourceKind", "REMODELING_PROJECT");
                meta.put("projectKey", project.key);
                meta.put("sourceFiles", project.sources);
                meta.put("budgetLines", project.lines);
                meta.put("ganttTaskCount", project.tasks.size());
                meta.put("supportNote", "Datos consolidados desde presupuesto/gastos/Gantt del proyecto.");

                WorkItem item = new WorkItem(area, "REMODELING", project.title);
                item.update(project.title,
                        "Proyecto de remodelación consolidado desde las planillas del Hotel El Almendro.",
                        project.location, project.responsible, "NORMAL", project.status(),
                        project.startDate(), project.endDate(), project.progress(),
                        null, project.category, null, null, null,
                        project.materialSummary(), project.primarySupplier(), project.estimatedCost(), project.actualCost(), toJson(meta));
                item.setPlanningMetadata(project.stage(), null, null);
                item.setImportSource(uploadName, project.sources.isEmpty() ? null : project.sources.getFirst(), null, projectSourceKey);
                saved = repository.saveAndFlush(item);
                activityService.record(saved, username, "IMPORTED",
                        "Importó la remodelación «" + saved.getTitle() + "» desde " + uploadName + ".");
                projectsCreated++;
            }

            for (TaskData task : project.tasks.values()) {
                String taskSourceKey = "remodeling-gantt:" + normalize(uploadName) + ":" + project.key + ":" + task.key();
                if (repository.existsBySourceKey(taskSourceKey)) { skipped++; continue; }

                Map<String,Object> taskMeta = new LinkedHashMap<>();
                taskMeta.put("sourceKind", "REMODELING_GANTT");
                taskMeta.put("parentProjectKey", project.key);
                taskMeta.put("parentProjectId", saved.getId().toString());
                taskMeta.put("sourceFile", task.sourceFile());
                taskMeta.put("sourceGroup", ganttSourceLabel(task.sourceFile(), project.location));
                taskMeta.put("sourceSheet", task.sourceSheet());
                taskMeta.put("sourceRow", task.sourceRow());

                WorkItem existingTask = findExistingGanttTask(task, project.location);
                if (existingTask != null) {
                    boolean improvesDates = task.start() != null && (existingTask.getScheduledStart() == null
                            || !task.start().equals(existingTask.getScheduledStart())
                            || !Objects.equals(task.end(), existingTask.getScheduledEnd()));
                    boolean improvesProgress = task.progress() != null
                            && task.progress().compareTo(existingTask.getProgressPercent() == null ? BigDecimal.ZERO : existingTask.getProgressPercent()) != 0;
                    if (!improvesDates && !improvesProgress) { skipped++; continue; }

                    existingTask.update(task.title(), existingTask.getDescription(), project.location, task.responsible(),
                            "NORMAL", task.status(), task.start(), task.end(), task.progress(), task.notes(),
                            project.category, null, null, null, null, null, null, null, toJson(taskMeta));
                    existingTask.setPlanningMetadata(task.phase(), null, null);
                    existingTask.setImportSource(uploadName, task.sourceSheet(), task.sourceRow(), taskSourceKey);
                    WorkItem refreshed = repository.saveAndFlush(existingTask);
                    activityService.record(refreshed, username, "UPDATED",
                            "Actualizó fechas/progreso del hito o tarea «" + refreshed.getTitle() + "» desde " + uploadName + ".");
                    tasksCreated++;
                    continue;
                }

                WorkItem gantt = new WorkItem(area, "REMODELING_GANTT", task.title());
                gantt.update(task.title(), null, project.location, task.responsible(), "NORMAL", task.status(),
                        task.start(), task.end(), task.progress(), task.notes(), project.category, null, null, null,
                        null, null, null, null, toJson(taskMeta));
                gantt.setPlanningMetadata(task.phase(), null, null);
                gantt.setImportSource(uploadName, task.sourceSheet(), task.sourceRow(), taskSourceKey);
                WorkItem ganttSaved = repository.saveAndFlush(gantt);
                activityService.record(ganttSaved, username, "IMPORTED",
                        "Importó el hito/tarea «" + ganttSaved.getTitle() + "» para «" + project.title + "».");
                tasksCreated++;
            }
        }

        for (SupportAggregate support : parsed.supports.values()) {
            String supportSourceKey = "remodeling-support:" + normalize(uploadName) + ":" + support.key;

            Map<String,Object> meta = new LinkedHashMap<>();
            meta.put("sourceKind", "REMODELING_SUPPORT");
            meta.put("supportType", support.supportType);
            meta.put("sourceFile", support.sourceFile);
            meta.put("sheetNames", new ArrayList<>(support.sheetNames));
            meta.put("rows", support.rows);
            meta.put("sheetSummaries", support.sheetSummaries);
            meta.put("vatRate", new BigDecimal("0.19"));

            Optional<WorkItem> existingSupport = repository.findBySourceKey(supportSourceKey);
            if (existingSupport.isPresent()) {
                WorkItem supportItem = existingSupport.get();
                supportItem.update(support.title, support.description, support.location, null, "NORMAL", "COMPLETED",
                        null, null, BigDecimal.ZERO,
                        "Información de apoyo actualizada desde las planillas de Remodelación.",
                        support.supportType, null, null, null, null, null, null, null, toJson(meta));
                supportItem.setPlanningMetadata("Apoyo", null, null);
                supportItem.setImportSource(uploadName, support.sourceFile, null, supportSourceKey);
                WorkItem refreshedSupport = repository.saveAndFlush(supportItem);
                activityService.record(refreshedSupport, username, "UPDATED",
                        "Actualizó información de apoyo «" + refreshedSupport.getTitle() + "» desde " + uploadName + ".");
                supportUpdated++;
                continue;
            }

            WorkItem supportItem = new WorkItem(area, "REMODELING_SUPPORT", support.title);
            supportItem.update(support.title,
                    support.description,
                    support.location, null, "NORMAL", "COMPLETED",
                    null, null, BigDecimal.ZERO,
                    "Información de apoyo importada desde las planillas de Remodelación.",
                    support.supportType, null, null, null,
                    null, null, null, null, toJson(meta));
            supportItem.setPlanningMetadata("Apoyo", null, null);
            supportItem.setImportSource(uploadName, support.sourceFile, null, supportSourceKey);
            WorkItem savedSupport = repository.saveAndFlush(supportItem);
            activityService.record(savedSupport, username, "IMPORTED",
                    "Importó información de apoyo «" + savedSupport.getTitle() + "» desde " + uploadName + ".");
            supportCreated++;
        }
        return new ImportResult(projectsCreated, tasksCreated, supportCreated, supportUpdated, skipped, parsed.supportFiles, parsed.crossAreaFiles);
    }


    private WorkItem findExistingProjectForGantt(ProjectAggregate project) {
        return repository.findByArea_SlugAndWorkTypeOrderByScheduledStartAscCreatedAtDesc("remodelacion", "REMODELING").stream()
                .filter(item -> {
                    String importedKey = importedProjectKey(item);
                    if (!blank(importedKey) && importedKey.equals(project.key)) return true;
                    boolean sameLocation = !blank(project.location) && normalize(item.getLocation()).equals(normalize(project.location));
                    boolean sameTitle = normalize(item.getTitle()).equals(normalize(project.title));
                    return sameLocation && (sameTitle || project.key.startsWith("room-") || project.key.startsWith("rooms-"));
                })
                .findFirst().orElse(null);
    }

    @SuppressWarnings("unchecked")
    private WorkItem mergeExistingProject(WorkItem existing, ProjectAggregate incoming, String uploadName, String username) {
        Map<String,Object> meta = importedMeta(existing);
        List<String> sourceFiles = new ArrayList<>();
        Object currentSources = meta.get("sourceFiles");
        if (currentSources instanceof Collection<?> values) for (Object value : values) if (value != null) sourceFiles.add(value.toString());
        for (String source : incoming.sources) if (!sourceFiles.contains(source)) sourceFiles.add(source);

        List<Map<String,Object>> combinedLines = new ArrayList<>();
        Object currentLines = meta.get("budgetLines");
        if (currentLines instanceof Collection<?> values) {
            for (Object value : values) if (value instanceof Map<?,?> map) {
                Map<String,Object> copy = new LinkedHashMap<>();
                map.forEach((k,v) -> copy.put(String.valueOf(k), v));
                combinedLines.add(copy);
            }
        }
        Set<String> lineKeys = new LinkedHashSet<>();
        for (Map<String,Object> line : combinedLines) lineKeys.add(budgetLineKey(line));
        for (Map<String,Object> line : incoming.lines) if (lineKeys.add(budgetLineKey(line))) combinedLines.add(new LinkedHashMap<>(line));

        meta.put("sourceKind", "REMODELING_PROJECT");
        meta.put("projectKey", incoming.key);
        meta.put("sourceFiles", sourceFiles);
        meta.put("budgetLines", combinedLines);
        int previousGantt = number(meta.get("ganttTaskCount")).intValue();
        meta.put("ganttTaskCount", Math.max(previousGantt, incoming.tasks.size()));
        meta.put("supportNote", "Datos consolidados desde presupuesto/gastos/Gantt del proyecto.");

        BigDecimal lineEstimated = totalLines(combinedLines, "ESTIMATED");
        BigDecimal lineActual = totalLines(combinedLines, "ACTUAL");
        BigDecimal estimated = lineEstimated.signum() > 0 ? lineEstimated : existing.getEstimatedCost();
        BigDecimal actual = lineActual.signum() > 0 ? lineActual : existing.getActualCost();
        LocalDate start = minDate(existing.getScheduledStart(), incoming.startDate());
        LocalDate end = maxDate(existing.getScheduledEnd(), incoming.endDate());
        BigDecimal progress = incoming.tasks.isEmpty() ? existing.getProgressPercent() : incoming.progress();
        String status = incoming.tasks.isEmpty() ? existing.getStatus() : incoming.status();
        String category = blank(existing.getCategory()) ? incoming.category : existing.getCategory();
        String materials = blank(existing.getMaterials()) ? incoming.materialSummary() : existing.getMaterials();
        String supplier = blank(existing.getSupplierName()) ? incoming.primarySupplier() : existing.getSupplierName();

        existing.update(existing.getTitle(), existing.getDescription(), blank(existing.getLocation()) ? incoming.location : existing.getLocation(),
                blank(existing.getResponsibleName()) ? incoming.responsible : existing.getResponsibleName(), existing.getPriority(), status,
                start, end, progress, existing.getNotes(), category, existing.getAssetName(), existing.getFrequency(), existing.getSeason(),
                materials, supplier, estimated, actual, toJson(meta));
        if (!incoming.tasks.isEmpty()) existing.setPlanningMetadata(incoming.stage(), existing.getPlannedYear(), existing.getPlannedMonth());
        WorkItem refreshed = repository.saveAndFlush(existing);
        activityService.record(refreshed, username, "UPDATED",
                "Consolidó información adicional de la remodelación «" + refreshed.getTitle() + "» desde " + uploadName + ".");
        return refreshed;
    }

    private Map<String,Object> importedMeta(WorkItem item) {
        if (blank(item.getImportedData())) return new LinkedHashMap<>();
        try {
            @SuppressWarnings("unchecked") Map<String,Object> value = json.readValue(item.getImportedData(), Map.class);
            return value == null ? new LinkedHashMap<>() : new LinkedHashMap<>(value);
        } catch (Exception ignored) { return new LinkedHashMap<>(); }
    }

    private String importedProjectKey(WorkItem item) {
        Object key = importedMeta(item).get("projectKey");
        return key == null ? null : key.toString();
    }

    private String budgetLineKey(Map<String,Object> line) {
        return String.join("|", Objects.toString(line.get("kind"), ""), Objects.toString(line.get("sourceFile"), ""),
                Objects.toString(line.get("sourceSheet"), ""), Objects.toString(line.get("sourceRow"), ""),
                Objects.toString(line.get("product"), ""), Objects.toString(line.get("total"), ""));
    }

    private BigDecimal totalLines(List<Map<String,Object>> lines, String kind) {
        BigDecimal total = BigDecimal.ZERO;
        for (Map<String,Object> line : lines) {
            if (!kind.equals(Objects.toString(line.get("kind"), ""))) continue;
            try { total = total.add(new BigDecimal(Objects.toString(line.get("total"), "0"))); } catch (Exception ignored) {}
        }
        return total.setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal number(Object value) {
        try { return new BigDecimal(Objects.toString(value, "0")); } catch (Exception ignored) { return BigDecimal.ZERO; }
    }

    private LocalDate minDate(LocalDate a, LocalDate b) { if (a == null) return b; if (b == null) return a; return a.isBefore(b) ? a : b; }
    private LocalDate maxDate(LocalDate a, LocalDate b) { if (a == null) return b; if (b == null) return a; return a.isAfter(b) ? a : b; }

    private WorkItem findExistingGanttTask(TaskData task, String location) {
        return workItemService.findDuplicates(task.title(), location, null).stream()
                .filter(item -> "remodelacion".equals(item.getArea().getSlug()))
                .filter(item -> "REMODELING_GANTT".equals(item.getWorkType()))
                .filter(item -> normalize(item.getTitle()).equals(normalize(task.title())))
                .filter(item -> blank(location) || normalize(item.getLocation()).equals(normalize(location)))
                .findFirst().orElse(null);
    }

    private String ganttSourceLabel(String sourceFile, String fallbackLocation) {
        String n = normalize(sourceFile);
        if (n.contains("piscina")) return "Piscina";
        if (n.contains("jardin")) return "Jardín";
        if (n.contains("quincho") || n.contains("terraza")) return "Quincho / Terraza";
        if (n.contains("cocina")) return "Cocina";
        if (n.contains("comedor")) return "Comedor";
        if (n.contains("pasillo")) return "Pasillos";
        if (n.contains("oficina electrica")) return "Oficina eléctrica";
        if (n.contains("oficina")) return "Oficina";
        if (n.contains("bodega")) return "Bodega";
        return blank(fallbackLocation) ? prettyFilename(sourceFile) : fallbackLocation;
    }

    private ProjectPreview preview(ProjectAggregate project, boolean refreshDuplicates) {
        List<DuplicateRef> duplicates = workItemService.findDuplicates(project.title, project.location, null).stream()
                .limit(4)
                .map(item -> new DuplicateRef(item.getId().toString(), item.getTitle(), item.getArea().getSlug(),
                        item.getArea().getName(), item.getLocation()))
                .toList();
        return new ProjectPreview(project.key, project.title, project.location, project.category,
                project.estimatedCost(), project.actualCost(), project.lines.size(), project.tasks.size(),
                List.copyOf(project.sources), duplicates);
    }

    private ParsedBundle parse(MultipartFile upload) {
        validate(upload);
        ParsedBundle bundle = new ParsedBundle();
        try {
            String name = Optional.ofNullable(upload.getOriginalFilename()).orElse("archivo");
            if (normalize(name).endsWith("zip")) {
                try (ZipInputStream zin = new ZipInputStream(upload.getInputStream())) {
                    ZipEntry entry;
                    while ((entry = zin.getNextEntry()) != null) {
                        if (entry.isDirectory() || !entry.getName().toLowerCase(Locale.ROOT).endsWith(".xlsx")) continue;
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        zin.transferTo(out);
                        parseWorkbook(entry.getName(), out.toByteArray(), bundle);
                    }
                }
            } else {
                parseWorkbook(name, upload.getBytes(), bundle);
            }
        } catch (IOException ex) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No fue posible leer el archivo de Remodelación.");
        }
        if (bundle.projects.isEmpty() && bundle.supports.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No se detectaron proyectos ni información de apoyo reconocible en el archivo.");
        }
        return bundle;
    }

    private void parseWorkbook(String sourcePath, byte[] bytes, ParsedBundle bundle) {
        String fileNorm = normalize(sourcePath);
        if (fileNorm.contains("insumos jardineria")) {
            bundle.crossAreaFiles.add(sourcePath + " → Jardinería"); return;
        }
        if (fileNorm.contains("proveedores remodelaciones")) {
            bundle.supportFiles.add(sourcePath + " → Directorio de proveedores");
            parseSupportWorkbook(sourcePath, bytes, bundle, "PROVIDERS", "Directorio de proveedores", "Proveedores", "Directorio de proveedores y productos utilizados como apoyo para Remodelación.");
            return;
        }
        if (fileNorm.contains("en bodega")) {
            bundle.supportFiles.add(sourcePath + " → Bodega / compras e insumos (3 hojas)");
            parseInventoryWorkbook(sourcePath, bytes, bundle);
            return;
        }
        try (Workbook workbook = WorkbookFactory.create(new ByteArrayInputStream(bytes))) {
            DataFormatter formatter = new DataFormatter(new Locale("es", "CL"));
            FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
            for (int i=0; i<workbook.getNumberOfSheets(); i++) {
                Sheet sheet = workbook.getSheetAt(i);
                if (normalize(sheet.getSheetName()).contains("acerca de")) continue;
                String title = findProjectTitle(sheet, formatter, evaluator, sourcePath);
                if (title == null) continue;
                if (shouldSkipTemplateSheet(title, sourcePath)) continue;
                ProjectAggregate project = bundle.projects.computeIfAbsent(projectKey(title, sourcePath), key ->
                        new ProjectAggregate(key, displayProjectTitle(title, sourcePath), inferLocation(title, sourcePath), inferCategory(title, sourcePath)));
                project.sources.add(sourcePath + " · " + sheet.getSheetName());
                boolean parsedGantt = parseGantt(sheet, formatter, evaluator, sourcePath, project);
                boolean parsedCosts = parseCosts(sheet, formatter, evaluator, sourcePath, project);
                boolean parsedMilestones = parseMilestones(sheet, formatter, evaluator, sourcePath, project);
                if (!parsedGantt && !parsedCosts && !parsedMilestones && hasMeaningfulRows(sheet, formatter, evaluator)) {
                    bundle.warnings.add("Se detectó contenido no tabular en «" + sourcePath + " · " + sheet.getSheetName() + "»; se conservó como fuente del proyecto, pero no se convirtió en filas automáticas.");
                }
            }
        } catch (Exception ex) {
            bundle.warnings.add("No se pudo interpretar «" + sourcePath + "»: " + safe(ex.getMessage()));
        }
    }

    private boolean parseGantt(Sheet sheet, DataFormatter f, FormulaEvaluator e, String sourcePath, ProjectAggregate project) {
        for (Row row : sheet) {
            Map<Integer,String> headers = rowMap(row, f, e);

            // Las plantillas Vertex42 incluyen una columna A oculta con instrucciones extensas.
            // Ese texto contiene palabras como "inicio", "finalización" y "tarea", por lo que
            // buscar solo por coincidencia parcial puede confundir A con los encabezados reales.
            Integer taskCol = findHeader(headers, "tarea");
            Integer startCol = findHeader(headers, "inicio");
            Integer endCol = findHeader(headers, "fin");
            if (taskCol == null || startCol == null || endCol == null) continue;

            Integer ownerCol = findHeader(headers, "asignado a");
            if (ownerCol == null) ownerCol = findHeader(headers, "asignado");
            if (ownerCol == null) ownerCol = findHeader(headers, "responsable");
            Integer progressCol = findHeader(headers, "progreso");

            boolean vertex42 = isVertex42Gantt(sheet, row.getRowNum(), taskCol, startCol, endCol, f, e);
            String phase = "Planificación";
            for (int r=row.getRowNum()+1; r<=sheet.getLastRowNum(); r++) {
                Row data = sheet.getRow(r); if (data == null) continue;
                String task = text(data.getCell(taskCol), f, e);
                if (blank(task)) continue;

                LocalDate start = vertex42
                        ? vertex42Date(sheet, data.getCell(startCol), f, e, new HashSet<>())
                        : iso(date(data.getCell(startCol), f, e));
                LocalDate end = vertex42
                        ? vertex42Date(sheet, data.getCell(endCol), f, e, new HashSet<>())
                        : iso(date(data.getCell(endCol), f, e));

                String owner = ownerCol == null ? null : text(data.getCell(ownerCol), f, e);
                if (start == null && end == null && owner == null && task.length() < 80) {
                    if (!normalize(task).contains("inserta nuevas filas")) phase = task;
                    continue;
                }
                if (normalize(task).matches("tarea \\d+")) continue;

                if (start == null && end != null) start = end;
                if (end == null && start != null) end = start;
                if (start != null && end != null && end.isBefore(start)) {
                    LocalDate tmp = start; start = end; end = tmp;
                }

                BigDecimal progress = parseProgress(progressCol == null ? null : text(data.getCell(progressCol), f, e));
                String status = progress.compareTo(BigDecimal.valueOf(100)) >= 0 ? "COMPLETED" :
                        progress.compareTo(BigDecimal.ZERO) > 0 ? "IN_PROGRESS" : "PLANNED";
                TaskData taskData = new TaskData(taskKey(task,start,end,owner), task, owner, phase,
                        start, end, progress, status, null, sourcePath, sheet.getSheetName(), r+1);
                project.tasks.putIfAbsent(taskData.key(), taskData);
                project.responsible = project.responsible == null ? owner : project.responsible;
            }
            return true;
        }
        return false;
    }

    private boolean parseMilestones(Sheet sheet, DataFormatter f, FormulaEvaluator e, String sourcePath, ProjectAggregate project) {
        for (Row row : sheet) {
            Map<Integer,String> headers = rowMap(row,f,e);
            Integer doneCol=findContains(headers,"se hizo"), dateCol=findContains(headers,"fecha"), milestoneCol=findContains(headers,"hito");
            if (doneCol==null || dateCol==null || milestoneCol==null) continue;
            Integer who=findContains(headers,"quien");
            for(int r=row.getRowNum()+1;r<=sheet.getLastRowNum();r++){
                Row data=sheet.getRow(r); if(data==null) continue;
                String done=text(data.getCell(doneCol),f,e), milestone=text(data.getCell(milestoneCol),f,e);
                if(blank(done)&&blank(milestone)) continue;
                String title=blank(milestone)?done:milestone;
                LocalDate when=iso(date(data.getCell(dateCol),f,e));
                String owner=who==null?null:text(data.getCell(who),f,e);
                TaskData td=new TaskData(taskKey(title,when,when,owner),title,owner,"Hito",when,when,
                        BigDecimal.valueOf(100),"COMPLETED",done,sourcePath,sheet.getSheetName(),r+1);
                project.tasks.putIfAbsent(td.key(),td);
            }
            return true;
        }
        return false;
    }

    private boolean parseCosts(Sheet sheet, DataFormatter f, FormulaEvaluator e, String sourcePath, ProjectAggregate project) {
        for (Row row : sheet) {
            Map<Integer,String> headers=rowMap(row,f,e);
            Integer product=findContains(headers,"tipo de producto");
            if(product==null) product=findContains(headers,"producto");
            Integer value=findContains(headers,"valor con iva");
            Integer total=findContains(headers,"valor total");
            if(product==null || (value==null && total==null)) continue;
            Integer category=findContains(headers,"categoria");
            Integer provider=findContains(headers,"proveedor");
            Integer qty=findContains(headers,"mt 2");
            if(qty==null) qty=findContains(headers,"uni");
            Integer dateCol=findContains(headers,"fecha");
            boolean estimated=isEstimatedSource(sourcePath,sheet.getSheetName());
            String currentCategory=null;
            for(int r=row.getRowNum()+1;r<=sheet.getLastRowNum();r++){
                Row data=sheet.getRow(r); if(data==null) continue;
                String cat=category==null?null:text(data.getCell(category),f,e);
                if(!blank(cat)) currentCategory=cat;
                String productName=text(data.getCell(product),f,e);
                if(blank(productName)) continue;
                BigDecimal lineTotal=money(total==null?null:data.getCell(total),f,e);
                BigDecimal unitValue=money(value==null?null:data.getCell(value),f,e);
                if(lineTotal==null || lineTotal.signum()==0) lineTotal=unitValue;
                if(lineTotal==null || lineTotal.signum()<0) continue;
                String providerName=provider==null?null:text(data.getCell(provider),f,e);
                String dateValue=dateCol==null?null:date(data.getCell(dateCol),f,e);
                String quantity=qty==null?null:text(data.getCell(qty),f,e);
                Map<String,Object> line=new LinkedHashMap<>();
                line.put("kind", estimated?"ESTIMATED":"ACTUAL"); line.put("date",dateValue);
                line.put("category",currentCategory); line.put("provider",providerName); line.put("product",productName);
                line.put("quantity",quantity); line.put("unitValue",unitValue); line.put("total",lineTotal);
                line.put("sourceFile",sourcePath); line.put("sourceSheet",sheet.getSheetName()); line.put("sourceRow",r+1);
                project.lines.add(line);
                if(estimated) project.estimated=project.estimated.add(lineTotal); else project.actual=project.actual.add(lineTotal);
                if(project.primarySupplier==null && !blank(providerName)) project.primarySupplier=providerName;
                if(project.firstMaterial==null) project.firstMaterial=productName;
                LocalDate purchase=iso(dateValue);
                if(purchase!=null){
                    if(project.costStart==null||purchase.isBefore(project.costStart))project.costStart=purchase;
                    if(project.costEnd==null||purchase.isAfter(project.costEnd))project.costEnd=purchase;
                }
            }
            return true;
        }
        return false;
    }


    private void parseInventoryWorkbook(String sourcePath, byte[] bytes, ParsedBundle bundle) {
        SupportAggregate support = bundle.supports.computeIfAbsent(
                normalize("INVENTORY " + sourcePath),
                key -> new SupportAggregate(key, "EN BODEGA", "INVENTORY", sourcePath, "Bodega",
                        "Compras, insumos y materiales registrados en las hojas GENERAL, MOTO y LED de decoración e iluminación.")
        );
        try (Workbook workbook = WorkbookFactory.create(new ByteArrayInputStream(bytes))) {
            DataFormatter formatter = new DataFormatter(new Locale("es", "CL"));
            FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
            for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
                Sheet sheet = workbook.getSheetAt(i);
                if (normalize(sheet.getSheetName()).contains("acerca de")) continue;

                Row header = null;
                for (Row row : sheet) {
                    Map<Integer,String> headers = rowMap(row, formatter, evaluator);
                    Integer provider = findHeader(headers, "proveedor");
                    Integer product = findHeader(headers, "tipo de producto");
                    Integer total = findHeader(headers, "valor total");
                    if (provider != null && product != null && total != null) { header = row; break; }
                }
                if (header == null) {
                    bundle.warnings.add("La hoja «" + sheet.getSheetName() + "» de «" + sourcePath + "» no tiene una tabla de bodega reconocible.");
                    continue;
                }

                Map<Integer,String> headers = rowMap(header, formatter, evaluator);
                Integer providerCol = findHeader(headers, "proveedor");
                Integer productCol = findHeader(headers, "tipo de producto");
                Integer qtyCol = findHeader(headers, "mt 2 o uni");
                if (qtyCol == null) qtyCol = findContains(headers, "mt 2");
                if (qtyCol == null) qtyCol = findContains(headers, "uni");
                Integer unitCol = findHeader(headers, "valor con iva");
                Integer totalCol = findHeader(headers, "valor total");
                int firstCol = 0;

                String sheetTitle = inventorySheetTitle(sheet, formatter, evaluator);
                support.sheetNames.add(sheetTitle);
                Map<String,Object> vatSummary = inventoryVatSummary(sheet, formatter, evaluator);
                if (!vatSummary.isEmpty()) support.sheetSummaries.put(sheet.getSheetName(), vatSummary);
                String currentCategory = null;
                boolean datedSection = false;

                for (int r = header.getRowNum() + 1; r <= sheet.getLastRowNum(); r++) {
                    Row data = sheet.getRow(r);
                    if (data == null) continue;

                    String provider = text(data.getCell(providerCol), formatter, evaluator);
                    String product = text(data.getCell(productCol), formatter, evaluator);
                    if (blank(provider) && blank(product)) continue;

                    LocalDate purchaseDate = iso(date(data.getCell(firstCol), formatter, evaluator));
                    String firstText = text(data.getCell(firstCol), formatter, evaluator);
                    if (purchaseDate != null) {
                        datedSection = true;
                        currentCategory = null;
                    } else if (!datedSection && !blank(firstText)) {
                        currentCategory = firstText;
                    }

                    BigDecimal unitValue = money(unitCol == null ? null : data.getCell(unitCol), formatter, evaluator);
                    BigDecimal totalValue = money(totalCol == null ? null : data.getCell(totalCol), formatter, evaluator);
                    String quantity = qtyCol == null ? null : text(data.getCell(qtyCol), formatter, evaluator);
                    String destination = text(data.getCell(6), formatter, evaluator);

                    Map<String,Object> record = new LinkedHashMap<>();
                    record.put("fecha", purchaseDate == null ? null : purchaseDate.toString());
                    record.put("categoria", currentCategory);
                    record.put("proveedor", provider);
                    record.put("producto", product);
                    record.put("cantidad", quantity);
                    record.put("valorUnitario", unitValue);
                    record.put("valorTotal", totalValue);
                    record.put("destino", destination);
                    record.put("_sheet", sheet.getSheetName());
                    record.put("_sheetTitle", sheetTitle);
                    record.put("_row", r + 1);
                    support.rows.add(record);
                }
            }
        } catch (Exception ex) {
            bundle.warnings.add("No se pudo interpretar «" + sourcePath + "» como inventario de bodega: " + safe(ex.getMessage()));
        }
    }

    private String inventorySheetTitle(Sheet sheet, DataFormatter formatter, FormulaEvaluator evaluator) {
        String rawName = sheet.getSheetName();
        if ("Hoja1".equalsIgnoreCase(rawName)) {
            Row first = sheet.getRow(0);
            String title = first == null ? null : text(first.getCell(0), formatter, evaluator);
            if (!blank(title)) return title.trim();
        }
        return rawName;
    }

    private Map<String,Object> inventoryVatSummary(Sheet sheet, DataFormatter formatter, FormulaEvaluator evaluator) {
        Map<String,Object> result = new LinkedHashMap<>();
        for (Row row : sheet) {
            for (Cell cell : row) {
                String label = normalize(text(cell, formatter, evaluator));
                if (!"con iva".equals(label) && !"sin iva".equals(label)) continue;
                BigDecimal value = null;
                for (int offset = 1; offset <= 2 && value == null; offset++) {
                    int index = cell.getColumnIndex() - offset;
                    if (index >= 0) value = money(row.getCell(index), formatter, evaluator);
                }
                if (value == null || value.signum() <= 0) continue;
                result.put("con iva".equals(label) ? "withVat" : "withoutVat", value);
            }
        }
        return result;
    }

    private void parseSupportWorkbook(String sourcePath, byte[] bytes, ParsedBundle bundle,
                                      String supportType, String title, String location, String description) {
        SupportAggregate support = bundle.supports.computeIfAbsent(
                normalize(supportType + " " + sourcePath),
                key -> new SupportAggregate(key, title, supportType, sourcePath, location, description)
        );
        try (Workbook workbook = WorkbookFactory.create(new ByteArrayInputStream(bytes))) {
            DataFormatter formatter = new DataFormatter(new Locale("es", "CL"));
            FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
            for (int i=0; i<workbook.getNumberOfSheets(); i++) {
                Sheet sheet = workbook.getSheetAt(i);
                if (normalize(sheet.getSheetName()).contains("acerca de")) continue;
                Row header = null;
                for (Row row : sheet) {
                    Map<Integer,String> headers = rowMap(row, formatter, evaluator);
                    if (supportType.equals("PROVIDERS") && findContains(headers,"nombre proveedor") != null) { header=row; break; }
                    if (supportType.equals("INVENTORY") && findContains(headers,"tipo de producto") != null) { header=row; break; }
                }
                if (header == null) continue;
                support.sheetNames.add(sheet.getSheetName());
                Map<Integer,String> headers=rowMap(header,formatter,evaluator);
                for(int r=header.getRowNum()+1;r<=sheet.getLastRowNum();r++){
                    Row data=sheet.getRow(r); if(data==null) continue;
                    Map<String,Object> record=new LinkedHashMap<>();
                    for(Map.Entry<Integer,String> h:headers.entrySet()){
                        String value=text(data.getCell(h.getKey()),formatter,evaluator);
                        if(!blank(value)) record.put(h.getValue(),value);
                    }
                    if(record.isEmpty()) continue;
                    record.put("_sheet",sheet.getSheetName());
                    record.put("_row",r+1);
                    support.rows.add(record);
                }
            }
        } catch (Exception ex) {
            bundle.warnings.add("No se pudo interpretar la información de apoyo «" + sourcePath + "»: " + safe(ex.getMessage()));
        }
    }

    private boolean shouldSkipTemplateSheet(String title,String sourcePath){
        String n=normalize(title), p=normalize(sourcePath);
        return n.equals("remodelacion habitaciones") && (ROOM.matcher(p).find() || p.contains("pasillos"));
    }

    private boolean isEstimatedSource(String sourcePath,String sheet){
        String p=normalize(sourcePath), s=normalize(sheet);
        if(s.equals("real")||s.contains("gasto real")||s.contains("costos reales")) return false;
        if(s.contains("presu")||s.contains("presupuesto")||s.contains("estimado")||s.contains("cotizacion")) return true;
        return p.contains("presu")||p.contains("presupuesto");
    }

    private String projectKey(String title,String sourcePath){
        String combined=normalize(sourcePath+" "+title);
        Matcher m=ROOM.matcher(combined);
        if(m.find()) return m.group(2)==null?"room-"+m.group(1):"rooms-"+m.group(1)+"-"+m.group(2);
        if(combined.contains("cabana sol"))return "cabana-sol";
        if(combined.contains("cabana luna"))return "cabana-luna";
        if(combined.contains("pasillos")&&(combined.contains("piso 2")||combined.contains("pasillos 2")||combined.contains("segundo piso")))return "pasillos-piso-2";
        if(combined.contains("pasillos")&&(combined.contains("primer piso")||combined.contains("piso 1")))return "pasillos-piso-1";
        if(combined.contains("cocina")&&combined.contains("salon"))return "cocina-salon";
        if(combined.contains("campanas")&&combined.contains("cocina"))return "campanas-cocina-quincho";
        if(combined.contains("cocina"))return "cocina-hotel";
        if(combined.contains("comedor"))return "comedor";
        if(combined.contains("bodega oeste"))return "bodega-oeste";
        if(combined.contains("acopio"))return "zona-acopio";
        if(combined.contains("quincho")||combined.contains("terraza"))return "quincho-terraza";
        if(combined.contains("oficina electrica"))return "oficina-electrica";
        if(combined.contains("oficina"))return "oficina";
        if(combined.contains("stand"))return "stand";
        return normalize(title).replace(' ','-');
    }

    private String displayProjectTitle(String title,String sourcePath){
        String n=normalize(title);
        if(n.equals("remodelacion habitaciones")) return prettyFilename(sourcePath);
        return title.trim();
    }

    private String inferLocation(String title,String sourcePath){
        String combined=normalize(sourcePath+" "+title);
        Matcher m=ROOM.matcher(combined);
        if(m.find()) return m.group(2)==null?"Habitación "+m.group(1):"Habitaciones "+m.group(1)+" y "+m.group(2);
        if(combined.contains("cabana sol"))return "Cabaña Sol";
        if(combined.contains("cabana luna"))return "Cabaña Luna";
        if(combined.contains("pasillos")&&(combined.contains("piso 2")||combined.contains("pasillos 2")||combined.contains("segundo piso")))return "Pasillos · Piso 2";
        if(combined.contains("pasillos"))return "Pasillos · Primer piso";
        if(combined.contains("cocina")&&combined.contains("salon"))return "Cocina / Salón";
        if(combined.contains("cocina"))return "Cocina";
        if(combined.contains("comedor"))return "Comedor";
        if(combined.contains("bodega oeste"))return "Bodega Oeste";
        if(combined.contains("acopio"))return "Zona de acopio";
        if(combined.contains("quincho")||combined.contains("terraza"))return "Quincho / Terraza";
        if(combined.contains("oficina electrica"))return "Oficina eléctrica";
        if(combined.contains("oficina"))return "Oficina";
        if(combined.contains("stand"))return "Stand";
        return "Otra zona";
    }

    private String inferCategory(String title,String sourcePath){
        String location=inferLocation(title,sourcePath);
        if(location.startsWith("Habitación")||location.startsWith("Habitaciones"))return "Habitación";
        if(location.startsWith("Pasillos"))return "Pasillos";
        if(location.contains("Cocina"))return "Cocina";
        if(location.contains("Comedor"))return "Comedor";
        if(location.contains("Oficina"))return "Oficina";
        if(location.contains("Bodega"))return "Bodega";
        if(location.contains("Quincho"))return "Quincho / Terraza";
        return "Área común";
    }

    private String findProjectTitle(Sheet sheet,DataFormatter f,FormulaEvaluator e,String sourcePath){
        for(int r=0;r<=Math.min(sheet.getLastRowNum(),5);r++){
            Row row=sheet.getRow(r); if(row==null)continue;
            for(Cell cell:row){
                String t=text(cell,f,e); String n=normalize(t);
                if(blank(t))continue;
                if(n.contains("remodel")||n.contains("renovacion")||n.contains("transformacion")||n.contains("costo stand")||n.contains("insumos bodega")) return t.trim();
            }
        }
        String filename=prettyFilename(sourcePath);
        String n=normalize(filename);
        if(n.contains("remodel")||n.contains("renov")||n.contains("presu")||n.contains("gastos stand")||n.contains("insumos nueva bodega")) return filename;
        return null;
    }

    private Map<Integer,String> rowMap(Row row,DataFormatter f,FormulaEvaluator e){
        Map<Integer,String> out=new LinkedHashMap<>();
        for(Cell cell:row){String t=text(cell,f,e);if(!blank(t))out.put(cell.getColumnIndex(),normalize(t));}
        return out;
    }

    private Integer findHeader(Map<Integer,String> map,String target){
        String wanted=normalize(target);
        Integer exact=map.entrySet().stream()
                .filter(entry->entry.getValue().equals(wanted))
                .map(Map.Entry::getKey).findFirst().orElse(null);
        if(exact!=null)return exact;

        // Evita tomar columnas de instrucciones ocultas de plantillas como Vertex42.
        return map.entrySet().stream()
                .filter(entry->entry.getValue().length()<=40)
                .filter(entry->entry.getValue().contains(wanted))
                .map(Map.Entry::getKey).findFirst().orElse(null);
    }

    private boolean isVertex42Gantt(Sheet sheet,int headerRow,Integer taskCol,Integer startCol,Integer endCol,
                                    DataFormatter f,FormulaEvaluator e){
        if(taskCol==null||startCol==null||endCol==null)return false;
        if(!"tarea".equals(normalize(text(sheet.getRow(headerRow).getCell(taskCol),f,e))))return false;
        if(!"inicio".equals(normalize(text(sheet.getRow(headerRow).getCell(startCol),f,e))))return false;
        if(!"fin".equals(normalize(text(sheet.getRow(headerRow).getCell(endCol),f,e))))return false;

        // La plantilla usada por el Hotel mantiene una escala diaria inmediatamente sobre
        // la tabla (normalmente I5:BL5). Basta detectar varias fechas consecutivas.
        Row timeline=sheet.getRow(Math.max(0,headerRow-1));
        if(timeline==null)return false;
        int consecutiveDates=0;
        for(int c=endCol+1;c<=Math.min(timeline.getLastCellNum(),endCol+70);c++){
            LocalDate d=iso(date(timeline.getCell(c),f,e));
            if(d!=null){
                consecutiveDates++;
                if(consecutiveDates>=7)return true;
            }
        }
        return false;
    }

    private LocalDate vertex42Date(Sheet sheet,Cell cell,DataFormatter f,FormulaEvaluator e,Set<String> visited){
        if(cell==null)return null;

        // 1) Valor numérico/caché real guardado dentro del XLSX.
        String direct=date(cell,f,e);
        LocalDate parsed=iso(direct);
        if(parsed!=null)return parsed;

        // 2) Resolver las fórmulas simples que utiliza la plantilla:
        // Project_Start, E14, F10-1, E38+1, DATE(2021,12,20), etc.
        if(cell.getCellType()==CellType.FORMULA){
            String key=cell.getAddress().formatAsString();
            if(!visited.add(key))return null;
            String formula=cell.getCellFormula();
            LocalDate resolved=resolveVertex42Formula(sheet,formula,f,e,visited);
            visited.remove(key);
            if(resolved!=null)return resolved;
        }
        return null;
    }

    private LocalDate resolveVertex42Formula(Sheet sheet,String formula,DataFormatter f,FormulaEvaluator e,Set<String> visited){
        if(blank(formula))return null;
        String cleanFormula=formula.replace("$","").replace(" ","").trim();

        Matcher dateFn=Pattern.compile("(?i)^DATE\\((\\d{4}),(\\d{1,2}),(\\d{1,2})\\)$").matcher(cleanFormula);
        if(dateFn.matches()){
            try{return LocalDate.of(Integer.parseInt(dateFn.group(1)),Integer.parseInt(dateFn.group(2)),Integer.parseInt(dateFn.group(3)));}catch(Exception ignored){}
        }

        if("Project_Start".equalsIgnoreCase(cleanFormula)){
            // En este formato el inicio del proyecto está en E3.
            Row row=sheet.getRow(2);
            return row==null?null:vertex42Date(sheet,row.getCell(4),f,e,visited);
        }

        Matcher ref=Pattern.compile("(?i)^([A-Z]{1,3})(\\d+)([+-]\\d+)?$").matcher(cleanFormula);
        if(ref.matches()){
            int col=columnIndex(ref.group(1));
            int rowIndex=Integer.parseInt(ref.group(2))-1;
            if(col<0||rowIndex<0)return null;
            Row row=sheet.getRow(rowIndex);
            if(row==null)return null;
            LocalDate base=vertex42Date(sheet,row.getCell(col),f,e,visited);
            if(base==null)return null;
            if(ref.group(3)!=null){
                try{base=base.plusDays(Integer.parseInt(ref.group(3)));}catch(Exception ignored){}
            }
            return base;
        }
        return null;
    }

    private int columnIndex(String letters){
        int value=0;
        for(char ch:letters.toUpperCase(Locale.ROOT).toCharArray()){
            if(ch<'A'||ch>'Z')return-1;
            value=value*26+(ch-'A'+1);
        }
        return value-1;
    }

    private Integer findContains(Map<Integer,String> map,String target){return map.entrySet().stream().filter(e->e.getValue().contains(normalize(target))).map(Map.Entry::getKey).findFirst().orElse(null);}
    private String text(Cell cell,DataFormatter f,FormulaEvaluator e){if(cell==null)return null;try{String v=f.formatCellValue(cell,e);return clean(v);}catch(Exception ex){return clean(f.formatCellValue(cell));}}
    private String date(Cell cell,DataFormatter f,FormulaEvaluator e){
        if(cell==null)return null;
        try{
            Double numeric = rawExcelNumeric(cell);
            if(numeric != null && DateUtil.isValidExcelDate(numeric)){
                LocalDate d=ExcelDateSupport.toLocalDate(numeric);
                if(d.getYear()>=2000&&d.getYear()<=2200)return d.toString();
            }

            if(cell.getCellType()==CellType.FORMULA){
                CellValue evaluated=null;
                try { evaluated=e.evaluate(cell); } catch (Exception ignored) {}
                if(evaluated!=null && evaluated.getCellType()==CellType.NUMERIC){
                    double evaluatedNumeric=evaluated.getNumberValue();
                    if(DateUtil.isValidExcelDate(evaluatedNumeric)){
                        LocalDate d=ExcelDateSupport.toLocalDate(evaluatedNumeric);
                        if(d.getYear()>=2000&&d.getYear()<=2200)return d.toString();
                    }
                }
            }
        }catch(Exception ignored){}

        // Algunas plantillas Gantt formatean fechas calculadas como texto visible.
        // Se intenta con y sin evaluador para no depender de que POI comprenda toda la fórmula.
        String[] visibleCandidates = new String[]{text(cell,f,e), clean(f.formatCellValue(cell))};
        for(String t : visibleCandidates){
            if(t==null) continue;
            String candidate=t.trim().replace('.', '-');
            for(String pattern : List.of("dd-MM-yy","dd-MM-yyyy","d-M-yy","d-M-yyyy","dd/MM/yy","dd/MM/yyyy","d/M/yy","d/M/yyyy")){
                try{return java.time.LocalDate.parse(candidate,java.time.format.DateTimeFormatter.ofPattern(pattern)).toString();}catch(Exception ignored){}
            }
            try{return LocalDate.parse(candidate.substring(0,Math.min(10,candidate.length()))).toString();}catch(Exception ignored){}
        }
        return null;
    }

    private Double rawExcelNumeric(Cell cell){
        try{
            if(cell.getCellType()==CellType.NUMERIC) return cell.getNumericCellValue();
            if(cell instanceof XSSFCell xssf){
                String raw=xssf.getRawValue();
                if(raw!=null&&!raw.isBlank()) return Double.parseDouble(raw.trim());
            }
            if(cell.getCellType()==CellType.FORMULA && cell.getCachedFormulaResultType()==CellType.NUMERIC){
                return cell.getNumericCellValue();
            }
        }catch(Exception ignored){}
        return null;
    }
    private LocalDate iso(String value){try{return value==null?null:LocalDate.parse(value);}catch(Exception ex){return null;}}
    private BigDecimal money(Cell cell,DataFormatter f,FormulaEvaluator e){
        if(cell==null)return null;
        try{if(cell.getCellType()==CellType.NUMERIC)return BigDecimal.valueOf(cell.getNumericCellValue()).setScale(2,RoundingMode.HALF_UP);}catch(Exception ignored){}
        String t=text(cell,f,e);if(t==null)return null;String cleaned=t.replaceAll("[^0-9,.-]","").replace(".","").replace(',', '.');
        try{return new BigDecimal(cleaned).setScale(2,RoundingMode.HALF_UP);}catch(Exception ex){return null;}
    }
    private BigDecimal parseProgress(String value){
        if(value==null)return BigDecimal.ZERO;String cleaned=value.replace("%","").replace(',','.').trim();
        try{BigDecimal n=new BigDecimal(cleaned);if(n.compareTo(BigDecimal.ONE)<=0)n=n.multiply(BigDecimal.valueOf(100));return n.max(BigDecimal.ZERO).min(BigDecimal.valueOf(100)).setScale(2,RoundingMode.HALF_UP);}catch(Exception ex){return BigDecimal.ZERO;}
    }
    private boolean hasMeaningfulRows(Sheet sheet,DataFormatter f,FormulaEvaluator e){int count=0;for(Row row:sheet){for(Cell c:row){if(!blank(text(c,f,e))&&++count>=3)return true;}}return false;}
    private String taskKey(String title,LocalDate start,LocalDate end,String owner){return normalize(title)+"|"+Objects.toString(start,"")+"|"+Objects.toString(end,"")+"|"+normalize(owner);}
    private String prettyFilename(String path){String name=path.replace('\\','/');name=name.substring(name.lastIndexOf('/')+1).replaceFirst("(?i)\\.xlsx$","");return name.replaceAll("#U00d1A","Ñ").replaceAll("#U00f3n","ó").trim();}
    private String normalize(String value){if(value==null)return "";return Normalizer.normalize(value,Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+"," ").trim().replaceAll("\\s+"," ");}
    private String clean(String value){if(value==null)return null;String t=value.trim();return t.isEmpty()?null:t;}
    private boolean blank(String value){return value==null||value.isBlank();}
    private String safe(String value){return value==null?"error desconocido":value.replaceAll("[\\r\\n]+"," ");}
    private String toJson(Object value){try{return json.writeValueAsString(value);}catch(Exception ex){return null;}}
    private void validate(MultipartFile file){
        if(file==null||file.isEmpty())throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Selecciona un Excel o ZIP de Remodelación.");
        String name=Optional.ofNullable(file.getOriginalFilename()).orElse("").toLowerCase(Locale.ROOT);
        if(!name.endsWith(".xlsx")&&!name.endsWith(".zip"))throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Solo se aceptan archivos .xlsx o .zip.");
    }

    private static final class ParsedBundle{
        final Map<String,ProjectAggregate> projects=new LinkedHashMap<>();
        final Map<String,SupportAggregate> supports=new LinkedHashMap<>();
        final List<String> supportFiles=new ArrayList<>();
        final List<String> crossAreaFiles=new ArrayList<>();
        final List<String> warnings=new ArrayList<>();
    }

    private static final class SupportAggregate{
        final String key; final String title; final String supportType; final String sourceFile; final String location; final String description;
        final List<Map<String,Object>> rows=new ArrayList<>();
        final Set<String> sheetNames=new LinkedHashSet<>();
        final Map<String,Map<String,Object>> sheetSummaries=new LinkedHashMap<>();
        SupportAggregate(String key,String title,String supportType,String sourceFile,String location,String description){
            this.key=key;this.title=title;this.supportType=supportType;this.sourceFile=sourceFile;this.location=location;this.description=description;
        }
    }
    private static final class ProjectAggregate{
        final String key; final String title; final String location; final String category;
        final List<String> sources=new ArrayList<>(); final List<Map<String,Object>> lines=new ArrayList<>();
        final Map<String,TaskData> tasks=new LinkedHashMap<>();
        BigDecimal estimated=BigDecimal.ZERO, actual=BigDecimal.ZERO; String responsible,primarySupplier,firstMaterial;
        LocalDate costStart,costEnd;
        ProjectAggregate(String key,String title,String location,String category){this.key=key;this.title=title;this.location=location;this.category=category;}
        BigDecimal estimatedCost(){return estimated.signum()==0?null:estimated.setScale(2,RoundingMode.HALF_UP);} BigDecimal actualCost(){return actual.signum()==0?null:actual.setScale(2,RoundingMode.HALF_UP);}
        LocalDate startDate(){return tasks.values().stream().map(TaskData::start).filter(Objects::nonNull).min(LocalDate::compareTo).orElse(costStart);}
        LocalDate endDate(){return tasks.values().stream().map(TaskData::end).filter(Objects::nonNull).max(LocalDate::compareTo).orElse(costEnd);}
        BigDecimal progress(){if(tasks.isEmpty())return BigDecimal.ZERO;return tasks.values().stream().map(TaskData::progress).reduce(BigDecimal.ZERO,BigDecimal::add).divide(BigDecimal.valueOf(tasks.size()),2,RoundingMode.HALF_UP);}
        String status(){BigDecimal p=progress();return p.compareTo(BigDecimal.valueOf(100))>=0?"COMPLETED":p.signum()>0?"IN_PROGRESS":"PLANNED";}
        String stage(){String status=status();return "COMPLETED".equals(status)?"Finalizada":"IN_PROGRESS".equals(status)?"Ejecución":"Diseño / planificación";}
        String materialSummary(){return firstMaterial==null?null:firstMaterial+(lines.size()>1?" y "+(lines.size()-1)+" ítems más":"");}
        String primarySupplier(){return primarySupplier;}
    }

    private record TaskData(String key,String title,String responsible,String phase,LocalDate start,LocalDate end,
                            BigDecimal progress,String status,String notes,String sourceFile,String sourceSheet,Integer sourceRow){}
    public record DuplicateRef(String id,String title,String areaSlug,String areaName,String location){}
    public record ProjectPreview(String key,String title,String location,String category,BigDecimal estimatedCost,BigDecimal actualCost,
                                 int budgetLines,int ganttTasks,List<String> sourceFiles,List<DuplicateRef> duplicates){}
    public record AnalysisResult(String filename,int projectCount,int ganttTaskCount,int budgetLineCount,int supportRecordCount,int supportSheetCount,
                                 List<String> supportFiles,List<String> crossAreaFiles,List<ProjectPreview> projects,List<String> warnings){}
    public record ImportResult(int projectsCreated,int ganttTasksCreated,int supportItemsCreated,int supportItemsUpdated,int skipped,List<String> supportFiles,List<String> crossAreaFiles){}
}
