package cl.mmsolutions.backend.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Entrega index.html en rutas Angular directas para que F5 y enlaces internos
 * funcionen desde la URL publica sin exponer los endpoints /api/**.
 */
@Controller
public class SpaController {

    @GetMapping({
            "/login", "/activar-cuenta", "/sin-accesos", "/sin-permiso",
            "/dashboard", "/gastos", "/calendario", "/activos",
            "/trabajadores", "/configuracion", "/historial",
            "/documentos", "/documentos/**", "/areas/**"
    })
    public String angularPage() {
        return "forward:/index.html";
    }
}
