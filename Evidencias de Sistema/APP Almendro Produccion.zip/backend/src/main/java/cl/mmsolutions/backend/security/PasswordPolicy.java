package cl.mmsolutions.backend.security;

public final class PasswordPolicy {
    public static final int MIN_LENGTH = 12;
    public static final int MAX_LENGTH = 128;
    public static final String REQUIREMENTS = "Mínimo 12 caracteres y al menos una mayúscula.";

    private PasswordPolicy() {}

    public static void validate(String password, String confirmation) {
        if (password == null || !password.equals(confirmation)) {
            throw new PasswordPolicyException("Las contraseñas no coinciden.");
        }
        boolean hasUppercase = password.codePoints().anyMatch(Character::isUpperCase);
        if (password.length() < MIN_LENGTH || password.length() > MAX_LENGTH || !hasUppercase) {
            throw new PasswordPolicyException(REQUIREMENTS);
        }
    }

    public static class PasswordPolicyException extends RuntimeException {
        public PasswordPolicyException(String message) {
            super(message);
        }
    }
}
