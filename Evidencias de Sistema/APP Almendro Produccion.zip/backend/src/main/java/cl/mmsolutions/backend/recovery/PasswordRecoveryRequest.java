package cl.mmsolutions.backend.recovery;

import cl.mmsolutions.backend.user.AppUser;
import jakarta.persistence.*;

import java.time.OffsetDateTime;

@Entity
@Table(name = "password_recovery_request")
public class PasswordRecoveryRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private AppUser user;

    @Column(name = "code_hash", nullable = false, length = 255)
    private String codeHash;

    @Column(name = "reset_token_hash", unique = true, length = 64)
    private String resetTokenHash;

    @Column(name = "failed_attempts", nullable = false)
    private int failedAttempts;

    @Column(name = "expires_at", nullable = false)
    private OffsetDateTime expiresAt;

    @Column(name = "verified_at")
    private OffsetDateTime verifiedAt;

    @Column(name = "used_at")
    private OffsetDateTime usedAt;

    @Column(name = "invalidated_at")
    private OffsetDateTime invalidatedAt;

    @Column(name = "created_at", nullable = false, insertable = false, updatable = false)
    private OffsetDateTime createdAt;

    protected PasswordRecoveryRequest() {}

    public PasswordRecoveryRequest(AppUser user, String codeHash, OffsetDateTime expiresAt) {
        this.user = user;
        this.codeHash = codeHash;
        this.expiresAt = expiresAt;
    }

    public AppUser getUser() { return user; }
    public String getCodeHash() { return codeHash; }
    public String getResetTokenHash() { return resetTokenHash; }
    public int getFailedAttempts() { return failedAttempts; }
    public OffsetDateTime getExpiresAt() { return expiresAt; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
    public OffsetDateTime getVerifiedAt() { return verifiedAt; }

    public boolean isCodeUsable(OffsetDateTime now, int maximumAttempts) {
        return usedAt == null && invalidatedAt == null && verifiedAt == null
                && failedAttempts < maximumAttempts && expiresAt.isAfter(now);
    }

    public boolean isResetUsable(OffsetDateTime now) {
        return usedAt == null && invalidatedAt == null && verifiedAt != null
                && resetTokenHash != null && expiresAt.isAfter(now);
    }

    public void failAttempt(OffsetDateTime now, int maximumAttempts) {
        failedAttempts++;
        if (failedAttempts >= maximumAttempts) invalidatedAt = now;
    }

    public void verify(OffsetDateTime now, String tokenHash) {
        verifiedAt = now;
        resetTokenHash = tokenHash;
    }

    public void use(OffsetDateTime now) { usedAt = now; }
    public void invalidate(OffsetDateTime now) { invalidatedAt = now; }
}
