package cl.mmsolutions.backend.worker;

import cl.mmsolutions.backend.audit.SystemActivityService;
import cl.mmsolutions.backend.document.DocumentService;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.security.access.prepost.PreAuthorize;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/workers")
@PreAuthorize("@permissionService.has(authentication, 'trabajadores')")
public class WorkerController {
    private static final List<String> DEFAULT_DOCUMENT_CATEGORIES = List.of(
            "Documento", "Contrato", "Entrega EPP", "Certificado", "Capacitación", "Antecedente"
    );
    private final JdbcTemplate jdbc;
    private final DocumentService documents;
    private final SystemActivityService audit;
    public WorkerController(JdbcTemplate jdbc,DocumentService documents,SystemActivityService audit){this.jdbc=jdbc;this.documents=documents;this.audit=audit;}

    @GetMapping
    public List<WorkerResponse> list(){return jdbc.query("""
        SELECT w.*, (SELECT COUNT(*) FROM worker_document wd WHERE wd.worker_id=w.id) document_count
        FROM worker w WHERE w.active=TRUE ORDER BY w.full_name
        """,(rs,n)->map(rs));}

    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("@permissionService.has(authentication, 'trabajadores') and @permissionService.has(authentication, 'create-edit')")
    @Transactional
    public WorkerResponse create(@RequestBody WorkerRequest r, Authentication auth){
        UUID id=UUID.randomUUID(); Long uid=userId(auth);
        jdbc.update("INSERT INTO worker(id,full_name,rut,position,department,phone,email,notes,created_by) VALUES(?,?,?,?,?,?,?,?,?)",
                id,req(r.fullName()),clean(r.rut()),clean(r.position()),clean(r.department()),clean(r.phone()),clean(r.email()),clean(r.notes()),uid);
        WorkerResponse created=get(id);
        audit.record("trabajadores","Trabajadores",id,created.fullName(),"TRABAJADOR","CREATED",
                "Trabajador agregado" + (created.position()==null?"":" · "+created.position()),auth);
        return created;
    }

    @PutMapping("/{id}")
    @PreAuthorize("@permissionService.has(authentication, 'trabajadores') and @permissionService.has(authentication, 'create-edit')")
    @Transactional
    public WorkerResponse update(@PathVariable UUID id,@RequestBody WorkerRequest r,Authentication auth){
        jdbc.update("UPDATE worker SET full_name=?,rut=?,position=?,department=?,phone=?,email=?,notes=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                req(r.fullName()),clean(r.rut()),clean(r.position()),clean(r.department()),clean(r.phone()),clean(r.email()),clean(r.notes()),id);
        WorkerResponse updated=get(id);
        audit.record("trabajadores","Trabajadores",id,updated.fullName(),"TRABAJADOR","UPDATED",
                "Ficha de trabajador actualizada",auth);
        return updated;
    }

    @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
    @PreAuthorize("@permissionService.has(authentication, 'trabajadores') and @permissionService.has(authentication, 'delete')")
    @Transactional
    public void delete(@PathVariable UUID id,Authentication auth){
        WorkerResponse current=get(id);
        jdbc.update("UPDATE worker SET active=FALSE,updated_at=CURRENT_TIMESTAMP WHERE id=?",id);
        audit.record("trabajadores","Trabajadores",id,current.fullName(),"TRABAJADOR","DELETED",
                "Trabajador dado de baja",auth);
    }

    @GetMapping("/{id}/documents")
    public List<WorkerDocument> workerDocuments(@PathVariable UUID id){
        return jdbc.query("""
            SELECT d.id,d.name,d.file_type,d.index_status,d.created_at,dv.version_number,dv.size_bytes,dv.original_filename,
                   COALESCE(NULLIF(TRIM(wd.document_type),''),'Documento') document_type
            FROM worker_document wd JOIN document d ON d.id=wd.document_id JOIN document_version dv ON dv.id=d.current_version_id
            WHERE wd.worker_id=? AND d.status='ACTIVE' ORDER BY d.created_at DESC
            """,(rs,n)->new WorkerDocument(rs.getObject("id",UUID.class),rs.getString("name"),rs.getString("file_type"),rs.getString("index_status"),rs.getInt("version_number"),rs.getLong("size_bytes"),rs.getString("original_filename"),rs.getObject("created_at",OffsetDateTime.class),rs.getString("document_type")),id);
    }

    @GetMapping("/document-categories")
    public List<String> documentCategories(){
        List<String> result=new ArrayList<>(DEFAULT_DOCUMENT_CATEGORIES);
        List<String> stored=jdbc.queryForList("""
            SELECT DISTINCT document_type FROM worker_document
            WHERE document_type IS NOT NULL AND TRIM(document_type)<>''
            ORDER BY document_type
            """,String.class);
        for(String category:stored){
            String normalized=normalizeCategory(category);
            if(result.stream().noneMatch(value->categoryKey(value).equals(categoryKey(normalized)))) result.add(normalized);
        }
        return result;
    }

    @PostMapping(path="/{id}/documents",consumes="multipart/form-data") @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("@permissionService.has(authentication, 'trabajadores') and @permissionService.has(authentication, 'create-edit')")
    @Transactional
    public WorkerDocument upload(@PathVariable UUID id,@RequestPart("file") MultipartFile file,@RequestPart("documentType") String documentType,Authentication auth){
        if(jdbc.queryForObject("SELECT COUNT(*) FROM worker WHERE id=? AND active=TRUE",Integer.class,id)==0) throw new IllegalArgumentException("Trabajador no encontrado.");
        String category=canonicalCategory(documentType);
        var doc=documents.upload("trabajadores",file,auth.getName());
        jdbc.update("INSERT INTO worker_document(worker_id,document_id,document_type) VALUES(?,?,?)",id,doc.id(),category);
        return new WorkerDocument(doc.id(),doc.name(),doc.fileType(),doc.indexStatus(),doc.versionNumber(),doc.sizeBytes(),doc.originalFilename(),doc.createdAt(),category);
    }

    @DeleteMapping("/{workerId}/documents/{documentId}") @ResponseStatus(HttpStatus.NO_CONTENT)
    @PreAuthorize("@permissionService.has(authentication, 'trabajadores') and @permissionService.has(authentication, 'delete')")
    @Transactional
    public void deleteDocument(@PathVariable UUID workerId,@PathVariable UUID documentId,Authentication auth){
        jdbc.update("DELETE FROM worker_document WHERE worker_id=? AND document_id=?",workerId,documentId);
        documents.delete(documentId,auth.getName());
    }

    private WorkerResponse get(UUID id){return jdbc.queryForObject("""
        SELECT w.*, (SELECT COUNT(*) FROM worker_document wd WHERE wd.worker_id=w.id) document_count FROM worker w WHERE w.id=?
        """,(rs,n)->map(rs),id);}
    private WorkerResponse map(java.sql.ResultSet rs) throws java.sql.SQLException{return new WorkerResponse(rs.getObject("id",UUID.class),rs.getString("full_name"),rs.getString("rut"),rs.getString("position"),rs.getString("department"),rs.getString("phone"),rs.getString("email"),rs.getString("notes"),rs.getBoolean("active"),rs.getInt("document_count"),rs.getObject("created_at",OffsetDateTime.class),rs.getObject("updated_at",OffsetDateTime.class));}
    private Long userId(Authentication auth){return auth==null?null:jdbc.queryForObject("SELECT id FROM app_user WHERE username=?",Long.class,auth.getName());}
    private static String req(String s){if(s==null||s.isBlank())throw new IllegalArgumentException("El nombre es obligatorio.");return s.trim();}
    private static String clean(String s){return s==null||s.isBlank()?null:s.trim();}
    private String canonicalCategory(String value){
        String normalized=normalizeCategory(value);
        if(normalized.equalsIgnoreCase("Personalizado")) throw new IllegalArgumentException("Escribe el nombre de la categoría personalizada.");
        return documentCategories().stream()
                .filter(category->categoryKey(category).equals(categoryKey(normalized)))
                .findFirst().orElse(normalized);
    }
    private static String normalizeCategory(String value){
        if(value==null||value.isBlank()) throw new IllegalArgumentException("Selecciona un tipo de documento.");
        String normalized=value.trim().replaceAll("\\s+"," ");
        if(normalized.length()>120) throw new IllegalArgumentException("La categoría no puede superar 120 caracteres.");
        return normalized;
    }
    private static String categoryKey(String value){return value.toLowerCase(java.util.Locale.ROOT);}
    public record WorkerRequest(String fullName,String rut,String position,String department,String phone,String email,String notes){}
    public record WorkerResponse(UUID id,String fullName,String rut,String position,String department,String phone,String email,String notes,boolean active,int documentCount,OffsetDateTime createdAt,OffsetDateTime updatedAt){}
    public record WorkerDocument(UUID id,String name,String fileType,String indexStatus,int versionNumber,long sizeBytes,String originalFilename,OffsetDateTime createdAt,String documentType){}
}
