package cl.mmsolutions.backend.search;

import cl.mmsolutions.backend.document.DocumentStorageProvider;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Comment;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.InputStream;

import java.text.Normalizer;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;


@Service
public class DocumentSearchService {

    private static final int MAX_RESULTS =
            50;

    private static final int MAX_LOCATIONS_PER_RESULT =
            5;

    private static final int MAX_FRAGMENTS_PER_DOCUMENT =
            200_000;


    private final JdbcTemplate jdbcTemplate;
    private final DocumentStorageProvider storage;


    public DocumentSearchService(
            JdbcTemplate jdbcTemplate,
            DocumentStorageProvider storage
    ) {

        this.jdbcTemplate =
                jdbcTemplate;
        this.storage = storage;
    }


    /*
     * ============================================================
     * BÚSQUEDA GLOBAL O POR ÁREA
     * ============================================================
     */

    @Transactional
    public List<SearchResult> search(
            String query,
            String areaSlug
    ) {

        String normalizedQuery =
                normalizeText(
                        query
                );


        if (
                normalizedQuery.length() < 2
        ) {

            return List.of();
        }


        /*
         * Antes de buscar sincronizamos el índice.
         *
         * Esto garantiza que:
         *
         * - documentos nuevos aparezcan;
         * - documentos editados usen la versión actual;
         * - documentos eliminados desaparezcan.
         */

        synchronizeIndex();


        StringBuilder sql =
                new StringBuilder(
                        """
                        SELECT
                            s.document_id,

                            d.name AS document_name,

                            d.file_type::text AS file_type,

                            a.slug AS area_slug,

                            a.name AS area_name,

                            s.source_type,

                            s.sheet_name,

                            s.cell_reference,

                            s.normalized_content

                        FROM document_search_fragment s

                        INNER JOIN document d
                            ON d.id = s.document_id

                        INNER JOIN area a
                            ON a.id = d.area_id

                        WHERE d.status = 'ACTIVE'

                          AND POSITION(
                              ? IN s.normalized_content
                          ) > 0
                        """
                );


        List<Object> parameters =
                new ArrayList<>();


        parameters.add(
                normalizedQuery
        );


        /*
         * Si se entrega areaSlug,
         * la búsqueda queda limitada a esa tarjeta.
         */

        if (
                areaSlug != null
                && !areaSlug.isBlank()
        ) {

            sql.append(
                    """
                     AND a.slug = ?
                    """
            );


            parameters.add(
                    areaSlug
            );
        }


        List<SearchRow> matchingRows =
                jdbcTemplate.query(
                        sql.toString(),

                        (rs, rowNum) ->
                                new SearchRow(
                                        rs.getObject(
                                                "document_id",
                                                UUID.class
                                        ),

                                        rs.getString(
                                                "document_name"
                                        ),

                                        rs.getString(
                                                "file_type"
                                        ),

                                        rs.getString(
                                                "area_slug"
                                        ),

                                        rs.getString(
                                                "area_name"
                                        ),

                                        rs.getString(
                                                "source_type"
                                        ),

                                        rs.getString(
                                                "sheet_name"
                                        ),

                                        rs.getString(
                                                "cell_reference"
                                        ),

                                        rs.getString(
                                                "normalized_content"
                                        )
                                ),

                        parameters.toArray()
                );


        /*
         * Agrupamos todas las coincidencias
         * pertenecientes al mismo documento.
         */

        Map<UUID, SearchAccumulator> grouped =
                new LinkedHashMap<>();


        for (
                SearchRow row :
                matchingRows
        ) {

            SearchAccumulator accumulator =
                    grouped.computeIfAbsent(
                            row.documentId(),

                            ignored ->
                                    new SearchAccumulator(
                                            row.documentId(),
                                            row.documentName(),
                                            row.fileType(),
                                            row.areaSlug(),
                                            row.areaName()
                                    )
                    );


            int occurrences =
                    countOccurrences(
                            row.normalizedContent(),
                            normalizedQuery
                    );


            accumulator.matchCount +=
                    occurrences;


            if (
                    "FILENAME".equals(
                            row.sourceType()
                    )
            ) {

                accumulator.filenameMatch =
                        true;
            }


            String location =
                    buildLocation(
                            row
                    );


            if (
                    location != null
                    && accumulator.locations.size()
                    < MAX_LOCATIONS_PER_RESULT
            ) {

                accumulator.locations.add(
                        location
                );
            }
        }


        return grouped
                .values()
                .stream()

                /*
                 * Si coincide el nombre del archivo,
                 * aparece primero.
                 */

                .sorted(
                        Comparator
                                .comparing(
                                        SearchAccumulator::isFilenameMatch
                                )
                                .reversed()

                                .thenComparing(
                                        SearchAccumulator::getMatchCount,
                                        Comparator.reverseOrder()
                                )

                                .thenComparing(
                                        SearchAccumulator::getDocumentName,
                                        String.CASE_INSENSITIVE_ORDER
                                )
                )

                .limit(
                        MAX_RESULTS
                )

                .map(
                        SearchAccumulator::toResult
                )

                .toList();
    }


    /*
     * ============================================================
     * SINCRONIZAR ÍNDICE
     * ============================================================
     */

    private void synchronizeIndex() {

        List<ActiveDocument> documents =
                jdbcTemplate.query(
                        """
                        SELECT
                            d.id,

                            d.name,

                            d.file_type::text AS file_type,

                            d.index_status::text AS index_status,

                            dv.id AS version_id,

                            dv.original_filename,

                            dv.version_number,

                            dv.local_storage_path,

                            dv.cloud_storage_path

                        FROM document d

                        INNER JOIN document_version dv
                            ON dv.id = d.current_version_id

                        WHERE d.status = 'ACTIVE'
                        """,

                        (rs, rowNum) ->
                                new ActiveDocument(
                                        rs.getObject(
                                                "id",
                                                UUID.class
                                        ),

                                        rs.getString(
                                                "name"
                                        ),

                                        rs.getString(
                                                "file_type"
                                        ),

                                        rs.getString(
                                                "index_status"
                                        ),

                                        rs.getObject(
                                                "version_id",
                                                UUID.class
                                        ),

                                        rs.getString(
                                                "original_filename"
                                        ),

                                        rs.getInt("version_number"),

                                        storage.keyFromDatabase(
                                                rs.getString("local_storage_path"),
                                                rs.getString("cloud_storage_path")
                                        )
                                )
                );


        /*
         * Limpiar índices de documentos eliminados.
         */

        jdbcTemplate.update(
                """
                DELETE FROM document_search_fragment s

                WHERE NOT EXISTS (

                    SELECT 1

                    FROM document d

                    WHERE d.id = s.document_id

                      AND d.status = 'ACTIVE'
                )
                """
        );


        for (
                ActiveDocument document :
                documents
        ) {

            Integer currentVersionFragments =
                    jdbcTemplate.queryForObject(
                            """
                            SELECT COUNT(*)

                            FROM document_search_fragment

                            WHERE document_id = ?

                              AND document_version_id = ?
                            """,

                            Integer.class,

                            document.documentId(),

                            document.versionId()
                    );


            boolean alreadyIndexed =
                    currentVersionFragments != null
                    && currentVersionFragments > 0;


            boolean statusReady =
                    "PDF".equals(
                            document.fileType()
                    )
                    || "INDEXED".equals(
                            document.indexStatus()
                    );


            if (
                    alreadyIndexed
                    && statusReady
            ) {

                continue;
            }


            indexDocument(
                    document
            );
        }
    }


    /*
     * ============================================================
     * INDEXAR DOCUMENTO
     * ============================================================
     */

    private void indexDocument(
            ActiveDocument document
    ) {

        /*
         * Eliminar índice anterior del documento.
         */

        jdbcTemplate.update(
                """
                DELETE FROM document_search_fragment

                WHERE document_id = ?
                """,

                document.documentId()
        );


        List<SearchFragmentInput> fragments =
                new ArrayList<>();


        /*
         * Siempre indexamos el nombre del archivo.
         */

        addFragment(
                fragments,

                "FILENAME",

                null,

                null,

                document.documentName()
        );


        try {

            if (
                    document.storageKey() != null
                    && storage.exists(document.storageKey())
            ) {

                switch (
                        document.fileType()
                ) {

                    case "XLSX" ->

                            extractExcel(
                                    storage.open(document.storageKey()),
                                    fragments
                            );


                    case "DOCX" ->

                            extractWord(
                                    storage.open(document.storageKey()),
                                    fragments
                            );


                    /*
                     * PDF todavía se busca solamente
                     * por nombre del archivo.
                     */

                    case "PDF" -> {
                    }


                    default -> {
                    }
                }
            }


            insertFragments(
                    document,
                    fragments
            );


            if (
                    "PDF".equals(
                            document.fileType()
                    )
            ) {

                jdbcTemplate.update(
                        """
                        UPDATE document

                        SET
                            index_status = 'NOT_APPLICABLE',

                            last_indexed_at = CURRENT_TIMESTAMP

                        WHERE id = ?
                        """,

                        document.documentId()
                );

            } else {

                jdbcTemplate.update(
                        """
                        UPDATE document

                        SET
                            index_status = 'INDEXED',

                            last_indexed_at = CURRENT_TIMESTAMP

                        WHERE id = ?
                        """,

                        document.documentId()
                );
            }

        } catch (Exception e) {

            /*
             * Si falla el contenido,
             * conservamos búsqueda por nombre.
             */

            jdbcTemplate.update(
                    """
                    DELETE FROM document_search_fragment

                    WHERE document_id = ?
                    """,

                    document.documentId()
            );


            List<SearchFragmentInput> filenameOnly =
                    new ArrayList<>();


            addFragment(
                    filenameOnly,

                    "FILENAME",

                    null,

                    null,

                    document.documentName()
            );


            insertFragments(
                    document,
                    filenameOnly
            );


            if (
                    !"PDF".equals(
                            document.fileType()
                    )
            ) {

                jdbcTemplate.update(
                        """
                        UPDATE document

                        SET
                            index_status = 'ERROR',

                            last_indexed_at = NULL

                        WHERE id = ?
                        """,

                        document.documentId()
                );
            }
        }
    }


    /*
     * ============================================================
     * EXTRAER CONTENIDO EXCEL
     * ============================================================
     */

    private void extractExcel(
            InputStream source,
            List<SearchFragmentInput> fragments
    ) throws Exception {

        try (
                InputStream input =
                        source;

                Workbook workbook =
                        WorkbookFactory.create(
                                input
                        )
        ) {

            DataFormatter formatter =
                    new DataFormatter();


            FormulaEvaluator evaluator =
                    workbook
                            .getCreationHelper()
                            .createFormulaEvaluator();


            for (
                    int sheetIndex = 0;
                    sheetIndex <
                            workbook.getNumberOfSheets();
                    sheetIndex++
            ) {

                if (
                        fragments.size()
                        >= MAX_FRAGMENTS_PER_DOCUMENT
                ) {

                    return;
                }


                Sheet sheet =
                        workbook.getSheetAt(
                                sheetIndex
                        );


                String sheetName =
                        sheet.getSheetName();


                /*
                 * Nombre de hoja.
                 */

                addFragment(
                        fragments,

                        "SHEET",

                        sheetName,

                        null,

                        sheetName
                );


                for (
                        Row row :
                        sheet
                ) {

                    if (
                            fragments.size()
                            >= MAX_FRAGMENTS_PER_DOCUMENT
                    ) {

                        return;
                    }


                    for (
                            Cell cell :
                            row
                    ) {

                        if (
                                fragments.size()
                                >= MAX_FRAGMENTS_PER_DOCUMENT
                        ) {

                            return;
                        }


                        String value;


                        try {

                            value =
                                    formatter.formatCellValue(
                                            cell,
                                            evaluator
                                    );

                        } catch (
                                RuntimeException ignored
                        ) {

                            value =
                                    formatter.formatCellValue(
                                            cell
                                    );
                        }


                        String reference =
                                cell
                                        .getAddress()
                                        .formatAsString();


                        if (
                                value != null
                                && !value.isBlank()
                        ) {

                            addFragment(
                                    fragments,

                                    "CELL",

                                    sheetName,

                                    reference,

                                    value
                            );
                        }


                        Comment comment =
                                cell.getCellComment();


                        if (
                                comment != null
                                && comment.getString() != null
                        ) {

                            String commentText =
                                    comment
                                            .getString()
                                            .getString();


                            if (
                                    commentText != null
                                    && !commentText.isBlank()
                            ) {

                                addFragment(
                                        fragments,

                                        "COMMENT",

                                        sheetName,

                                        reference,

                                        commentText
                                );
                            }
                        }
                    }
                }
            }
        }
    }


    /*
     * ============================================================
     * EXTRAER CONTENIDO WORD
     * ============================================================
     */

    private void extractWord(
            InputStream source,
            List<SearchFragmentInput> fragments
    ) throws Exception {

        try (
                InputStream input =
                        source;

                XWPFDocument document =
                        new XWPFDocument(
                                input
                        )
        ) {

            for (
                    XWPFParagraph paragraph :
                    document.getParagraphs()
            ) {

                if (
                        fragments.size()
                        >= MAX_FRAGMENTS_PER_DOCUMENT
                ) {

                    return;
                }


                String text =
                        paragraph.getText();


                if (
                        text != null
                        && !text.isBlank()
                ) {

                    addFragment(
                            fragments,

                            "WORD_PARAGRAPH",

                            null,

                            null,

                            text
                    );
                }
            }


            for (
                    XWPFTable table :
                    document.getTables()
            ) {

                for (
                        XWPFTableRow row :
                        table.getRows()
                ) {

                    for (
                            XWPFTableCell cell :
                            row.getTableCells()
                    ) {

                        if (
                                fragments.size()
                                >= MAX_FRAGMENTS_PER_DOCUMENT
                        ) {

                            return;
                        }


                        String text =
                                cell.getText();


                        if (
                                text != null
                                && !text.isBlank()
                        ) {

                            addFragment(
                                    fragments,

                                    "WORD_TABLE",

                                    null,

                                    null,

                                    text
                            );
                        }
                    }
                }
            }
        }
    }


    /*
     * ============================================================
     * AGREGAR FRAGMENTO
     * ============================================================
     */

    private void addFragment(
            List<SearchFragmentInput> fragments,
            String sourceType,
            String sheetName,
            String cellReference,
            String content
    ) {

        if (
                content == null
                || content.isBlank()
        ) {

            return;
        }


        if (
                fragments.size()
                >= MAX_FRAGMENTS_PER_DOCUMENT
        ) {

            return;
        }


        String normalized =
                normalizeText(
                        content
                );


        if (
                normalized.isBlank()
        ) {

            return;
        }


        fragments.add(
                new SearchFragmentInput(
                        sourceType,

                        sheetName,

                        cellReference,

                        content,

                        normalized
                )
        );
    }


    /*
     * ============================================================
     * INSERTAR FRAGMENTOS
     * ============================================================
     */

    private void insertFragments(
            ActiveDocument document,
            List<SearchFragmentInput> fragments
    ) {

        if (
                fragments.isEmpty()
        ) {

            return;
        }


        List<Object[]> batch =
                fragments
                        .stream()
                        .map(
                                fragment ->
                                        new Object[] {
                                                UUID.randomUUID(),

                                                document.documentId(),

                                                document.versionId(),

                                                fragment.sourceType(),

                                                fragment.sheetName(),

                                                fragment.cellReference(),

                                                fragment.content(),

                                                fragment.normalizedContent()
                                        }
                        )
                        .toList();


        jdbcTemplate.batchUpdate(
                """
                INSERT INTO document_search_fragment (
                    id,
                    document_id,
                    document_version_id,
                    source_type,
                    sheet_name,
                    cell_reference,
                    content,
                    normalized_content
                )

                VALUES (
                    ?, ?, ?, ?, ?, ?, ?, ?
                )
                """,

                batch
        );
    }


    /*
     * ============================================================
     * NORMALIZAR TEXTO
     * ============================================================
     */

    private String normalizeText(
            String value
    ) {

        if (
                value == null
        ) {

            return "";
        }


        String normalized =
                Normalizer.normalize(
                        value,
                        Normalizer.Form.NFD
                );


        return normalized
                .replaceAll(
                        "\\p{M}",
                        ""
                )
                .toLowerCase(
                        Locale.ROOT
                )
                .replaceAll(
                        "\\s+",
                        " "
                )
                .trim();
    }


    /*
     * ============================================================
     * CONTAR COINCIDENCIAS
     * ============================================================
     */

    private int countOccurrences(
            String content,
            String query
    ) {

        if (
                content == null
                || content.isBlank()
                || query.isBlank()
        ) {

            return 0;
        }


        int count =
                0;


        int position =
                0;


        while (true) {

            int found =
                    content.indexOf(
                            query,
                            position
                    );


            if (
                    found < 0
            ) {

                break;
            }


            count++;


            position =
                    found
                    + query.length();
        }


        return count;
    }


    /*
     * ============================================================
     * UBICACIÓN
     * ============================================================
     */

    private String buildLocation(
            SearchRow row
    ) {

        return switch (
                row.sourceType()
        ) {

            case "FILENAME" ->

                    "Nombre del archivo";


            case "SHEET" ->

                    row.sheetName() != null

                            ? "Hoja \""
                                + row.sheetName()
                                + "\""

                            : "Nombre de hoja";


            case "CELL" -> {

                if (
                        row.sheetName() != null
                        && row.cellReference() != null
                ) {

                    yield "Hoja \""
                            + row.sheetName()
                            + "\", celda "
                            + row.cellReference();
                }


                yield "Contenido de Excel";
            }


            case "COMMENT" -> {

                if (
                        row.sheetName() != null
                        && row.cellReference() != null
                ) {

                    yield "Comentario en hoja \""
                            + row.sheetName()
                            + "\", celda "
                            + row.cellReference();
                }


                yield "Comentario de Excel";
            }


            case "WORD_PARAGRAPH" ->

                    "Contenido del documento Word";


            case "WORD_TABLE" ->

                    "Tabla del documento Word";


            default ->

                    null;
        };
    }


    /*
     * ============================================================
     * RECORDS
     * ============================================================
     */

    private record ActiveDocument(
            UUID documentId,
            String documentName,
            String fileType,
            String indexStatus,
            UUID versionId,
            String originalFilename,
            int versionNumber,
            String storageKey
    ) {
    }


    private record SearchFragmentInput(
            String sourceType,
            String sheetName,
            String cellReference,
            String content,
            String normalizedContent
    ) {
    }


    private record SearchRow(
            UUID documentId,
            String documentName,
            String fileType,
            String areaSlug,
            String areaName,
            String sourceType,
            String sheetName,
            String cellReference,
            String normalizedContent
    ) {
    }


    private static class SearchAccumulator {

        private final UUID documentId;

        private final String documentName;

        private final String fileType;

        private final String areaSlug;

        private final String areaName;

        private final Set<String> locations =
                new LinkedHashSet<>();


        private int matchCount =
                0;


        private boolean filenameMatch =
                false;


        private SearchAccumulator(
                UUID documentId,
                String documentName,
                String fileType,
                String areaSlug,
                String areaName
        ) {

            this.documentId =
                    documentId;

            this.documentName =
                    documentName;

            this.fileType =
                    fileType;

            this.areaSlug =
                    areaSlug;

            this.areaName =
                    areaName;
        }


        private boolean isFilenameMatch() {

            return filenameMatch;
        }


        private Integer getMatchCount() {

            return matchCount;
        }


        private String getDocumentName() {

            return documentName;
        }


        private SearchResult toResult() {

            return new SearchResult(
                    documentId,

                    documentName,

                    fileType,

                    areaSlug,

                    areaName,

                    matchCount,

                    filenameMatch,

                    List.copyOf(
                            locations
                    )
            );
        }
    }


    public record SearchResult(
            UUID documentId,
            String documentName,
            String fileType,
            String areaSlug,
            String areaName,
            int matchCount,
            boolean filenameMatch,
            List<String> locations
    ) {
    }
}
