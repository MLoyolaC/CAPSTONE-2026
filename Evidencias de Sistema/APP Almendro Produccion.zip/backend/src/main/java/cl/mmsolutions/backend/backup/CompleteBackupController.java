package cl.mmsolutions.backend.backup;

import tools.jackson.databind.JsonNode;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;

@RestController
@RequestMapping("/api/admin/backup")
@PreAuthorize("@permissionService.isAdmin(authentication)")
public class CompleteBackupController {
    private final CompleteBackupService service;
    public CompleteBackupController(CompleteBackupService service) { this.service = service; }

    public record ExportRequest(String password, JsonNode browserSettings) { }

    @PostMapping(value = "/export", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<StreamingResponseBody> export(@RequestBody ExportRequest request) throws Exception {
        Path backup = service.exportBackup(request.password(), request.browserSettings());
        StreamingResponseBody stream = output -> {
            try (InputStream in = Files.newInputStream(backup)) { in.transferTo(output); }
            finally { service.removeExport(backup); }
        };
        String filename = "omm-respaldo-completo-" + LocalDate.now() + ".ommbackup";
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                .header(HttpHeaders.CACHE_CONTROL, "no-store")
                .contentLength(Files.size(backup))
                .body(stream);
    }

    @PostMapping(value = "/restore", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<CompleteBackupService.RestoreResult> restore(
            @RequestPart("file") MultipartFile file,
            @RequestPart("password") String password,
            @RequestPart("confirmation") String confirmation,
            HttpServletRequest request) {
        CompleteBackupService.RestoreResult result = service.restoreBackup(file, password, confirmation);
        if (request.getSession(false) != null) request.getSession(false).invalidate();
        return ResponseEntity.status(HttpStatus.OK).body(result);
    }
}
