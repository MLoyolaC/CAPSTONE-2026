package cl.mmsolutions.backend.workitem;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.security.access.prepost.PreAuthorize;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/work-items")
public class WorkItemController {

    private final WorkItemService workItemService;

    public WorkItemController(WorkItemService workItemService) {
        this.workItemService = workItemService;
    }

    @GetMapping
    @PreAuthorize("@permissionService.hasArea(authentication, #area)")
    public List<WorkItemResponse> list(
            @RequestParam String area,
            @RequestParam String type
    ) {
        return workItemService.list(area, type).stream().map(this::toResponse).toList();
    }


    @GetMapping("/duplicates")
    @PreAuthorize("@permissionService.has(authentication, 'create-edit')")
    public List<WorkItemResponse> duplicates(
            @RequestParam String title,
            @RequestParam(required = false) String location,
            @RequestParam(required = false) UUID excludeId
    ) {
        return workItemService.findDuplicates(title, location, excludeId).stream().map(this::toResponse).toList();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("@permissionService.hasArea(authentication, #request.areaSlug()) and @permissionService.has(authentication, 'create-edit')")
    public WorkItemResponse create(
            @RequestBody WorkItemRequest request,
            Authentication authentication
    ) {
        return toResponse(workItemService.create(request, username(authentication)));
    }

    @PutMapping("/{id}")
    @PreAuthorize("@permissionService.hasWorkItem(authentication, #id) and @permissionService.has(authentication, 'create-edit')")
    public WorkItemResponse update(
            @PathVariable UUID id,
            @RequestBody WorkItemRequest request,
            Authentication authentication
    ) {
        return toResponse(workItemService.update(id, request, username(authentication)));
    }

    @PatchMapping("/bulk-status")
    @PreAuthorize("@permissionService.hasArea(authentication, #request.areaSlug()) and @permissionService.has(authentication, 'create-edit')")
    public BulkStatusResponse bulkStatus(
            @RequestBody BulkStatusRequest request,
            Authentication authentication
    ) {
        WorkItemService.BulkStatusResult result = workItemService.bulkUpdateStatus(
                request.ids(),
                request.areaSlug(),
                request.status(),
                username(authentication)
        );
        return new BulkStatusResponse(
                result.operationId(),
                result.items().size(),
                result.items().stream().map(this::toResponse).toList()
        );
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @PreAuthorize("@permissionService.hasWorkItem(authentication, #id) and @permissionService.has(authentication, 'delete')")
    public void delete(
            @PathVariable UUID id,
            Authentication authentication
    ) {
        workItemService.delete(id, username(authentication));
    }

    private String username(Authentication authentication) {
        return authentication == null ? null : authentication.getName();
    }

    private WorkItemResponse toResponse(WorkItem workItem) {
        return new WorkItemResponse(
                workItem.getId(),
                workItem.getArea().getSlug(),
                workItem.getArea().getName(),
                workItem.getWorkType(),
                workItem.getPhase(),
                workItem.getPlannedYear(),
                workItem.getPlannedMonth(),
                workItem.getTitle(),
                workItem.getDescription(),
                workItem.getLocation(),
                workItem.getResponsibleName(),
                workItem.getPriority(),
                workItem.getStatus(),
                workItem.getScheduledStart(),
                workItem.getScheduledEnd(),
                workItem.getDisplayColor(),
                workItem.getTextColor(),
                workItem.getCompletedDate(),
                workItem.getProgressPercent(),
                workItem.getNotes(),
                workItem.getCategory(),
                workItem.getAssetName(),
                workItem.getFrequency(),
                workItem.getSeason(),
                workItem.getMaterials(),
                workItem.getSupplierName(),
                workItem.getEstimatedCost(),
                workItem.getActualCost(),
                workItem.getImportSourceFilename(),
                workItem.getSourceSheetName(),
                workItem.getSourceRowNumber(),
                workItem.getImportedData(),
                workItem.getCreatedAt(),
                workItem.getUpdatedAt(),
                workItem.getAssetId()
        );
    }

    public record WorkItemRequest(
            String areaSlug,
            String workType,
            String phase,
            Integer plannedYear,
            Integer plannedMonth,
            String title,
            String description,
            String location,
            String responsibleName,
            String priority,
            String status,
            LocalDate scheduledStart,
            LocalDate scheduledEnd,
            String displayColor,
            String textColor,
            BigDecimal progressPercent,
            String notes,
            String category,
            String assetName,
            String frequency,
            String season,
            String materials,
            String supplierName,
            BigDecimal estimatedCost,
            BigDecimal actualCost,
            String importedData,
            UUID assetId
    ) {}

    public record BulkStatusRequest(
            List<UUID> ids,
            String areaSlug,
            String status
    ) {}

    public record BulkStatusResponse(
            UUID operationId,
            int updatedCount,
            List<WorkItemResponse> items
    ) {}

    public record WorkItemResponse(
            UUID id,
            String areaSlug,
            String areaName,
            String workType,
            String phase,
            Integer plannedYear,
            Integer plannedMonth,
            String title,
            String description,
            String location,
            String responsibleName,
            String priority,
            String status,
            LocalDate scheduledStart,
            LocalDate scheduledEnd,
            String displayColor,
            String textColor,
            LocalDate completedDate,
            BigDecimal progressPercent,
            String notes,
            String category,
            String assetName,
            String frequency,
            String season,
            String materials,
            String supplierName,
            BigDecimal estimatedCost,
            BigDecimal actualCost,
            String importSourceFilename,
            String sourceSheetName,
            Integer sourceRowNumber,
            String importedData,
            OffsetDateTime createdAt,
            OffsetDateTime updatedAt,
            UUID assetId
    ) {}
}
