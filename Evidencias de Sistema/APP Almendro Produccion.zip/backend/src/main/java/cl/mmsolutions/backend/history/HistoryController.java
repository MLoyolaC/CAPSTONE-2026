package cl.mmsolutions.backend.history;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/history")
public class HistoryController {

    private final HistoryService historyService;

    public HistoryController(
            HistoryService historyService
    ) {
        this.historyService =
                historyService;
    }


    @GetMapping
    @PreAuthorize("@permissionService.has(authentication, 'history') and ((#areaSlug == null and #documentId == null) or (#areaSlug != null and @permissionService.hasArea(authentication, #areaSlug)) or (#documentId != null and @permissionService.hasDocument(authentication, #documentId)) or @permissionService.isAdmin(authentication))")
    public List<HistoryService.HistoryEntry>
    getHistory(

            @RequestParam(
                    required = false
            )
            String areaSlug,

            @RequestParam(
                    required = false
            )
            UUID documentId,

            Authentication authentication
    ) {

        return historyService.getHistory(
                areaSlug,
                documentId,
                authentication.getName()
        );
    }
}
