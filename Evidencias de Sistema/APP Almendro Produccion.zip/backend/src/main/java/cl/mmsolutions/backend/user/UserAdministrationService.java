package cl.mmsolutions.backend.user;

import cl.mmsolutions.backend.invitation.InvitationEmailService;
import cl.mmsolutions.backend.invitation.InvitationService;
import cl.mmsolutions.backend.security.Permissions;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

@Service
public class UserAdministrationService {
    private static final Logger log = LoggerFactory.getLogger(UserAdministrationService.class);
    private final AppUserRepository users;
    private final InvitationService invitations;
    private final InvitationEmailService emails;
    private final JdbcTemplate jdbc;

    public UserAdministrationService(AppUserRepository users, InvitationService invitations,
                                     InvitationEmailService emails, JdbcTemplate jdbc) {
        this.users = users;
        this.invitations = invitations;
        this.emails = emails;
        this.jdbc = jdbc;
    }

    @Transactional(readOnly = true)
    public List<UserView> list() {
        return users.findAll().stream().sorted(Comparator.comparing(AppUser::getUsername)).map(this::view).toList();
    }

    public SaveResult create(CreateUserRequest request) {
        AppUser saved = persistNew(request);
        return sendInvitation(saved);
    }

    @Transactional
    protected AppUser persistNew(CreateUserRequest request) {
        String username = normalizeUsername(request.username());
        String email = normalizeEmail(request.email());
        ensureUnique(null, username, email);
        AppUser user = new AppUser(username, request.fullName().trim(), email, request.role());
        user.updateProfile(request.fullName().trim(), email, request.role(), validatePermissions(request.permissions()));
        try {
            return users.saveAndFlush(user);
        } catch (DataIntegrityViolationException ex) {
            throw new DuplicateUserException("El nombre de usuario o correo ya está registrado.");
        }
    }

    @Transactional
    public UserView update(Long id, UpdateUserRequest request) {
        AppUser user = users.findById(id).orElseThrow(() -> new UserNotFoundException());
        if (isPrimaryAdministrator(user) && (request.role() != Role.ADMIN || !request.enabled())) {
            throw new ProtectedUserException(
                    "El administrador principal debe conservar su rol y permanecer habilitado.");
        }
        String username = normalizeUsername(request.username());
        String email = normalizeEmail(request.email());
        if (!username.equals(user.getUsername()) && user.getAccountStatus() != AccountStatus.PENDING_ACTIVATION) {
            throw new IllegalArgumentException("El nombre de usuario solo puede cambiar antes de activar la cuenta.");
        }
        ensureUnique(id, username, email);
        user.updateUsername(username);
        user.updateProfile(request.fullName().trim(), email, request.role(), validatePermissions(request.permissions()));
        user.setEnabledState(request.enabled());
        return view(users.saveAndFlush(user));
    }

    public SaveResult resend(Long id) {
        AppUser user = users.findById(id).orElseThrow(() -> new UserNotFoundException());
        return sendInvitation(user);
    }

    @Transactional
    public DeleteResult delete(Long id) {
        AppUser user = users.findByIdForUpdate(id).orElseThrow(UserNotFoundException::new);
        if (isPrimaryAdministrator(user)) {
            throw new ProtectedUserException("El administrador principal no puede eliminarse.");
        }
        try {
            jdbc.update("DELETE FROM document_edit_session WHERE user_id = ?", id);
            users.delete(user);
            users.flush();
            log.info("User identity deleted successfully for userId={}", id);
            return new DeleteResult(user.getFullName());
        } catch (RuntimeException ex) {
            log.error("User identity deletion failed for userId={}, exceptionType={}",
                    id, ex.getClass().getSimpleName(), ex);
            throw new UserDeletionException(ex);
        }
    }

    private SaveResult sendInvitation(AppUser user) {
        InvitationService.IssuedInvitation issued = invitations.issue(user.getId());
        try {
            emails.sendActivation(user, issued.rawToken(), issued.expirationHours());
            return new SaveResult(view(user), true, "Invitación enviada a Resend correctamente.");
        } catch (InvitationEmailService.EmailDeliveryException ex) {
            return new SaveResult(view(user), false,
                    "El perfil fue guardado, pero no fue posible enviar la invitación.");
        }
    }

    private void ensureUnique(Long currentId, String username, String email) {
        users.findByUsernameIgnoreCase(username).filter(user -> !user.getId().equals(currentId)).ifPresent(user -> {
            throw new DuplicateUserException("El nombre de usuario ya está registrado.");
        });
        users.findByEmailIgnoreCase(email).filter(user -> !user.getId().equals(currentId)).ifPresent(user -> {
            throw new DuplicateUserException("El correo electrónico ya está registrado.");
        });
    }

    private static Set<String> validatePermissions(Set<String> permissions) {
        if (permissions == null) return Set.of();
        if (!Permissions.ALL.containsAll(permissions)) throw new IllegalArgumentException("Hay permisos no reconocidos.");
        if (permissions.contains("manage-access") && !permissions.contains("configuracion")) {
            throw new IllegalArgumentException(
                    "Administrar accesos requiere también el permiso de Configuración.");
        }
        return Set.copyOf(permissions);
    }

    private static String normalizeUsername(String value) { return value.trim().toLowerCase(Locale.ROOT); }
    private static String normalizeEmail(String value) { return value.trim().toLowerCase(Locale.ROOT); }

    private UserView view(AppUser user) {
        Set<String> effective = user.getRole() == Role.ADMIN ? Permissions.ALL : Set.copyOf(user.getPermissions());
        return new UserView(user.getId(), user.getFullName(), user.getUsername(), user.getEmail(), user.getRole(),
                user.getAccountStatus(), user.isEnabled(), Set.copyOf(user.getPermissions()), effective,
                isPrimaryAdministrator(user));
    }

    private boolean isPrimaryAdministrator(AppUser user) {
        return user.getRole() == Role.ADMIN && users.findFirstByRoleOrderByIdAsc(Role.ADMIN)
                .map(primary -> primary.getId().equals(user.getId()))
                .orElse(false);
    }

    public record CreateUserRequest(
            @NotBlank @Size(max = 120) String fullName,
            @NotBlank @Pattern(regexp = "[a-zA-Z0-9._-]{3,50}") String username,
            @NotBlank @Email @Size(max = 254) String email,
            @NotNull Role role,
            Set<String> permissions) {}

    public record UpdateUserRequest(
            @NotBlank @Size(max = 120) String fullName,
            @NotBlank @Pattern(regexp = "[a-zA-Z0-9._-]{3,50}") String username,
            @NotBlank @Email @Size(max = 254) String email,
            @NotNull Role role,
            boolean enabled,
            Set<String> permissions) {}

    public record UserView(Long id, String fullName, String username, String email, Role role,
                           AccountStatus status, boolean enabled, Set<String> permissions,
                           Set<String> effectivePermissions, boolean primaryAdministrator) {}
    public record SaveResult(UserView user, boolean invitationSent, String message) {}
    public record DeleteResult(String fullName) {}

    public static class DuplicateUserException extends RuntimeException {
        public DuplicateUserException(String message) { super(message); }
    }
    public static class UserNotFoundException extends RuntimeException {}
    public static class ProtectedUserException extends RuntimeException {
        public ProtectedUserException(String message) { super(message); }
    }
    public static class UserDeletionException extends RuntimeException {
        public UserDeletionException(Throwable cause) { super(cause); }
    }
}
