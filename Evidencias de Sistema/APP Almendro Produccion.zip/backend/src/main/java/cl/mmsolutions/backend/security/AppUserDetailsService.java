package cl.mmsolutions.backend.security;

import cl.mmsolutions.backend.user.AppUser;
import cl.mmsolutions.backend.user.AppUserRepository;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;

@Service
public class AppUserDetailsService implements UserDetailsService {

    private final AppUserRepository userRepository;

    public AppUserDetailsService(AppUserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String username)
            throws UsernameNotFoundException {

        AppUser user = userRepository
                .findByUsernameIgnoreCase(username.trim())
                .orElseThrow(() ->
                        new UsernameNotFoundException("Credenciales inválidas")
                );

        ArrayList<String> authorities = new ArrayList<>();
        authorities.add("ROLE_" + user.getRole().name());
        (user.getRole() == cl.mmsolutions.backend.user.Role.ADMIN
                ? Permissions.ALL : user.getPermissions())
                .forEach(permission -> authorities.add("PERM_" + permission));

        return User.withUsername(user.getUsername())
                .password(user.getPasswordHash() == null ? "{noop}__pending_account__" : user.getPasswordHash())
                .authorities(authorities.toArray(String[]::new))
                .disabled(!user.isEnabled())
                .build();
    }
}
