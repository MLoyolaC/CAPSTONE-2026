package cl.mmsolutions.backend.operationalimport;

import cl.mmsolutions.backend.area.Area;
import cl.mmsolutions.backend.asset.AssetLinkService;
import cl.mmsolutions.backend.importing.ExcelDateSupport;
import cl.mmsolutions.backend.location.LocationService;
import cl.mmsolutions.backend.workitem.WorkItem;
import cl.mmsolutions.backend.workitem.WorkItemActivityService;
import cl.mmsolutions.backend.workitem.WorkItemRepository;
import cl.mmsolutions.backend.workitem.WorkItemService;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import tools.jackson.core.JacksonException;
import tools.jackson.databind.json.JsonMapper;

import java.io.InputStream;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

@Service
public class OperationalImportService {
    private final WorkItemRepository repository;
    private final WorkItemActivityService activity;
    private final cl.mmsolutions.backend.area.AreaRepository areaRepository;
    private final WorkItemService workItemService;
    private final LocationService locationService;
    private final JsonMapper jsonMapper;
    private final AssetLinkService assetLinkService;
    public OperationalImportService(
            WorkItemRepository repository,
            WorkItemActivityService activity,
            cl.mmsolutions.backend.area.AreaRepository areaRepository,
            WorkItemService workItemService,
            LocationService locationService,
            JsonMapper jsonMapper,
            AssetLinkService assetLinkService
    ){
        this.repository=repository;
        this.activity=activity;
        this.areaRepository=areaRepository;
        this.workItemService=workItemService;
        this.locationService=locationService;
        this.jsonMapper=jsonMapper;
        this.assetLinkService=assetLinkService;
    }

    @Transactional
    public ImportResult importFile(String slug, MultipartFile file, String username, boolean forceDuplicates){
        if(file==null||file.isEmpty()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Selecciona un archivo.");
        String name=Optional.ofNullable(file.getOriginalFilename()).orElse("archivo");
        String ext=extension(name);
        ParsedWorkbook parsed;
        try(InputStream in=file.getInputStream()){
            if("prevencion-riesgos".equals(slug) && "xlsx".equals(ext)) parsed=parsed(parsePrevention(in,name));
            else if("mantencion-jardineria".equals(slug) && "xlsx".equals(ext)) parsed=parsed(parseGardeningExcel(in,name));
            else if("mantencion-jardineria".equals(slug) && "docx".equals(ext)) parsed=parsed(parseGardeningDocx(in,name));
            else if(isFlexibleArea(slug) && Set.of("xlsx","xls").contains(ext)) parsed=parseFlexibleExcel(in,slug);
            else throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Formato no reconocido para esta área.");
        }catch(ResponseStatusException e){throw e;}catch(Exception e){throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"No fue posible interpretar el archivo: "+e.getMessage());}
        if(parsed.candidates().isEmpty()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"No se detectaron filas válidas para importar.");
        Area area=findArea(slug); int created=0,skipped=parsed.omitted();
        UUID operationId=UUID.randomUUID();
        List<DuplicateWarning> duplicates=new ArrayList<>();
        String type=workType(slug);
        for(Candidate c:parsed.candidates()){
            if(c.title()==null||c.title().isBlank()){skipped++;continue;}
            String key="OP|"+slug+"|"+normalize(name)+"|"+normalize(c.sheet())+"|"+c.row()+"|"+normalize(c.title());
            if(repository.existsBySourceKey(key)){skipped++;continue;}
            if(isFlexibleArea(slug)&&!forceDuplicates){
                List<WorkItem> matches=workItemService.findDuplicates(c.title(),c.location(),null).stream()
                        .filter(existing->type.equals(existing.getWorkType()))
                        .toList();
                if(!matches.isEmpty()){
                    WorkItem existing=matches.getFirst();
                    duplicates.add(new DuplicateWarning(c.title(),c.location(),existing.getId(),existing.getTitle(),existing.getLocation(),existing.getArea().getSlug()));
                    skipped++;
                    continue;
                }
            }
            String candidateLocation=c.location();
            if("mantencion-reactiva".equals(slug)&&candidateLocation!=null&&!candidateLocation.isBlank()){
                candidateLocation=locationService.canonicalizeOrRegister(slug,candidateLocation);
            }
            WorkItem item=new WorkItem(area,type,c.title().trim());
            item.update(c.title().trim(),c.description(),candidateLocation,c.responsible(),c.priority(),c.status(),c.start(),c.end(),c.progress(),c.notes(),c.category(),c.assetName(),c.frequency(),c.season(),c.materials(),null,null,c.actualCost(),c.importedData());
            if ("mantencion-maquinas".equals(slug)) {
                assetLinkService.findExactUniqueActive(c.assetName(), candidateLocation).ifPresent(asset -> {
                    item.setAssetReference(asset.id(), asset.name());
                });
            }
            item.setPlanningMetadata(c.phase(),c.plannedYear(),c.plannedMonth());
            item.setImportSource(name,c.sheet(),c.row(),key);
            if("COMPLETED".equals(c.status())) item.setImportedCompletedDate(c.end()!=null?c.end():c.start());
            repository.saveAndFlush(item);
            activity.record(item,username,"IMPORTED","Importado desde "+name+" · "+c.sheet(),List.of(),operationId);
            created++;
        }
        return new ImportResult(name,slug,operationId,parsed.detected(),created,skipped,parsed.errors().size(),duplicates.size(),summary(slug,parsed.candidates()),duplicates,parsed.errors());
    }

    private ParsedWorkbook parseFlexibleExcel(InputStream in,String slug) throws Exception{
        List<Candidate> candidates=new ArrayList<>();
        List<String> errors=new ArrayList<>();
        int detected=0,omitted=0,recognizedSheets=0;
        try(Workbook workbook=WorkbookFactory.create(in)){
            FormulaEvaluator evaluator=workbook.getCreationHelper().createFormulaEvaluator();
            DataFormatter formatter=new DataFormatter(new Locale("es","CL"));
            for(Sheet sheet:workbook){
                HeaderMapping header=findHeader(sheet,slug,formatter,evaluator);
                if(header==null) continue;
                recognizedSheets++;
                for(int rowIndex=header.rowIndex()+1;rowIndex<=sheet.getLastRowNum();rowIndex++){
                    Row row=sheet.getRow(rowIndex);
                    if(row==null||blankRow(row,formatter,evaluator)) continue;
                    if(repeatedHeader(row,header,formatter,evaluator)){omitted++;continue;}

                    EnumMap<ImportField,String> values=new EnumMap<>(ImportField.class);
                    for(ColumnBinding binding:header.columns()){
                        String value=cellText(row.getCell(binding.index()),formatter,evaluator);
                        if(value!=null&&!value.isBlank()) values.putIfAbsent(binding.field(),value.trim());
                    }
                    String asset=clean(values.get(ImportField.ASSET));
                    String description=clean(values.get(ImportField.DESCRIPTION));
                    String title=clean(values.get(ImportField.TITLE));
                    if(title==null&&"mantencion-maquinas".equals(slug)) title=asset;
                    if(title==null) title=description;
                    if(noiseTitle(title)){omitted++;continue;}

                    detected++;
                    if(title==null){
                        omitted++;
                        errors.add(sheet.getSheetName()+" · fila "+(rowIndex+1)+": falta un nombre, trabajo o equipo reconocible.");
                        continue;
                    }

                    LocalDate start=dateValue(row,header,ImportField.START_DATE,formatter,evaluator);
                    LocalDate end=dateValue(row,header,ImportField.END_DATE,formatter,evaluator);
                    if(start==null&&end!=null) start=end;
                    if(start!=null&&end!=null&&end.isBefore(start)){
                        omitted++;
                        errors.add(sheet.getSheetName()+" · fila "+(rowIndex+1)+": la fecha de término es anterior al inicio.");
                        continue;
                    }

                    String rawStatus=clean(values.get(ImportField.STATUS));
                    Map<String,String> metadata=new LinkedHashMap<>();
                    metadata.put("origen","Importación Excel flexible");
                    put(metadata,"marca",values.get(ImportField.BRAND));
                    put(metadata,"modelo",values.get(ImportField.MODEL));
                    put(metadata,"estadoOriginal",rawStatus);
                    String importedData=toJson(metadata);
                    String candidateDescription=Objects.equals(description,title)?null:description;

                    candidates.add(new Candidate(
                            title,candidateDescription,clean(values.get(ImportField.LOCATION)),clean(values.get(ImportField.RESPONSIBLE)),
                            mapPriority(values.get(ImportField.PRIORITY)),mapStatus(rawStatus,slug),start,end,BigDecimal.ZERO,
                            clean(values.get(ImportField.NOTES)),clean(values.get(ImportField.CATEGORY)),clean(values.get(ImportField.FREQUENCY)),
                            null,null,null,"Importación Excel",start==null?null:start.getYear(),start==null?null:start.getMonthValue(),
                            importedData,sheet.getSheetName(),rowIndex+1,null,asset
                    ));
                }
            }
        }
        if(recognizedSheets==0) errors.add("No se encontró una fila de encabezados con campos reconocibles.");
        return new ParsedWorkbook(candidates,detected,omitted,errors);
    }

    private HeaderMapping findHeader(Sheet sheet,String slug,DataFormatter formatter,FormulaEvaluator evaluator){
        HeaderMapping best=null;
        int bestScore=0;
        int last=Math.min(sheet.getLastRowNum(),50);
        for(int rowIndex=sheet.getFirstRowNum();rowIndex<=last;rowIndex++){
            Row row=sheet.getRow(rowIndex);if(row==null)continue;
            List<ColumnBinding> columns=new ArrayList<>();
            Set<ImportField> fields=EnumSet.noneOf(ImportField.class);
            for(int column=0;column<row.getLastCellNum();column++){
                String label=cellText(row.getCell(column),formatter,evaluator);
                ImportField field=fieldForHeader(label,slug);
                if(field!=null){columns.add(new ColumnBinding(column,field,label));fields.add(field);}
            }
            boolean primary=fields.contains(ImportField.TITLE)||fields.contains(ImportField.DESCRIPTION)
                    ||("mantencion-maquinas".equals(slug)&&fields.contains(ImportField.ASSET));
            int score=fields.size()*10+columns.size();
            if(primary&&fields.size()>=2&&score>bestScore){best=new HeaderMapping(rowIndex,columns);bestScore=score;}
        }
        return best;
    }

    private ImportField fieldForHeader(String label,String slug){
        String value=normalize(label);
        if(value.isBlank())return null;
        if(has(value,"realizado-por","responsable","encargado","tecnico","asignado"))return ImportField.RESPONSIBLE;
        if(has(value,"fecha-termino","fecha-fin","termino","vencimiento","fecha-final"))return ImportField.END_DATE;
        if(has(value,"fecha-inicio","inicio","fecha-programada","fecha-mantencion","fecha"))return ImportField.START_DATE;
        if(has(value,"ubicacion","habitacion","zona","area","sala","sector","lugar","dependencia"))return ImportField.LOCATION;
        if(has(value,"prioridad","urgencia"))return ImportField.PRIORITY;
        if(has(value,"estado","status","realizado","completado"))return ImportField.STATUS;
        if(has(value,"marca"))return ImportField.BRAND;
        if(has(value,"modelo"))return ImportField.MODEL;
        if(has(value,"frecuencia","periodicidad"))return ImportField.FREQUENCY;
        if(has(value,"tipo","categoria","clase"))return ImportField.CATEGORY;
        if(has(value,"observacion","observaciones","nota","notas","comentario","comentarios"))return ImportField.NOTES;
        if(has(value,"descripcion","detalle","detalle-trabajo"))return ImportField.DESCRIPTION;
        if(has(value,"maquina","equipo","nombre-maquina","nombre-equipo"))return ImportField.ASSET;
        if("mantencion-maquinas".equals(slug)&&has(value,"nombre"))return ImportField.ASSET;
        if(has(value,"nombre","trabajo","labor","tarea","mantencion","mantenimiento","incidencia","falla","problema","actividad","item"))return ImportField.TITLE;
        return null;
    }

    private LocalDate dateValue(Row row,HeaderMapping header,ImportField field,DataFormatter formatter,FormulaEvaluator evaluator){
        return header.columns().stream().filter(binding->binding.field()==field).map(binding->cellDate(row.getCell(binding.index()),formatter,evaluator)).filter(Objects::nonNull).findFirst().orElse(null);
    }

    private LocalDate cellDate(Cell cell,DataFormatter formatter,FormulaEvaluator evaluator){
        if(cell==null)return null;
        try{
            if(cell.getCellType()==CellType.NUMERIC&&DateUtil.isValidExcelDate(cell.getNumericCellValue()))return ExcelDateSupport.toLocalDate(cell.getNumericCellValue());
            if(cell.getCellType()==CellType.FORMULA){
                CellValue value=evaluator.evaluate(cell);
                if(value!=null&&value.getCellType()==CellType.NUMERIC&&DateUtil.isValidExcelDate(value.getNumberValue()))return ExcelDateSupport.toLocalDate(value.getNumberValue());
            }
        }catch(Exception ignored){}
        return parseDateText(cellText(cell,formatter,evaluator));
    }

    private static LocalDate parseDateText(String text){
        if(text==null||text.isBlank())return null;
        String value=text.trim();
        try{return LocalDate.parse(value);}catch(Exception ignored){}
        java.util.regex.Matcher match=java.util.regex.Pattern.compile("^(\\d{1,2})[/-](\\d{1,2})[/-](\\d{2}|\\d{4})$").matcher(value);
        if(!match.matches())return null;
        try{
            int year=Integer.parseInt(match.group(3));if(year<100)year+=2000;
            return LocalDate.of(year,Integer.parseInt(match.group(2)),Integer.parseInt(match.group(1)));
        }catch(Exception ignored){return null;}
    }

    private static String cellText(Cell cell,DataFormatter formatter,FormulaEvaluator evaluator){
        if(cell==null)return null;
        String value=formatter.formatCellValue(cell,evaluator);
        return value==null||value.trim().isEmpty()?null:value.trim();
    }

    private static boolean blankRow(Row row,DataFormatter formatter,FormulaEvaluator evaluator){
        for(int column=0;column<row.getLastCellNum();column++)if(cellText(row.getCell(column),formatter,evaluator)!=null)return false;
        return true;
    }

    private static boolean repeatedHeader(Row row,HeaderMapping header,DataFormatter formatter,FormulaEvaluator evaluator){
        long matches=header.columns().stream().filter(binding->normalize(binding.label()).equals(normalize(cellText(row.getCell(binding.index()),formatter,evaluator)))).count();
        return matches>=2;
    }

    private static boolean noiseTitle(String title){
        String value=normalize(title);
        return value.isBlank()||value.equals("total")||value.equals("totales")||value.startsWith("subtotal")
                ||value.equals("nota")||value.equals("notas")||value.equals("observaciones");
    }

    private static String mapPriority(String value){
        String normalized=normalize(value);
        if(has(normalized,"urgente","critica","critico"))return "URGENT";
        if(has(normalized,"alta","alto"))return "HIGH";
        if(has(normalized,"baja","bajo"))return "LOW";
        return "NORMAL";
    }

    private static String mapStatus(String value,String slug){
        String normalized=normalize(value);
        if(has(normalized,"completado","completada","realizado","realizada","finalizado","finalizada","listo","si","x"))return "COMPLETED";
        if(has(normalized,"cancelado","cancelada"))return "CANCELLED";
        if(has(normalized,"en-proceso","en-curso","iniciada","iniciado"))return "IN_PROGRESS";
        if(has(normalized,"atrasado","atrasada","vencido","vencida"))return "OVERDUE";
        if(has(normalized,"pendiente"))return "PENDING";
        return "mantencion-reactiva".equals(slug)?"PENDING":"PLANNED";
    }

    private String toJson(Map<String,String> values){
        try{return jsonMapper.writeValueAsString(values);}catch(JacksonException exception){throw new IllegalStateException("No fue posible conservar los metadatos importados.",exception);}
    }

    private static void put(Map<String,String> target,String key,String value){if(value!=null&&!value.isBlank())target.put(key,value.trim());}
    private static String clean(String value){return value==null||value.isBlank()?null:value.trim();}
    private static boolean has(String value,String... candidates){
        return Arrays.stream(candidates).anyMatch(candidate -> value.equals(candidate)
                || value.startsWith(candidate+"-")
                || value.endsWith("-"+candidate)
                || value.contains("-"+candidate+"-"));
    }
    private static boolean isFlexibleArea(String slug){return Set.of("mantencion-reactiva","mantencion-maquinas").contains(slug);}
    private static String workType(String slug){return switch(slug){case "prevencion-riesgos"->"PREVENTION";case "mantencion-jardineria"->"GARDENING";case "mantencion-reactiva"->"REACTIVE_MAINTENANCE";case "mantencion-maquinas"->"MACHINE_MAINTENANCE";default->throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Área no compatible con importación operacional.");};}
    private static ParsedWorkbook parsed(List<Candidate> candidates){return new ParsedWorkbook(candidates,candidates.size(),0,List.of());}

    private List<Candidate> parsePrevention(InputStream in,String filename) throws Exception{
        List<Candidate> out=new ArrayList<>();
        try(Workbook wb=WorkbookFactory.create(in)){
            Sheet ws=wb.getSheetAt(0); DataFormatter fmt=new DataFormatter();
            for(int r=9;r<=ws.getLastRowNum();r++){
                Row row=ws.getRow(r); if(row==null) continue;
                String id=text(row.getCell(1),fmt); String title=text(row.getCell(2),fmt); String resp=text(row.getCell(3),fmt);
                LocalDate start=date(row.getCell(4)); LocalDate end=date(row.getCell(5)); Double pct=number(row.getCell(7));
                if(title==null||title.isBlank()||"PROYECTOS".equalsIgnoreCase(title.trim())) continue;
                BigDecimal progress=BigDecimal.valueOf(pct==null?0:(pct<=1?pct*100:pct));
                String status=progress.compareTo(BigDecimal.valueOf(100))>=0?"COMPLETED":(start!=null&&start.isBefore(LocalDate.now())?"IN_PROGRESS":"PLANNED");
                out.add(new Candidate(title,"Actividad importada desde Carta Gantt de Prevención.","Hotel El Almendro",resp,"NORMAL",status,start,end,progress,null,"Prevención",null,null,null,null,"Prevención 2025",start==null?2025:start.getYear(),start==null?null:start.getMonthValue(),"PREVENCION|"+id,ws.getSheetName(),r+1,null,null));
            }
        }
        return out;
    }

    private List<Candidate> parseGardeningExcel(InputStream in,String filename) throws Exception{
        List<Candidate> out=new ArrayList<>();
        try(Workbook wb=WorkbookFactory.create(in)){
            DataFormatter fmt=new DataFormatter();
            for(Sheet ws:wb){
                String sn=ws.getSheetName();
                if(sn.equalsIgnoreCase("RIEGO Agua TRATADA")){
                    Map<String,List<String>> days=new LinkedHashMap<>();
                    Row dayRow=ws.getRow(1), zoneRow=ws.getRow(2);
                    if(dayRow!=null&&zoneRow!=null){for(int c=0;c<7;c++){String day=text(dayRow.getCell(c),fmt),zone=text(zoneRow.getCell(c),fmt);if(day!=null&&zone!=null)days.computeIfAbsent(zone,k->new ArrayList<>()).add(day);}}
                    String note=ws.getRow(5)==null?null:text(ws.getRow(5).getCell(0),fmt);
                    int idx=1; for(var e:days.entrySet()) out.add(new Candidate("Riego con agua tratada · "+prettyZone(e.getKey()),note,prettyZone(e.getKey()),null,"NORMAL","PLANNED",null,null,BigDecimal.ZERO,note,"Riego",String.join(", ",e.getValue()),"Todo el año",null,null,"Riego semanal",null,null,"RIEGO|"+e.getKey(),sn,idx++,null,null));
                    continue;
                }
                if(sn.equalsIgnoreCase("Trabajos Maestros")||sn.equalsIgnoreCase("CACHUREOS")) continue;
                String location=switch(sn){case "CENTRO"->"Centro de Eventos";case "HOTEL1"->"Hotel";case "PARCELA CASA"->"Parcela Casa";default->sn;};
                for(int r=1;r<=ws.getLastRowNum();r++){
                    Row row=ws.getRow(r); if(row==null) continue; String title=text(row.getCell(1),fmt); if(title==null||title.isBlank())continue;
                    Double pr=number(row.getCell(0)); String winter=text(row.getCell(3),fmt),summer=text(row.getCell(5),fmt);
                    String season=(mark(winter)&&mark(summer))?"Todo el año":mark(winter)?"Invierno/Otoño":mark(summer)?"Verano/Primavera":null;
                    String priority=pr!=null&&pr<=1?"HIGH":pr!=null&&pr>=3?"LOW":"NORMAL";
                    out.add(new Candidate(title,null,location,null,priority,"PLANNED",null,null,BigDecimal.ZERO,null,"Jardinería",null,season,null,null,"Plan jardinería 2024",2024,null,"JARDIN|"+sn+"|"+(r+1),sn,r+1,null,null));
                }
            }
        }
        return out;
    }

    private List<Candidate> parseGardeningDocx(InputStream in,String filename) throws Exception{
        List<Candidate> out=new ArrayList<>(); String section="General"; int row=0;
        try(XWPFDocument doc=new XWPFDocument(in)){
            for(XWPFParagraph p:doc.getParagraphs()){
                String t=p.getText()==null?"":p.getText().trim(); if(t.isBlank())continue;
                if(t.equalsIgnoreCase("CENTRO DE EVENTOS")||t.equalsIgnoreCase("HOTEL")||t.toUpperCase(Locale.ROOT).contains("PERMANENTE DURANTE LA SEMANA")){section=t;continue;}
                t=t.replaceFirst("^[~•\\-]+\\s*","").trim(); if(t.isBlank())continue; row++;
                String loc=section.equalsIgnoreCase("CENTRO DE EVENTOS")?"Centro de Eventos":section.equalsIgnoreCase("HOTEL")?"Hotel":"General";
                String freq=section.toUpperCase(Locale.ROOT).contains("PERMANENTE")?frequencyFromText(t):null;
                out.add(new Candidate(t,"Labor descrita en documento Labores Jardineros.",loc,null,"NORMAL","PLANNED",null,null,BigDecimal.ZERO,null,"Jardinería",freq,null,null,null,"Labores recurrentes",null,null,"JARDIN-DOCX|"+section+"|"+row,section,row,null,null));
            }
        }
        return out;
    }

    private Area findArea(String slug){
        return areaRepository.findAll().stream()
                .filter(a -> slug.equals(a.getSlug()) && a.isActive())
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"Área no encontrada: "+slug));
    }

    private static LocalDate date(Cell c){if(c==null)return null;try{if(c.getCellType()==CellType.NUMERIC&&DateUtil.isValidExcelDate(c.getNumericCellValue()))return ExcelDateSupport.toLocalDate(c.getNumericCellValue());if(c.getCellType()==CellType.FORMULA&&c.getCachedFormulaResultType()==CellType.NUMERIC&&DateUtil.isValidExcelDate(c.getNumericCellValue()))return ExcelDateSupport.toLocalDate(c.getNumericCellValue());}catch(Exception ignored){}return null;}
    private static Double number(Cell c){if(c==null)return null;try{if(c.getCellType()==CellType.NUMERIC)return c.getNumericCellValue();if(c.getCellType()==CellType.FORMULA&&c.getCachedFormulaResultType()==CellType.NUMERIC)return c.getNumericCellValue();String s=c.toString().replace("%","").replace(",",".").trim();return s.isBlank()?null:Double.parseDouble(s);}catch(Exception e){return null;}}
    private static String text(Cell c,DataFormatter f){if(c==null)return null;String v=f.formatCellValue(c);return v==null||v.trim().isEmpty()?null:v.trim();}
    private static boolean mark(String s){return s!=null&&!s.isBlank();}
    private static String extension(String n){int p=n.lastIndexOf('.');return p<0?"":n.substring(p+1).toLowerCase(Locale.ROOT);}
    private static String normalize(String s){return s==null?"":java.text.Normalizer.normalize(s,java.text.Normalizer.Form.NFD).replaceAll("\\p{M}","").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+","-").replaceAll("(^-|-$)","");}
    private static String prettyZone(String s){if(s==null)return "Sin ubicación";return switch(s.toUpperCase(Locale.ROOT)){case "PARCELA CASA"->"Parcela Casa";case "PARCELA HOTEL"->"Parcela Hotel";default->s;};}
    private static String frequencyFromText(String t){String u=t.toLowerCase(Locale.ROOT);List<String>d=new ArrayList<>();for(String x:List.of("lunes","martes","miércoles","jueves","viernes","sábado","domingo"))if(u.contains(x))d.add(x);return d.isEmpty()?"Permanente durante la semana":String.join(", ",d);}
    private static String summary(String slug,List<Candidate> candidates){
        if("prevencion-riesgos".equals(slug))return "Carta Gantt de Prevención: "+candidates.size()+" actividades reconocidas.";
        if("mantencion-reactiva".equals(slug))return "Mantención Reactiva: "+candidates.size()+" incidencias reconocidas.";
        if("mantencion-maquinas".equals(slug))return "Máquinas: "+candidates.size()+" equipos o mantenciones reconocidos.";
        long sectors=candidates.stream().map(Candidate::location).filter(Objects::nonNull).distinct().count();
        return "Jardinería: "+candidates.size()+" labores reconocidas en "+sectors+" sectores.";
    }

    public record ImportResult(String filename,String areaSlug,UUID batchId,int detected,int created,int skipped,int errors,int duplicateCount,String summary,List<DuplicateWarning> duplicates,List<String> warnings){}
    public record DuplicateWarning(String incomingTitle,String incomingLocation,UUID existingId,String existingTitle,String existingLocation,String areaSlug){}
    private record ParsedWorkbook(List<Candidate> candidates,int detected,int omitted,List<String> errors){}
    private record HeaderMapping(int rowIndex,List<ColumnBinding> columns){}
    private record ColumnBinding(int index,ImportField field,String label){}
    private enum ImportField {TITLE,ASSET,DESCRIPTION,LOCATION,RESPONSIBLE,START_DATE,END_DATE,STATUS,PRIORITY,CATEGORY,FREQUENCY,NOTES,BRAND,MODEL}
    private record Candidate(String title,String description,String location,String responsible,String priority,String status,LocalDate start,LocalDate end,BigDecimal progress,String notes,String category,String frequency,String season,String materials,BigDecimal actualCost,String phase,Integer plannedYear,Integer plannedMonth,String importedData,String sheet,int row,String source,String assetName){}
}
