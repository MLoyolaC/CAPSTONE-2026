package cl.mmsolutions.backend.document;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.UUID;

public interface DocumentStorageProvider {
    enum Kind { LOCAL, SUPABASE }

    Kind kind();

    String buildKey(UUID documentId, UUID versionId, String filename);

    StoredObject store(String key, InputStream input, long contentLength, String mimeType);

    InputStream open(String key) throws IOException;

    StorageMetadata metadata(String key);

    boolean exists(String key);

    void delete(String key);

    List<StoredObject> list();

    default boolean supportsFullRestore() { return false; }

    default StorageReplacement replaceAll(List<RestoreObject> objects) {
        throw new DocumentStorageException("La restauración completa no está disponible para este proveedor.");
    }

    default String databasePath(String key) { return key; }

    default String keyFromDatabase(String localPath, String cloudPath) {
        return kind() == Kind.LOCAL ? localPath : cloudPath;
    }

    default String backupPath(String key) {
        return key.startsWith("documents/") ? key.substring("documents/".length()) : key;
    }

    default String keyFromBackupPath(String path) {
        return kind() == Kind.SUPABASE ? "documents/" + path : path;
    }

    record StoredObject(String key, long size, String mimeType) {}

    record StorageMetadata(String key, long size, String mimeType) {}

    record RestoreObject(String path, long size, InputStreamSource source) {}

    @FunctionalInterface
    interface InputStreamSource {
        InputStream open() throws IOException;
    }

    interface StorageReplacement {
        void commit();
        void rollback();
    }
}
