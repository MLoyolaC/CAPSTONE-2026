package cl.mmsolutions.backend.improvements;

import cl.mmsolutions.backend.area.Area;
import cl.mmsolutions.backend.area.AreaRepository;
import cl.mmsolutions.backend.workitem.WorkItem;
import cl.mmsolutions.backend.workitem.WorkItemActivityService;
import cl.mmsolutions.backend.workitem.WorkItemRepository;
import org.apache.poi.ss.usermodel.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import tools.jackson.databind.json.JsonMapper;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.ResolverStyle;
import java.time.temporal.ChronoField;
import java.util.*;

@Service
public class ImprovementImportService {

    private static final Map<String,Integer> MONTHS = Map.ofEntries(
            Map.entry("enero",1), Map.entry("febrero",2), Map.entry("marzo",3), Map.entry("abril",4),
            Map.entry("mayo",5), Map.entry("junio",6), Map.entry("julio",7), Map.entry("agosto",8),
            Map.entry("septiembre",9), Map.entry("setiembre",9), Map.entry("octubre",10),
            Map.entry("noviembre",11), Map.entry("diciembre",12)
    );

    private final AreaRepository areaRepository;
    private final WorkItemRepository workItemRepository;
    private final WorkItemActivityService activityService;
    private final JsonMapper jsonMapper = JsonMapper.builder().build();

    public ImprovementImportService(AreaRepository areaRepository, WorkItemRepository workItemRepository,
                                    WorkItemActivityService activityService) {
        this.areaRepository = areaRepository;
        this.workItemRepository = workItemRepository;
        this.activityService = activityService;
    }

    public AnalysisResult analyze(MultipartFile file) {
        validateFile(file);
        byte[] bytes;
        try { bytes = file.getBytes(); }
        catch (IOException ex) { throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"No fue posible leer la planilla."); }

        String checksum = sha256(bytes);
        String filename = clean(file.getOriginalFilename());
        List<Candidate> candidates = new ArrayList<>();
        List<String> warnings = new ArrayList<>();

        try (InputStream input = file.getInputStream(); Workbook workbook = WorkbookFactory.create(input)) {
            DataFormatter formatter = new DataFormatter(new Locale("es","CL"));
            FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();

            for (int i=0; i<workbook.getNumberOfSheets(); i++) {
                Sheet sheet = workbook.getSheetAt(i);
                int before = candidates.size();
                if (parseGantt(sheet, formatter, evaluator, filename, candidates)) continue;
                parseIdeaBlocks(sheet, formatter, evaluator, filename, candidates);
                parseGoals(sheet, formatter, evaluator, filename, candidates);
                parseAnnualPlan(sheet, formatter, evaluator, filename, candidates);
                if (candidates.size()==before && hasMeaningfulContent(sheet,formatter,evaluator)) {
                    String normalizedSheet = normalize(sheet.getSheetName());
                    if (normalizedSheet.equals("resumen")) {
                        warnings.add("La hoja Resumen contiene fórmulas de ingresos/gastos con referencias eliminadas (#REF!); no existen montos confiables para importar.");
                    } else if (!normalizedSheet.equals("listas")) {
                        warnings.add("La hoja «"+sheet.getSheetName()+"» contiene información, pero no coincide con las estructuras de Proyectos, Metas, Plan Anual o Carta Gantt.");
                    }
                }
            }
        } catch (Exception ex) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"No fue posible analizar la estructura del Excel: "+safeMessage(ex));
        }

        LinkedHashMap<String,Candidate> unique = new LinkedHashMap<>();
        for (Candidate c: candidates) unique.putIfAbsent(c.sourceKey(), c);
        List<Candidate> result = unique.values().stream()
                .map(c -> c.withAlreadyImported(isAlreadyImported(filename, c)))
                .toList();

        Map<String,Long> byKind = new LinkedHashMap<>();
        for (Candidate c: result) byKind.merge(c.sourceKind(),1L,Long::sum);
        long pending = result.stream().filter(c -> !c.alreadyImported()).count();
        long historical = result.stream().filter(c -> "COMPLETED".equals(c.status())).count();
        return new AnalysisResult(filename, checksum, result.size(), pending, historical, byKind, result, warnings);
    }

    @Transactional
    public ImportResult commit(ImportRequest request, String username) {
        if (request==null || request.candidates()==null || request.candidates().isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"No hay registros seleccionados para incorporar.");
        }
        Area area = areaRepository.findAll().stream()
                .filter(a -> a.isActive() && "mejoras".equals(a.getSlug())).findFirst()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"Área Mejoras no encontrada."));
        int created=0, skipped=0;
        for (Candidate c: request.candidates()) {
            if (c==null || clean(c.title())==null) continue;
            if (isAlreadyImported(request.filename(), c)) { skipped++; continue; }
            String workType = "IMPROVEMENT_GANTT".equals(c.workType()) ? "IMPROVEMENT_GANTT" : "IMPROVEMENT";
            WorkItem item = new WorkItem(area, workType, c.title().trim());
            Map<String,Object> meta = new LinkedHashMap<>();
            meta.put("sourceKind", c.sourceKind());
            meta.put("sourceSection", c.sourceSection());
            meta.put("sourceSheet", c.sourceSheetName());
            meta.put("sourceRow", c.sourceRowNumber());
            meta.put("sourceColumn", c.sourceColumn());
            meta.put("originalText", c.originalText());
            meta.put("realizedDate", c.realizedDate());
            String importedData;
            try { importedData = jsonMapper.writeValueAsString(meta); } catch (Exception ex) { importedData=null; }

            BigDecimal progress = "IMPROVEMENT_GANTT".equals(workType)
                    ? (c.progressPercent()==null?BigDecimal.ZERO:c.progressPercent()) : BigDecimal.ZERO;
            item.update(c.title().trim(), clean(c.description()), clean(c.sector()), clean(c.responsibleName()),
                    "NORMAL", normalizeStatus(c.status()), parseIso(c.ideaDate()), parseIso(c.targetDate()), progress,
                    clean(c.notes()), clean(c.category()), null, clean(c.frequency()), null, clean(c.materials()),
                    clean(c.supplierName()), c.estimatedCost(), null, importedData);
            item.setPlanningMetadata(clean(c.phase()), c.targetYear(), c.targetMonth());
            if ("COMPLETED".equals(normalizeStatus(c.status()))) {
                LocalDate importedCompleted = parseIso(c.realizedDate());
                if (importedCompleted == null && "IMPROVEMENT_GANTT".equals(workType)) {
                    importedCompleted = parseIso(c.targetDate());
                }
                item.setImportedCompletedDate(importedCompleted);
            }
            item.setImportSource(clean(request.filename()), c.sourceSheetName(), c.sourceRowNumber(), c.sourceKey());
            WorkItem saved = workItemRepository.saveAndFlush(item);
            activityService.record(saved, username, "IMPORTED",
                    "Importó «"+saved.getTitle()+"» desde "+request.filename()+" · "+c.sourceSection()+".");
            created++;
        }
        return new ImportResult(created, skipped);
    }

    private boolean parseGantt(Sheet sheet, DataFormatter f, FormulaEvaluator e, String filename, List<Candidate> out) {
        for (Row header: sheet) {
            Map<Integer,String> cols = rowValues(header,f,e);
            Integer phase=findColumn(cols,"fase"), task=findColumn(cols,"tarea"), owner=findColumn(cols,"responsable");
            Integer start=findColumn(cols,"inicio"), days=findColumn(cols,"dias"), end=findColumn(cols,"fin");
            Integer progress=findContainsColumn(cols,"avance"), status=findColumn(cols,"estado");
            if (phase==null || task==null || start==null || end==null) continue;
            for (int r=header.getRowNum()+1;r<=sheet.getLastRowNum();r++) {
                Row row=sheet.getRow(r); if(row==null) continue;
                String title=text(row.getCell(task),f,e); if(blank(title)) continue;
                String phaseText=text(row.getCell(phase),f,e);
                String ownerText=owner==null?null:text(row.getCell(owner),f,e);
                String startDate=date(row.getCell(start),f,e), endDate=date(row.getCell(end),f,e);
                BigDecimal pct=parsePercent(progress==null?null:text(row.getCell(progress),f,e));
                String state=status==null?null:text(row.getCell(status),f,e);
                String key=sourceKey(filename,sheet.getSheetName(),r+1,task,title);
                out.add(new Candidate(key,"GANTT","Carta Gantt",sheet.getSheetName(),r+1,columnName(task),
                        "IMPROVEMENT_GANTT",phaseText,title,null,null,phaseText,ownerText,null,startDate,null,null,endDate,
                        ganttStatus(state),null,null,null,pct,state==null?null:"Estado original: "+state,null,title,"ALTA",true,false));
            }
            return true;
        }
        return false;
    }

    private void parseIdeaBlocks(Sheet sheet, DataFormatter f, FormulaEvaluator e, String filename, List<Candidate> out) {
        for (Row header: sheet) {
            Map<Integer,String> labels=rowValues(header,f,e);
            List<Integer> ideaCols=labels.entrySet().stream().filter(x->normalize(x.getValue()).contains("fecha de la idea")).map(Map.Entry::getKey).toList();
            if (ideaCols.isEmpty()) continue;
            for (Integer ideaCol:ideaCols) {
                int taskCol=ideaCol-1; if(taskCol<0) continue;
                String group=clean(labels.get(taskCol)); if(group==null) group="Proyectos pendientes";
                int realized=findRealizedDateColumn(labels,ideaCol+1,ideaCol+3);
                for(int r=header.getRowNum()+1;r<=sheet.getLastRowNum();r++) {
                    Row row=sheet.getRow(r); if(row==null) continue;
                    String title=text(row.getCell(taskCol),f,e); if(blank(title)||isHeaderLike(title)) continue;
                    String idea=date(row.getCell(ideaCol),f,e);
                    String done=realized<0?null:date(row.getCell(realized),f,e);
                    String section="Proyectos Pendientes · "+displayGroup(group);
                    String key=sourceKey(filename,sheet.getSheetName(),r+1,taskCol,title);
                    out.add(new Candidate(key,"POR_HACER",section,sheet.getSheetName(),r+1,columnName(taskCol),"IMPROVEMENT",null,
                            title,null,null,displayGroup(group),null,null,idea,null,null,null,done==null?"PLANNED":"COMPLETED",
                            null,null,null,BigDecimal.ZERO,done==null?null:"Realizado: "+done,done,title,"ALTA",true,false));
                }
            }
            return;
        }
    }

    private void parseGoals(Sheet sheet, DataFormatter f, FormulaEvaluator e, String filename, List<Candidate> out) {
        for(Row header:sheet){
            Map<Integer,String> values=rowValues(header,f,e);
            Integer month=findColumn(values,"mes"), task=findColumn(values,"tarea"), who=findContainsColumn(values,"quien la realiza");
            Integer freq=findColumn(values,"frecuencia"), done=findContainsColumn(values,"se esta realizando");
            boolean ongoingHeader = done != null;
            if(done==null) done=findContainsColumn(values,"se realizo");
            if(task==null || month==null) continue;
            String section=goalSection(sheet.getSheetName());
            if(section==null) return;
            for(int r=header.getRowNum()+1;r<=sheet.getLastRowNum();r++){
                Row row=sheet.getRow(r); if(row==null) continue;
                String title=text(row.getCell(task),f,e); if(blank(title)) continue;
                String monthText=text(row.getCell(month),f,e), responsible=who==null?null:text(row.getCell(who),f,e);
                String frequency=freq==null?null:text(row.getCell(freq),f,e), doneText=done==null?null:text(row.getCell(done),f,e);
                Integer targetMonth=monthFromFlexibleText(monthText);
                String key=sourceKey(filename,sheet.getSheetName(),r+1,task,title);
                out.add(new Candidate(key,"POR_HACER",section,sheet.getSheetName(),r+1,columnName(task),"IMPROVEMENT",null,
                        title,null,null,section,responsible,frequency,null,null,targetMonth,null,goalStatus(doneText,ongoingHeader),null,null,null,
                        BigDecimal.ZERO,joinNotes(monthText==null?null:"Mes original: "+monthText,doneText==null?null:"Estado original: "+doneText),
                        null,title,"ALTA",true,false));
            }
            return;
        }
    }

    private void parseAnnualPlan(Sheet sheet, DataFormatter f, FormulaEvaluator e, String filename, List<Candidate> out) {
        Integer year=parseYear(sheet.getSheetName()); if(year==null) return;
        for(int r=0;r<=sheet.getLastRowNum();r++){
            Row months=sheet.getRow(r); if(months==null) continue;
            Map<Integer,Integer> monthCols=monthColumns(months,f,e); if(monthCols.size()<6) continue;
            String sector=findSectorContext(sheet,r,f,e);
            int maxMonthCol=monthCols.keySet().stream().max(Integer::compareTo).orElse(12);
            for(int rr=r+1;rr<=sheet.getLastRowNum();rr++){
                Row row=sheet.getRow(rr); if(row==null) continue;
                if(monthColumns(row,f,e).size()>=6) break;
                String rowCategory=firstTextBefore(row,monthCols.keySet().stream().min(Integer::compareTo).orElse(1),f,e);
                if(rowCategory!=null && normalize(rowCategory).contains("proyectos pendientes")){
                    parsePendingProjects(sheet,rr+1,f,e,filename,out,sector,year,maxMonthCol);
                    break;
                }
                if(blank(rowCategory)) continue;
                for(var entry:monthCols.entrySet()){
                    String raw=text(row.getCell(entry.getKey()),f,e); if(blank(raw)||looksLikeBudgetOnly(raw)) continue;
                    List<String> tasks=splitAnnualCell(raw);
                    for(int ix=0;ix<tasks.size();ix++){
                        String title=tasks.get(ix);
                        String section="Plan Anual · "+(sector==null?"Sin sector":sector)+" · "+cleanCategory(rowCategory);
                        String key=sourceKey(filename,sheet.getSheetName(),rr+1,entry.getKey(),title+"#"+ix);
                        out.add(new Candidate(key,"ANNUAL_PLAN",section,sheet.getSheetName(),rr+1,columnName(entry.getKey()),"IMPROVEMENT",null,
                                title,null,sector,cleanCategory(rowCategory),null,null,null,year,entry.getValue(),null,"PLANNED",null,null,null,
                                BigDecimal.ZERO,"Plan anual "+year+" · "+(sector==null?"":sector),null,raw,"ALTA",true,false));
                    }
                }
            }
        }
    }

    private void parsePendingProjects(Sheet sheet,int start,DataFormatter f,FormulaEvaluator e,String filename,List<Candidate> out,
                                      String sector,Integer year,int maxCol){
        int blanks=0;
        for(int r=start;r<=sheet.getLastRowNum();r++){
            Row row=sheet.getRow(r); if(row==null){if(++blanks>=3)break;continue;}
            String title=text(row.getCell(0),f,e); if(blank(title)){if(++blanks>=3)break;continue;} blanks=0;
            BigDecimal budget=null;
            for(int c=1;c<=Math.min(maxCol,4);c++){budget=parseMoney(text(row.getCell(c),f,e));if(budget!=null)break;}
            String section="Plan Anual · Proyectos pendientes"+(sector==null?"":" · "+sector);
            String key=sourceKey(filename,sheet.getSheetName(),r+1,0,title);
            out.add(new Candidate(key,"ANNUAL_PLAN",section,sheet.getSheetName(),r+1,"A","IMPROVEMENT",null,title,null,sector,
                    "Proyecto pendiente",null,null,null,year,null,null,"PLANNED",null,null,budget,BigDecimal.ZERO,
                    "Listado pendiente en el plan "+year,null,title,"ALTA",true,false));
        }
    }

    private boolean isAlreadyImported(String filename, Candidate c) {
        if (workItemRepository.existsBySourceKey(c.sourceKey())) return true;
        return clean(filename) != null
                && clean(c.sourceSheetName()) != null
                && c.sourceRowNumber() != null
                && clean(c.title()) != null
                && workItemRepository.existsByImportSourceFilenameAndSourceSheetNameAndSourceRowNumberAndTitle(
                        clean(filename), clean(c.sourceSheetName()), c.sourceRowNumber(), clean(c.title()));
    }

    private String goalSection(String sheet){
        String n=normalize(sheet);
        if(n.contains("metas recepcion"))return "Metas Recepción";
        if(n.contains("metas obras"))return "Metas Obras";
        if(n.contains("metas jard"))return "Metas Jardinería";
        if(n.contains("meta marketing"))return "Metas Marketing";
        if(n.contains("metas oficina"))return "Metas Oficina";
        return null;
    }

    private String displayGroup(String raw){
        String n=normalize(raw);
        if(n.contains("elemento con maestros"))return "Elemento con maestros";
        if(n.contains("elemento mios"))return "Elementos propios";
        if(n.contains("posibles proyectos"))return "Posibles proyectos";
        if(n.contains("proyectos mantencion"))return "Proyectos mantención";
        if(n.contains("para eventos"))return "Para eventos";
        if(n.contains("trabajo electrico"))return "Trabajo eléctrico";
        if(n.contains("trabajo en fierro"))return "Trabajo en fierro";
        return raw==null?"Proyectos pendientes":raw.trim();
    }

    private String cleanCategory(String raw){return raw==null?null:raw.trim().replaceAll("\\s+"," ");}
    private List<String> splitAnnualCell(String raw){
        String[] parts=raw.split("(?:-{2,}|/{2,}|\\r?\\n)+");
        List<String> out=new ArrayList<>(); for(String p:parts){String c=clean(p);if(c!=null)out.add(c);} return out.isEmpty()?List.of(raw.trim()):out;
    }
    private String goalStatus(String raw, boolean ongoingHeader){
        String n=normalize(raw);
        if(n.equals("listo")) return "COMPLETED";
        if(n.contains("parte")||n.contains("mas o menos")) return "IN_PROGRESS";
        if(n.equals("si")) return ongoingHeader ? "IN_PROGRESS" : "COMPLETED";
        return "PLANNED";
    }
    private String ganttStatus(String raw){String n=normalize(raw);if(n.contains("complet"))return "COMPLETED";if(n.contains("atras"))return "OVERDUE";if(n.contains("curso"))return "IN_PROGRESS";return "PENDING";}
    private BigDecimal parsePercent(String raw){if(blank(raw))return BigDecimal.ZERO;try{String n=raw.replace("%","").replace(",",".").trim();BigDecimal v=new BigDecimal(n);if(v.compareTo(BigDecimal.ONE)<=0)v=v.multiply(BigDecimal.valueOf(100));return v.max(BigDecimal.ZERO).min(BigDecimal.valueOf(100));}catch(Exception ex){return BigDecimal.ZERO;}}
    private String joinNotes(String...parts){return Arrays.stream(parts).filter(Objects::nonNull).filter(x->!x.isBlank()).reduce((a,b)->a+" · "+b).orElse(null);}
    private String sourceKey(String filename,String sheet,int row,int col,String title){return "MEJORAS|"+normalize(filename)+"|"+normalize(sheet)+"|"+row+"|"+col+"|"+normalize(title);}
    private Map<Integer,String> rowValues(Row row,DataFormatter f,FormulaEvaluator e){Map<Integer,String> m=new LinkedHashMap<>();for(Cell c:row)m.put(c.getColumnIndex(),text(c,f,e));return m;}
    private Integer findColumn(Map<Integer,String> m,String wanted){String w=normalize(wanted);return m.entrySet().stream().filter(x->normalize(x.getValue()).equals(w)).map(Map.Entry::getKey).findFirst().orElse(null);}
    private Integer findContainsColumn(Map<Integer,String> m,String wanted){String w=normalize(wanted);return m.entrySet().stream().filter(x->normalize(x.getValue()).contains(w)).map(Map.Entry::getKey).findFirst().orElse(null);}
    private int findRealizedDateColumn(Map<Integer,String> m,int start,int end){for(int c=start;c<=end;c++)if(normalize(m.get(c)).contains("fecha que se realizo"))return c;return -1;}
    private Map<Integer,Integer> monthColumns(Row row,DataFormatter f,FormulaEvaluator e){Map<Integer,Integer> m=new LinkedHashMap<>();for(Cell c:row){Integer month=MONTHS.get(normalize(text(c,f,e)));if(month!=null)m.put(c.getColumnIndex(),month);}return m;}
    private String findSectorContext(Sheet sheet,int row,DataFormatter f,FormulaEvaluator e){for(int r=Math.max(0,row-3);r<=row;r++){Row x=sheet.getRow(r);if(x==null)continue;String all=String.join(" ",rowValues(x,f,e).values());String n=normalize(all);if(n.contains("centro de eventos"))return "Centro de Eventos";if(n.contains("hotel"))return "Hotel";}return null;}
    private String firstTextBefore(Row row,int end,DataFormatter f,FormulaEvaluator e){for(int c=0;c<end;c++){String v=text(row.getCell(c),f,e);if(!blank(v))return v.trim();}return null;}
    private Integer monthFromFlexibleText(String raw){String n=normalize(raw);for(var x:MONTHS.entrySet())if(n.contains(x.getKey()))return x.getValue();return null;}
    private Integer parseYear(String raw){return raw!=null&&raw.matches("20\\d{2}")?Integer.valueOf(raw):null;}
    private String date(Cell cell,DataFormatter f,FormulaEvaluator e){if(cell==null)return null;try{if(cell.getCellType()==CellType.NUMERIC){double n=cell.getNumericCellValue();if(DateUtil.isCellDateFormatted(cell)||(n>30000&&n<70000))return DateUtil.getLocalDateTime(n).toLocalDate().toString();}}catch(Exception ignored){}return parseFlexibleDate(text(cell,f,e));}
    private String parseFlexibleDate(String raw){if(blank(raw)||raw.trim().matches("\\d{4}"))return null;String v=raw.trim();List<DateTimeFormatter> formats=List.of(DateTimeFormatter.ofPattern("d-M-uuuu").withResolverStyle(ResolverStyle.STRICT),DateTimeFormatter.ofPattern("d/M/uuuu").withResolverStyle(ResolverStyle.STRICT),new DateTimeFormatterBuilder().appendPattern("d-M-").appendValueReduced(ChronoField.YEAR,2,2,2000).toFormatter().withResolverStyle(ResolverStyle.STRICT),new DateTimeFormatterBuilder().appendPattern("d-M.").appendValueReduced(ChronoField.YEAR,2,2,2000).toFormatter().withResolverStyle(ResolverStyle.STRICT));for(DateTimeFormatter fmt:formats)try{return LocalDate.parse(v,fmt).toString();}catch(Exception ignored){}return null;}
    private BigDecimal parseMoney(String raw){
        if(blank(raw)) return null;
        String n = raw.toLowerCase(Locale.ROOT)
                .replace("$", "")
                .replace("clp", "")
                .replace(" ", "")
                .trim();
        try {
            if(n.matches("\\d+(?:[.,]\\d+)?m")) {
                return new BigDecimal(n.substring(0,n.length()-1).replace(',','.'))
                        .multiply(BigDecimal.valueOf(1_000_000)).setScale(0,RoundingMode.HALF_UP);
            }
            if(n.matches("\\d+(?:[.,]\\d+)?mil")) {
                return new BigDecimal(n.substring(0,n.length()-3).replace(',','.'))
                        .multiply(BigDecimal.valueOf(1_000)).setScale(0,RoundingMode.HALF_UP);
            }
            String digits = n.replace(".", "").replace(",", "");
            if(digits.matches("\\d{4,}")) return new BigDecimal(digits);
        } catch(Exception ignored) {}
        return null;
    }
    private boolean looksLikeBudgetOnly(String v){return parseMoney(v)!=null&&v.trim().length()<=12;}
    private String text(Cell cell,DataFormatter f,FormulaEvaluator e){if(cell==null)return null;try{String v=f.formatCellValue(cell,e);return clean(v);}catch(Exception ex){return null;}}
    private boolean hasMeaningfulContent(Sheet sheet,DataFormatter f,FormulaEvaluator e){int count=0;for(Row r:sheet)for(Cell c:r)if(!blank(text(c,f,e))&&++count>=5)return true;return false;}
    private boolean isHeaderLike(String v){String n=normalize(v);return n.equals("tarea")||n.equals("mes")||n.startsWith("fecha de la idea");}
    private String normalizeStatus(String raw){return Set.of("PLANNED","PENDING","IN_PROGRESS","COMPLETED","OVERDUE","CANCELLED").contains(raw)?raw:"PLANNED";}
    private LocalDate parseIso(String raw){try{return blank(raw)?null:LocalDate.parse(raw);}catch(Exception ex){return null;}}
    private void validateFile(MultipartFile file){if(file==null||file.isEmpty())throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Selecciona una planilla Excel.");String n=Optional.ofNullable(file.getOriginalFilename()).orElse("").toLowerCase(Locale.ROOT);if(!n.endsWith(".xlsx")&&!n.endsWith(".xls"))throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"El archivo debe ser una planilla Excel.");}
    private String sha256(byte[] bytes){try{MessageDigest d=MessageDigest.getInstance("SHA-256");StringBuilder b=new StringBuilder();for(byte x:d.digest(bytes))b.append(String.format("%02x",x));return b.toString();}catch(NoSuchAlgorithmException ex){throw new IllegalStateException(ex);}}
    private String columnName(int index){int n=index+1;StringBuilder b=new StringBuilder();while(n>0){int r=(n-1)%26;b.insert(0,(char)('A'+r));n=(n-1)/26;}return b.toString();}
    private String clean(String v){if(v==null)return null;String t=v.trim();return t.isEmpty()?null:t;}
    private boolean blank(String v){return clean(v)==null;}
    private String normalize(String v){if(v==null)return "";return java.text.Normalizer.normalize(v.toLowerCase(Locale.ROOT),java.text.Normalizer.Form.NFD).replaceAll("\\p{M}+","").replaceAll("[^a-z0-9]+"," ").trim();}
    private String safeMessage(Exception ex){return ex.getMessage()==null?ex.getClass().getSimpleName():ex.getMessage();}

    public record Candidate(String sourceKey,String sourceKind,String sourceSection,String sourceSheetName,Integer sourceRowNumber,String sourceColumn,
                            String workType,String phase,String title,String description,String sector,String category,String responsibleName,String frequency,
                            String ideaDate,Integer targetYear,Integer targetMonth,String targetDate,String status,String supplierName,String materials,
                            BigDecimal estimatedCost,BigDecimal progressPercent,String notes,String realizedDate,String originalText,String confidence,
                            boolean recommended,boolean alreadyImported){
        Candidate withAlreadyImported(boolean value){return new Candidate(sourceKey,sourceKind,sourceSection,sourceSheetName,sourceRowNumber,sourceColumn,workType,phase,title,description,sector,category,responsibleName,frequency,ideaDate,targetYear,targetMonth,targetDate,status,supplierName,materials,estimatedCost,progressPercent,notes,realizedDate,originalText,confidence,recommended,value);}
    }
    public record AnalysisResult(String filename,String checksum,int candidateCount,long pendingCount,long historicalCount,Map<String,Long> byKind,List<Candidate> candidates,List<String>warnings){}
    public record ImportRequest(String filename,List<Candidate> candidates){}
    public record ImportResult(int created,int skipped){}
}
