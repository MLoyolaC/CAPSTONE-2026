package cl.mmsolutions.backend.settings;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.http.CacheControl;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;
import java.util.concurrent.TimeUnit;

@RestController
@RequestMapping("/api/account")
public class AccountSettingsController {
    private final AccountSettingsService service;

    public AccountSettingsController(AccountSettingsService service) { this.service = service; }

    @PatchMapping("/email")
    public Map<String, String> updateEmail(@Valid @RequestBody EmailRequest request, Authentication auth) {
        return Map.of("email", service.updateEmail(auth.getName(), request.email()));
    }

    @PutMapping("/avatar/preset")
    public AccountSettingsService.AvatarState preset(@RequestBody PresetRequest request, Authentication auth) {
        return service.choosePreset(auth.getName(), request.preset());
    }

    @PostMapping(path = "/avatar/image", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public AccountSettingsService.AvatarState image(@RequestPart("file") MultipartFile file, Authentication auth) {
        return service.upload(auth.getName(), file);
    }

    @GetMapping("/avatar")
    public ResponseEntity<byte[]> avatar(Authentication auth) {
        AccountSettingsService.StoredImage image = service.avatar(auth.getName());
        return ResponseEntity.ok().contentType(MediaType.parseMediaType(image.mime()))
                .cacheControl(CacheControl.maxAge(5, TimeUnit.MINUTES).cachePrivate())
                .body(image.bytes());
    }

    public record EmailRequest(@NotBlank @Email @Size(max = 254) String email) {}
    public record PresetRequest(String preset) {}
}
