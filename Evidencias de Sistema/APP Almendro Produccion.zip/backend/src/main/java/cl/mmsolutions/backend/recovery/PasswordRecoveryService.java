package cl.mmsolutions.backend.recovery;

import cl.mmsolutions.backend.invitation.InvitationEmailService;
import cl.mmsolutions.backend.security.PasswordPolicy;
import cl.mmsolutions.backend.user.AccountStatus;
import cl.mmsolutions.backend.user.AppUser;
import cl.mmsolutions.backend.user.AppUserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.OffsetDateTime;
import java.util.Base64;
import java.util.HexFormat;
import java.util.Locale;

@Service
public class PasswordRecoveryService {
    private static final Logger log = LoggerFactory.getLogger(PasswordRecoveryService.class);
    private static final String NEUTRAL_MESSAGE =
            "Si existe una cuenta activa asociada, recibirás un código para restablecer la contraseña.";
    private static final String INVALID_CODE = "El código no es válido o ya no está disponible.";

    private final PasswordRecoveryRepository requests;
    private final AppUserRepository users;
    private final PasswordEncoder passwordEncoder;
    private final InvitationEmailService emails;
    private final SessionRegistry sessions;
    private final SecureRandom random = new SecureRandom();
    private final int expirationMinutes;
    private final int maximumAttempts;
    private final int cooldownSeconds;

    public PasswordRecoveryService(
            PasswordRecoveryRepository requests,
            AppUserRepository users,
            PasswordEncoder passwordEncoder,
            InvitationEmailService emails,
            SessionRegistry sessions,
            @Value("${app.password-recovery.expiration-minutes:15}") int expirationMinutes,
            @Value("${app.password-recovery.maximum-attempts:5}") int maximumAttempts,
            @Value("${app.password-recovery.cooldown-seconds:60}") int cooldownSeconds) {
        this.requests = requests;
        this.users = users;
        this.passwordEncoder = passwordEncoder;
        this.emails = emails;
        this.sessions = sessions;
        this.expirationMinutes = Math.max(10, Math.min(15, expirationMinutes));
        this.maximumAttempts = Math.max(3, Math.min(10, maximumAttempts));
        this.cooldownSeconds = Math.max(30, Math.min(300, cooldownSeconds));
        log.info("Password recovery configured: expirationMinutes={}, maximumAttempts={}, cooldownSeconds={}",
                this.expirationMinutes, this.maximumAttempts, this.cooldownSeconds);
    }

    @Transactional
    public RequestResult request(String email) {
        String normalized = normalizeEmail(email);
        AppUser candidate = users.findByEmailIgnoreCase(normalized).orElse(null);
        if (candidate == null) return neutralResult();

        AppUser user = users.findByIdForUpdate(candidate.getId()).orElse(null);
        if (!canRecover(user, normalized)) return neutralResult();

        OffsetDateTime now = OffsetDateTime.now();
        PasswordRecoveryRequest current = requests
                .findFirstByUserIdOrderByCreatedAtDesc(user.getId())
                .orElse(null);
        if (current != null && current.getCreatedAt() != null
                && current.getCreatedAt().plusSeconds(cooldownSeconds).isAfter(now)) {
            return neutralResult();
        }

        requests.invalidateOpenForUser(user.getId(), now);
        String code = "%06d".formatted(random.nextInt(1_000_000));
        PasswordRecoveryRequest recovery = requests.saveAndFlush(new PasswordRecoveryRequest(
                user, passwordEncoder.encode(code), now.plusMinutes(expirationMinutes)));
        try {
            emails.sendPasswordRecovery(user, code, expirationMinutes);
        } catch (InvitationEmailService.EmailDeliveryException ex) {
            recovery.invalidate(now);
            requests.save(recovery);
            log.warn("Password recovery email could not be delivered for userId={}", user.getId());
        }
        return neutralResult();
    }

    @Transactional
    public VerificationResult verify(String email, String code) {
        String normalized = normalizeEmail(email);
        AppUser candidate = users.findByEmailIgnoreCase(normalized).orElseThrow(() -> new RecoveryException(INVALID_CODE));
        AppUser user = users.findByIdForUpdate(candidate.getId()).orElseThrow(() -> new RecoveryException(INVALID_CODE));
        if (!canRecover(user, normalized)) throw new RecoveryException(INVALID_CODE);

        OffsetDateTime now = OffsetDateTime.now();
        PasswordRecoveryRequest recovery = requests
                .findFirstByUserIdAndUsedAtIsNullAndInvalidatedAtIsNullOrderByCreatedAtDesc(user.getId())
                .orElseThrow(() -> new RecoveryException(INVALID_CODE));
        if (!recovery.isCodeUsable(now, maximumAttempts)) {
            recovery.invalidate(now);
            throw new RecoveryException(INVALID_CODE);
        }
        if (code == null || !code.matches("\\d{6}") || !passwordEncoder.matches(code, recovery.getCodeHash())) {
            recovery.failAttempt(now, maximumAttempts);
            throw new RecoveryException(INVALID_CODE);
        }

        byte[] tokenBytes = new byte[48];
        random.nextBytes(tokenBytes);
        String rawToken = Base64.getUrlEncoder().withoutPadding().encodeToString(tokenBytes);
        recovery.verify(now, sha256(rawToken));
        requests.save(recovery);
        return new VerificationResult(rawToken, recovery.getExpiresAt());
    }

    @Transactional
    public void reset(String resetToken, String password, String confirmation) {
        try {
            PasswordPolicy.validate(password, confirmation);
        } catch (PasswordPolicy.PasswordPolicyException ex) {
            throw new RecoveryException(ex.getMessage());
        }
        if (resetToken == null || resetToken.isBlank() || resetToken.length() > 200) {
            throw new RecoveryException("La autorización para restablecer la contraseña no es válida.");
        }

        OffsetDateTime now = OffsetDateTime.now();
        PasswordRecoveryRequest recovery = requests.findByResetTokenHashForUpdate(sha256(resetToken))
                .orElseThrow(() -> new RecoveryException("La autorización para restablecer la contraseña no es válida."));
        AppUser user = recovery.getUser();
        if (!recovery.isResetUsable(now) || !canRecover(user, user.getEmail())) {
            recovery.invalidate(now);
            throw new RecoveryException("La autorización para restablecer la contraseña expiró o ya fue utilizada.");
        }

        user.resetPassword(passwordEncoder.encode(password));
        recovery.use(now);
        requests.invalidateOpenForUser(user.getId(), now);
        users.save(user);
        requests.save(recovery);
        expireSessions(user.getUsername());
    }

    private boolean canRecover(AppUser user, String normalizedEmail) {
        return user != null && user.isEnabled() && user.getAccountStatus() == AccountStatus.ACTIVE
                && user.getPasswordHash() != null && user.getEmail() != null
                && user.getEmail().trim().toLowerCase(Locale.ROOT).equals(normalizedEmail);
    }

    private RequestResult neutralResult() {
        return new RequestResult(NEUTRAL_MESSAGE, cooldownSeconds);
    }

    private void expireSessions(String username) {
        sessions.getAllPrincipals().stream()
                .filter(principal -> principal instanceof UserDetails details
                        && details.getUsername().equalsIgnoreCase(username))
                .flatMap(principal -> sessions.getAllSessions(principal, false).stream())
                .forEach(session -> session.expireNow());
    }

    private static String normalizeEmail(String email) {
        return email == null ? "" : email.trim().toLowerCase(Locale.ROOT);
    }

    private static String sha256(String value) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256")
                    .digest(value.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException ex) {
            throw new IllegalStateException(ex);
        }
    }

    public record RequestResult(String message, int cooldownSeconds) {}
    public record VerificationResult(String resetToken, OffsetDateTime expiresAt) {}

    public static class RecoveryException extends RuntimeException {
        public RecoveryException(String message) { super(message); }
    }
}
