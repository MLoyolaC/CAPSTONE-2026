package cl.mmsolutions.backend.workitem;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.Locale;
import java.util.regex.Pattern;

public final class DisplayColorValidator {

    private static final Pattern HEX_COLOR = Pattern.compile("^#[0-9A-Fa-f]{6}$");

    private DisplayColorValidator() {}

    public static String normalize(String value) {
        if (value == null || value.isBlank()) return null;
        String trimmed = value.trim();
        if (!HEX_COLOR.matcher(trimmed).matches()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "El color de identificación debe usar el formato #RRGGBB."
            );
        }
        return trimmed.toUpperCase(Locale.ROOT);
    }
}
