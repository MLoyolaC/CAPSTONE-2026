package cl.mmsolutions.backend.workitem;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import tools.jackson.core.JacksonException;
import tools.jackson.databind.json.JsonMapper;

import java.util.List;
import java.util.UUID;

@Service
public class WorkItemActivityService {

    private final JdbcTemplate jdbcTemplate;
    private final JsonMapper objectMapper;

    public WorkItemActivityService(JdbcTemplate jdbcTemplate, JsonMapper objectMapper) {
        this.jdbcTemplate = jdbcTemplate;
        this.objectMapper = objectMapper;
    }

    public void record(WorkItem item, String username, String action, String details) {
        record(item, username, action, details, List.of(), null);
    }

    public void record(
            WorkItem item,
            String username,
            String action,
            String details,
            List<WorkItemAuditChange> changes,
            UUID operationId
    ) {
        if (item == null || item.getArea() == null) return;

        UserSnapshot user = findUser(username);
        String changesJson = serializeChanges(changes);

        jdbcTemplate.update(
                """
                INSERT INTO work_item_activity (
                    id, work_item_id, area_id, user_id,
                    username_snapshot, role_snapshot,
                    work_type, item_title, action, details,
                    operation_id, changes
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?::jsonb)
                """,
                UUID.randomUUID(),
                item.getId(),
                item.getArea().getId(),
                user.id(),
                user.username(),
                user.role(),
                item.getWorkType(),
                item.getTitle(),
                action,
                details,
                operationId,
                changesJson
        );
    }

    private String serializeChanges(List<WorkItemAuditChange> changes) {
        try {
            return objectMapper.writeValueAsString(changes == null ? List.of() : changes);
        } catch (JacksonException exception) {
            throw new IllegalStateException("No se pudo serializar el detalle de auditoría.", exception);
        }
    }

    private UserSnapshot findUser(String username) {
        if (username == null || username.isBlank()) {
            return new UserSnapshot(null, null, null);
        }

        return jdbcTemplate.query(
                "SELECT id, username, role FROM app_user WHERE username = ?",
                rs -> rs.next()
                        ? new UserSnapshot(rs.getLong("id"), rs.getString("username"), rs.getString("role"))
                        : new UserSnapshot(null, username, null),
                username
        );
    }

    private record UserSnapshot(Long id, String username, String role) {}
}
