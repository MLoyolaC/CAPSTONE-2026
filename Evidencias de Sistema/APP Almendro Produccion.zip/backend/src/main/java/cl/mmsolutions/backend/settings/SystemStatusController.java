package cl.mmsolutions.backend.settings;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class SystemStatusController {
    private final JdbcTemplate jdbc;
    private final String resendApiKey;
    private final String fromEmail;

    public SystemStatusController(JdbcTemplate jdbc,
                                  @Value("${app.resend.api-key:}") String resendApiKey,
                                  @Value("${app.resend.from-email:}") String fromEmail) {
        this.jdbc = jdbc;
        this.resendApiKey = resendApiKey;
        this.fromEmail = fromEmail;
    }

    @GetMapping("/api/system/status")
    public SystemStatus status() {
        String database;
        try {
            database = Integer.valueOf(1).equals(jdbc.queryForObject("SELECT 1", Integer.class)) ? "AVAILABLE" : "UNAVAILABLE";
        } catch (RuntimeException ex) {
            database = "UNAVAILABLE";
        }
        String email = resendApiKey.isBlank() || fromEmail.isBlank() ? "CONFIGURATION_PENDING" : "AVAILABLE";
        return new SystemStatus(database, email, fromEmail.isBlank() ? null : fromEmail);
    }

    public record SystemStatus(String database, String email, String emailSender) {}
}
