package cl.mmsolutions.backend.document;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.json.JsonMapper;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.List;
import java.util.UUID;

@Service
@ConditionalOnProperty(name = "app.documents.storage-provider", havingValue = "supabase")
public class SupabaseDocumentStorageProvider implements DocumentStorageProvider {
    private static final int PAGE_SIZE = 1000;

    private final HttpClient http;
    private final JsonMapper json;
    private final URI storageBase;
    private final String bucket;
    private final String secretKey;
    private volatile boolean privateBucketVerified;

    @Autowired
    public SupabaseDocumentStorageProvider(
            @Value("${app.documents.supabase-url:}") String supabaseUrl,
            @Value("${app.documents.supabase-bucket:omm-documents}") String bucket,
            @Value("${app.documents.supabase-secret-key:}") String secretKey,
            JsonMapper json
    ) {
        this(supabaseUrl, bucket, secretKey, json, HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(15)).build());
    }

    SupabaseDocumentStorageProvider(String supabaseUrl, String bucket, String secretKey, JsonMapper json, HttpClient http) {
        if (supabaseUrl == null || supabaseUrl.isBlank()) throw new IllegalStateException("SUPABASE_URL es obligatoria para storage Supabase.");
        if (bucket == null || !bucket.matches("[a-z0-9][a-z0-9._-]{2,62}")) throw new IllegalStateException("El bucket de Supabase Storage no es válido.");
        if (secretKey == null || secretKey.isBlank()) throw new IllegalStateException("SUPABASE_SECRET_KEY es obligatoria para storage Supabase.");
        String base = supabaseUrl.replaceAll("/+$", "") + "/storage/v1";
        this.storageBase = URI.create(base);
        this.bucket = bucket;
        this.secretKey = secretKey;
        this.json = json;
        this.http = http;
    }

    @Override public Kind kind() { return Kind.SUPABASE; }

    @Override
    public String buildKey(UUID documentId, UUID versionId, String filename) {
        if (filename == null || filename.isBlank() || filename.contains("/") || filename.contains("\\")) {
            throw new DocumentStorageException("Nombre de archivo inválido.");
        }
        return "documents/" + documentId + "/" + versionId + "/" + filename;
    }

    @Override
    public StoredObject store(String key, InputStream input, long contentLength, String mimeType) {
        ensurePrivateBucket();
        validateKey(key);
        HttpRequest request = authenticated(uploadUri(key))
                .timeout(Duration.ofMinutes(2))
                .header("Content-Type", mimeType)
                .header("x-upsert", "false")
                .POST(HttpRequest.BodyPublishers.ofInputStream(() -> input))
                .build();
        try (input) {
            HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString());
            requireSuccess(response.statusCode(), "guardar");
            return new StoredObject(key, contentLength, mimeType);
        } catch (IOException exception) {
            throw new DocumentStorageException("No fue posible guardar el documento en Supabase Storage.", exception);
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new DocumentStorageException("La carga a Supabase Storage fue interrumpida.", exception);
        }
    }

    @Override
    public InputStream open(String key) throws IOException {
        ensurePrivateBucket();
        validateKey(key);
        HttpRequest request = authenticated(downloadUri(key)).timeout(Duration.ofMinutes(2)).GET().build();
        try {
            HttpResponse<InputStream> response = http.send(request, HttpResponse.BodyHandlers.ofInputStream());
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                response.body().close();
                throw new DocumentStorageException("Supabase Storage rechazó la lectura del documento (HTTP " + response.statusCode() + ").");
            }
            return response.body();
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new IOException("La lectura desde Supabase Storage fue interrumpida.", exception);
        }
    }

    @Override
    public StorageMetadata metadata(String key) {
        ensurePrivateBucket();
        validateKey(key);
        HttpRequest request = authenticated(downloadUri(key)).timeout(Duration.ofSeconds(30)).GET().build();
        try {
            HttpResponse<InputStream> response = http.send(request, HttpResponse.BodyHandlers.ofInputStream());
            response.body().close();
            requireSuccess(response.statusCode(), "consultar");
            long size = response.headers().firstValueAsLong("content-length").orElse(-1L);
            String mime = response.headers().firstValue("content-type").orElse("application/octet-stream");
            return new StorageMetadata(key, size, mime);
        } catch (IOException exception) {
            throw new DocumentStorageException("No fue posible consultar el documento en Supabase Storage.", exception);
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new DocumentStorageException("La consulta a Supabase Storage fue interrumpida.", exception);
        }
    }

    @Override
    public boolean exists(String key) {
        ensurePrivateBucket();
        validateKey(key);
        HttpRequest request = authenticated(downloadUri(key)).timeout(Duration.ofSeconds(30)).GET().build();
        try {
            HttpResponse<InputStream> response = http.send(request, HttpResponse.BodyHandlers.ofInputStream());
            response.body().close();
            if (response.statusCode() == 404) return false;
            requireSuccess(response.statusCode(), "consultar existencia");
            return true;
        } catch (IOException exception) {
            throw new DocumentStorageException("No fue posible comprobar el documento en Supabase Storage.", exception);
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new DocumentStorageException("La consulta a Supabase Storage fue interrumpida.", exception);
        }
    }

    @Override
    public void delete(String key) {
        ensurePrivateBucket();
        validateKey(key);
        String body = "{\"prefixes\":[\"" + jsonEscape(key) + "\"]}";
        HttpRequest request = authenticated(uri("/object/" + encodeSegment(bucket))).timeout(Duration.ofSeconds(30))
                .header("Content-Type", "application/json")
                .method("DELETE", HttpRequest.BodyPublishers.ofString(body)).build();
        try {
            HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() != 404) requireSuccess(response.statusCode(), "eliminar");
        } catch (IOException exception) {
            throw new DocumentStorageException("No fue posible eliminar el documento de Supabase Storage.", exception);
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new DocumentStorageException("La eliminación en Supabase Storage fue interrumpida.", exception);
        }
    }

    @Override
    public List<StoredObject> list() {
        ensurePrivateBucket();
        List<StoredObject> objects = new ArrayList<>();
        Deque<String> prefixes = new ArrayDeque<>();
        prefixes.add("documents");
        while (!prefixes.isEmpty()) listPrefix(prefixes.removeFirst(), prefixes, objects);
        objects.sort(Comparator.comparing(StoredObject::key));
        return objects;
    }

    private void listPrefix(String prefix, Deque<String> pending, List<StoredObject> objects) {
        int offset = 0;
        while (true) {
            String body = "{\"prefix\":\"" + jsonEscape(prefix) + "\",\"limit\":" + PAGE_SIZE
                    + ",\"offset\":" + offset + ",\"sortBy\":{\"column\":\"name\",\"order\":\"asc\"}}";
            HttpRequest request = authenticated(uri("/object/list/" + encodeSegment(bucket)))
                    .timeout(Duration.ofSeconds(60)).header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body)).build();
            try {
                HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString());
                requireSuccess(response.statusCode(), "enumerar");
                JsonNode entries = json.readTree(response.body());
                int count = 0;
                for (JsonNode entry : entries) {
                    count++;
                    String name = entry.path("name").asString();
                    if (name.isBlank()) continue;
                    String key = prefix.isBlank() ? name : prefix + "/" + name;
                    if (entry.path("id").isMissingNode() || entry.path("id").isNull()) {
                        pending.addLast(key);
                    } else {
                        long size = entry.path("metadata").path("size").asLong(-1L);
                        String mime = entry.path("metadata").path("mimetype").asString("application/octet-stream");
                        objects.add(new StoredObject(key, size, mime));
                    }
                }
                if (count < PAGE_SIZE) return;
                offset += PAGE_SIZE;
            } catch (IOException exception) {
                throw new DocumentStorageException("No fue posible enumerar Supabase Storage.", exception);
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
                throw new DocumentStorageException("La enumeración de Supabase Storage fue interrumpida.", exception);
            }
        }
    }

    private void ensurePrivateBucket() {
        if (privateBucketVerified) return;
        synchronized (this) {
            if (privateBucketVerified) return;
            HttpRequest request = authenticated(uri("/bucket/" + encodeSegment(bucket))).GET()
                    .timeout(Duration.ofSeconds(30)).build();
            try {
                HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString());
                requireSuccess(response.statusCode(), "verificar el bucket");
                JsonNode metadata = json.readTree(response.body());
                if (metadata.path("public").asBoolean(false)) {
                    throw new DocumentStorageException("El bucket configurado es público; se requiere un bucket privado.");
                }
                privateBucketVerified = true;
            } catch (IOException exception) {
                throw new DocumentStorageException("No fue posible verificar el bucket privado de Supabase Storage.", exception);
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
                throw new DocumentStorageException("La verificación de Supabase Storage fue interrumpida.", exception);
            }
        }
    }

    private HttpRequest.Builder authenticated(URI uri) {
        HttpRequest.Builder request = HttpRequest.newBuilder(uri)
                .header("apikey", secretKey)
                .header("Accept", "application/json");
        // Legacy service_role keys are JWTs and still require Bearer auth. Current
        // sb_secret keys are API keys and must not be presented as bearer tokens.
        if (!secretKey.startsWith("sb_secret_")) {
            request.header("Authorization", "Bearer " + secretKey);
        }
        return request;
    }

    private URI uploadUri(String key) {
        StringBuilder path = new StringBuilder("/object/").append(encodeSegment(bucket));
        for (String segment : key.split("/")) path.append('/').append(encodeSegment(segment));
        return uri(path.toString());
    }

    private URI downloadUri(String key) {
        StringBuilder path = new StringBuilder("/object/authenticated/").append(encodeSegment(bucket));
        for (String segment : key.split("/")) path.append('/').append(encodeSegment(segment));
        return uri(path.toString());
    }

    private URI uri(String path) { return URI.create(storageBase.toString() + path); }

    private String encodeSegment(String value) {
        return URLEncoder.encode(value, StandardCharsets.UTF_8).replace("+", "%20");
    }

    private String jsonEscape(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private void validateKey(String key) {
        if (key == null || !key.startsWith("documents/") || key.contains("../") || key.endsWith("/")) {
            throw new DocumentStorageException("Clave de almacenamiento inválida.");
        }
    }

    private void requireSuccess(int status, String operation) {
        if (status < 200 || status >= 300) {
            throw new DocumentStorageException("Supabase Storage rechazó la operación de " + operation + " (HTTP " + status + ").");
        }
    }
}
