package cl.mmsolutions.backend.document;

import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api")
public class DocumentController {

    private final DocumentService documentService;

    public DocumentController(
            DocumentService documentService
    ) {
        this.documentService =
                documentService;
    }

    @GetMapping(
            "/areas/{areaSlug}/documents"
    )
    @PreAuthorize("@permissionService.hasAreaOrDocuments(authentication, #areaSlug)")
    public List<DocumentService.DocumentSummary>
    getDocuments(
            @PathVariable String areaSlug
    ) {

        return documentService
                .getDocumentsByArea(
                        areaSlug
                );
    }

    @PostMapping(
            path =
                    "/areas/{areaSlug}/documents",

            consumes =
                    MediaType.MULTIPART_FORM_DATA_VALUE
    )
    @PreAuthorize("@permissionService.hasAreaOrDocuments(authentication, #areaSlug) and @permissionService.has(authentication, 'create-edit')")
    public DocumentService.DocumentSummary
    upload(
            @PathVariable String areaSlug,

            @RequestPart("file")
            MultipartFile file,

            Authentication authentication
    ) {

        return documentService.upload(
                areaSlug,
                file,
                authentication.getName()
        );
    }

    @GetMapping(
            "/documents/{documentId}/preview"
    )
    @PreAuthorize("@permissionService.hasDocument(authentication, #documentId)")
    public DocumentService.ExcelPreview
    preview(
            @PathVariable UUID documentId,
            Authentication authentication
    ) {
        DocumentService.ExcelPreview preview = documentService.getExcelPreview(documentId);
        documentService.recordAccess(documentId, authentication.getName(), "OPENED");
        return preview;
    }


    @GetMapping("/documents/{documentId}/docx-preview")
    @PreAuthorize("@permissionService.hasDocument(authentication, #documentId)")
    public DocumentService.DocxPreview docxPreview(@PathVariable UUID documentId, Authentication authentication) {
        DocumentService.DocxPreview preview = documentService.getDocxPreview(documentId);
        documentService.recordAccess(documentId, authentication.getName(), "OPENED");
        return preview;
    }

    @GetMapping("/documents/{documentId}/inline")
    @PreAuthorize("@permissionService.hasDocument(authentication, #documentId)")
    public ResponseEntity<StreamingResponseBody> inline(@PathVariable UUID documentId, Authentication authentication) {
        DocumentService.StoredDocumentFile storedFile = documentService.getCurrentFile(documentId);
        StreamingResponseBody resource = output -> {
            try (var input = documentService.openStoredFile(storedFile)) { input.transferTo(output); }
            documentService.recordAccess(documentId, authentication.getName(), "OPENED");
        };
        ContentDisposition disposition = ContentDisposition.inline()
                .filename(storedFile.filename(), StandardCharsets.UTF_8).build();
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(storedFile.mimeType()))
                .header(HttpHeaders.CONTENT_DISPOSITION, disposition.toString())
                .contentLength(storedFile.sizeBytes())
                .body(resource);
    }

    @PostMapping(
            path =
                    "/documents/{documentId}/replace",

            consumes =
                    MediaType.MULTIPART_FORM_DATA_VALUE
    )
    @PreAuthorize("@permissionService.hasDocument(authentication, #documentId) and @permissionService.has(authentication, 'create-edit')")
    public DocumentService.DocumentSummary
    replace(
            @PathVariable UUID documentId,

            @RequestPart("file")
            MultipartFile file,

            Authentication authentication
    ) {

        return documentService.replace(
                documentId,
                file,
                authentication.getName()
        );
    }

    @DeleteMapping(
            "/documents/{documentId}"
    )
    @PreAuthorize("@permissionService.hasDocument(authentication, #documentId) and @permissionService.has(authentication, 'delete')")
    public ResponseEntity<Void>
    delete(
            @PathVariable UUID documentId,
            Authentication authentication
    ) {

        documentService.delete(
                documentId,
                authentication.getName()
        );

        return ResponseEntity
                .noContent()
                .build();
    }

    @GetMapping(
            "/documents/{documentId}/download"
    )
    @PreAuthorize("@permissionService.hasDocument(authentication, #documentId)")
    public ResponseEntity<StreamingResponseBody>
    download(
            @PathVariable UUID documentId,
            Authentication authentication
    ) {

        DocumentService.StoredDocumentFile
                storedFile =
                documentService
                        .getCurrentFile(
                                documentId
                        );

        StreamingResponseBody resource = output -> {
            try (var input = documentService.openStoredFile(storedFile)) { input.transferTo(output); }
            documentService.recordAccess(documentId, authentication.getName(), "DOWNLOADED");
        };

        ContentDisposition disposition =
                ContentDisposition
                        .attachment()
                        .filename(
                                storedFile.filename(),
                                StandardCharsets.UTF_8
                        )
                        .build();

        return ResponseEntity.ok()
                .contentType(
                        MediaType.parseMediaType(
                                storedFile.mimeType()
                        )
                )
                .header(
                        HttpHeaders.CONTENT_DISPOSITION,
                        disposition.toString()
                )
                .contentLength(storedFile.sizeBytes())
                .body(resource);
    }
}
