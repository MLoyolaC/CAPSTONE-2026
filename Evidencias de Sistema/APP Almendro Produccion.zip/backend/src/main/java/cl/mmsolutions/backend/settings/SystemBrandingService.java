package cl.mmsolutions.backend.settings;

import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.time.OffsetDateTime;
import java.util.Set;

@Service
public class SystemBrandingService {
    private static final Set<String> PRESETS = Set.of("hotel", "bell", "building", "key", "landmark");
    private final JdbcTemplate jdbc;
    private final SafeImageValidator images;

    public SystemBrandingService(JdbcTemplate jdbc, SafeImageValidator images) {
        this.jdbc = jdbc;
        this.images = images;
    }

    @Transactional(readOnly = true)
    public BrandingState state() {
        return jdbc.queryForObject("SELECT icon_preset, custom_image IS NOT NULL, updated_at FROM system_branding WHERE id=1",
                (rs, row) -> new BrandingState(rs.getString(1), rs.getBoolean(2),
                        rs.getObject(3, OffsetDateTime.class)));
    }

    @Transactional
    public BrandingState choosePreset(String preset, String username) {
        if (!PRESETS.contains(preset)) throw new IllegalArgumentException("La identidad seleccionada no es válida.");
        jdbc.update("UPDATE system_branding SET icon_preset=?, custom_image=NULL, custom_mime=NULL, updated_at=NOW(), updated_by=? WHERE id=1",
                preset, username);
        return state();
    }

    @Transactional
    public BrandingState upload(MultipartFile file, String username) {
        SafeImageValidator.ValidatedImage image = images.validate(file);
        jdbc.update("UPDATE system_branding SET custom_image=?, custom_mime=?, updated_at=NOW(), updated_by=? WHERE id=1",
                image.bytes(), image.mime(), username);
        return state();
    }

    @Transactional(readOnly = true)
    public AccountSettingsService.StoredImage image() {
        return jdbc.query("SELECT custom_image, custom_mime FROM system_branding WHERE id=1 AND custom_image IS NOT NULL",
                (rs, row) -> new AccountSettingsService.StoredImage(rs.getBytes(1), rs.getString(2))).stream().findFirst()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    }

    public record BrandingState(String preset, boolean customImage, OffsetDateTime updatedAt) {}
}
