package cl.mmsolutions.backend.history;

import cl.mmsolutions.backend.workitem.WorkItemAuditChange;
import cl.mmsolutions.backend.security.PermissionService;
import cl.mmsolutions.backend.security.Permissions;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.json.JsonMapper;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.Set;

@Service
public class HistoryService {
    private final JdbcTemplate jdbcTemplate;
    private final JsonMapper objectMapper;
    private final PermissionService permissionService;

    public HistoryService(JdbcTemplate jdbcTemplate, JsonMapper objectMapper,
                          PermissionService permissionService) {
        this.jdbcTemplate = jdbcTemplate;
        this.objectMapper = objectMapper;
        this.permissionService = permissionService;
    }

    public List<HistoryEntry> getHistory(String areaSlug, UUID documentId, String username) {
        StringBuilder sql = new StringBuilder("""
            SELECT * FROM (
                SELECT da.id::text AS activity_id, d.id::text AS document_id, d.name AS item_name,
                       d.file_type::text AS file_type, a.slug AS area_slug, a.name AS area_name,
                       u.username AS username, u.role::text AS role, da.action::text AS action,
                       dv.version_number AS version_number, da.created_at AS created_at,
                       NULL::text AS details, 'DOCUMENT'::text AS entry_type, NULL::text AS item_id,
                       '[]'::text AS changes_json, NULL::text AS operation_id
                FROM document_activity da
                INNER JOIN document d ON d.id = da.document_id
                INNER JOIN area a ON a.id = d.area_id
                LEFT JOIN app_user u ON u.id = da.user_id
                LEFT JOIN document_version dv ON dv.id = da.document_version_id
                UNION ALL
                SELECT wa.id::text AS activity_id, NULL::text AS document_id, wa.item_title AS item_name,
                       'REGISTRO'::text AS file_type, a.slug AS area_slug, a.name AS area_name,
                       wa.username_snapshot AS username, wa.role_snapshot AS role, wa.action AS action,
                       NULL::integer AS version_number, wa.created_at AS created_at, wa.details AS details,
                       'WORK_ITEM'::text AS entry_type, wa.work_item_id::text AS item_id,
                       wa.changes::text AS changes_json, wa.operation_id::text AS operation_id
                FROM work_item_activity wa
                INNER JOIN area a ON a.id = wa.area_id
                UNION ALL
                SELECT sa.id::text AS activity_id, NULL::text AS document_id, sa.item_name AS item_name,
                       sa.item_type AS file_type, sa.area_slug AS area_slug, sa.area_name AS area_name,
                       sa.username_snapshot AS username, sa.role_snapshot AS role, sa.action AS action,
                       NULL::integer AS version_number, sa.created_at AS created_at, sa.details AS details,
                       'SYSTEM'::text AS entry_type, sa.item_id AS item_id,
                       '[]'::text AS changes_json, NULL::text AS operation_id
                FROM system_activity sa
            ) h WHERE 1 = 1
            """);
        List<Object> parameters = new ArrayList<>();
        if (areaSlug != null && !areaSlug.isBlank()) { sql.append(" AND h.area_slug = ?"); parameters.add(areaSlug); }
        if (documentId != null) { sql.append(" AND h.document_id = ?"); parameters.add(documentId.toString()); }
        if ((areaSlug == null || areaSlug.isBlank()) && documentId == null) {
            Set<String> permissions = permissionService.permissionsFor(username);
            if (!permissions.containsAll(Permissions.ALL)) {
                List<String> allowedSlugs = jdbcTemplate.queryForList(
                        "SELECT slug FROM area ORDER BY slug", String.class).stream()
                        .filter(slug -> permissions.contains(Permissions.forAreaSlug(slug)))
                        .toList();
                boolean allDocuments = permissions.contains("documentos");
                if (allowedSlugs.isEmpty()) {
                    sql.append(allDocuments ? " AND h.entry_type = 'DOCUMENT'" : " AND 1 = 0");
                } else {
                    sql.append(" AND (");
                    if (allDocuments) sql.append("h.entry_type = 'DOCUMENT' OR ");
                    sql.append("h.area_slug IN (")
                            .append(String.join(",", java.util.Collections.nCopies(allowedSlugs.size(), "?")))
                            .append("))");
                    parameters.addAll(allowedSlugs);
                }
            }
        }
        sql.append(" ORDER BY h.created_at DESC, h.activity_id DESC");
        return jdbcTemplate.query(sql.toString(), (rs,rowNum) -> new HistoryEntry(
                rs.getString("activity_id"), rs.getString("document_id"), rs.getString("item_name"), rs.getString("file_type"),
                rs.getString("area_slug"), rs.getString("area_name"), rs.getString("username"), rs.getString("role"),
                rs.getString("action"), (Integer) rs.getObject("version_number"),
                rs.getObject("created_at", OffsetDateTime.class), rs.getString("details"), rs.getString("entry_type"), rs.getString("item_id"),
                parseChanges(rs.getString("changes_json")), rs.getString("operation_id")
        ), parameters.toArray());
    }

    /** Internal/test callers that already scope the query to an area or document. */
    public List<HistoryEntry> getHistory(String areaSlug, UUID documentId) {
        if ((areaSlug == null || areaSlug.isBlank()) && documentId == null) {
            throw new IllegalArgumentException("El historial general requiere un usuario autenticado.");
        }
        return getHistory(areaSlug, documentId, "");
    }

    private List<WorkItemAuditChange> parseChanges(String json) {
        if (json == null || json.isBlank()) return List.of();
        try {
            return objectMapper.readValue(json, new TypeReference<>() {});
        } catch (Exception ignored) {
            return List.of();
        }
    }

    public record HistoryEntry(String id, String documentId, String documentName, String fileType, String areaSlug,
                               String areaName, String username, String role, String action, Integer versionNumber,
                               OffsetDateTime createdAt, String details, String entryType, String itemId,
                               List<WorkItemAuditChange> changes, String operationId) {}
}
