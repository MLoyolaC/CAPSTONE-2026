package cl.mmsolutions.backend.audit;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class SystemActivityService {
    private final JdbcTemplate jdbc;

    public SystemActivityService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void record(String areaSlug, String areaName, Object itemId, String itemName,
                       String itemType, String action, String details, Authentication auth) {
        String username = auth == null ? null : auth.getName();
        String role = null;
        if (auth != null && auth.getAuthorities() != null && !auth.getAuthorities().isEmpty()) {
            role = auth.getAuthorities().iterator().next().getAuthority();
            if (role != null && role.startsWith("ROLE_")) role = role.substring(5);
        }
        jdbc.update("""
            INSERT INTO system_activity(
                id, area_slug, area_name, item_id, item_name, item_type,
                username_snapshot, role_snapshot, action, details
            ) VALUES(?,?,?,?,?,?,?,?,?,?)
            """, UUID.randomUUID(), areaSlug, areaName,
            itemId == null ? null : itemId.toString(), itemName, itemType,
            username, role, action, details);
    }
}
