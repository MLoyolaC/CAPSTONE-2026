package cl.mmsolutions.backend.improvements;

import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.security.access.prepost.PreAuthorize;

@RestController
@RequestMapping("/api/areas/mejoras/imports")
@PreAuthorize("@permissionService.has(authentication, 'mejoras') and @permissionService.has(authentication, 'import')")
public class ImprovementImportController {
    private final ImprovementImportService importService;
    public ImprovementImportController(ImprovementImportService importService) { this.importService = importService; }

    @PostMapping(path = "/analyze", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ImprovementImportService.AnalysisResult analyze(@RequestPart("file") MultipartFile file) {
        return importService.analyze(file);
    }

    @PostMapping
    public ImprovementImportService.ImportResult commit(
            @RequestBody ImprovementImportService.ImportRequest request,
            Authentication authentication
    ) {
        return importService.commit(request, authentication == null ? null : authentication.getName());
    }
}
