package cl.mmsolutions.backend.asset;

import cl.mmsolutions.backend.audit.SystemActivityService;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.access.prepost.PreAuthorize;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/assets")
public class AssetController {
    private final JdbcTemplate jdbc;
    private final SystemActivityService audit;
    public AssetController(JdbcTemplate jdbc, SystemActivityService audit) { this.jdbc = jdbc; this.audit = audit; }

    @GetMapping
    @PreAuthorize("@permissionService.has(authentication, 'activos') or @permissionService.hasArea(authentication, 'mantencion-maquinas')")
    public List<AssetResponse> list(@RequestParam(defaultValue = "false") boolean includeInactive) {
        return jdbc.query("""
            SELECT a.id, ar.slug area_slug, a.code, a.name, a.category, a.location,
                   a.description, a.notes, a.operational_status, a.active, a.created_at, a.updated_at,
                   (SELECT COUNT(*) FROM work_item wi WHERE wi.asset_id=a.id AND wi.work_type='MACHINE_MAINTENANCE') linked_machine_count
            FROM asset a JOIN area ar ON ar.id=a.area_id
            WHERE (? OR a.active=TRUE)
            ORDER BY COALESCE(a.location,''), a.name
            """, (rs,n)->new AssetResponse(
                rs.getObject("id",UUID.class), rs.getString("area_slug"), rs.getString("code"),
                rs.getString("name"), rs.getString("category"), rs.getString("location"),
                rs.getString("description"), rs.getString("notes"), rs.getString("operational_status"), rs.getBoolean("active"),
                rs.getObject("created_at",OffsetDateTime.class), rs.getObject("updated_at",OffsetDateTime.class),
                rs.getLong("linked_machine_count")
        ), includeInactive);
    }

    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("@permissionService.has(authentication, 'activos') and @permissionService.has(authentication, 'create-edit')")
    @Transactional
    public AssetResponse create(@RequestBody AssetRequest r, Authentication auth) {
        UUID id=UUID.randomUUID(); String slug=blank(r.areaSlug())?"mantencion-maquinas":r.areaSlug();
        Long areaId=jdbc.queryForObject("SELECT id FROM area WHERE slug=?",Long.class,slug);
        jdbc.update("""
            INSERT INTO asset(id,area_id,code,name,category,location,description,notes,operational_status,active)
            VALUES(?,?,?,?,?,?,?,?,?,?)
            """, id,areaId,clean(r.code()),required(r.name()),clean(r.category()),clean(r.location()),
            clean(r.description()),clean(r.notes()),status(r.operationalStatus()),r.active()==null||r.active());
        AssetResponse created = get(id);
        audit.record("mantencion-maquinas", "Activos", id, created.name(), "ACTIVO", "CREATED",
                "Activo creado en " + (created.location()==null?"sin ubicación":created.location()), auth);
        return created;
    }

    @PutMapping("/{id}")
    @PreAuthorize("@permissionService.has(authentication, 'activos') and @permissionService.has(authentication, 'create-edit')")
    @Transactional
    public AssetResponse update(@PathVariable UUID id,@RequestBody AssetRequest r, Authentication auth) {
        String slug=blank(r.areaSlug())?"mantencion-maquinas":r.areaSlug();
        Long areaId=jdbc.queryForObject("SELECT id FROM area WHERE slug=?",Long.class,slug);
        jdbc.update("""
            UPDATE asset SET area_id=?,code=?,name=?,category=?,location=?,description=?,notes=?,operational_status=?,active=?,updated_at=CURRENT_TIMESTAMP
            WHERE id=?
            """,areaId,clean(r.code()),required(r.name()),clean(r.category()),clean(r.location()),clean(r.description()),clean(r.notes()),status(r.operationalStatus()),r.active()==null||r.active(),id);
        jdbc.update("UPDATE work_item SET asset_name=?, location=?, updated_at=CURRENT_TIMESTAMP WHERE asset_id=?",
                required(r.name()), clean(r.location()), id);
        AssetResponse updated = get(id);
        audit.record("mantencion-maquinas", "Activos", id, updated.name(), "ACTIVO", "UPDATED",
                "Activo actualizado", auth);
        return updated;
    }

    @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
    @PreAuthorize("@permissionService.has(authentication, 'activos') and @permissionService.has(authentication, 'delete')")
    @Transactional
    public void delete(@PathVariable UUID id, Authentication auth){
        AssetResponse current = get(id);
        jdbc.update("UPDATE asset SET active=FALSE,updated_at=CURRENT_TIMESTAMP WHERE id=?",id);
        audit.record("mantencion-maquinas", "Activos", id, current.name(), "ACTIVO", "DELETED",
                "Activo dado de baja", auth);
    }

    private AssetResponse get(UUID id){
        return jdbc.queryForObject("""
            SELECT a.id, ar.slug area_slug, a.code, a.name, a.category, a.location,a.description,a.notes,a.operational_status,a.active,a.created_at,a.updated_at,
                   (SELECT COUNT(*) FROM work_item wi WHERE wi.asset_id=a.id AND wi.work_type='MACHINE_MAINTENANCE') linked_machine_count
            FROM asset a JOIN area ar ON ar.id=a.area_id WHERE a.id=?
            """,(rs,n)->new AssetResponse(rs.getObject("id",UUID.class),rs.getString("area_slug"),rs.getString("code"),rs.getString("name"),rs.getString("category"),rs.getString("location"),rs.getString("description"),rs.getString("notes"),rs.getString("operational_status"),rs.getBoolean("active"),rs.getObject("created_at",OffsetDateTime.class),rs.getObject("updated_at",OffsetDateTime.class),rs.getLong("linked_machine_count")),id);
    }
    private static boolean blank(String s){return s==null||s.isBlank();}
    private static String clean(String s){return blank(s)?null:s.trim();}
    private static String required(String s){if(blank(s)) throw new IllegalArgumentException("El nombre es obligatorio.");return s.trim();}
    private static String status(String value){
        if (blank(value)) return "OPERATIONAL";
        String normalized=value.trim().toUpperCase();
        if (!List.of("OPERATIONAL","FAULT","OUT_OF_SERVICE").contains(normalized)) throw new IllegalArgumentException("Estado de activo no válido.");
        return normalized;
    }

    public record AssetRequest(String areaSlug,String code,String name,String category,String location,String description,String notes,String operationalStatus,Boolean active){}
    public record AssetResponse(UUID id,String areaSlug,String code,String name,String category,String location,String description,String notes,String operationalStatus,boolean active,OffsetDateTime createdAt,OffsetDateTime updatedAt,long linkedMachineCount){}
}
