package cl.mmsolutions.backend.user;

import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/users")
@PreAuthorize("@permissionService.has(authentication, 'manage-access')")
public class UserAdministrationController {
    private final UserAdministrationService service;

    public UserAdministrationController(UserAdministrationService service) { this.service = service; }

    @GetMapping
    public List<UserAdministrationService.UserView> list() { return service.list(); }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public UserAdministrationService.SaveResult create(
            @Valid @RequestBody UserAdministrationService.CreateUserRequest request) {
        return service.create(request);
    }

    @PutMapping("/{id}")
    public UserAdministrationService.UserView update(@PathVariable Long id,
            @Valid @RequestBody UserAdministrationService.UpdateUserRequest request) {
        return service.update(id, request);
    }

    @PostMapping("/{id}/resend-invitation")
    public UserAdministrationService.SaveResult resend(@PathVariable Long id) { return service.resend(id); }

    @DeleteMapping("/{id}")
    public UserAdministrationService.DeleteResult delete(@PathVariable Long id) { return service.delete(id); }
}
