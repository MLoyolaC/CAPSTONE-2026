package cl.mmsolutions.backend.recovery;

import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.OffsetDateTime;
import java.util.Optional;

public interface PasswordRecoveryRepository extends JpaRepository<PasswordRecoveryRequest, Long> {
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    Optional<PasswordRecoveryRequest> findFirstByUserIdOrderByCreatedAtDesc(Long userId);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    Optional<PasswordRecoveryRequest> findFirstByUserIdAndUsedAtIsNullAndInvalidatedAtIsNullOrderByCreatedAtDesc(Long userId);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select r from PasswordRecoveryRequest r join fetch r.user where r.resetTokenHash = :tokenHash")
    Optional<PasswordRecoveryRequest> findByResetTokenHashForUpdate(@Param("tokenHash") String tokenHash);

    @Modifying
    @Query("update PasswordRecoveryRequest r set r.invalidatedAt = :now " +
            "where r.user.id = :userId and r.usedAt is null and r.invalidatedAt is null")
    int invalidateOpenForUser(@Param("userId") Long userId, @Param("now") OffsetDateTime now);
}
