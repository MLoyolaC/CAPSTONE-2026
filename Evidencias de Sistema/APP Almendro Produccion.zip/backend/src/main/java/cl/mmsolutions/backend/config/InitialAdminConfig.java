package cl.mmsolutions.backend.config;

import cl.mmsolutions.backend.user.AppUser;
import cl.mmsolutions.backend.user.AppUserRepository;
import cl.mmsolutions.backend.user.Role;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Locale;

@Configuration
public class InitialAdminConfig {

    @Bean
    public ApplicationRunner createInitialAdmin(
            AppUserRepository userRepository,
            PasswordEncoder passwordEncoder,
            @Value("${app.bootstrap.admin.username:}") String username,
            @Value("${app.bootstrap.admin.password:}") String password
    ) {
        return args -> {

            if (username.isBlank() || password.isBlank()) {
                return;
            }

            String normalizedUsername =
                    username.trim().toLowerCase(Locale.ROOT);

            if (!normalizedUsername.matches("[a-z0-9._-]{3,50}")) {
                throw new IllegalStateException(
                        "El nombre del administrador no es válido."
                );
            }

            if (password.length() < 12) {
                throw new IllegalStateException(
                        "La contraseña inicial debe tener al menos 12 caracteres."
                );
            }

            if (userRepository
                    .findByUsernameIgnoreCase(normalizedUsername)
                    .isEmpty()) {

                AppUser admin = new AppUser(
                        normalizedUsername,
                        passwordEncoder.encode(password),
                        Role.ADMIN,
                        true
                );

                userRepository.save(admin);
            }
        };
    }
}