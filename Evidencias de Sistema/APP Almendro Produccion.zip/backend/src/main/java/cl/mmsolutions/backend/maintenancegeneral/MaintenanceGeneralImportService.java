package cl.mmsolutions.backend.maintenancegeneral;

import cl.mmsolutions.backend.document.DocumentService;
import cl.mmsolutions.backend.location.LocationService;
import tools.jackson.core.JacksonException;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.json.JsonMapper;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.Normalizer;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.ResolverStyle;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;

@Service
public class MaintenanceGeneralImportService {

    private static final String AREA_SLUG = "mantencion-general";
    private static final Pattern DIACRITICS = Pattern.compile("\\p{M}+");
    private static final Pattern NON_WORD = Pattern.compile("[^a-z0-9]+");
    private static final Pattern DATE_TEXT = Pattern.compile("^\\s*(\\d{1,2})[/-](\\d{1,2})[/-](\\d{4})\\s*$");
    private static final Pattern YEAR_TEXT = Pattern.compile("^(19|20)\\d{2}$");
    private static final Pattern ROOM_NUMBER = Pattern.compile("^\\s*(\\d{3})(?:\\b|\\s|/|-|$).*");
    private static final DateTimeFormatter STRICT_DATE = new DateTimeFormatterBuilder()
            .appendValue(ChronoField.DAY_OF_MONTH, 1, 2, java.time.format.SignStyle.NOT_NEGATIVE)
            .appendLiteral('/')
            .appendValue(ChronoField.MONTH_OF_YEAR, 1, 2, java.time.format.SignStyle.NOT_NEGATIVE)
            .appendLiteral('/')
            .appendValue(ChronoField.YEAR, 4)
            .toFormatter(Locale.ROOT)
            .withResolverStyle(ResolverStyle.STRICT);

    private final JdbcTemplate jdbcTemplate;
    private final DocumentService documentService;
    private final LocationService locationService;
    private final JsonMapper objectMapper;

    public MaintenanceGeneralImportService(
            JdbcTemplate jdbcTemplate,
            DocumentService documentService,
            LocationService locationService,
            JsonMapper objectMapper
    ) {
        this.jdbcTemplate = jdbcTemplate;
        this.documentService = documentService;
        this.locationService = locationService;
        this.objectMapper = objectMapper;
    }

    public WorkbookAnalysis analyze(MultipartFile file) {
        validateExcel(file);

        try (InputStream input = file.getInputStream();
             Workbook workbook = WorkbookFactory.create(input)) {

            FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
            DataFormatter formatter = new DataFormatter(new Locale("es", "CL"));
            List<SheetAnalysis> sheets = new ArrayList<>();

            for (int index = 0; index < workbook.getNumberOfSheets(); index++) {
                sheets.add(analyzeSheet(workbook.getSheetAt(index), index, evaluator, formatter));
            }

            return new WorkbookAnalysis(
                    safeFilename(file.getOriginalFilename()),
                    sheets.size(),
                    sheets.stream().mapToInt(SheetAnalysis::rowCount).sum(),
                    sheets.stream().mapToInt(sheet -> sheet.notes().size()).sum(),
                    sheets,
                    findDuplicateImport(file)
            );

        } catch (IOException | RuntimeException e) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "No fue posible leer la planilla Excel."
            );
        }
    }

    @Transactional
    public ImportResult commit(MultipartFile file, String username, boolean forceDuplicate) {
        WorkbookAnalysis analysis = analyze(file);

        if (analysis.duplicate() != null && !forceDuplicate) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Esta planilla ya fue incorporada anteriormente con el mismo nombre y contenido."
            );
        }
        DocumentService.DocumentSummary document = documentService.upload(AREA_SLUG, file, username);

        Long areaId = findAreaId();
        Long userId = findUserId(username);
        UUID documentVersionId = findCurrentVersionId(document.id());
        UUID batchId = UUID.randomUUID();

        jdbcTemplate.update(
                """
                INSERT INTO mg_import_batch (
                    id,
                    area_id,
                    document_id,
                    document_version_id,
                    original_filename,
                    imported_by,
                    sheet_count,
                    row_count,
                    note_count,
                    status
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'COMPLETED')
                """,
                batchId,
                areaId,
                document.id(),
                documentVersionId,
                analysis.filename(),
                userId,
                analysis.sheetCount(),
                analysis.rowCount(),
                analysis.noteCount()
        );

        try (InputStream input = file.getInputStream();
             Workbook workbook = WorkbookFactory.create(input)) {

            FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
            DataFormatter formatter = new DataFormatter(new Locale("es", "CL"));

            for (int index = 0; index < workbook.getNumberOfSheets(); index++) {
                Sheet sheet = workbook.getSheetAt(index);
                SheetAnalysis sheetAnalysis = analyzeSheet(sheet, index, evaluator, formatter);
                persistSheet(
                        batchId,
                        areaId,
                        document.id(),
                        documentVersionId,
                        analysis.filename(),
                        sheet,
                        sheetAnalysis,
                        evaluator,
                        formatter
                );
            }

        } catch (IOException e) {
            throw new ResponseStatusException(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "La planilla fue guardada, pero no fue posible convertir sus datos."
            );
        }

        return new ImportResult(
                batchId,
                document.id(),
                analysis.filename(),
                analysis.sheetCount(),
                analysis.rowCount(),
                analysis.noteCount()
        );
    }

    public List<ImportSummary> listImports() {
        return jdbcTemplate.query(
                """
                SELECT
                    b.id,
                    b.document_id,
                    b.original_filename,
                    b.sheet_count,
                    b.row_count,
                    b.note_count,
                    b.created_at
                FROM mg_import_batch b
                INNER JOIN area a ON a.id = b.area_id
                WHERE a.slug = ?
                ORDER BY b.created_at DESC
                """,
                (rs, rowNum) -> new ImportSummary(
                        rs.getObject("id", UUID.class),
                        rs.getObject("document_id", UUID.class),
                        rs.getString("original_filename"),
                        rs.getInt("sheet_count"),
                        rs.getInt("row_count"),
                        rs.getInt("note_count"),
                        rs.getObject("created_at", java.time.OffsetDateTime.class)
                ),
                AREA_SLUG
        );
    }

    public ImportDetail getImport(UUID batchId) {
        ImportSummary summary = jdbcTemplate.query(
                        """
                        SELECT
                            b.id,
                            b.document_id,
                            b.original_filename,
                            b.sheet_count,
                            b.row_count,
                            b.note_count,
                            b.created_at
                        FROM mg_import_batch b
                        INNER JOIN area a ON a.id = b.area_id
                        WHERE b.id = ?
                          AND a.slug = ?
                        """,
                        (rs, rowNum) -> new ImportSummary(
                                rs.getObject("id", UUID.class),
                                rs.getObject("document_id", UUID.class),
                                rs.getString("original_filename"),
                                rs.getInt("sheet_count"),
                                rs.getInt("row_count"),
                                rs.getInt("note_count"),
                                rs.getObject("created_at", java.time.OffsetDateTime.class)
                        ),
                        batchId,
                        AREA_SLUG
                )
                .stream()
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Importación no encontrada."
                ));

        List<ImportedSheet> sheets = jdbcTemplate.query(
                """
                SELECT
                    id,
                    sheet_index,
                    sheet_name,
                    title_text,
                    header_row_number,
                    data_start_row,
                    row_count,
                    note_count
                FROM mg_import_sheet
                WHERE batch_id = ?
                ORDER BY sheet_index
                """,
                (rs, rowNum) -> {
                    UUID sheetId = rs.getObject("id", UUID.class);
                    return new ImportedSheet(
                            sheetId,
                            rs.getInt("sheet_index"),
                            rs.getString("sheet_name"),
                            rs.getString("title_text"),
                            rs.getInt("header_row_number"),
                            rs.getInt("data_start_row"),
                            rs.getInt("row_count"),
                            rs.getInt("note_count"),
                            loadColumns(sheetId),
                            loadRows(sheetId),
                            loadNotes(sheetId)
                    );
                },
                batchId
        );

        return new ImportDetail(summary, sheets);
    }

    @Transactional
    public ImportedRow updateRow(UUID rowId, Map<String, String> values) {
        RowContext context = jdbcTemplate.query(
                        """
                        SELECT r.id, r.sheet_id
                        FROM mg_import_row r
                        INNER JOIN mg_import_sheet s ON s.id = r.sheet_id
                        INNER JOIN mg_import_batch b ON b.id = s.batch_id
                        INNER JOIN area a ON a.id = b.area_id
                        WHERE r.id = ?
                          AND a.slug = ?
                        """,
                        (rs, rowNum) -> new RowContext(
                                rs.getObject("id", UUID.class),
                                rs.getObject("sheet_id", UUID.class)
                        ),
                        rowId,
                        AREA_SLUG
                )
                .stream()
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Fila importada no encontrada."
                ));

        List<ImportedColumn> columns = loadColumns(context.sheetId());
        Map<String, String> cleaned = new LinkedHashMap<>();

        for (ImportedColumn column : columns) {
            String value = values == null ? "" : values.getOrDefault(column.key(), "");
            value = value == null ? "" : value.trim();

            if ("LOCATION".equals(column.semanticType()) && !value.isBlank()) {
                value = normalizeLocationValue(column.label(), value);
                value = locationService.canonicalizeOrRegister(AREA_SLUG, value);
            }

            cleaned.put(column.key(), value);
        }

        List<String> warnings = validateRow(cleaned, columns);

        jdbcTemplate.update(
                """
                UPDATE mg_import_row
                SET data = ?::jsonb,
                    validation_warnings = ?::jsonb,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
                """,
                toJson(cleaned),
                toJson(warnings),
                rowId
        );

        return jdbcTemplate.queryForObject(
                """
                SELECT id, source_row_number, data::text, validation_warnings::text
                FROM mg_import_row
                WHERE id = ?
                """,
                (rs, rowNum) -> new ImportedRow(
                        rs.getObject("id", UUID.class),
                        rs.getInt("source_row_number"),
                        fromJsonMap(rs.getString("data")),
                        fromJsonList(rs.getString("validation_warnings"))
                ),
                rowId
        );
    }

    @Transactional
    public int integrateExistingImport(UUID batchId) {
        ImportBatchContext batch = jdbcTemplate.query(
                        """
                        SELECT b.area_id, b.document_id, b.document_version_id, b.original_filename
                        FROM mg_import_batch b
                        INNER JOIN area a ON a.id = b.area_id
                        WHERE b.id = ?
                          AND a.slug = ?
                        """,
                        (rs, rowNum) -> new ImportBatchContext(
                                rs.getLong("area_id"),
                                rs.getObject("document_id", UUID.class),
                                rs.getObject("document_version_id", UUID.class),
                                rs.getString("original_filename")
                        ),
                        batchId,
                        AREA_SLUG
                )
                .stream()
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Importación no encontrada."
                ));

        List<ImportedSheetContext> sheets = jdbcTemplate.query(
                """
                SELECT id, sheet_index, sheet_name, title_text, header_row_number, data_start_row
                FROM mg_import_sheet
                WHERE batch_id = ?
                ORDER BY sheet_index
                """,
                (rs, rowNum) -> new ImportedSheetContext(
                        rs.getObject("id", UUID.class),
                        rs.getInt("sheet_index"),
                        rs.getString("sheet_name"),
                        rs.getString("title_text"),
                        rs.getInt("header_row_number"),
                        rs.getInt("data_start_row")
                ),
                batchId
        );

        int integrated = 0;

        for (ImportedSheetContext sheet : sheets) {
            List<ImportedColumn> storedColumns = loadColumns(sheet.id());
            List<ColumnAnalysis> columns = new ArrayList<>();

            for (int index = 0; index < storedColumns.size(); index++) {
                ImportedColumn column = storedColumns.get(index);
                columns.add(new ColumnAnalysis(index, column.key(), column.label(), column.semanticType()));
            }

            SheetAnalysis analysis = new SheetAnalysis(
                    sheet.index(),
                    sheet.name(),
                    sheet.title(),
                    sheet.headerRowNumber(),
                    sheet.dataStartRow(),
                    columns,
                    0,
                    List.of(),
                    List.of(),
                    List.of()
            );

            List<ImportedRow> rows = loadRows(sheet.id());

            for (ImportedRow row : rows) {
                UUID workItemId = createOrMergeWorkItem(
                        batch.areaId(),
                        batch.documentId(),
                        batch.documentVersionId(),
                        batch.filename(),
                        analysis,
                        row.sourceRowNumber(),
                        row.values()
                );

                jdbcTemplate.update(
                        """
                        UPDATE mg_import_row
                        SET work_item_id = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE id = ?
                        """,
                        workItemId,
                        row.id()
                );

                integrated++;
            }
        }

        return integrated;
    }

    private void persistSheet(
            UUID batchId,
            Long areaId,
            UUID documentId,
            UUID documentVersionId,
            String sourceFilename,
            Sheet sheet,
            SheetAnalysis analysis,
            FormulaEvaluator evaluator,
            DataFormatter formatter
    ) {
        UUID sheetId = UUID.randomUUID();

        jdbcTemplate.update(
                """
                INSERT INTO mg_import_sheet (
                    id,
                    batch_id,
                    sheet_index,
                    sheet_name,
                    title_text,
                    header_row_number,
                    data_start_row,
                    row_count,
                    note_count
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                sheetId,
                batchId,
                analysis.index(),
                analysis.name(),
                blankToNull(analysis.title()),
                analysis.headerRowNumber(),
                analysis.dataStartRow(),
                analysis.rowCount(),
                analysis.notes().size()
        );

        for (ColumnAnalysis column : analysis.columns()) {
            jdbcTemplate.update(
                    """
                    INSERT INTO mg_import_column (
                        id,
                        sheet_id,
                        column_index,
                        column_key,
                        original_label,
                        semantic_type,
                        display_order
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    UUID.randomUUID(),
                    sheetId,
                    column.index(),
                    column.key(),
                    column.label(),
                    column.semanticType(),
                    column.index()
            );
        }

        ParsedRows parsed = parseRows(sheet, analysis, evaluator, formatter, true);

        for (ParsedRow row : parsed.rows()) {
            Map<String, String> values = new LinkedHashMap<>(row.values());

            for (ColumnAnalysis column : analysis.columns()) {
                if (!"LOCATION".equals(column.semanticType())) {
                    continue;
                }

                String location = values.get(column.key());

                if (location == null || location.isBlank()) {
                    continue;
                }

                location = normalizeLocationValue(column.label(), location);
                location = locationService.canonicalizeOrRegister(AREA_SLUG, location);
                values.put(column.key(), location);
            }

            List<String> warnings = validateRow(
                    values,
                    analysis.columns().stream()
                            .map(column -> new ImportedColumn(
                                    column.key(),
                                    column.label(),
                                    column.semanticType()
                            ))
                            .toList()
            );

            UUID importedRowId = UUID.randomUUID();

            jdbcTemplate.update(
                    """
                    INSERT INTO mg_import_row (
                        id,
                        sheet_id,
                        source_row_number,
                        data,
                        validation_warnings
                    )
                    VALUES (?, ?, ?, ?::jsonb, ?::jsonb)
                    """,
                    importedRowId,
                    sheetId,
                    row.sourceRowNumber(),
                    toJson(values),
                    toJson(warnings)
            );

            UUID workItemId = createOrMergeWorkItem(
                    areaId,
                    documentId,
                    documentVersionId,
                    sourceFilename,
                    analysis,
                    row.sourceRowNumber(),
                    values
            );

            jdbcTemplate.update(
                    """
                    UPDATE mg_import_row
                    SET work_item_id = ?
                    WHERE id = ?
                    """,
                    workItemId,
                    importedRowId
            );
        }

        for (ParsedNote note : parsed.notes()) {
            jdbcTemplate.update(
                    """
                    INSERT INTO mg_import_note (
                        id,
                        sheet_id,
                        source_row_number,
                        note_text
                    )
                    VALUES (?, ?, ?, ?)
                    """,
                    UUID.randomUUID(),
                    sheetId,
                    note.sourceRowNumber(),
                    note.text()
            );
        }
    }

    private UUID createOrMergeWorkItem(
            Long areaId,
            UUID documentId,
            UUID documentVersionId,
            String sourceFilename,
            SheetAnalysis sheet,
            int sourceRowNumber,
            Map<String, String> values
    ) {
        String location = firstValue(values, sheet.columns(), "LOCATION");
        String name = firstValue(values, sheet.columns(), "NAME");
        String code = firstValue(values, sheet.columns(), "CODE");
        location = inferRoomLocation(location, values, sheet.columns());

        if (!location.isBlank()) {
            location = locationService.canonicalizeOrRegister(AREA_SLUG, location);
        }

        String responsible = firstValue(values, sheet.columns(), "RESPONSIBLE");
        String supplier = firstValue(values, sheet.columns(), "SUPPLIER");
        String detail = firstValue(values, sheet.columns(), "DETAIL");
        String category = categoryName(sourceFilename, sheet);
        String title = buildOperationalTitle(name, code, location, category, sourceRowNumber);
        String sourceKey = buildSourceKey(name, code, location, category, sheet.name(), sourceRowNumber);

        List<LocalDate> dates = new ArrayList<>();
        LocalDate scheduledStart = null;
        LocalDate completedDate = null;

        for (ColumnAnalysis column : sheet.columns()) {
            if (!"DATE".equals(column.semanticType())) {
                continue;
            }

            LocalDate parsed = parseImportedDate(values.get(column.key()));

            if (parsed == null) {
                continue;
            }

            dates.add(parsed);
            String label = normalize(column.label());

            if (containsAny(label, "proxima", "programada", "programado", "inicio", "agendada")) {
                if (!parsed.isBefore(LocalDate.now())) {
                    scheduledStart = earliest(scheduledStart, parsed);
                }
            }
        }

        if (scheduledStart == null) {
            scheduledStart = dates.stream()
                    .filter(date -> !date.isBefore(LocalDate.now()))
                    .min(LocalDate::compareTo)
                    .orElse(null);
        }

        completedDate = dates.stream()
                .filter(date -> date.isBefore(LocalDate.now()) || date.isEqual(LocalDate.now()))
                .max(LocalDate::compareTo)
                .orElse(null);

        String status = mapImportedStatus(
                firstValue(values, sheet.columns(), "STATUS"),
                scheduledStart,
                completedDate
        );

        BigDecimal estimatedCost = null;
        BigDecimal actualCost = null;

        for (ColumnAnalysis column : sheet.columns()) {
            if (!"COST".equals(column.semanticType())) {
                continue;
            }

            BigDecimal amount = parseMoney(values.get(column.key()));

            if (amount == null) {
                continue;
            }

            String label = normalize(column.label());

            if (containsAny(label, "presupuesto", "estimado", "estimada", "cotizacion")) {
                estimatedCost = amount;
            } else if (containsAny(label, "real", "gasto", "pagado", "pagada", "costo", "coste", "total")) {
                actualCost = amount;
            }
        }

        Map<String, String> additionalData = additionalImportedData(values, sheet);

        List<ImportedWorkItemContext> existing = jdbcTemplate.query(
                """
                SELECT id, imported_data
                FROM work_item
                WHERE source_document_id = ?
                  AND source_key = ?
                """,
                (rs, rowNum) -> new ImportedWorkItemContext(
                        rs.getObject("id", UUID.class),
                        rs.getString("imported_data")
                ),
                documentId,
                sourceKey
        );

        if (!existing.isEmpty()) {
            ImportedWorkItemContext current = existing.get(0);
            Map<String, String> merged = fromJsonMap(current.importedData());
            merged.putAll(additionalData);

            jdbcTemplate.update(
                    """
                    UPDATE work_item
                    SET responsible_name = COALESCE(NULLIF(responsible_name, ''), NULLIF(?, '')),
                        supplier_name = COALESCE(NULLIF(supplier_name, ''), NULLIF(?, '')),
                        description = COALESCE(NULLIF(description, ''), NULLIF(?, '')),
                        scheduled_start = COALESCE(scheduled_start, ?),
                        completed_date = CASE
                            WHEN CAST(? AS DATE) IS NULL THEN completed_date
                            WHEN completed_date IS NULL THEN CAST(? AS DATE)
                            ELSE GREATEST(completed_date, CAST(? AS DATE))
                        END,
                        estimated_cost = COALESCE(estimated_cost, ?),
                        actual_cost = COALESCE(actual_cost, ?),
                        imported_data = ?,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """,
                    blankToNull(responsible),
                    blankToNull(supplier),
                    blankToNull(detail),
                    scheduledStart,
                    completedDate,
                    completedDate,
                    completedDate,
                    estimatedCost,
                    actualCost,
                    toJson(merged),
                    current.id()
            );

            return current.id();
        }

        UUID id = UUID.randomUUID();

        jdbcTemplate.update(
                """
                INSERT INTO work_item (
                    id,
                    area_id,
                    work_type,
                    title,
                    description,
                    location,
                    responsible_name,
                    priority,
                    status,
                    scheduled_start,
                    completed_date,
                    progress_percent,
                    notes,
                    category,
                    supplier_name,
                    estimated_cost,
                    actual_cost,
                    source_document_id,
                    source_version_id,
                    source_sheet_name,
                    source_row_number,
                    source_key,
                    import_source_filename,
                    imported_data
                )
                VALUES (?, ?, 'GENERAL_MAINTENANCE', ?, ?, ?, ?, 'NORMAL', ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                id,
                areaId,
                title,
                blankToNull(detail),
                blankToNull(location),
                blankToNull(responsible),
                status,
                scheduledStart,
                completedDate,
                null,
                blankToNull(category),
                blankToNull(supplier),
                estimatedCost,
                actualCost,
                documentId,
                documentVersionId,
                sheet.name(),
                sourceRowNumber,
                sourceKey,
                sourceFilename,
                toJson(additionalData)
        );

        return id;
    }

    private Map<String, String> additionalImportedData(
            Map<String, String> values,
            SheetAnalysis sheet
    ) {
        Map<String, String> result = new LinkedHashMap<>();
        Map<String, Integer> labelCounts = new LinkedHashMap<>();

        for (ColumnAnalysis column : sheet.columns()) {
            String value = values.get(column.key());

            if (value == null || value.isBlank()) {
                continue;
            }

            if (Set.of("NAME", "LOCATION", "RESPONSIBLE", "SUPPLIER", "DETAIL", "STATUS").contains(column.semanticType())) {
                continue;
            }

            String baseLabel = sheet.name() + " · " + column.label();
            int occurrence = labelCounts.merge(baseLabel, 1, Integer::sum);
            String label = occurrence == 1 ? baseLabel : baseLabel + " (" + occurrence + ")";
            result.put(label, value);
        }

        return result;
    }

    private String firstValue(
            Map<String, String> values,
            List<ColumnAnalysis> columns,
            String semanticType
    ) {
        for (ColumnAnalysis column : columns) {
            if (!semanticType.equals(column.semanticType())) {
                continue;
            }

            String value = values.get(column.key());

            if (value != null && !value.isBlank()) {
                return value.trim();
            }
        }

        return "";
    }

    private String categoryName(String sourceFilename, SheetAnalysis sheet) {
        String title = sheet.title() == null ? "" : sheet.title().trim();
        String normalizedTitle = normalize(title);
        String sheetName = sheet.name() == null ? "" : sheet.name().trim();
        String normalizedSheet = normalize(sheetName);

        if (!sheetName.isBlank()
                && !normalizedSheet.matches("hoja ?\\d+")
                && !normalizedSheet.matches("sheet ?\\d+")
                && normalizedTitle.startsWith("registro de mantenimientos")) {
            return displayCategory(sheetName);
        }

        if (!title.isBlank() && title.length() <= 120) {
            return title;
        }

        String filename = sourceFilename == null ? "Mantención general" : sourceFilename;
        filename = filename.replaceFirst("(?i)\\.xlsx?$", "").replace('_', ' ').trim();

        if (filename.length() > 120) {
            filename = filename.substring(0, 120).trim();
        }

        return filename.isBlank() ? "Mantención general" : filename;
    }

    private String buildOperationalTitle(
            String name,
            String code,
            String location,
            String category,
            int sourceRowNumber
    ) {
        if (!name.isBlank()) {
            if (name.trim().matches("\\d{3}") && normalize(location).startsWith("habitacion ")) {
                return category + " · " + location;
            }
            return name;
        }

        if (!code.isBlank() && !location.isBlank()) {
            return category + " · " + code + " · " + location;
        }

        if (!location.isBlank()) {
            return category + " · " + location;
        }

        if (!code.isBlank()) {
            return category + " · " + code;
        }

        return category + " · Registro " + sourceRowNumber;
    }

    private String buildSourceKey(
            String name,
            String code,
            String location,
            String category,
            String sheetName,
            int sourceRowNumber
    ) {
        String identity = !name.isBlank()
                ? name + "|" + location
                : !code.isBlank()
                ? code + "|" + location
                : !location.isBlank()
                ? category + "|" + location
                : sheetName + "|" + sourceRowNumber;

        return "mg|" + normalize(identity);
    }

    private String mapImportedStatus(
            String original,
            LocalDate scheduledStart,
            LocalDate completedDate
    ) {
        String value = normalize(original);

        if (!value.isBlank()) {
            if (containsAny(value, "complet", "finaliz", "realiz", "hecho", "termin")) {
                return "COMPLETED";
            }
            if (containsAny(value, "proceso", "curso", "ejecucion")) {
                return "IN_PROGRESS";
            }
            if (containsAny(value, "atras", "venc")) {
                return "OVERDUE";
            }
            if (containsAny(value, "cancel", "descart")) {
                return "CANCELLED";
            }
            if (containsAny(value, "plan", "program")) {
                return "PLANNED";
            }
            if (containsAny(value, "pend")) {
                return "PENDING";
            }
        }

        if (scheduledStart != null) {
            return "PENDING";
        }

        if (completedDate != null) {
            return "COMPLETED";
        }

        return "PENDING";
    }

    private LocalDate parseImportedDate(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }

        String trimmed = value.trim();

        try {
            if (trimmed.matches("^\\d{4}-\\d{2}-\\d{2}$")) {
                return LocalDate.parse(trimmed);
            }

            var match = DATE_TEXT.matcher(trimmed);

            if (match.matches()) {
                String normalized = match.group(1) + "/" + match.group(2) + "/" + match.group(3);
                return LocalDate.parse(normalized, STRICT_DATE);
            }
        } catch (RuntimeException ignored) {
            return null;
        }

        return null;
    }

    private LocalDate earliest(LocalDate current, LocalDate candidate) {
        if (candidate == null) {
            return current;
        }

        if (current == null || candidate.isBefore(current)) {
            return candidate;
        }

        return current;
    }

    private BigDecimal parseMoney(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }

        String cleaned = value.trim()
                .replace("$", "")
                .replace("CLP", "")
                .replace("clp", "")
                .replace(" ", "");

        if (cleaned.matches("^-?\\d{1,3}(\\.\\d{3})+(,\\d+)?$")) {
            cleaned = cleaned.replace(".", "").replace(',', '.');
        } else if (cleaned.matches("^-?\\d+(,\\d+)?$")) {
            cleaned = cleaned.replace(',', '.');
        } else {
            cleaned = cleaned.replaceAll("[^0-9,.-]", "");

            if (cleaned.contains(",") && !cleaned.contains(".")) {
                cleaned = cleaned.replace(',', '.');
            }
        }

        try {
            return new BigDecimal(cleaned).setScale(2, RoundingMode.HALF_UP);
        } catch (RuntimeException e) {
            return null;
        }
    }

    private record ImportBatchContext(
            Long areaId,
            UUID documentId,
            UUID documentVersionId,
            String filename
    ) {
    }

    private record ImportedSheetContext(
            UUID id,
            int index,
            String name,
            String title,
            int headerRowNumber,
            int dataStartRow
    ) {
    }

    private record ImportedWorkItemContext(
            UUID id,
            String importedData
    ) {
    }

    private SheetAnalysis analyzeSheet(
            Sheet sheet,
            int index,
            FormulaEvaluator evaluator,
            DataFormatter formatter
    ) {
        int headerIndex = detectHeaderRow(sheet, evaluator, formatter);
        Row headerRow = sheet.getRow(headerIndex);
        boolean useSubheader = shouldUseSubheader(sheet, headerIndex, evaluator, formatter);
        Row subheaderRow = useSubheader ? sheet.getRow(headerIndex + 1) : null;
        int dataStart = headerIndex + (useSubheader ? 2 : 1);

        List<ColumnAnalysis> columns = buildColumns(
                sheet,
                headerRow,
                subheaderRow,
                dataStart,
                evaluator,
                formatter
        );

        ParsedRows parsed = parseRows(
                sheet,
                new SheetAnalysis(
                        index,
                        sheet.getSheetName(),
                        detectTitle(sheet, headerIndex, evaluator, formatter),
                        headerIndex + 1,
                        dataStart + 1,
                        columns,
                        0,
                        List.of(),
                        List.of(),
                        List.of()
                ),
                evaluator,
                formatter,
                false
        );

        List<Map<String, String>> preview = parsed.rows()
                .stream()
                .limit(8)
                .map(ParsedRow::values)
                .toList();

        Set<String> warnings = new LinkedHashSet<>();

        for (ParsedRow row : parsed.rows()) {
            warnings.addAll(row.warnings());
        }

        return new SheetAnalysis(
                index,
                sheet.getSheetName(),
                detectTitle(sheet, headerIndex, evaluator, formatter),
                headerIndex + 1,
                dataStart + 1,
                columns,
                parsed.rows().size(),
                parsed.notes().stream().map(ParsedNote::text).toList(),
                preview,
                warnings.stream().limit(15).toList()
        );
    }

    private int detectHeaderRow(
            Sheet sheet,
            FormulaEvaluator evaluator,
            DataFormatter formatter
    ) {
        int last = Math.min(sheet.getLastRowNum(), 24);
        double bestScore = Double.NEGATIVE_INFINITY;
        int bestRow = Math.max(sheet.getFirstRowNum(), 0);

        for (int rowIndex = Math.max(sheet.getFirstRowNum(), 0); rowIndex <= last; rowIndex++) {
            Row row = sheet.getRow(rowIndex);

            if (row == null) {
                continue;
            }

            int nonBlank = 0;
            int semantic = 0;
            int textCells = 0;

            for (int cellIndex = row.getFirstCellNum(); cellIndex >= 0 && cellIndex < row.getLastCellNum(); cellIndex++) {
                String value = displayValue(row.getCell(cellIndex), evaluator, formatter, null);

                if (value.isBlank()) {
                    continue;
                }

                nonBlank++;

                if (!value.matches("[-+]?\\d+(?:[.,]\\d+)?")) {
                    textCells++;
                }

                if (!"OTHER".equals(semanticType(value))) {
                    semantic++;
                }
            }

            if (nonBlank == 0) {
                continue;
            }

            double score = semantic * 9d + Math.min(nonBlank, 15) * 1.8d + Math.min(textCells, 10) * 0.8d;

            if (nonBlank == 1) {
                score -= 8d;
            }

            if (score > bestScore) {
                bestScore = score;
                bestRow = rowIndex;
            }
        }

        return bestRow;
    }

    private boolean shouldUseSubheader(
            Sheet sheet,
            int headerIndex,
            FormulaEvaluator evaluator,
            DataFormatter formatter
    ) {
        Row header = sheet.getRow(headerIndex);
        Row next = sheet.getRow(headerIndex + 1);

        if (header == null || next == null) {
            return false;
        }

        Map<String, Integer> headerCounts = new LinkedHashMap<>();
        int duplicateHeaders = 0;

        for (int i = 0; i < header.getLastCellNum(); i++) {
            String value = displayValue(header.getCell(i), evaluator, formatter, null);

            if (value.isBlank()) {
                continue;
            }

            String normalized = normalize(value);
            int count = headerCounts.merge(normalized, 1, Integer::sum);

            if (count == 2) {
                duplicateHeaders++;
            }
        }

        if (duplicateHeaders == 0) {
            return false;
        }

        int populated = 0;
        int shortContext = 0;

        for (int i = 0; i < Math.max(header.getLastCellNum(), next.getLastCellNum()); i++) {
            String value = displayValue(next.getCell(i), evaluator, formatter, null);

            if (value.isBlank()) {
                continue;
            }

            populated++;

            if (YEAR_TEXT.matcher(value.trim()).matches() || value.trim().length() <= 12) {
                shortContext++;
            }
        }

        return populated >= 2 && shortContext >= Math.ceil(populated * 0.7d);
    }

    private List<ColumnAnalysis> buildColumns(
            Sheet sheet,
            Row header,
            Row subheader,
            int dataStart,
            FormulaEvaluator evaluator,
            DataFormatter formatter
    ) {
        int maxColumn = Math.max(
                header == null ? 0 : header.getLastCellNum(),
                detectDataColumnCount(sheet, dataStart)
        );

        List<ColumnAnalysis> columns = new ArrayList<>();
        Map<String, Integer> duplicateKeys = new LinkedHashMap<>();

        for (int index = 0; index < maxColumn; index++) {
            String main = header == null
                    ? ""
                    : displayValue(header.getCell(index), evaluator, formatter, null).trim();

            String sub = subheader == null
                    ? ""
                    : displayValue(subheader.getCell(index), evaluator, formatter, null).trim();

            if (main.isBlank() && !columnHasData(sheet, dataStart, index, evaluator, formatter)) {
                continue;
            }

            String label = main;

            if (!sub.isBlank()) {
                label = label.isBlank() ? sub : label + " " + sub;
            }

            if (label.isBlank()) {
                label = "Columna " + (index + 1);
            }

            String baseKey = slugKey(label);
            int number = duplicateKeys.merge(baseKey, 1, Integer::sum);
            String key = number == 1 ? baseKey : baseKey + "_" + number;

            columns.add(new ColumnAnalysis(
                    index,
                    key,
                    label,
                    semanticType(label)
            ));
        }

        return columns;
    }

    private ParsedRows parseRows(
            Sheet sheet,
            SheetAnalysis analysis,
            FormulaEvaluator evaluator,
            DataFormatter formatter,
            boolean full
    ) {
        List<ParsedRow> rows = new ArrayList<>();
        List<ParsedNote> notes = new ArrayList<>();
        int dataStartZeroBased = analysis.dataStartRow() - 1;

        for (int rowIndex = dataStartZeroBased; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
            Row row = sheet.getRow(rowIndex);

            if (row == null) {
                continue;
            }

            Map<String, String> values = new LinkedHashMap<>();
            List<String> warnings = new ArrayList<>();
            int meaningful = 0;
            int numericOrShort = 0;

            Set<Integer> mappedIndexes = new LinkedHashSet<>();

            for (ColumnAnalysis column : analysis.columns()) {
                mappedIndexes.add(column.index());
                Cell cell = row.getCell(column.index());
                String value = displayValue(cell, evaluator, formatter, column.semanticType());

                if (!value.isBlank()) {
                    meaningful++;

                    if (value.length() <= 18 || value.matches("[-+]?\\d+(?:[.,]\\d+)?")) {
                        numericOrShort++;
                    }

                    String warning = dateWarning(value, column);

                    if (warning != null) {
                        warnings.add("Fila " + (rowIndex + 1) + ": " + warning);
                    }
                }

                values.put(column.key(), value);
            }

            List<String> outsideTexts = new ArrayList<>();

            if (row.getLastCellNum() > 0) {
                for (int cellIndex = 0; cellIndex < row.getLastCellNum(); cellIndex++) {
                    if (mappedIndexes.contains(cellIndex)) {
                        continue;
                    }

                    String value = displayValue(row.getCell(cellIndex), evaluator, formatter, null);

                    if (!value.isBlank()) {
                        outsideTexts.add(value);
                    }
                }
            }

            if (meaningful == 0 && outsideTexts.isEmpty()) {
                continue;
            }

            if (meaningful == 0 && !outsideTexts.isEmpty()) {
                notes.add(new ParsedNote(rowIndex + 1, String.join(" · ", outsideTexts)));
                continue;
            }

            if (meaningful == 1 && numericOrShort == 0) {
                String only = values.values().stream().filter(value -> !value.isBlank()).findFirst().orElse("");

                if (only.length() >= 24) {
                    notes.add(new ParsedNote(rowIndex + 1, only));
                    continue;
                }
            }

            rows.add(new ParsedRow(rowIndex + 1, values, warnings));

        }

        return new ParsedRows(rows, notes);
    }

    private String displayValue(
            Cell cell,
            FormulaEvaluator evaluator,
            DataFormatter formatter,
            String semanticType
    ) {
        if (cell == null || cell.getCellType() == CellType.BLANK) {
            return "";
        }

        CellType effective = cell.getCellType();

        if (effective == CellType.FORMULA) {
            try {
                effective = evaluator.evaluateFormulaCell(cell);
            } catch (RuntimeException ignored) {
                return formatter.formatCellValue(cell).trim();
            }
        }

        if (effective == CellType.NUMERIC) {
            double value = cell.getNumericCellValue();

            if (DateUtil.isCellDateFormatted(cell)
                    || ("DATE".equals(semanticType) && value >= 20000d && value <= 80000d)) {
                try {
                    return DateUtil.getLocalDateTime(value).toLocalDate().toString();
                } catch (RuntimeException ignored) {
                    return formatter.formatCellValue(cell).trim();
                }
            }

            BigDecimal number = BigDecimal.valueOf(value).stripTrailingZeros();

            if (number.scale() < 0) {
                number = number.setScale(0, RoundingMode.UNNECESSARY);
            }

            return number.toPlainString();
        }

        if (effective == CellType.BOOLEAN) {
            return Boolean.toString(cell.getBooleanCellValue());
        }

        return formatter.formatCellValue(cell, evaluator).trim();
    }

    private String dateWarning(String value, ColumnAnalysis column) {
        if (!"DATE".equals(column.semanticType()) || value == null || value.isBlank()) {
            return null;
        }

        if (value.matches("^\\d{4}-\\d{2}-\\d{2}$")) {
            try {
                LocalDate.parse(value);
                return null;
            } catch (RuntimeException e) {
                return "fecha inválida en " + column.label() + ": " + value;
            }
        }

        var match = DATE_TEXT.matcher(value);

        if (!match.matches()) {
            return null;
        }

        String normalized = match.group(1) + "/" + match.group(2) + "/" + match.group(3);

        try {
            LocalDate.parse(normalized, STRICT_DATE);
            return null;
        } catch (RuntimeException e) {
            return "fecha inválida en " + column.label() + ": " + value;
        }
    }

    private List<String> validateRow(
            Map<String, String> values,
            List<ImportedColumn> columns
    ) {
        List<String> warnings = new ArrayList<>();

        for (ImportedColumn column : columns) {
            if (!"DATE".equals(column.semanticType())) {
                continue;
            }

            String value = values.get(column.key());
            String warning = dateWarning(
                    value,
                    new ColumnAnalysis(0, column.key(), column.label(), column.semanticType())
            );

            if (warning != null) {
                warnings.add(warning);
            }
        }

        return warnings;
    }

    private String detectTitle(
            Sheet sheet,
            int headerIndex,
            FormulaEvaluator evaluator,
            DataFormatter formatter
    ) {
        List<String> values = new ArrayList<>();

        for (int rowIndex = Math.max(sheet.getFirstRowNum(), 0); rowIndex < headerIndex; rowIndex++) {
            Row row = sheet.getRow(rowIndex);

            if (row == null) {
                continue;
            }

            for (int cellIndex = 0; cellIndex < row.getLastCellNum(); cellIndex++) {
                String value = displayValue(row.getCell(cellIndex), evaluator, formatter, null);

                if (!value.isBlank()) {
                    values.add(value);
                }
            }
        }

        return String.join(" · ", values);
    }

    private int detectDataColumnCount(Sheet sheet, int dataStart) {
        int max = 0;
        int last = Math.min(sheet.getLastRowNum(), dataStart + 80);

        for (int rowIndex = dataStart; rowIndex <= last; rowIndex++) {
            Row row = sheet.getRow(rowIndex);

            if (row != null && row.getLastCellNum() > max) {
                max = row.getLastCellNum();
            }
        }

        return max;
    }

    private boolean columnHasData(
            Sheet sheet,
            int dataStart,
            int columnIndex,
            FormulaEvaluator evaluator,
            DataFormatter formatter
    ) {
        int last = Math.min(sheet.getLastRowNum(), dataStart + 80);

        for (int rowIndex = dataStart; rowIndex <= last; rowIndex++) {
            Row row = sheet.getRow(rowIndex);

            if (row == null) {
                continue;
            }

            if (!displayValue(row.getCell(columnIndex), evaluator, formatter, null).isBlank()) {
                return true;
            }
        }

        return false;
    }

    private String semanticType(String label) {
        String value = normalize(label);

        if (value.isBlank()) {
            return "OTHER";
        }

        if (value.matches("^(num|numero|nro|n)$") || value.startsWith("numero ")) {
            return "NUMBER";
        }

        if (containsAny(value, "ubicacion", "zona", "habitacion", "hab ", "hab", "sector", "sala")) {
            return "LOCATION";
        }

        if (containsAny(value, "fecha", "mantencion fecha", "ultima mantencion")) {
            return "DATE";
        }

        if (containsAny(value, "quien lo hizo", "responsable", "encargado", "realizado por")) {
            return "RESPONSIBLE";
        }

        if (containsAny(value, "proveedor", "empresa")) {
            return "SUPPLIER";
        }

        if (containsAny(value, "costo", "gasto", "presupuesto", "valor", "precio")) {
            return "COST";
        }

        if (containsAny(value, "estado", "situacion")) {
            return "STATUS";
        }

        if (containsAny(value, "detalle", "descripcion", "observacion", "trabajo realizado", "comentario")) {
            return "DETAIL";
        }

        if (containsAny(value, "nemotecnico", "codigo", "cod ")) {
            return "CODE";
        }

        if (containsAny(value, "nombre", "objeto", "equipo", "radiador", "activo", "elemento")) {
            return "NAME";
        }

        return "OTHER";
    }

    private boolean containsAny(String value, String... candidates) {
        for (String candidate : candidates) {
            if (value.equals(candidate) || value.contains(candidate)) {
                return true;
            }
        }

        return false;
    }

    private String normalize(String value) {
        if (value == null) {
            return "";
        }

        String normalized = Normalizer.normalize(
                value.toLowerCase(Locale.ROOT).trim(),
                Normalizer.Form.NFD
        );

        normalized = DIACRITICS.matcher(normalized).replaceAll("");
        normalized = NON_WORD.matcher(normalized).replaceAll(" ");

        return normalized.trim().replaceAll("\\s+", " ");
    }

    private String slugKey(String value) {
        String normalized = normalize(value).replace(' ', '_');
        return normalized.isBlank() ? "columna" : normalized;
    }

    private String inferRoomLocation(
            String currentLocation,
            Map<String, String> values,
            List<ColumnAnalysis> columns
    ) {
        String current = currentLocation == null ? "" : currentLocation.trim();
        String normalizedCurrent = normalize(current);
        boolean genericLocation = current.isBlank()
                || normalizedCurrent.equals("hotel")
                || normalizedCurrent.equals("todo el hotel")
                || normalizedCurrent.equals("hotel el almendro");

        if (!genericLocation) {
            return current;
        }

        for (ColumnAnalysis column : columns) {
            if ("NUMBER".equals(column.semanticType())) {
                continue;
            }

            String label = normalize(column.label());
            if (!containsAny(label, "habitacion", "hab", "radiador", "dormitorio", "pieza", "cuarto")) {
                continue;
            }

            String raw = values.get(column.key());
            if (raw == null || raw.isBlank()) {
                continue;
            }

            var match = ROOM_NUMBER.matcher(raw.trim());
            if (match.matches()) {
                int room = Integer.parseInt(match.group(1));
                if (room >= 100 && room <= 999) {
                    return "Habitación " + room;
                }
            }
        }

        return current;
    }

    private String displayCategory(String value) {
        if (value == null || value.isBlank()) {
            return "Mantención general";
        }

        String clean = value.trim().replace('_', ' ').toLowerCase(Locale.ROOT);
        StringBuilder result = new StringBuilder();
        for (String part : clean.split("\\s+")) {
            if (part.isBlank()) {
                continue;
            }
            if (!result.isEmpty()) {
                result.append(' ');
            }
            result.append(Character.toUpperCase(part.charAt(0)));
            if (part.length() > 1) {
                result.append(part.substring(1));
            }
        }
        return result.toString();
    }

    private DuplicateImportInfo findDuplicateImport(MultipartFile file) {
        String filename = safeFilename(file.getOriginalFilename());
        String hash = calculateSha256(file);

        return jdbcTemplate.query(
                        """
                        SELECT b.id, b.original_filename, b.created_at
                        FROM mg_import_batch b
                        INNER JOIN document_version dv ON dv.id = b.document_version_id
                        INNER JOIN area a ON a.id = b.area_id
                        WHERE a.slug = ?
                          AND LOWER(b.original_filename) = LOWER(?)
                          AND dv.sha256 = ?
                        ORDER BY b.created_at DESC
                        LIMIT 1
                        """,
                        (rs, rowNum) -> new DuplicateImportInfo(
                                rs.getObject("id", UUID.class),
                                rs.getString("original_filename"),
                                rs.getObject("created_at", java.time.OffsetDateTime.class)
                        ),
                        AREA_SLUG,
                        filename,
                        hash
                )
                .stream()
                .findFirst()
                .orElse(null);
    }

    private String calculateSha256(MultipartFile file) {
        try (InputStream input = file.getInputStream()) {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] buffer = new byte[8192];
            int read;
            while ((read = input.read(buffer)) >= 0) {
                if (read > 0) {
                    digest.update(buffer, 0, read);
                }
            }
            return HexFormat.of().formatHex(digest.digest());
        } catch (IOException | NoSuchAlgorithmException e) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "No fue posible verificar el contenido de la planilla."
            );
        }
    }

    private String normalizeLocationValue(String label, String value) {
        String normalizedLabel = normalize(label);
        String trimmed = value == null ? "" : value.trim();

        if ((normalizedLabel.equals("hab") || normalizedLabel.startsWith("habitacion"))
                && trimmed.matches("\\d{2,4}")) {
            return "Habitación " + trimmed;
        }

        return trimmed;
    }

    private List<ImportedColumn> loadColumns(UUID sheetId) {
        return jdbcTemplate.query(
                """
                SELECT column_key, original_label, semantic_type
                FROM mg_import_column
                WHERE sheet_id = ?
                ORDER BY display_order
                """,
                (rs, rowNum) -> new ImportedColumn(
                        rs.getString("column_key"),
                        rs.getString("original_label"),
                        rs.getString("semantic_type")
                ),
                sheetId
        );
    }

    private List<ImportedRow> loadRows(UUID sheetId) {
        return jdbcTemplate.query(
                """
                SELECT id, source_row_number, data::text, validation_warnings::text
                FROM mg_import_row
                WHERE sheet_id = ?
                ORDER BY source_row_number
                """,
                (rs, rowNum) -> new ImportedRow(
                        rs.getObject("id", UUID.class),
                        rs.getInt("source_row_number"),
                        fromJsonMap(rs.getString("data")),
                        fromJsonList(rs.getString("validation_warnings"))
                ),
                sheetId
        );
    }

    private List<ImportedNote> loadNotes(UUID sheetId) {
        return jdbcTemplate.query(
                """
                SELECT id, source_row_number, note_text
                FROM mg_import_note
                WHERE sheet_id = ?
                ORDER BY source_row_number NULLS LAST, created_at
                """,
                (rs, rowNum) -> new ImportedNote(
                        rs.getObject("id", UUID.class),
                        (Integer) rs.getObject("source_row_number"),
                        rs.getString("note_text")
                ),
                sheetId
        );
    }

    private String toJson(Object value) {
        try {
            return objectMapper.writeValueAsString(value);
        } catch (JacksonException e) {
            throw new ResponseStatusException(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "No fue posible guardar la información importada."
            );
        }
    }

    private Map<String, String> fromJsonMap(String json) {
        try {
            return objectMapper.readValue(json, new TypeReference<LinkedHashMap<String, String>>() {});
        } catch (JacksonException e) {
            return new LinkedHashMap<>();
        }
    }

    private List<String> fromJsonList(String json) {
        try {
            return objectMapper.readValue(json, new TypeReference<List<String>>() {});
        } catch (JacksonException e) {
            return List.of();
        }
    }

    private void validateExcel(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Selecciona una planilla Excel."
            );
        }

        String filename = safeFilename(file.getOriginalFilename()).toLowerCase(Locale.ROOT);

        if (!filename.endsWith(".xlsx")) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Solo se permiten archivos Excel XLSX."
            );
        }
    }

    private String safeFilename(String value) {
        if (value == null || value.isBlank()) {
            return "planilla.xlsx";
        }

        String cleaned = value.replace('\\', '/');
        int slash = cleaned.lastIndexOf('/');
        return slash >= 0 ? cleaned.substring(slash + 1) : cleaned;
    }

    private Long findAreaId() {
        return jdbcTemplate.queryForObject(
                "SELECT id FROM area WHERE slug = ? AND active = TRUE",
                Long.class,
                AREA_SLUG
        );
    }

    private Long findUserId(String username) {
        return jdbcTemplate.queryForObject(
                "SELECT id FROM app_user WHERE username = ? AND enabled = TRUE",
                Long.class,
                username
        );
    }

    private UUID findCurrentVersionId(UUID documentId) {
        return jdbcTemplate.queryForObject(
                "SELECT current_version_id FROM document WHERE id = ?",
                UUID.class,
                documentId
        );
    }

    private String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value;
    }

    private record ParsedRows(
            List<ParsedRow> rows,
            List<ParsedNote> notes
    ) {
    }

    private record ParsedRow(
            int sourceRowNumber,
            Map<String, String> values,
            List<String> warnings
    ) {
    }

    private record ParsedNote(
            int sourceRowNumber,
            String text
    ) {
    }

    private record RowContext(
            UUID id,
            UUID sheetId
    ) {
    }

    public record WorkbookAnalysis(
            String filename,
            int sheetCount,
            int rowCount,
            int noteCount,
            List<SheetAnalysis> sheets,
            DuplicateImportInfo duplicate
    ) {
    }

    public record DuplicateImportInfo(
            UUID batchId,
            String filename,
            java.time.OffsetDateTime importedAt
    ) {
    }

    public record SheetAnalysis(
            int index,
            String name,
            String title,
            int headerRowNumber,
            int dataStartRow,
            List<ColumnAnalysis> columns,
            int rowCount,
            List<String> notes,
            List<Map<String, String>> previewRows,
            List<String> warnings
    ) {
    }

    public record ColumnAnalysis(
            int index,
            String key,
            String label,
            String semanticType
    ) {
    }

    public record ImportResult(
            UUID batchId,
            UUID documentId,
            String filename,
            int sheetCount,
            int rowCount,
            int noteCount
    ) {
    }

    public record ImportSummary(
            UUID id,
            UUID documentId,
            String filename,
            int sheetCount,
            int rowCount,
            int noteCount,
            java.time.OffsetDateTime createdAt
    ) {
    }

    public record ImportDetail(
            ImportSummary summary,
            List<ImportedSheet> sheets
    ) {
    }

    public record ImportedSheet(
            UUID id,
            int index,
            String name,
            String title,
            int headerRowNumber,
            int dataStartRow,
            int rowCount,
            int noteCount,
            List<ImportedColumn> columns,
            List<ImportedRow> rows,
            List<ImportedNote> notes
    ) {
    }

    public record ImportedColumn(
            String key,
            String label,
            String semanticType
    ) {
    }

    public record ImportedRow(
            UUID id,
            int sourceRowNumber,
            Map<String, String> values,
            List<String> warnings
    ) {
    }

    public record ImportedNote(
            UUID id,
            Integer sourceRowNumber,
            String text
    ) {
    }
}
