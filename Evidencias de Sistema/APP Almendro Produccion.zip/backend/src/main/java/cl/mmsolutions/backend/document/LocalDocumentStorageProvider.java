package cl.mmsolutions.backend.document;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.stream.Stream;

@Service
@ConditionalOnProperty(name = "app.documents.storage-provider", havingValue = "local", matchIfMissing = true)
public class LocalDocumentStorageProvider implements DocumentStorageProvider {
    private final Path root;

    public LocalDocumentStorageProvider(@Value("${app.documents.storage-path:storage/documents}") String path) {
        root = Path.of(path).toAbsolutePath().normalize();
        try { Files.createDirectories(root); }
        catch (IOException exception) { throw new DocumentStorageException("No fue posible crear el almacenamiento local.", exception); }
    }

    @Override public Kind kind() { return Kind.LOCAL; }

    @Override
    public String buildKey(UUID documentId, UUID versionId, String filename) {
        validateFilename(filename);
        return documentId + "/" + versionId + "/" + filename;
    }

    @Override
    public StoredObject store(String key, InputStream input, long contentLength, String mimeType) {
        Path target = resolve(key);
        try {
            Files.createDirectories(target.getParent());
            try (InputStream source = input; OutputStream output = Files.newOutputStream(
                    target, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE)) {
                source.transferTo(output);
            }
            long actual = Files.size(target);
            if (actual != contentLength) {
                Files.deleteIfExists(target);
                throw new DocumentStorageException("El tamaño almacenado no coincide con el archivo recibido.");
            }
            return new StoredObject(key, actual, mimeType);
        } catch (DocumentStorageException exception) {
            throw exception;
        } catch (IOException exception) {
            throw new DocumentStorageException("No fue posible guardar el archivo local.", exception);
        }
    }

    @Override public InputStream open(String key) throws IOException { return Files.newInputStream(resolve(key)); }

    @Override
    public StorageMetadata metadata(String key) {
        Path path = resolve(key);
        try {
            if (!Files.isRegularFile(path)) throw new DocumentStorageException("El archivo almacenado no existe.");
            return new StorageMetadata(key, Files.size(path), Files.probeContentType(path));
        } catch (IOException exception) {
            throw new DocumentStorageException("No fue posible consultar el archivo local.", exception);
        }
    }

    @Override public boolean exists(String key) { return Files.isRegularFile(resolve(key)); }

    @Override
    public void delete(String key) {
        Path file = resolve(key);
        try {
            Files.deleteIfExists(file);
            pruneEmptyParents(file.getParent());
        } catch (IOException exception) {
            throw new DocumentStorageException("No fue posible eliminar el archivo local.", exception);
        }
    }

    @Override
    public List<StoredObject> list() {
        List<StoredObject> result = new ArrayList<>();
        if (!Files.isDirectory(root)) return result;
        try (Stream<Path> files = Files.walk(root)) {
            for (Path path : (Iterable<Path>) files.filter(Files::isRegularFile)::iterator) {
                result.add(new StoredObject(databasePath(path), Files.size(path), Files.probeContentType(path)));
            }
        } catch (IOException exception) {
            throw new DocumentStorageException("No fue posible enumerar los documentos locales.", exception);
        }
        result.sort(Comparator.comparing(StoredObject::key));
        return result;
    }

    @Override public boolean supportsFullRestore() { return true; }

    @Override
    public StorageReplacement replaceAll(List<RestoreObject> objects) {
        Path parent = root.getParent();
        if (parent == null) throw new DocumentStorageException("La ruta documental local no tiene carpeta contenedora.");
        Path stage = null;
        Path previous = parent.resolve(root.getFileName() + "-before-restore-" + System.currentTimeMillis());
        boolean movedPrevious = false;
        try {
            Files.createDirectories(parent);
            stage = Files.createTempDirectory(parent, "documents-restore-");
            for (RestoreObject object : objects) {
                Path destination = resolveInside(stage, object.path());
                Files.createDirectories(destination.getParent());
                try (InputStream input = object.source().open(); OutputStream output = Files.newOutputStream(
                        destination, StandardOpenOption.CREATE_NEW)) {
                    input.transferTo(output);
                }
                if (Files.size(destination) != object.size()) throw new IOException("Tamaño restaurado inválido: " + object.path());
            }
            if (Files.exists(root)) { move(root, previous); movedPrevious = true; }
            move(stage, root); stage = null;
            final boolean hadPrevious = movedPrevious;
            return new StorageReplacement() {
                private boolean completed;
                @Override public synchronized void commit() {
                    if (completed) return;
                    try { if (hadPrevious) deleteTree(previous); }
                    catch (IOException exception) { throw new DocumentStorageException("No fue posible limpiar el almacenamiento anterior.", exception); }
                    completed = true;
                }
                @Override public synchronized void rollback() {
                    if (completed) return;
                    try {
                        deleteTree(root);
                        if (hadPrevious && Files.exists(previous)) move(previous, root);
                        else Files.createDirectories(root);
                    } catch (IOException exception) {
                        throw new DocumentStorageException("No fue posible revertir la restauración documental.", exception);
                    }
                    completed = true;
                }
            };
        } catch (Exception exception) {
            try {
                if (Files.exists(root) && movedPrevious) deleteTree(root);
                if (movedPrevious && Files.exists(previous)) move(previous, root);
            } catch (Exception rollback) { exception.addSuppressed(rollback); }
            throw new DocumentStorageException("No fue posible reemplazar el almacenamiento documental local.", exception);
        } finally {
            if (stage != null) try { deleteTree(stage); } catch (IOException ignored) { }
        }
    }

    @Override public String databasePath(String key) { return normalizeKey(key); }

    private String databasePath(Path path) { return root.relativize(path.toAbsolutePath().normalize()).toString().replace('\\', '/'); }

    private Path resolve(String key) { return resolveInside(root, normalizeKey(key)); }

    private Path resolveInside(Path base, String key) {
        Path path = base.resolve(key.replace('/', java.io.File.separatorChar)).normalize();
        if (!path.startsWith(base)) throw new DocumentStorageException("Clave de almacenamiento inválida.");
        return path;
    }

    private String normalizeKey(String key) {
        if (key == null || key.isBlank() || key.startsWith("/") || key.startsWith("\\")) {
            throw new DocumentStorageException("Clave de almacenamiento inválida.");
        }
        String normalized = key.replace('\\', '/');
        if (normalized.startsWith("documents/")) normalized = normalized.substring("documents/".length());
        if (normalized.contains("../") || normalized.equals("..")) throw new DocumentStorageException("Clave de almacenamiento inválida.");
        return normalized;
    }

    private void validateFilename(String filename) {
        if (filename == null || filename.isBlank() || !Path.of(filename).getFileName().toString().equals(filename)) {
            throw new DocumentStorageException("Nombre de archivo inválido.");
        }
    }

    private void pruneEmptyParents(Path directory) throws IOException {
        while (directory != null && !directory.equals(root) && directory.startsWith(root)) {
            try (Stream<Path> entries = Files.list(directory)) { if (entries.findAny().isPresent()) return; }
            Files.deleteIfExists(directory);
            directory = directory.getParent();
        }
    }

    private void move(Path source, Path target) throws IOException {
        try { Files.move(source, target, StandardCopyOption.ATOMIC_MOVE); }
        catch (AtomicMoveNotSupportedException ignored) { Files.move(source, target); }
    }

    private void deleteTree(Path directory) throws IOException {
        if (!Files.exists(directory)) return;
        try (Stream<Path> paths = Files.walk(directory)) {
            for (Path path : (Iterable<Path>) paths.sorted(Comparator.reverseOrder())::iterator) Files.deleteIfExists(path);
        }
    }
}
