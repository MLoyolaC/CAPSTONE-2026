package cl.mmsolutions.backend.security;

import jakarta.servlet.http.HttpServletResponse;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;

@Configuration
@EnableMethodSecurity
public class SecurityConfig {

    @Bean
    public SessionRegistry sessionRegistry() {
        return new SessionRegistryImpl();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return PasswordEncoderFactories.createDelegatingPasswordEncoder();
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider(
            AppUserDetailsService userDetailsService,
            PasswordEncoder passwordEncoder
    ) {
        DaoAuthenticationProvider provider =
                new DaoAuthenticationProvider(userDetailsService);

        provider.setPasswordEncoder(passwordEncoder);

        return provider;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(
            HttpSecurity http,
            DaoAuthenticationProvider authenticationProvider,
            SessionRegistry sessionRegistry
    ) throws Exception {

        http
                .authenticationProvider(authenticationProvider)

                .csrf(csrf -> csrf.spa())

                .authorizeHttpRequests(auth -> auth
                        .requestMatchers(
                                "/api/health",
                                "/api/auth/csrf",
                                "/api/auth/login",
                                "/api/auth/password-recovery/**",
                                "/api/invitations/validate",
                                "/api/invitations/activate"
                        ).permitAll()
                        .requestMatchers("/api/**").authenticated()
                        // Angular y sus archivos públicos pueden descargarse sin sesión.
                        // Las operaciones y datos permanecen protegidos en /api/**.
                        .requestMatchers(
                                "/", "/index.html", "/favicon.ico",
                                "/*.js", "/*.css", "/*.png", "/*.svg", "/*.ico",
                                "/*.woff", "/*.woff2", "/assets/**", "/media/**",
                                "/login", "/activar-cuenta", "/sin-accesos", "/sin-permiso",
                                "/dashboard", "/gastos", "/calendario",
                                "/activos", "/trabajadores", "/configuracion", "/historial",
                                "/documentos/**", "/areas/**"
                        ).permitAll()
                        .anyRequest().denyAll()
                )

                .formLogin(form -> form
                        .loginProcessingUrl("/api/auth/login")
                        .successHandler((request, response, authentication) ->
                                response.setStatus(
                                        HttpServletResponse.SC_NO_CONTENT
                                )
                        )
                        .failureHandler((request, response, exception) ->
                                response.setStatus(
                                        HttpServletResponse.SC_UNAUTHORIZED
                                )
                        )
                        .permitAll()
                )

                .logout(logout -> logout
                        .logoutUrl("/api/auth/logout")
                        .logoutSuccessHandler((request, response, authentication) ->
                                response.setStatus(
                                        HttpServletResponse.SC_NO_CONTENT
                                )
                        )
                        .deleteCookies("JSESSIONID")
                )

                .httpBasic(AbstractHttpConfigurer::disable)

                .requestCache(AbstractHttpConfigurer::disable)

                .exceptionHandling(exceptions ->
                        exceptions.authenticationEntryPoint(
                                (request, response, exception) ->
                                        response.setStatus(
                                                HttpServletResponse.SC_UNAUTHORIZED
                                        )
                        ).accessDeniedHandler(
                                (request, response, exception) ->
                                        response.setStatus(HttpServletResponse.SC_FORBIDDEN)
                        )
                )

                .sessionManagement(session ->
                        session.sessionFixation(
                                fixation -> fixation.changeSessionId()
                        ).maximumSessions(-1)
                                .sessionRegistry(sessionRegistry)
                                .expiredSessionStrategy(event -> event.getResponse().setStatus(
                                        HttpServletResponse.SC_UNAUTHORIZED))
                );

        return http.build();
    }
}
