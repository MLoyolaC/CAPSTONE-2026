package cl.mmsolutions.backend.invitation;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.Lock;

import java.time.OffsetDateTime;
import java.util.Optional;

public interface AccountInvitationRepository extends JpaRepository<AccountInvitation, Long> {
    Optional<AccountInvitation> findByTokenHash(String tokenHash);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select i from AccountInvitation i join fetch i.user where i.tokenHash = :tokenHash")
    Optional<AccountInvitation> findByTokenHashForUpdate(@Param("tokenHash") String tokenHash);

    @Modifying
    @Query("update AccountInvitation i set i.invalidatedAt = :now where i.user.id = :userId and i.usedAt is null and i.invalidatedAt is null")
    int invalidateOpenForUser(@Param("userId") Long userId, @Param("now") OffsetDateTime now);
}
