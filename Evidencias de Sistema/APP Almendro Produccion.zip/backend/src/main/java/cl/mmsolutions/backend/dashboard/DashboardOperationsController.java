package cl.mmsolutions.backend.dashboard;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardOperationsController {
    private final DashboardOperationsService service;

    public DashboardOperationsController(DashboardOperationsService service) {
        this.service = service;
    }

    @GetMapping("/operations")
    @PreAuthorize("@permissionService.has(authentication, 'dashboard')")
    public DashboardOperationsResponse operations(Authentication authentication) {
        return service.overview(authentication.getName());
    }
}
