package cl.mmsolutions.backend.dashboard;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

public record DashboardOperationsResponse(
        LocalDate asOf,
        int upcomingDays,
        List<AreaOverview> areas,
        List<ItemSummary> items
) {
    public record AreaOverview(
            String slug,
            String name,
            int open,
            int pending,
            int inProgress,
            int overdue,
            int upcoming,
            int completed,
            int cancelled,
            int otherOpen,
            int total,
            BigDecimal averageProgress,
            BigDecimal estimatedCost,
            BigDecimal actualCost,
            String dimensionLabel,
            List<DimensionCount> dimensions
    ) {}

    public record DimensionCount(String label, int count) {}

    public record ItemSummary(
            UUID id,
            String areaSlug,
            String areaName,
            String workType,
            String title,
            String location,
            String responsibleName,
            String priority,
            String status,
            String operationalState,
            LocalDate scheduledStart,
            LocalDate scheduledEnd,
            LocalDate completedDate,
            BigDecimal progressPercent,
            Integer plannedYear,
            Integer plannedMonth,
            String category,
            String assetName,
            String frequency,
            String season,
            BigDecimal estimatedCost,
            BigDecimal actualCost,
            OffsetDateTime updatedAt,
            boolean upcoming
    ) {}
}
