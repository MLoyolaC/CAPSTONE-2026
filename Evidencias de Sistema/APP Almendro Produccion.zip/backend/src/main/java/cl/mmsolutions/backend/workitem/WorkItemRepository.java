package cl.mmsolutions.backend.workitem;

import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface WorkItemRepository
        extends JpaRepository<WorkItem, UUID> {

    List<WorkItem> findByArea_SlugAndWorkTypeOrderByScheduledStartAscCreatedAtDesc(
            String areaSlug,
            String workType
    );

    boolean existsBySourceKey(String sourceKey);

    Optional<WorkItem> findBySourceKey(String sourceKey);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select item from WorkItem item where item.id in :ids")
    List<WorkItem> findAllByIdInForUpdate(@Param("ids") List<UUID> ids);

    boolean existsByImportSourceFilenameAndSourceSheetNameAndSourceRowNumberAndTitle(
            String importSourceFilename,
            String sourceSheetName,
            Integer sourceRowNumber,
            String title
    );
}
