package cl.mmsolutions.backend.importing;

import org.apache.poi.ss.usermodel.DateUtil;

import java.time.LocalDate;

public final class ExcelDateSupport {
    private ExcelDateSupport() {}

    public static LocalDate toLocalDate(double serialDate) {
        if (!DateUtil.isValidExcelDate(serialDate)) {
            throw new IllegalArgumentException("Fecha Excel inválida.");
        }
        return DateUtil.getLocalDateTime(serialDate).toLocalDate();
    }
}
