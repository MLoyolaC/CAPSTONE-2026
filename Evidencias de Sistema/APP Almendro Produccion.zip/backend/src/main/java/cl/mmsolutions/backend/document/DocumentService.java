package cl.mmsolutions.backend.document;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Comment;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Paths;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

@Service
public class DocumentService {
    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentService.class);

    private static final long MAX_FILE_SIZE =
            25L * 1024L * 1024L;

    private static final int MAX_PREVIEW_ROWS =
            200;

    private static final int MAX_PREVIEW_COLUMNS =
            40;

    private final JdbcTemplate jdbcTemplate;
    private final DocumentStorageProvider storage;

    public DocumentService(
            JdbcTemplate jdbcTemplate,
            DocumentStorageProvider storage
    ) {
        this.jdbcTemplate = jdbcTemplate;
        this.storage = storage;
    }


    /*
     * ============================================================
     * LISTAR DOCUMENTOS DE UN ÁREA
     * ============================================================
     */

    public List<DocumentSummary>
    getDocumentsByArea(
            String areaSlug
    ) {

        return jdbcTemplate.query(
                """
                SELECT
                    d.id,
                    d.name,
                    d.file_type,
                    d.index_status,
                    d.created_at,
                    dv.version_number,
                    dv.size_bytes,
                    dv.original_filename
                FROM document d
                INNER JOIN area a
                    ON a.id = d.area_id
                INNER JOIN document_version dv
                    ON dv.id = d.current_version_id
                WHERE a.slug = ?
                  AND a.active = TRUE
                  AND d.status = 'ACTIVE'
                ORDER BY
                    d.updated_at DESC,
                    d.created_at DESC
                """,

                (rs, rowNum) ->
                        new DocumentSummary(
                                rs.getObject(
                                        "id",
                                        UUID.class
                                ),

                                rs.getString(
                                        "name"
                                ),

                                rs.getString(
                                        "file_type"
                                ),

                                rs.getString(
                                        "index_status"
                                ),

                                rs.getInt(
                                        "version_number"
                                ),

                                rs.getLong(
                                        "size_bytes"
                                ),

                                rs.getString(
                                        "original_filename"
                                ),

                                rs.getObject(
                                        "created_at",
                                        OffsetDateTime.class
                                )
                        ),

                areaSlug
        );
    }


    /*
     * ============================================================
     * SUBIR DOCUMENTO NUEVO
     * ============================================================
     */

    @Transactional
    public DocumentSummary upload(
            String areaSlug,
            MultipartFile file,
            String username
    ) {

        validateFile(file);

        Long areaId =
                findAreaId(
                        areaSlug
                );

        Long userId =
                findUserId(
                        username
                );

        String originalFilename =
                sanitizeFilename(
                        file.getOriginalFilename()
                );

        String extension =
                getExtension(
                        originalFilename
                );

        String fileType =
                extension.toUpperCase(
                        Locale.ROOT
                );

        String mimeType =
                getMimeType(
                        extension
                );

        String indexStatus =
                fileType.equals("PDF")
                        ? "NOT_APPLICABLE"
                        : "PENDING";

        UUID documentId =
                UUID.randomUUID();

        UUID versionId =
                UUID.randomUUID();

        String sha256 = calculateHash(file);
        String storageKey = storage.buildKey(documentId, versionId, originalFilename);
        storeAndVerify(file, storageKey, mimeType, sha256);
        registerRollbackCleanup(storageKey);
        String localPath = storage.kind() == DocumentStorageProvider.Kind.LOCAL
                ? storage.databasePath(storageKey) : null;
        String cloudPath = storage.kind() == DocumentStorageProvider.Kind.SUPABASE
                ? storage.databasePath(storageKey) : null;
        String syncStatus = storage.kind() == DocumentStorageProvider.Kind.LOCAL ? "LOCAL_ONLY" : "SYNCED";

        try {

            jdbcTemplate.update(
                    """
                    INSERT INTO document (
                        id,
                        area_id,
                        name,
                        file_type,
                        status,
                        index_status,
                        created_by
                    )
                    VALUES (
                        ?, ?, ?, ?,
                        'ACTIVE',
                        ?,
                        ?
                    )
                    """,

                    documentId,
                    areaId,
                    originalFilename,
                    fileType,
                    indexStatus,
                    userId
            );

            jdbcTemplate.update(
                    """
                    INSERT INTO document_version (
                        id,
                        document_id,
                        version_number,
                        original_filename,
                        mime_type,
                        size_bytes,
                        sha256,
                        local_storage_path,
                        cloud_storage_path,
                        sync_status,
                        source,
                        uploaded_by
                    )
                    VALUES (
                        ?, ?, 1, ?, ?, ?, ?, ?, ?, ?,
                        'ORIGINAL',
                        ?
                    )
                    """,

                    versionId,
                    documentId,
                    originalFilename,
                    mimeType,
                    file.getSize(),
                    sha256,
                    localPath,
                    cloudPath,
                    syncStatus,
                    userId
            );

            jdbcTemplate.update(
                    """
                    UPDATE document
                    SET
                        current_version_id = ?,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """,

                    versionId,
                    documentId
            );

            jdbcTemplate.update(
                    """
                    INSERT INTO document_activity (
                        document_id,
                        document_version_id,
                        user_id,
                        action
                    )
                    VALUES (
                        ?, ?, ?, 'UPLOADED'
                    )
                    """,

                    documentId,
                    versionId,
                    userId
            );

        } catch (RuntimeException e) {
            cleanupStoredObject(storageKey, e);
            throw e;
        }

        return new DocumentSummary(
                documentId,
                originalFilename,
                fileType,
                indexStatus,
                1,
                file.getSize(),
                originalFilename,
                OffsetDateTime.now()
        );
    }


    /*
     * ============================================================
     * REEMPLAZAR / CREAR NUEVA VERSIÓN
     * ============================================================
     */

    @Transactional
    public DocumentSummary replace(
            UUID documentId,
            MultipartFile file,
            String username
    ) {

        validateFile(file);

        Long userId =
                findUserId(
                        username
                );

        CurrentDocument current =
                findCurrentDocumentForUpdate(
                        documentId
                );

        String newFilename =
                sanitizeFilename(
                        file.getOriginalFilename()
                );

        String extension =
                getExtension(
                        newFilename
                );

        String fileType =
                extension.toUpperCase(
                        Locale.ROOT
                );

        if (!fileType.equals(
                current.fileType()
        )) {

            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "La nueva versión debe tener el mismo tipo de archivo."
            );
        }

        int newVersionNumber =
                current.versionNumber() + 1;

        UUID newVersionId =
                UUID.randomUUID();

        String storageKey = storage.buildKey(documentId, newVersionId, newFilename);

        String newHash = calculateHash(file);

        if (newHash.equalsIgnoreCase(
                current.sha256()
        )) {

            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "El archivo no contiene cambios respecto de la versión actual."
            );
        }

        String indexStatus =
                fileType.equals("PDF")
                        ? "NOT_APPLICABLE"
                        : "PENDING";

        storeAndVerify(file, storageKey, getMimeType(extension), newHash);
        registerRollbackCleanup(storageKey);
        String localPath = storage.kind() == DocumentStorageProvider.Kind.LOCAL
                ? storage.databasePath(storageKey) : null;
        String cloudPath = storage.kind() == DocumentStorageProvider.Kind.SUPABASE
                ? storage.databasePath(storageKey) : null;
        String syncStatus = storage.kind() == DocumentStorageProvider.Kind.LOCAL ? "LOCAL_ONLY" : "SYNCED";

        try {

            jdbcTemplate.update(
                    """
                    INSERT INTO document_version (
                        id,
                        document_id,
                        version_number,
                        original_filename,
                        mime_type,
                        size_bytes,
                        sha256,
                        local_storage_path,
                        cloud_storage_path,
                        sync_status,
                        source,
                        uploaded_by
                    )
                    VALUES (
                        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                        'REPLACEMENT',
                        ?
                    )
                    """,

                    newVersionId,
                    documentId,
                    newVersionNumber,
                    newFilename,
                    getMimeType(extension),
                    file.getSize(),
                    newHash,
                    localPath,
                    cloudPath,
                    syncStatus,
                    userId
            );

            jdbcTemplate.update(
                    """
                    UPDATE document
                    SET
                        current_version_id = ?,
                        name = ?,
                        index_status = ?,
                        last_indexed_at = NULL,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                      AND status = 'ACTIVE'
                    """,

                    newVersionId,
                    newFilename,
                    indexStatus,
                    documentId
            );

            jdbcTemplate.update(
                    """
                    DELETE FROM document_search_entry
                    WHERE document_id = ?
                    """,

                    documentId
            );

            jdbcTemplate.update(
                    """
                    INSERT INTO document_activity (
                        document_id,
                        document_version_id,
                        user_id,
                        action
                    )
                    VALUES (
                        ?, ?, ?, 'REPLACED'
                    )
                    """,

                    documentId,
                    newVersionId,
                    userId
            );

        } catch (RuntimeException e) {
            cleanupStoredObject(storageKey, e);
            throw e;
        }

        return new DocumentSummary(
                documentId,
                newFilename,
                fileType,
                indexStatus,
                newVersionNumber,
                file.getSize(),
                newFilename,
                current.createdAt()
        );
    }


    /*
     * ============================================================
     * ELIMINAR DOCUMENTO
     * BORRADO LÓGICO
     * ============================================================
     */

    @Transactional
    public void delete(
            UUID documentId,
            String username
    ) {

        Long userId =
                findUserId(
                        username
                );

        CurrentDocument current =
                findCurrentDocumentForUpdate(
                        documentId
                );

        int updated =
                jdbcTemplate.update(
                        """
                        UPDATE document
                        SET
                            status = 'DELETED',
                            updated_at = CURRENT_TIMESTAMP
                        WHERE id = ?
                          AND status = 'ACTIVE'
                        """,

                        documentId
                );

        if (updated == 0) {

            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Documento no encontrado."
            );
        }

        jdbcTemplate.update(
                """
                INSERT INTO document_activity (
                    document_id,
                    document_version_id,
                    user_id,
                    action
                )
                VALUES (
                    ?, ?, ?, 'DELETED'
                )
                """,

                documentId,
                current.versionId(),
                userId
        );
    }

    @Transactional
    public void recordAccess(UUID documentId, String username, String action) {
        if (!"OPENED".equals(action) && !"DOWNLOADED".equals(action)) {
            throw new IllegalArgumentException("Acción documental no permitida.");
        }
        int inserted = jdbcTemplate.update(
                """
                INSERT INTO document_activity (document_id, document_version_id, user_id, action)
                SELECT d.id, d.current_version_id, u.id, ?
                FROM document d
                INNER JOIN app_user u ON LOWER(u.username) = LOWER(?) AND u.enabled = TRUE
                WHERE d.id = ? AND d.status = 'ACTIVE'
                """,
                action, username, documentId
        );
        if (inserted == 0) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Documento no encontrado.");
    }


    /*
     * ============================================================
     * VISTA PREVIA EXCEL
     * ============================================================
     */

    public ExcelPreview getExcelPreview(
            UUID documentId
    ) {

        StoredDocumentFile storedFile =
                getCurrentFile(
                        documentId
                );

        if (!storedFile.fileType()
                .equals("XLSX")) {

            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "La vista previa tabular está disponible solamente para archivos XLSX."
            );
        }

        List<ExcelSheetPreview> sheets =
                new ArrayList<>();

        try (
                InputStream inputStream =
                        storage.open(storedFile.storageKey());

                Workbook workbook =
                        WorkbookFactory.create(
                                inputStream
                        )
        ) {

            DataFormatter formatter =
                    new DataFormatter();

            FormulaEvaluator evaluator =
                    workbook
                            .getCreationHelper()
                            .createFormulaEvaluator();

            for (
                    int sheetIndex = 0;
                    sheetIndex < workbook.getNumberOfSheets();
                    sheetIndex++
            ) {

                Sheet sheet =
                        workbook.getSheetAt(
                                sheetIndex
                        );

                int totalRows;

                if (sheet.getPhysicalNumberOfRows() == 0) {

                    totalRows = 0;

                } else {

                    totalRows =
                            sheet.getLastRowNum() + 1;
                }

                int totalColumns = 0;

                for (Row row : sheet) {

                    short lastCell =
                            row.getLastCellNum();

                    if (lastCell > totalColumns) {

                        totalColumns =
                                lastCell;
                    }
                }

                int previewRows =
                        Math.min(
                                totalRows,
                                MAX_PREVIEW_ROWS
                        );

                int previewColumns =
                        Math.min(
                                totalColumns,
                                MAX_PREVIEW_COLUMNS
                        );

                List<ExcelRowPreview> rows =
                        new ArrayList<>();

                for (
                        int rowIndex = 0;
                        rowIndex < previewRows;
                        rowIndex++
                ) {

                    Row row =
                            sheet.getRow(
                                    rowIndex
                            );

                    List<ExcelCellPreview> cells =
                            new ArrayList<>();

                    for (
                            int columnIndex = 0;
                            columnIndex < previewColumns;
                            columnIndex++
                    ) {

                        Cell cell =
                                row == null
                                        ? null
                                        : row.getCell(
                                                columnIndex,
                                                Row.MissingCellPolicy.RETURN_BLANK_AS_NULL
                                        );

                        String value = "";

                        String note = null;

                        if (cell != null) {

                            try {

                                value =
                                        formatter.formatCellValue(
                                                cell,
                                                evaluator
                                        );

                            } catch (RuntimeException ignored) {

                                value =
                                        formatter.formatCellValue(
                                                cell
                                        );
                            }

                            Comment comment =
                                    cell.getCellComment();

                            if (
                                    comment != null
                                    && comment.getString() != null
                            ) {

                                note =
                                        comment
                                                .getString()
                                                .getString();
                            }
                        }

                        String reference =
                                columnName(
                                        columnIndex
                                )
                                        + (rowIndex + 1);

                        cells.add(
                                new ExcelCellPreview(
                                        columnIndex + 1,
                                        reference,
                                        value,
                                        note
                                )
                        );
                    }

                    rows.add(
                            new ExcelRowPreview(
                                    rowIndex + 1,
                                    cells
                            )
                    );
                }

                boolean truncated =
                        totalRows > MAX_PREVIEW_ROWS
                                || totalColumns > MAX_PREVIEW_COLUMNS;

                sheets.add(
                        new ExcelSheetPreview(
                                sheet.getSheetName(),
                                totalRows,
                                totalColumns,
                                truncated,
                                rows
                        )
                );
            }

        } catch (IOException e) {

            throw new ResponseStatusException(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "No fue posible generar la vista previa del Excel."
            );
        }

        return new ExcelPreview(
                storedFile.filename(),
                sheets
        );
    }


    /*
     * ============================================================
     * VISTA PREVIA DOCX
     * ============================================================
     */

    public DocxPreview getDocxPreview(UUID documentId) {
        StoredDocumentFile storedFile = getCurrentFile(documentId);
        if (!storedFile.fileType().equals("DOCX")) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "La vista previa de documento está disponible solamente para DOCX.");
        }
        List<DocxBlock> blocks = new ArrayList<>();
        try (InputStream in = storage.open(storedFile.storageKey()); XWPFDocument doc = new XWPFDocument(in)) {
            for (var element : doc.getBodyElements()) {
                if (element instanceof XWPFParagraph paragraph) {
                    String text = paragraph.getText() == null ? "" : paragraph.getText().trim();
                    if (!text.isBlank()) {
                        String style = paragraph.getStyle();
                        boolean heading = style != null && style.toLowerCase(Locale.ROOT).contains("heading");
                        blocks.add(new DocxBlock(heading ? "HEADING" : "PARAGRAPH", text, List.of()));
                    }
                } else if (element instanceof XWPFTable table) {
                    List<List<String>> rows = new ArrayList<>();
                    for (XWPFTableRow row : table.getRows()) {
                        List<String> cells = new ArrayList<>();
                        for (XWPFTableCell cell : row.getTableCells()) {
                            cells.add(cell.getText() == null ? "" : cell.getText().trim());
                        }
                        rows.add(cells);
                    }
                    if (!rows.isEmpty()) blocks.add(new DocxBlock("TABLE", null, rows));
                }
            }
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "No fue posible generar la vista previa del Word.");
        }
        return new DocxPreview(storedFile.filename(), blocks);
    }

    /*
     * ============================================================
     * OBTENER ARCHIVO ACTUAL
     * ============================================================
     */

    public StoredDocumentFile getCurrentFile(
            UUID documentId
    ) {

        List<StoredDocumentFile> files =
                jdbcTemplate.query(
                        """
                        SELECT
                            d.file_type,
                            dv.original_filename,
                            dv.mime_type,
                            dv.local_storage_path,
                            dv.cloud_storage_path,
                            dv.version_number,
                            dv.size_bytes,
                            dv.sha256
                        FROM document d
                        INNER JOIN document_version dv
                            ON dv.id = d.current_version_id
                        WHERE d.id = ?
                          AND d.status = 'ACTIVE'
                        """,

                        (rs, rowNum) ->
                                new StoredDocumentFile(
                                        rs.getString(
                                                "original_filename"
                                        ),

                                        rs.getString(
                                                "mime_type"
                                        ),

                                        rs.getString(
                                                "file_type"
                                        ),

                                        storage.keyFromDatabase(
                                                rs.getString("local_storage_path"),
                                                rs.getString("cloud_storage_path")
                                        ),
                                        rs.getInt("version_number"),
                                        rs.getLong("size_bytes"),
                                        rs.getString("sha256")
                                ),

                        documentId
                );

        if (files.isEmpty()) {

            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Documento no encontrado."
            );
        }

        StoredDocumentFile file =
                files.getFirst();

        if (file.storageKey() == null || file.storageKey().isBlank()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "El archivo no está disponible en el proveedor configurado.");
        }
        verifyStoredFile(file.storageKey(), file.sizeBytes(), file.sha256());

        return new StoredDocumentFile(
                file.filename(),
                file.mimeType(),
                file.fileType(),
                file.storageKey(),
                file.versionNumber(),
                file.sizeBytes(),
                file.sha256()
        );
    }

    public InputStream openStoredFile(StoredDocumentFile file) throws IOException {
        return storage.open(file.storageKey());
    }

    private void verifyStoredFile(String key, long expectedSize, String expectedSha256) {
        try {
            DocumentStorageProvider.StorageMetadata metadata = storage.metadata(key);
            if ((metadata.size() >= 0 && metadata.size() != expectedSize)
                    || !calculateHash(storage.open(key)).equalsIgnoreCase(expectedSha256)) {
                throw new ResponseStatusException(
                        HttpStatus.UNPROCESSABLE_ENTITY,
                        "El archivo almacenado está dañado o incompleto."
                );
            }
        } catch (IOException exception) {
            throw new ResponseStatusException(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "No fue posible leer el archivo almacenado."
            );
        }
    }

    private String calculateHash(InputStream source) throws IOException {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            try (InputStream input = new DigestInputStream(source, digest)) {
                input.transferTo(OutputStream.nullOutputStream());
            }
            return HexFormat.of().formatHex(digest.digest());
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("SHA-256 no está disponible.", exception);
        }
    }


    /*
     * ============================================================
     * DOCUMENTO ACTUAL
     * ============================================================
     */

    private CurrentDocument findCurrentDocumentForUpdate(
            UUID documentId
    ) {

        List<UUID> locked = jdbcTemplate.query(
                """
                SELECT id
                FROM document
                WHERE id = ?
                  AND status = 'ACTIVE'
                FOR UPDATE
                """,
                (rs, rowNum) -> rs.getObject("id", UUID.class),
                documentId
        );

        if (locked.isEmpty()) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Documento no encontrado."
            );
        }

        List<CurrentDocument> documents =
                jdbcTemplate.query(
                        """
                        SELECT
                            d.id,
                            d.name,
                            d.file_type,
                            d.created_at,
                            dv.id AS version_id,
                            dv.version_number,
                            dv.sha256
                        FROM document d
                        INNER JOIN document_version dv
                            ON dv.id = d.current_version_id
                        WHERE d.id = ?
                          AND d.status = 'ACTIVE'
                        """,

                        (rs, rowNum) ->
                                new CurrentDocument(
                                        rs.getObject(
                                                "id",
                                                UUID.class
                                        ),

                                        rs.getString(
                                                "name"
                                        ),

                                        rs.getString(
                                                "file_type"
                                        ),

                                        rs.getObject(
                                                "created_at",
                                                OffsetDateTime.class
                                        ),

                                        rs.getObject(
                                                "version_id",
                                                UUID.class
                                        ),

                                        rs.getInt(
                                                "version_number"
                                        ),

                                        rs.getString(
                                                "sha256"
                                        )
                                ),

                        documentId
                );

        if (documents.isEmpty()) {

            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Documento no encontrado."
            );
        }

        return documents.getFirst();
    }


    /*
     * ============================================================
     * BUSCAR ÁREA
     * ============================================================
     */

    private Long findAreaId(
            String slug
    ) {

        List<Long> ids =
                jdbcTemplate.query(
                        """
                        SELECT id
                        FROM area
                        WHERE slug = ?
                          AND active = TRUE
                        """,

                        (rs, rowNum) ->
                                rs.getLong(
                                        "id"
                                ),

                        slug
                );

        if (ids.isEmpty()) {

            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Área no encontrada."
            );
        }

        return ids.getFirst();
    }


    /*
     * ============================================================
     * BUSCAR USUARIO
     * ============================================================
     */

    private Long findUserId(
            String username
    ) {

        List<Long> ids =
                jdbcTemplate.query(
                        """
                        SELECT id
                        FROM app_user
                        WHERE username = ?
                          AND enabled = TRUE
                        """,

                        (rs, rowNum) ->
                                rs.getLong(
                                        "id"
                                ),

                        username
                );

        if (ids.isEmpty()) {

            throw new ResponseStatusException(
                    HttpStatus.UNAUTHORIZED,
                    "Usuario no válido."
            );
        }

        return ids.getFirst();
    }


    /*
     * ============================================================
     * VALIDAR ARCHIVO
     * ============================================================
     */

    private void validateFile(
            MultipartFile file
    ) {

        if (
                file == null
                || file.isEmpty()
        ) {

            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Debe seleccionar un archivo."
            );
        }

        if (
                file.getSize()
                > MAX_FILE_SIZE
        ) {

            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "El archivo supera el máximo permitido de 25 MB."
            );
        }

        String filename =
                sanitizeFilename(
                        file.getOriginalFilename()
                );

        String extension =
                getExtension(
                        filename
                );

        if (
                !extension.equals("xlsx")
                && !extension.equals("docx")
                && !extension.equals("pdf")
        ) {

            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Solo se permiten archivos XLSX, DOCX o PDF."
            );
        }
        validateSignature(file, extension);
    }

    private void validateSignature(MultipartFile file, String extension) {
        try {
            if ("pdf".equals(extension)) {
                try (InputStream input = file.getInputStream()) {
                    byte[] signature = input.readNBytes(5);
                    if (signature.length != 5 || signature[0] != '%' || signature[1] != 'P'
                            || signature[2] != 'D' || signature[3] != 'F' || signature[4] != '-') {
                        throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                                "El contenido del archivo no corresponde a un PDF válido.");
                    }
                }
                return;
            }
            boolean contentTypes = false;
            boolean expectedPayload = false;
            String required = "docx".equals(extension) ? "word/document.xml" : "xl/workbook.xml";
            try (ZipInputStream zip = new ZipInputStream(file.getInputStream())) {
                ZipEntry entry;
                while ((entry = zip.getNextEntry()) != null) {
                    String name = entry.getName();
                    if ("[Content_Types].xml".equals(name)) contentTypes = true;
                    if (required.equals(name)) expectedPayload = true;
                    if (contentTypes && expectedPayload) break;
                }
            }
            if (!contentTypes || !expectedPayload) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                        "El contenido del archivo no corresponde a su formato Office.");
            }
        } catch (ResponseStatusException exception) {
            throw exception;
        } catch (IOException exception) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No fue posible validar el archivo recibido.");
        }
    }


    /*
     * ============================================================
     * LIMPIAR NOMBRE
     * ============================================================
     */

    private String sanitizeFilename(
            String filename
    ) {

        if (
                filename == null
                || filename.isBlank()
        ) {

            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "El archivo no tiene un nombre válido."
            );
        }

        String safeName =
                Paths.get(
                                filename
                        )
                        .getFileName()
                        .toString()
                        .trim();

        safeName =
                safeName.replaceAll(
                        "[\\p{Cntrl}]",
                        ""
                );

        if (safeName.isBlank()) {

            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "El archivo no tiene un nombre válido."
            );
        }

        return safeName;
    }


    /*
     * ============================================================
     * OBTENER EXTENSIÓN
     * ============================================================
     */

    private String getExtension(
            String filename
    ) {

        int lastDot =
                filename.lastIndexOf(
                        '.'
                );

        if (
                lastDot < 0
                || lastDot == filename.length() - 1
        ) {

            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "El archivo no posee una extensión válida."
            );
        }

        return filename
                .substring(
                        lastDot + 1
                )
                .toLowerCase(
                        Locale.ROOT
                );
    }


    /*
     * ============================================================
     * MIME TYPE
     * ============================================================
     */

    private String getMimeType(
            String extension
    ) {

        return switch (extension) {

            case "xlsx" ->
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

            case "docx" ->
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document";

            case "pdf" ->
                    "application/pdf";

            default ->
                    "application/octet-stream";
        };
    }


    /*
     * ============================================================
     * GUARDAR + SHA-256
     * ============================================================
     */

    private String calculateHash(MultipartFile file) {
        try { return calculateHash(file.getInputStream()); }
        catch (IOException exception) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No fue posible leer el archivo recibido.");
        }
    }

    private void storeAndVerify(MultipartFile file, String key, String mimeType, String expectedHash) {
        try {
            storage.store(key, file.getInputStream(), file.getSize(), mimeType);
            verifyStoredFile(key, file.getSize(), expectedHash);
        } catch (ResponseStatusException exception) {
            cleanupStoredObject(key, exception);
            throw exception;
        } catch (IOException | DocumentStorageException exception) {
            cleanupStoredObject(key, exception);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "No fue posible almacenar el documento.");
        }
    }

    private void registerRollbackCleanup(String key) {
        if (!TransactionSynchronizationManager.isSynchronizationActive()) return;
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override public void afterCompletion(int status) {
                if (status != TransactionSynchronization.STATUS_COMMITTED) cleanupStoredObject(key, null);
            }
        });
    }

    private void cleanupStoredObject(String key, Throwable original) {
        try {
            storage.delete(key);
        } catch (RuntimeException cleanup) {
            LOGGER.error("No fue posible compensar el objeto documental provider={} key={}",
                    storage.kind(), key, cleanup);
            if (original != null) original.addSuppressed(cleanup);
        }
    }


    /*
     * ============================================================
     * CONVERTIR COLUMNA A A, B, C...
     * ============================================================
     */

    private String columnName(
            int columnIndex
    ) {

        StringBuilder result =
                new StringBuilder();

        int number =
                columnIndex + 1;

        while (number > 0) {

            int remainder =
                    (number - 1) % 26;

            result.insert(
                    0,
                    (char) (
                            'A' + remainder
                    )
            );

            number =
                    (number - 1) / 26;
        }

        return result.toString();
    }


    /*
     * ============================================================
     * RECORDS INTERNOS
     * ============================================================
     */

    private record CurrentDocument(
            UUID id,
            String name,
            String fileType,
            OffsetDateTime createdAt,
            UUID versionId,
            int versionNumber,
            String sha256
    ) {
    }


    public record DocumentSummary(
            UUID id,
            String name,
            String fileType,
            String indexStatus,
            int versionNumber,
            long sizeBytes,
            String originalFilename,
            OffsetDateTime createdAt
    ) {
    }


    public record StoredDocumentFile(
            String filename,
            String mimeType,
            String fileType,
            String storageKey,
            int versionNumber,
            long sizeBytes,
            String sha256
    ) {
    }


    public record ExcelPreview(
            String filename,
            List<ExcelSheetPreview> sheets
    ) {
    }

    public record DocxPreview(String filename, List<DocxBlock> blocks) {}
    public record DocxBlock(String type, String text, List<List<String>> rows) {}


    public record ExcelSheetPreview(
            String name,
            int totalRows,
            int totalColumns,
            boolean truncated,
            List<ExcelRowPreview> rows
    ) {
    }


    public record ExcelRowPreview(
            int rowNumber,
            List<ExcelCellPreview> cells
    ) {
    }


    public record ExcelCellPreview(
            int columnNumber,
            String reference,
            String value,
            String note
    ) {
    }
}
