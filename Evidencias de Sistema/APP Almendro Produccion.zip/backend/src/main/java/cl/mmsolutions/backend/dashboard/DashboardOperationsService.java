package cl.mmsolutions.backend.dashboard;

import cl.mmsolutions.backend.dashboard.DashboardOperationsRepository.AreaRow;
import cl.mmsolutions.backend.dashboard.DashboardOperationsRepository.ItemRow;
import cl.mmsolutions.backend.dashboard.DashboardOperationsResponse.AreaOverview;
import cl.mmsolutions.backend.dashboard.DashboardOperationsResponse.DimensionCount;
import cl.mmsolutions.backend.dashboard.DashboardOperationsResponse.ItemSummary;
import cl.mmsolutions.backend.security.PermissionService;
import cl.mmsolutions.backend.security.Permissions;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

@Service
public class DashboardOperationsService {
    static final int UPCOMING_DAYS = 14;
    private static final ZoneId CHILE = ZoneId.of("America/Santiago");
    private static final Locale ES_CL = Locale.forLanguageTag("es-CL");
    private static final List<String> OPERATIONAL_AREAS = List.of(
            "mantencion-general", "mantencion-reactiva", "mejoras", "remodelacion",
            "mantencion-maquinas", "mantencion-jardineria", "prevencion-riesgos"
    );

    private final DashboardOperationsRepository repository;
    private final PermissionService permissions;

    public DashboardOperationsService(DashboardOperationsRepository repository, PermissionService permissions) {
        this.repository = repository;
        this.permissions = permissions;
    }

    @Transactional(readOnly = true)
    public DashboardOperationsResponse overview(String username) {
        return overview(username, LocalDate.now(CHILE));
    }

    DashboardOperationsResponse overview(String username, LocalDate asOf) {
        Set<String> userPermissions = permissions.permissionsFor(username);
        Set<String> allowedSlugs = new LinkedHashSet<>();
        for (String slug : OPERATIONAL_AREAS) {
            if (userPermissions.contains(Permissions.forAreaSlug(slug))) allowedSlugs.add(slug);
        }

        List<AreaRow> areaRows = repository.findAreas(allowedSlugs);
        List<ItemRow> rows = repository.findItems(allowedSlugs);
        List<ItemSummary> items = rows.stream().map(row -> toSummary(row, asOf)).toList();
        Map<String, List<ItemRow>> byArea = new LinkedHashMap<>();
        for (ItemRow row : rows) byArea.computeIfAbsent(row.areaSlug(), ignored -> new ArrayList<>()).add(row);

        List<AreaOverview> areas = areaRows.stream()
                .map(area -> summarize(area, byArea.getOrDefault(area.slug(), List.of()), asOf))
                .toList();
        return new DashboardOperationsResponse(asOf, UPCOMING_DAYS, areas, items);
    }

    private AreaOverview summarize(AreaRow area, List<ItemRow> rows, LocalDate asOf) {
        int pending = 0;
        int inProgress = 0;
        int overdue = 0;
        int upcoming = 0;
        int completed = 0;
        int cancelled = 0;
        int otherOpen = 0;
        BigDecimal progress = BigDecimal.ZERO;
        int progressCount = 0;
        BigDecimal estimated = BigDecimal.ZERO;
        BigDecimal actual = BigDecimal.ZERO;

        Map<String, Integer> dimensions = new LinkedHashMap<>();
        for (ItemRow row : rows) {
            String state = operationalState(row, asOf);
            switch (state) {
                case "PENDING" -> pending++;
                case "IN_PROGRESS" -> inProgress++;
                case "OVERDUE" -> overdue++;
                case "COMPLETED" -> completed++;
                case "CANCELLED" -> cancelled++;
                default -> otherOpen++;
            }
            if (isUpcoming(row, asOf)) upcoming++;
            if (!"COMPLETED".equals(state) && !"CANCELLED".equals(state) && row.progressPercent() != null) {
                progress = progress.add(row.progressPercent());
                progressCount++;
            }
            if (row.estimatedCost() != null) estimated = estimated.add(row.estimatedCost());
            if (row.actualCost() != null) actual = actual.add(row.actualCost());
            String dimension = dimensionValue(area.slug(), row);
            if (dimension != null) dimensions.merge(dimension, 1, Integer::sum);
        }

        List<DimensionCount> topDimensions = dimensions.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed().thenComparing(Map.Entry.comparingByKey()))
                .limit(6)
                .map(entry -> new DimensionCount(entry.getKey(), entry.getValue()))
                .toList();
        BigDecimal averageProgress = progressCount == 0 ? null
                : progress.divide(BigDecimal.valueOf(progressCount), 1, RoundingMode.HALF_UP);
        int open = pending + inProgress + overdue + otherOpen;
        return new AreaOverview(area.slug(), area.name(), open, pending, inProgress, overdue, upcoming,
                completed, cancelled, otherOpen, rows.size(), averageProgress, estimated, actual,
                dimensionLabel(area.slug()), topDimensions);
    }

    private ItemSummary toSummary(ItemRow row, LocalDate asOf) {
        return new ItemSummary(row.id(), row.areaSlug(), row.areaName(), row.workType(), row.title(),
                row.location(), row.responsibleName(), row.priority(), row.status(), operationalState(row, asOf),
                row.scheduledStart(), row.scheduledEnd(), row.completedDate(), row.progressPercent(),
                row.plannedYear(), row.plannedMonth(), row.category(), row.assetName(), row.frequency(),
                row.season(), row.estimatedCost(), row.actualCost(), row.updatedAt(), isUpcoming(row, asOf));
    }

    static String operationalState(ItemRow row, LocalDate asOf) {
        String status = normalized(row.status());
        if ("COMPLETED".equals(status)) return "COMPLETED";
        if ("CANCELLED".equals(status)) return "CANCELLED";
        LocalDate due = dueDate(row);
        if ("OVERDUE".equals(status) || due != null && due.isBefore(asOf)) return "OVERDUE";
        if ("IN_PROGRESS".equals(status)) return "IN_PROGRESS";
        if (Set.of("PENDING", "PLANNED", "DRAFT", "IN_REVIEW").contains(status)) return "PENDING";
        return "OTHER_OPEN";
    }

    private static boolean isUpcoming(ItemRow row, LocalDate asOf) {
        String state = operationalState(row, asOf);
        if ("COMPLETED".equals(state) || "CANCELLED".equals(state) || "OVERDUE".equals(state)) return false;
        LocalDate due = dueDate(row);
        return due != null && !due.isBefore(asOf) && !due.isAfter(asOf.plusDays(UPCOMING_DAYS));
    }

    private static LocalDate dueDate(ItemRow row) {
        return row.scheduledEnd() != null ? row.scheduledEnd() : row.scheduledStart();
    }

    private static String normalized(String value) {
        return value == null ? "" : value.trim().toUpperCase(Locale.ROOT);
    }

    private static String dimensionLabel(String slug) {
        return switch (slug) {
            case "mantencion-general" -> "Ubicaciones con más registros";
            case "mantencion-reactiva" -> "Prioridad de incidencias";
            case "mejoras" -> "Categorías / orígenes";
            case "remodelacion" -> "Zonas intervenidas";
            case "mantencion-maquinas" -> "Equipos registrados";
            case "mantencion-jardineria" -> "Temporadas registradas";
            case "prevencion-riesgos" -> "Calendario preventivo";
            default -> "Distribución";
        };
    }

    private static String dimensionValue(String slug, ItemRow row) {
        return switch (slug) {
            case "mantencion-general", "remodelacion" -> clean(row.location());
            case "mantencion-reactiva" -> clean(row.priority());
            case "mejoras" -> clean(row.category());
            case "mantencion-maquinas" -> first(row.assetName(), row.location());
            case "mantencion-jardineria" -> first(row.season(), row.location(), row.category());
            case "prevencion-riesgos" -> monthLabel(dueDate(row));
            default -> null;
        };
    }

    private static String monthLabel(LocalDate date) {
        if (date == null) return null;
        String month = date.getMonth().getDisplayName(TextStyle.FULL, ES_CL);
        return month.substring(0, 1).toUpperCase(ES_CL) + month.substring(1) + " " + date.getYear();
    }

    private static String first(String... values) {
        for (String value : values) {
            String cleaned = clean(value);
            if (cleaned != null) return cleaned;
        }
        return null;
    }

    private static String clean(String value) {
        if (value == null || value.isBlank()) return null;
        return value.trim();
    }
}
