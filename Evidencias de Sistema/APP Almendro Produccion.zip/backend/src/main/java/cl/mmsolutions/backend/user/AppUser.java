package cl.mmsolutions.backend.user;

import jakarta.persistence.*;

import java.time.OffsetDateTime;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Table(name = "app_user")
public class AppUser {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 50)
    private String username;

    @Column(name = "password_hash", length = 255)
    private String passwordHash;

    @Column(name = "full_name", length = 120)
    private String fullName;

    @Column(length = 254)
    private String email;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Role role;

    @Column(nullable = false)
    private boolean enabled;

    @Enumerated(EnumType.STRING)
    @Column(name = "account_status", nullable = false, length = 30)
    private AccountStatus accountStatus = AccountStatus.ACTIVE;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "app_user_permission", joinColumns = @JoinColumn(name = "user_id"))
    @Column(name = "permission", nullable = false, length = 60)
    private Set<String> permissions = new LinkedHashSet<>();

    @Column(
        name = "created_at",
        nullable = false,
        insertable = false,
        updatable = false
    )
    private OffsetDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;

    protected AppUser() {
    }

    public AppUser(
            String username,
            String passwordHash,
            Role role,
            boolean enabled
    ) {
        this.username = username;
        this.passwordHash = passwordHash;
        this.role = role;
        this.enabled = enabled;
        this.fullName = username;
        this.accountStatus = enabled ? AccountStatus.ACTIVE : AccountStatus.DISABLED;
        this.updatedAt = OffsetDateTime.now();
    }

    public AppUser(String username, String fullName, String email, Role role) {
        this.username = username;
        this.fullName = fullName;
        this.email = email;
        this.role = role;
        this.enabled = false;
        this.accountStatus = AccountStatus.PENDING_ACTIVATION;
        this.updatedAt = OffsetDateTime.now();
    }

    public Long getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public Role getRole() {
        return role;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public String getFullName() { return fullName == null ? username : fullName; }
    public String getEmail() { return email; }
    public AccountStatus getAccountStatus() { return accountStatus; }
    public Set<String> getPermissions() { return permissions; }
    public OffsetDateTime getUpdatedAt() { return updatedAt; }

    public void updateEmail(String email) {
        this.email = email;
        this.updatedAt = OffsetDateTime.now();
    }

    public void updateProfile(String fullName, String email, Role role, Set<String> permissions) {
        this.fullName = fullName;
        this.email = email;
        this.role = role;
        this.permissions.clear();
        this.permissions.addAll(permissions);
        this.updatedAt = OffsetDateTime.now();
    }

    public void updateUsername(String username) {
        this.username = username;
        this.updatedAt = OffsetDateTime.now();
    }

    public void setEnabledState(boolean enabled) {
        if (accountStatus == AccountStatus.PENDING_ACTIVATION) return;
        this.enabled = enabled;
        this.accountStatus = enabled ? AccountStatus.ACTIVE : AccountStatus.DISABLED;
        this.updatedAt = OffsetDateTime.now();
    }

    public void activate(String encodedPassword) {
        this.passwordHash = encodedPassword;
        this.enabled = true;
        this.accountStatus = AccountStatus.ACTIVE;
        this.updatedAt = OffsetDateTime.now();
    }

    public void resetPassword(String encodedPassword) {
        if (!enabled || accountStatus != AccountStatus.ACTIVE) {
            throw new IllegalStateException("Only active accounts can reset their password.");
        }
        this.passwordHash = encodedPassword;
        this.updatedAt = OffsetDateTime.now();
    }
}
