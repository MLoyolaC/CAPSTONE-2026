package cl.mmsolutions.backend.remodeling;

import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.security.access.prepost.PreAuthorize;

@RestController
@RequestMapping("/api/remodeling-import")
@PreAuthorize("@permissionService.has(authentication, 'remodelacion') and @permissionService.has(authentication, 'import')")
public class RemodelingImportController {
    private final RemodelingImportService service;

    public RemodelingImportController(RemodelingImportService service) {
        this.service = service;
    }

    @PostMapping(value = "/analyze", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public RemodelingImportService.AnalysisResult analyze(@RequestPart("file") MultipartFile file) {
        return service.analyze(file);
    }

    @PostMapping(value = "/commit", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public RemodelingImportService.ImportResult commit(
            @RequestPart("file") MultipartFile file,
            @RequestParam(defaultValue = "false") boolean forceDuplicates,
            Authentication authentication
    ) {
        return service.commit(file, forceDuplicates, authentication == null ? null : authentication.getName());
    }
}
