package cl.mmsolutions.backend.security;

import java.util.LinkedHashSet;
import java.util.Set;

public final class Permissions {
    private Permissions() {}

    public static final Set<String> AREAS = Set.of(
            "dashboard", "mantencion-general", "mantencion-reactiva", "mejoras",
            "remodelacion", "maquinas", "jardineria", "prevencion", "calendario",
            "gastos", "documentos", "activos", "trabajadores", "configuracion"
    );
    public static final Set<String> ACTIONS = Set.of(
            "create-edit", "delete", "import", "history", "manage-access"
    );
    public static final Set<String> ALL;

    static {
        LinkedHashSet<String> values = new LinkedHashSet<>();
        values.addAll(AREAS);
        values.addAll(ACTIONS);
        ALL = Set.copyOf(values);
    }

    public static String forAreaSlug(String slug) {
        if (slug == null) return null;
        return switch (slug) {
            case "mantencion-maquinas" -> "maquinas";
            case "mantencion-jardineria" -> "jardineria";
            case "prevencion-riesgos" -> "prevencion";
            default -> slug;
        };
    }
}
