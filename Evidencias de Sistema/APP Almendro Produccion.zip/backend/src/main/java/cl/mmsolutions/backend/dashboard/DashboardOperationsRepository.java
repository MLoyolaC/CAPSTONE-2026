package cl.mmsolutions.backend.dashboard;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Set;
import java.util.UUID;

@Repository
class DashboardOperationsRepository {
    private final NamedParameterJdbcTemplate jdbc;

    DashboardOperationsRepository(NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    List<AreaRow> findAreas(Set<String> slugs) {
        if (slugs.isEmpty()) return List.of();
        return jdbc.query("""
                SELECT slug, name
                FROM area
                WHERE active = TRUE AND slug IN (:slugs)
                ORDER BY sort_order, name
                """, new MapSqlParameterSource("slugs", slugs), (rs, rowNum) ->
                new AreaRow(rs.getString("slug"), rs.getString("name")));
    }

    List<ItemRow> findItems(Set<String> slugs) {
        if (slugs.isEmpty()) return List.of();
        return jdbc.query("""
                SELECT w.id, a.slug AS area_slug, a.name AS area_name,
                       w.work_type, w.title, w.location, w.responsible_name,
                       w.priority, w.status, w.scheduled_start, w.scheduled_end,
                       w.completed_date, w.progress_percent, w.planned_year,
                       w.planned_month, w.category, w.asset_name, w.frequency,
                       w.season, w.estimated_cost, w.actual_cost, w.updated_at
                FROM work_item w
                JOIN area a ON a.id = w.area_id
                WHERE a.active = TRUE AND a.slug IN (:slugs)
                ORDER BY a.sort_order, w.updated_at DESC, w.title
                """, new MapSqlParameterSource("slugs", slugs), (rs, rowNum) -> new ItemRow(
                rs.getObject("id", UUID.class),
                rs.getString("area_slug"),
                rs.getString("area_name"),
                rs.getString("work_type"),
                rs.getString("title"),
                rs.getString("location"),
                rs.getString("responsible_name"),
                rs.getString("priority"),
                rs.getString("status"),
                localDate(rs.getDate("scheduled_start")),
                localDate(rs.getDate("scheduled_end")),
                localDate(rs.getDate("completed_date")),
                rs.getBigDecimal("progress_percent"),
                (Integer) rs.getObject("planned_year"),
                (Integer) rs.getObject("planned_month"),
                rs.getString("category"),
                rs.getString("asset_name"),
                rs.getString("frequency"),
                rs.getString("season"),
                rs.getBigDecimal("estimated_cost"),
                rs.getBigDecimal("actual_cost"),
                rs.getObject("updated_at", OffsetDateTime.class)
        ));
    }

    private static LocalDate localDate(Date date) {
        return date == null ? null : date.toLocalDate();
    }

    record AreaRow(String slug, String name) {}

    record ItemRow(
            UUID id,
            String areaSlug,
            String areaName,
            String workType,
            String title,
            String location,
            String responsibleName,
            String priority,
            String status,
            LocalDate scheduledStart,
            LocalDate scheduledEnd,
            LocalDate completedDate,
            BigDecimal progressPercent,
            Integer plannedYear,
            Integer plannedMonth,
            String category,
            String assetName,
            String frequency,
            String season,
            BigDecimal estimatedCost,
            BigDecimal actualCost,
            OffsetDateTime updatedAt
    ) {}
}
