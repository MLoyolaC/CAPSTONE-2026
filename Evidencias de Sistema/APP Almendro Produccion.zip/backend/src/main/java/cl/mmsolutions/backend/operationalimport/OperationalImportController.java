package cl.mmsolutions.backend.operationalimport;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.security.access.prepost.PreAuthorize;

@RestController
@RequestMapping("/api/operational-import")
public class OperationalImportController {
    private final OperationalImportService service;
    public OperationalImportController(OperationalImportService service){this.service=service;}

    @PostMapping(path="/{areaSlug}",consumes="multipart/form-data")
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("@permissionService.hasArea(authentication, #areaSlug) and @permissionService.has(authentication, 'import')")
    public OperationalImportService.ImportResult importFile(
            @PathVariable String areaSlug,
            @RequestPart("file") MultipartFile file,
            @RequestParam(defaultValue = "false") boolean forceDuplicates,
            Authentication auth
    ){
        return service.importFile(areaSlug,file,auth==null?null:auth.getName(),forceDuplicates);
    }
}
