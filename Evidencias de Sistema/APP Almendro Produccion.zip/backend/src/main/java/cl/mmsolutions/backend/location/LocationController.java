package cl.mmsolutions.backend.location;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.security.access.prepost.PreAuthorize;

import java.util.List;

@RestController
@RequestMapping("/api/areas/{areaSlug}/locations")
public class LocationController {

    private final LocationService locationService;

    public LocationController(LocationService locationService) {
        this.locationService = locationService;
    }

    @GetMapping
    @PreAuthorize("@permissionService.hasArea(authentication, #areaSlug)")
    public List<LocationService.LocationSuggestion> suggest(
            @PathVariable String areaSlug,
            @RequestParam(defaultValue = "") String q
    ) {
        return locationService.suggest(areaSlug, q);
    }
}
