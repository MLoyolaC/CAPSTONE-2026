package cl.mmsolutions.backend.workitem;

public record WorkItemAuditChange(
        String field,
        String label,
        String previousValue,
        String newValue,
        String valueType
) {
}
