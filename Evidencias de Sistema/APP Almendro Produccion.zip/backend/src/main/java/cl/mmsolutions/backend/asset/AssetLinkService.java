package cl.mmsolutions.backend.asset;

import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.text.Normalizer;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;

@Service
public class AssetLinkService {
    private final JdbcTemplate jdbc;

    public AssetLinkService(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    public AssetReference requireActive(UUID id) {
        AssetReference asset = requireExisting(id);
        if (!asset.active()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El activo seleccionado está dado de baja.");
        return asset;
    }

    public AssetReference requireExisting(UUID id) {
        return jdbc.query("""
                SELECT id, code, name, location, operational_status, active
                FROM asset WHERE id = ?
                """, (rs, row) -> new AssetReference(
                rs.getObject("id", UUID.class), rs.getString("code"), rs.getString("name"),
                rs.getString("location"), rs.getString("operational_status"), rs.getBoolean("active")
        ), id).stream().findFirst().orElseThrow(
                () -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "El activo seleccionado no existe.")
        );
    }

    /** Asociación automática conservadora: nombre y ubicación exactos, con un único activo activo. */
    public Optional<AssetReference> findExactUniqueActive(String name, String location) {
        String wantedName = normalize(name);
        String wantedLocation = normalize(location);
        if (wantedName.isBlank() || wantedLocation.isBlank()) return Optional.empty();
        List<AssetReference> matches = jdbc.query("""
                SELECT id, code, name, location, operational_status, active
                FROM asset WHERE active = TRUE
                """, (rs, row) -> new AssetReference(
                rs.getObject("id", UUID.class), rs.getString("code"), rs.getString("name"),
                rs.getString("location"), rs.getString("operational_status"), rs.getBoolean("active")
        )).stream().filter(asset -> wantedName.equals(normalize(asset.name()))
                && wantedLocation.equals(normalize(asset.location()))).toList();
        return matches.size() == 1 ? Optional.of(matches.getFirst()) : Optional.empty();
    }

    private String normalize(String value) {
        if (value == null) return "";
        return Normalizer.normalize(value, Normalizer.Form.NFD).replaceAll("\\p{M}+", "")
                .toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").trim().replaceAll("\\s+", " ");
    }

    public record AssetReference(UUID id, String code, String name, String location,
                                 String operationalStatus, boolean active) {}
}
