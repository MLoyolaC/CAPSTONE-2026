package cl.mmsolutions.backend.expenses;

import cl.mmsolutions.backend.workitem.WorkItem;
import cl.mmsolutions.backend.workitem.WorkItemRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Consolidación informativa a partir del costo real ACTUAL de cada trabajo.
 * No representa contabilidad, pagos ni movimientos históricos de caja.
 * No sumar presupuestos de Mejoras para evitar duplicarlos en Remodelación.
 */
@Service
public class ExpenseService {

    private final WorkItemRepository workItemRepository;

    public ExpenseService(WorkItemRepository workItemRepository) {
        this.workItemRepository = workItemRepository;
    }

    @Transactional(readOnly = true)
    public ExpenseReport report() {
        List<WorkItem> works = workItemRepository.findAll();
        Map<String, MutableArea> areaTotals = new LinkedHashMap<>();
        List<ExpenseDetail> details = new ArrayList<>();
        BigDecimal totalReal = BigDecimal.ZERO;
        BigDecimal proposalsEstimated = BigDecimal.ZERO;
        List<ProposalDetail> proposals = new ArrayList<>();

        for (WorkItem work : works) {
            String areaSlug = work.getArea().getSlug();
            String areaName = work.getArea().getName();
            MutableArea area = areaTotals.computeIfAbsent(
                    areaSlug, ignored -> new MutableArea(areaSlug, areaName)
            );

            // Las ideas/Mejoras son propuestas y no se suman al gasto real.
            if ("IMPROVEMENT".equals(work.getWorkType())) {
                if (positive(work.getEstimatedCost())) {
                    proposalsEstimated = proposalsEstimated.add(work.getEstimatedCost());
                    LocalDate target = work.getScheduledEnd() != null ? work.getScheduledEnd() : work.getScheduledStart();
                    proposals.add(new ProposalDetail(work.getId(), areaSlug, areaName, work.getTitle(), work.getLocation(), work.getStatus(), work.getEstimatedCost(), target, work.getPlannedYear(), work.getPlannedMonth()));
                }
                continue;
            }

            // Una actividad cancelada no debe contabilizarse como ejecución.
            if ("CANCELLED".equals(work.getStatus())) {
                continue;
            }

            BigDecimal amount = work.getActualCost();
            if (!positive(amount)) {
                continue;
            }

            totalReal = totalReal.add(amount);
            area.total = area.total.add(amount);
            area.records++;

            LocalDate operationDate = work.getCompletedDate() != null ? work.getCompletedDate()
                    : work.getScheduledEnd() != null ? work.getScheduledEnd()
                    : work.getScheduledStart() != null ? work.getScheduledStart()
                    : work.getCreatedAt() != null ? work.getCreatedAt().toLocalDate()
                    : null;

            details.add(new ExpenseDetail(
                    work.getId(), areaSlug, areaName, work.getTitle(),
                    work.getSupplierName(), work.getResponsibleName(),
                    work.getStatus(), amount, operationDate, work.getCreatedAt()
            ));
        }

        details.sort(Comparator.comparing(
                ExpenseDetail::createdAt,
                Comparator.nullsLast(Comparator.reverseOrder())
        ));

        List<AreaExpense> byArea = areaTotals.values().stream()
                .map(a -> new AreaExpense(a.slug, a.name, a.total, a.records))
                .sorted(Comparator.comparing(AreaExpense::total).reversed())
                .toList();

        proposals.sort(Comparator.comparing(ProposalDetail::targetDate, Comparator.nullsLast(Comparator.naturalOrder())));
        return new ExpenseReport(totalReal, proposalsEstimated, details.size(),
                byArea, details, proposals);
    }

    private boolean positive(BigDecimal amount) {
        return amount != null && amount.signum() > 0;
    }

    private static final class MutableArea {
        final String slug;
        final String name;
        BigDecimal total = BigDecimal.ZERO;
        int records = 0;

        MutableArea(String slug, String name) {
            this.slug = slug;
            this.name = name;
        }
    }

    public record AreaExpense(String slug, String name, BigDecimal total, int records) {}

    public record ExpenseDetail(UUID workItemId, String areaSlug, String areaName,
                                String title, String supplierName, String responsibleName,
                                String status, BigDecimal amount, LocalDate operationDate,
                                OffsetDateTime createdAt) {}

    public record ProposalDetail(UUID workItemId, String areaSlug, String areaName, String title, String location,
                                 String status, BigDecimal amount, LocalDate targetDate, Integer plannedYear, Integer plannedMonth) {}

    public record ExpenseReport(BigDecimal totalActual, BigDecimal estimatedImprovements,
                                int expenseCount, List<AreaExpense> byArea,
                                List<ExpenseDetail> expenses, List<ProposalDetail> proposals) {}
}
