package cl.mmsolutions.backend.settings;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Locale;
import java.util.Optional;

@Component
public class SafeImageValidator {
    public static final int MAX_BYTES = 1_048_576;
    private static final int MAX_DIMENSION = 2048;

    public ValidatedImage validate(MultipartFile file) {
        if (file == null || file.isEmpty()) throw new IllegalArgumentException("Selecciona una imagen.");
        if (file.getSize() > MAX_BYTES) throw new IllegalArgumentException("La imagen no puede superar 1 MB.");

        String filename = Optional.ofNullable(file.getOriginalFilename()).orElse("").toLowerCase(Locale.ROOT);
        boolean pngExtension = filename.endsWith(".png");
        boolean jpegExtension = filename.endsWith(".jpg") || filename.endsWith(".jpeg");
        if (!pngExtension && !jpegExtension) {
            throw new IllegalArgumentException("Usa una imagen PNG, JPG o JPEG.");
        }

        try {
            byte[] bytes = file.getBytes();
            String realMime = detect(bytes);
            String declaredMime = Optional.ofNullable(file.getContentType()).orElse("").toLowerCase(Locale.ROOT);
            boolean extensionMatches = (realMime.equals("image/png") && pngExtension)
                    || (realMime.equals("image/jpeg") && jpegExtension);
            if (!extensionMatches || !realMime.equals(declaredMime)) {
                throw new IllegalArgumentException("El contenido real de la imagen no coincide con su formato.");
            }
            BufferedImage image = ImageIO.read(new ByteArrayInputStream(bytes));
            if (image == null || image.getWidth() < 1 || image.getHeight() < 1
                    || image.getWidth() > MAX_DIMENSION || image.getHeight() > MAX_DIMENSION) {
                throw new IllegalArgumentException("La imagen no es válida o sus dimensiones son demasiado grandes.");
            }
            return new ValidatedImage(bytes, realMime);
        } catch (IOException ex) {
            throw new IllegalArgumentException("No fue posible leer la imagen.");
        }
    }

    private String detect(byte[] bytes) {
        if (bytes.length >= 8 && (bytes[0] & 0xff) == 0x89 && bytes[1] == 0x50
                && bytes[2] == 0x4e && bytes[3] == 0x47 && bytes[4] == 0x0d
                && bytes[5] == 0x0a && bytes[6] == 0x1a && bytes[7] == 0x0a) return "image/png";
        if (bytes.length >= 3 && (bytes[0] & 0xff) == 0xff && (bytes[1] & 0xff) == 0xd8
                && (bytes[2] & 0xff) == 0xff) return "image/jpeg";
        throw new IllegalArgumentException("El archivo no contiene una imagen PNG o JPEG válida.");
    }

    public record ValidatedImage(byte[] bytes, String mime) {}
}
