package cl.mmsolutions.backend.settings;

import cl.mmsolutions.backend.user.AppUser;
import cl.mmsolutions.backend.user.AppUserRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.util.Locale;
import java.util.Set;

@Service
public class AccountSettingsService {
    private static final Set<String> PRESETS = Set.of("user", "circle-user", "user-tie", "user-shield", "address-card");
    private final AppUserRepository users;
    private final JdbcTemplate jdbc;
    private final SafeImageValidator images;

    public AccountSettingsService(AppUserRepository users, JdbcTemplate jdbc, SafeImageValidator images) {
        this.users = users;
        this.jdbc = jdbc;
        this.images = images;
    }

    @Transactional
    public String updateEmail(String username, String rawEmail) {
        String email = rawEmail == null ? "" : rawEmail.trim().toLowerCase(Locale.ROOT);
        if (email.isBlank() || email.length() > 254 || !email.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {
            throw new IllegalArgumentException("Ingresa un correo electrónico válido.");
        }
        AppUser user = current(username);
        users.findByEmailIgnoreCase(email).filter(found -> !found.getId().equals(user.getId())).ifPresent(found -> {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "El correo electrónico ya está registrado.");
        });
        user.updateEmail(email);
        try {
            users.saveAndFlush(user);
        } catch (DataIntegrityViolationException ex) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "El correo electrónico ya está registrado.");
        }
        return email;
    }

    @Transactional
    public AvatarState choosePreset(String username, String preset) {
        if (!PRESETS.contains(preset)) throw new IllegalArgumentException("El avatar seleccionado no es válido.");
        Long id = current(username).getId();
        jdbc.update("UPDATE app_user SET avatar_preset=?, avatar_image=NULL, avatar_mime=NULL, updated_at=NOW() WHERE id=?", preset, id);
        return new AvatarState(preset, false);
    }

    @Transactional
    public AvatarState upload(String username, MultipartFile file) {
        SafeImageValidator.ValidatedImage image = images.validate(file);
        Long id = current(username).getId();
        jdbc.update("UPDATE app_user SET avatar_image=?, avatar_mime=?, updated_at=NOW() WHERE id=?",
                image.bytes(), image.mime(), id);
        return avatarState(username);
    }

    @Transactional(readOnly = true)
    public AvatarState avatarState(String username) {
        Long id = current(username).getId();
        return jdbc.queryForObject("SELECT avatar_preset, avatar_image IS NOT NULL FROM app_user WHERE id=?",
                (rs, row) -> new AvatarState(rs.getString(1), rs.getBoolean(2)), id);
    }

    @Transactional(readOnly = true)
    public StoredImage avatar(String username) {
        Long id = current(username).getId();
        return jdbc.query("SELECT avatar_image, avatar_mime FROM app_user WHERE id=? AND avatar_image IS NOT NULL",
                (rs, row) -> new StoredImage(rs.getBytes(1), rs.getString(2)), id).stream().findFirst()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    }

    private AppUser current(String username) {
        return users.findByUsernameIgnoreCase(username).filter(AppUser::isEnabled)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED));
    }

    public record AvatarState(String preset, boolean customImage) {}
    public record StoredImage(byte[] bytes, String mime) {}
}
