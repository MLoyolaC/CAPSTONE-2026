package cl.mmsolutions.backend.user;

public enum Role {
    ADMIN,
    USER
}