package cl.mmsolutions.backend.maintenancegeneral;

import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.security.access.prepost.PreAuthorize;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/areas/mantencion-general/imports")
@PreAuthorize("@permissionService.has(authentication, 'mantencion-general') and @permissionService.has(authentication, 'import')")
public class MaintenanceGeneralImportController {

    private final MaintenanceGeneralImportService importService;

    public MaintenanceGeneralImportController(
            MaintenanceGeneralImportService importService
    ) {
        this.importService = importService;
    }

    @PostMapping(
            path = "/analyze",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE
    )
    public MaintenanceGeneralImportService.WorkbookAnalysis analyze(
            @RequestPart("file") MultipartFile file
    ) {
        return importService.analyze(file);
    }

    @PostMapping(
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE
    )
    public MaintenanceGeneralImportService.ImportResult commit(
            @RequestPart("file") MultipartFile file,
            @RequestParam(defaultValue = "false") boolean force,
            Authentication authentication
    ) {
        return importService.commit(file, authentication.getName(), force);
    }

    @GetMapping
    public List<MaintenanceGeneralImportService.ImportSummary> list() {
        return importService.listImports();
    }

    @GetMapping("/{batchId}")
    public MaintenanceGeneralImportService.ImportDetail detail(
            @PathVariable UUID batchId
    ) {
        return importService.getImport(batchId);
    }


    @PostMapping("/{batchId}/integrate")
    public Map<String, Integer> integrate(
            @PathVariable UUID batchId
    ) {
        return Map.of(
                "integrated",
                importService.integrateExistingImport(batchId)
        );
    }

    @PutMapping("/rows/{rowId}")
    public MaintenanceGeneralImportService.ImportedRow updateRow(
            @PathVariable UUID rowId,
            @RequestBody Map<String, String> values
    ) {
        return importService.updateRow(rowId, values);
    }
}
