package cl.mmsolutions.backend.document;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.jdbc.core.JdbcTemplate;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;

class DocumentPreviewTest {
    @TempDir
    Path temporaryDirectory;

    @Test
    void excelPreviewKeepsSheetsRowsColumnsAndFormattedValues() throws Exception {
        UUID documentId = UUID.randomUUID();
        Path file = temporaryDirectory.resolve("operacion.xlsx");
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            var first = workbook.createSheet("Mantenciones");
            first.createRow(0).createCell(0).setCellValue("Equipo");
            first.getRow(0).createCell(1).setCellValue("Costo");
            first.createRow(1).createCell(0).setCellValue("Caldera");
            first.getRow(1).createCell(1).setCellValue(125000);
            var second = workbook.createSheet("Responsables");
            second.createRow(0).createCell(0).setCellValue("Nombre");
            second.createRow(1).createCell(0).setCellValue("Recepción");
            try (var output = Files.newOutputStream(file)) {
                workbook.write(output);
            }
        }
        DocumentService service = serviceWithCurrentFile(documentId, file, "XLSX");

        DocumentService.ExcelPreview preview = service.getExcelPreview(documentId);

        assertThat(preview.sheets()).extracting(DocumentService.ExcelSheetPreview::name)
                .containsExactly("Mantenciones", "Responsables");
        assertThat(preview.sheets().getFirst().totalRows()).isEqualTo(2);
        assertThat(preview.sheets().getFirst().totalColumns()).isEqualTo(2);
        assertThat(preview.sheets().getFirst().rows().get(1).cells().get(1).value()).isEqualTo("125000");
    }

    @Test
    void wordPreviewExtractsParagraphsAndTables() throws Exception {
        UUID documentId = UUID.randomUUID();
        Path file = temporaryDirectory.resolve("manual.docx");
        try (XWPFDocument document = new XWPFDocument()) {
            document.createParagraph().createRun().setText("Procedimiento de recepción");
            var table = document.createTable(1, 2);
            table.getRow(0).getCell(0).setText("Paso");
            table.getRow(0).getCell(1).setText("Responsable");
            try (var output = Files.newOutputStream(file)) {
                document.write(output);
            }
        }
        DocumentService service = serviceWithCurrentFile(documentId, file, "DOCX");

        DocumentService.DocxPreview preview = service.getDocxPreview(documentId);

        assertThat(preview.blocks()).anySatisfy(block -> assertThat(block.text()).contains("Procedimiento"));
        assertThat(preview.blocks()).anySatisfy(block -> assertThat(block.rows())
                .containsExactly(java.util.List.of("Paso", "Responsable")));
    }

    private DocumentService serviceWithCurrentFile(UUID id, Path file, String type) throws Exception {
        LocalDocumentStorageProvider storage = new LocalDocumentStorageProvider(temporaryDirectory.resolve("storage").toString());
        DocumentService service = spy(new DocumentService(mock(JdbcTemplate.class), storage));
        String mime = type.equals("XLSX")
                ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                : "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        String key = storage.buildKey(id, UUID.randomUUID(), file.getFileName().toString());
        storage.store(key, Files.newInputStream(file), Files.size(file), mime);
        doReturn(new DocumentService.StoredDocumentFile(
                file.getFileName().toString(), mime, type, key, 1, Files.size(file), "hash"
        )).when(service).getCurrentFile(id);
        return service;
    }
}
