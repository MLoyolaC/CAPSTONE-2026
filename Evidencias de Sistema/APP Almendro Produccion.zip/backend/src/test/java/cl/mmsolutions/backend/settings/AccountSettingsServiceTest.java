package cl.mmsolutions.backend.settings;

import cl.mmsolutions.backend.user.AppUser;
import cl.mmsolutions.backend.user.AppUserRepository;
import cl.mmsolutions.backend.user.Role;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.lang.reflect.Field;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class AccountSettingsServiceTest {
    private final AppUserRepository users = mock(AppUserRepository.class);
    private final JdbcTemplate jdbc = mock(JdbcTemplate.class);
    private final AccountSettingsService service = new AccountSettingsService(users, jdbc, new SafeImageValidator());

    @Test
    void updatesOnlyTheCurrentUsersValidEmail() throws Exception {
        AppUser current = user(10L, "current");
        when(users.findByUsernameIgnoreCase("current")).thenReturn(Optional.of(current));
        when(users.findByEmailIgnoreCase("new@example.cl")).thenReturn(Optional.empty());
        when(users.saveAndFlush(any())).thenAnswer(invocation -> invocation.getArgument(0));

        assertEquals("new@example.cl", service.updateEmail("current", " New@Example.cl "));
        assertEquals("new@example.cl", current.getEmail());
        verify(users).saveAndFlush(current);
    }

    @Test
    void rejectsInvalidAndDuplicateEmail() throws Exception {
        AppUser current = user(10L, "current");
        AppUser other = user(11L, "other");
        when(users.findByUsernameIgnoreCase("current")).thenReturn(Optional.of(current));
        when(users.findByEmailIgnoreCase("used@example.cl")).thenReturn(Optional.of(other));

        assertThrows(IllegalArgumentException.class, () -> service.updateEmail("current", "not-an-email"));
        ResponseStatusException duplicate = assertThrows(ResponseStatusException.class,
                () -> service.updateEmail("current", "used@example.cl"));
        assertEquals(HttpStatus.CONFLICT, duplicate.getStatusCode());
        verify(users, never()).saveAndFlush(any());
    }

    @Test
    void choosingAPresetClearsTheStoredCustomImage() throws Exception {
        AppUser current = user(10L, "current");
        when(users.findByUsernameIgnoreCase("current")).thenReturn(Optional.of(current));
        service.choosePreset("current", "user-shield");
        verify(jdbc).update(contains("avatar_image=NULL"), eq("user-shield"), eq(10L));
    }

    private AppUser user(Long id, String username) throws Exception {
        AppUser user = new AppUser(username, "hash", Role.USER, true);
        Field field = AppUser.class.getDeclaredField("id");
        field.setAccessible(true);
        field.set(user, id);
        return user;
    }
}
