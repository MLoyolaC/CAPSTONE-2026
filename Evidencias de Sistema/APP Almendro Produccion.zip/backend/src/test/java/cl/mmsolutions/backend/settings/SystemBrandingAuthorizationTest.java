package cl.mmsolutions.backend.settings;

import cl.mmsolutions.backend.user.AppUser;
import cl.mmsolutions.backend.user.AppUserRepository;
import cl.mmsolutions.backend.user.Role;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authorization.AuthorizationDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
@Transactional
class SystemBrandingAuthorizationTest {
    @Autowired SystemBrandingController controller;
    @Autowired AppUserRepository users;

    @AfterEach void clearSecurity() { SecurityContextHolder.clearContext(); }

    @Test
    void manageAccessCanChangeTheGlobalIdentity() {
        Authentication auth = authenticate("branding_allowed", Set.of("manage-access", "configuracion"));
        assertDoesNotThrow(() -> controller.preset(new SystemBrandingController.PresetRequest("hotel"), auth));
    }

    @Test
    void ordinaryUserCannotChangeTheGlobalIdentity() {
        Authentication auth = authenticate("branding_denied", Set.of("configuracion"));
        assertThrows(AuthorizationDeniedException.class,
                () -> controller.preset(new SystemBrandingController.PresetRequest("hotel"), auth));
    }

    private Authentication authenticate(String username, Set<String> permissions) {
        AppUser user = new AppUser(username, "hash", Role.USER, true);
        user.updateProfile(username, username + "@example.invalid", Role.USER, permissions);
        users.saveAndFlush(user);
        Authentication auth = new UsernamePasswordAuthenticationToken(username, "", List.of());
        SecurityContextHolder.getContext().setAuthentication(auth);
        return auth;
    }
}
