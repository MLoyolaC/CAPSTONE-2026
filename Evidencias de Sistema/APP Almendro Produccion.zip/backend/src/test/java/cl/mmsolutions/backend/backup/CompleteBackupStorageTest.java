package cl.mmsolutions.backend.backup;

import cl.mmsolutions.backend.document.DocumentStorageProvider;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.InputStream;
import java.nio.file.Path;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class CompleteBackupStorageTest {
    @TempDir Path temporaryDirectory;

    @Test
    void blocksCloudRestoreBeforeChangingStorageOrDatabase() {
        CloudProvider provider = new CloudProvider();
        CompleteBackupService service = new CompleteBackupService(
                "jdbc:postgresql://localhost/test", "user", "password", "",
                temporaryDirectory.toString(), provider);
        MockMultipartFile backup = new MockMultipartFile("file", "backup.ommbackup",
                "application/octet-stream", new byte[]{1});

        assertThatThrownBy(() -> service.restoreBackup(backup, "password-segura", "RESTAURAR"))
                .isInstanceOfSatisfying(ResponseStatusException.class,
                        exception -> assertThat(exception.getStatusCode()).isEqualTo(HttpStatus.CONFLICT));
        assertThat(provider.operations).isZero();
    }

    private static final class CloudProvider implements DocumentStorageProvider {
        private int operations;
        @Override public Kind kind() { return Kind.SUPABASE; }
        @Override public String buildKey(UUID documentId, UUID versionId, String filename) { operations++; return ""; }
        @Override public StoredObject store(String key, InputStream input, long contentLength, String mimeType) { operations++; return null; }
        @Override public InputStream open(String key) { operations++; return null; }
        @Override public StorageMetadata metadata(String key) { operations++; return null; }
        @Override public boolean exists(String key) { operations++; return false; }
        @Override public void delete(String key) { operations++; }
        @Override public List<StoredObject> list() { operations++; return List.of(); }
    }
}
