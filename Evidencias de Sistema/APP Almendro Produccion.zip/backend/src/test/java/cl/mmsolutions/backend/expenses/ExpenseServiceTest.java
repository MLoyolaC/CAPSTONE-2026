package cl.mmsolutions.backend.expenses;

import cl.mmsolutions.backend.area.Area;
import cl.mmsolutions.backend.workitem.WorkItem;
import cl.mmsolutions.backend.workitem.WorkItemRepository;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class ExpenseServiceTest {

    @Test
    void excluyePresupuestosDeMejorasYCargosCanceladosDelGastoReal() {
        WorkItemRepository repository = mock(WorkItemRepository.class);
        Area remodelArea = mock(Area.class);
        Area improvementArea = mock(Area.class);
        when(remodelArea.getSlug()).thenReturn("remodelacion");
        when(remodelArea.getName()).thenReturn("Remodelación");
        when(improvementArea.getSlug()).thenReturn("mejoras");
        when(improvementArea.getName()).thenReturn("Mejoras");

        WorkItem actual = mock(WorkItem.class);
        when(actual.getArea()).thenReturn(remodelArea);
        when(actual.getWorkType()).thenReturn("REMODELING");
        when(actual.getStatus()).thenReturn("IN_PROGRESS");
        when(actual.getActualCost()).thenReturn(new BigDecimal("800000"));

        WorkItem proposal = mock(WorkItem.class);
        when(proposal.getArea()).thenReturn(improvementArea);
        when(proposal.getWorkType()).thenReturn("IMPROVEMENT");
        when(proposal.getEstimatedCost()).thenReturn(new BigDecimal("500000"));
        when(proposal.getActualCost()).thenReturn(new BigDecimal("500000"));

        WorkItem cancelled = mock(WorkItem.class);
        when(cancelled.getArea()).thenReturn(remodelArea);
        when(cancelled.getWorkType()).thenReturn("REMODELING");
        when(cancelled.getStatus()).thenReturn("CANCELLED");
        when(cancelled.getActualCost()).thenReturn(new BigDecimal("100000"));

        when(repository.findAll()).thenReturn(List.of(actual, proposal, cancelled));

        ExpenseService.ExpenseReport result = new ExpenseService(repository).report();

        assertEquals(0, result.totalActual().compareTo(new BigDecimal("800000")));
        assertEquals(0, result.estimatedImprovements().compareTo(new BigDecimal("500000")));
        assertEquals(1, result.expenseCount());
        assertEquals(1, result.expenses().size());
    }
}
