package cl.mmsolutions.backend.operationalimport;

import cl.mmsolutions.backend.user.AppUser;
import cl.mmsolutions.backend.user.AppUserRepository;
import cl.mmsolutions.backend.user.Role;
import cl.mmsolutions.backend.workitem.WorkItem;
import cl.mmsolutions.backend.workitem.WorkItemRepository;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@Transactional
class OperationalImportServiceTest {

    @Autowired OperationalImportService service;
    @Autowired WorkItemRepository repository;
    @Autowired AppUserRepository users;
    @Autowired JdbcTemplate jdbcTemplate;

    @Test
    void importsReactiveExcelWithNumericDateAndAuthenticatedBatchAudit() throws Exception {
        String username = testUser();
        MockMultipartFile file = reactiveWorkbook("reactiva-prueba.xlsx");

        OperationalImportService.ImportResult result = service.importFile(
                "mantencion-reactiva", file, username, false
        );

        assertEquals(1, result.detected());
        assertEquals(1, result.created());
        assertEquals(0, result.skipped());
        assertEquals(0, result.errors());
        assertNotNull(result.batchId());

        WorkItem imported = items("mantencion-reactiva", "REACTIVE_MAINTENANCE").getFirst();
        assertEquals("Reparar ducha habitación 12", imported.getTitle());
        assertEquals("Habitación 12", imported.getLocation());
        assertEquals(LocalDate.of(2026, 11, 10), imported.getScheduledStart());
        assertEquals("PENDING", imported.getStatus());
        assertEquals(username, jdbcTemplate.queryForObject(
                "SELECT username_snapshot FROM work_item_activity WHERE work_item_id = ? AND action = 'IMPORTED'",
                String.class,
                imported.getId()
        ));
        assertEquals(result.batchId(), jdbcTemplate.queryForObject(
                "SELECT operation_id FROM work_item_activity WHERE work_item_id = ? AND action = 'IMPORTED'",
                UUID.class,
                imported.getId()
        ));
    }

    @Test
    void importsMachineFieldsAndSkipsReasonableDuplicateFromAnotherFile() throws Exception {
        String username = testUser();

        OperationalImportService.ImportResult first = service.importFile(
                "mantencion-maquinas", machineWorkbook("maquinas-a.xlsx"), username, false
        );
        OperationalImportService.ImportResult repeated = service.importFile(
                "mantencion-maquinas", machineWorkbook("maquinas-b.xlsx"), username, false
        );

        assertEquals(1, first.created());
        assertEquals(0, repeated.created());
        assertEquals(1, repeated.skipped());
        assertEquals(1, repeated.duplicateCount());
        assertEquals(1, repeated.duplicates().size());

        List<WorkItem> machines = items("mantencion-maquinas", "MACHINE_MAINTENANCE").stream()
                .filter(item -> "maquinas-a.xlsx".equals(item.getImportSourceFilename()))
                .toList();
        assertEquals(1, machines.size());
        WorkItem imported = machines.getFirst();
        assertEquals("Caldera principal", imported.getTitle());
        assertEquals("Caldera principal", imported.getAssetName());
        assertEquals("Sala de máquinas", imported.getLocation());
        assertTrue(imported.getImportedData().contains("Bosch"));
        assertTrue(imported.getImportedData().contains("GC7000"));
    }

    private String testUser() {
        String suffix = UUID.randomUUID().toString().substring(0, 8);
        AppUser user = users.saveAndFlush(new AppUser("qa-import-" + suffix, "hash", Role.USER, true));
        return user.getUsername();
    }

    private List<WorkItem> items(String area, String type) {
        return repository.findByArea_SlugAndWorkTypeOrderByScheduledStartAscCreatedAtDesc(area, type);
    }

    private MockMultipartFile reactiveWorkbook(String filename) throws Exception {
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Incidencias");
            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("Habitación");
            header.createCell(1).setCellValue("Trabajo");
            header.createCell(2).setCellValue("Fecha");
            header.createCell(3).setCellValue("Responsable");
            header.createCell(4).setCellValue("Estado");
            Row row = sheet.createRow(1);
            row.createCell(0).setCellValue("Habitación 12");
            row.createCell(1).setCellValue("Reparar ducha habitación 12");
            CellStyle dateStyle = workbook.createCellStyle();
            dateStyle.setDataFormat(workbook.getCreationHelper().createDataFormat().getFormat("dd/mm/yyyy"));
            row.createCell(2).setCellValue(LocalDateTime.of(2026, 11, 10, 0, 0));
            row.getCell(2).setCellStyle(dateStyle);
            row.createCell(3).setCellValue("Técnico QA");
            row.createCell(4).setCellValue("Pendiente");
            sheet.createRow(2);
            return multipart(filename, workbook);
        }
    }

    private MockMultipartFile machineWorkbook(String filename) throws Exception {
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Equipos");
            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("Nombre");
            header.createCell(1).setCellValue("Tipo");
            header.createCell(2).setCellValue("Ubicación");
            header.createCell(3).setCellValue("Estado");
            header.createCell(4).setCellValue("Marca");
            header.createCell(5).setCellValue("Modelo");
            Row row = sheet.createRow(1);
            row.createCell(0).setCellValue("Caldera principal");
            row.createCell(1).setCellValue("Calefacción");
            row.createCell(2).setCellValue("Sala de máquinas");
            row.createCell(3).setCellValue("Operativa");
            row.createCell(4).setCellValue("Bosch");
            row.createCell(5).setCellValue("GC7000");
            return multipart(filename, workbook);
        }
    }

    private MockMultipartFile multipart(String filename, XSSFWorkbook workbook) throws Exception {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        workbook.write(output);
        return new MockMultipartFile("file", filename, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", output.toByteArray());
    }
}
