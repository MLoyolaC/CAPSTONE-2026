package cl.mmsolutions.backend.security;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class PasswordPolicyTest {
    @Test
    void acceptsThePublishedPolicy() {
        assertDoesNotThrow(() -> PasswordPolicy.validate("Una frase larga", "Una frase larga"));
    }

    @Test
    void rejectsShortMissingUppercaseAndConfirmationMismatch() {
        PasswordPolicy.PasswordPolicyException shortPassword = assertThrows(
                PasswordPolicy.PasswordPolicyException.class,
                () -> PasswordPolicy.validate("Corta", "Corta"));
        assertEquals(PasswordPolicy.REQUIREMENTS, shortPassword.getMessage());

        assertThrows(PasswordPolicy.PasswordPolicyException.class,
                () -> PasswordPolicy.validate("una frase suficientemente larga", "una frase suficientemente larga"));
        assertThrows(PasswordPolicy.PasswordPolicyException.class,
                () -> PasswordPolicy.validate("Una frase suficientemente larga", "Una frase diferente"));
    }
}
