package cl.mmsolutions.backend.asset;

import cl.mmsolutions.backend.workitem.WorkItem;
import cl.mmsolutions.backend.workitem.WorkItemController;
import cl.mmsolutions.backend.workitem.WorkItemService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@Transactional
class AssetMachineLinkTest {
    @Autowired AssetController assets;
    @Autowired WorkItemService workItems;
    @Autowired JdbcTemplate jdbc;

    @Test
    void linksReadsUpdatesUnlinksAndDeletesSafelyWithRealActor() {
        String username = jdbc.query("SELECT username FROM app_user WHERE role='ADMIN' AND enabled=TRUE ORDER BY id LIMIT 1",
                rs -> rs.next() ? rs.getString(1) : "qa-link");
        var auth = new UsernamePasswordAuthenticationToken(username, "", List.of());
        SecurityContextHolder.getContext().setAuthentication(auth);
        AssetController.AssetResponse asset = assets.create(new AssetController.AssetRequest(
                "mantencion-maquinas", "ACT-QA-1", "Caldera principal", "Caldera", "Sala térmica",
                null, null, "OPERATIONAL", true), auth);

        WorkItem linked = workItems.create(request(asset.id(), "PENDING"), username);
        assertThat(linked.getAssetId()).isEqualTo(asset.id());
        assertThat(linked.getAssetName()).isEqualTo("Caldera principal");
        assertThat(linked.getLocation()).isEqualTo("Sala térmica");
        assertThat(assets.list(false).getFirst().linkedMachineCount()).isEqualTo(1);

        assets.update(asset.id(), new AssetController.AssetRequest(
                "mantencion-maquinas", "ACT-QA-1", "Caldera principal", "Caldera", "Sala térmica",
                null, null, "OUT_OF_SERVICE", true), auth);
        assertThat(workItems.list("mantencion-maquinas", "MACHINE_MAINTENANCE").getFirst().getStatus())
                .as("el estado físico no debe sobrescribir el flujo de mantención").isEqualTo("PENDING");

        WorkItem unlinked = workItems.update(linked.getId(), request(null, "IN_PROGRESS"), username);
        assertThat(unlinked.getAssetId()).isNull();
        WorkItem relinked = workItems.update(linked.getId(), request(asset.id(), "IN_PROGRESS"), username);
        assets.delete(asset.id(), auth);
        assertThat(relinked.getAssetId()).isEqualTo(asset.id());
        assertThat(assets.list(true).getFirst().active()).isFalse();

        assertThat(jdbc.queryForObject("SELECT username_snapshot FROM work_item_activity WHERE work_item_id=? ORDER BY created_at DESC LIMIT 1", String.class, linked.getId()))
                .isEqualTo(username);
        assertThat(jdbc.queryForObject("SELECT username_snapshot FROM system_activity WHERE item_id=? ORDER BY created_at DESC LIMIT 1", String.class, asset.id().toString()))
                .isEqualTo(username);

        workItems.delete(linked.getId(), username);
        assertThat(assets.list(true)).hasSize(1);
        SecurityContextHolder.clearContext();
    }

    private WorkItemController.WorkItemRequest request(UUID assetId, String status) {
        return new WorkItemController.WorkItemRequest(
                "mantencion-maquinas", "MACHINE_MAINTENANCE", null, null, null,
                "Mantención caldera", null, "Ubicación manipulada", null, "NORMAL", status,
                null, null, null, null, BigDecimal.ZERO, null, "Preventiva", "Texto manipulado",
                null, null, null, null, null, null, null, assetId
        );
    }
}
