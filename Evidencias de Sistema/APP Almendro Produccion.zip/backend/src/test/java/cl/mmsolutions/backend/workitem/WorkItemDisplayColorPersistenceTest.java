package cl.mmsolutions.backend.workitem;

import cl.mmsolutions.backend.area.Area;
import cl.mmsolutions.backend.area.AreaRepository;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
@Transactional
class WorkItemDisplayColorPersistenceTest {

    @Autowired WorkItemRepository repository;
    @Autowired AreaRepository areaRepository;
    @Autowired EntityManager entityManager;

    @Test
    void createsReadsAndUpdatesTheSamePersistedColor() {
        Area area = areaRepository.findAll().stream()
                .filter(candidate -> "prevencion-riesgos".equals(candidate.getSlug()))
                .findFirst()
                .orElseThrow();
        WorkItem created = new WorkItem(area, "PREVENTION", "Prueba transaccional de color");
        created.setDisplayColor(DisplayColorValidator.normalize("#4f8f72"));
        created.setTextColor(DisplayColorValidator.normalize("#ffffff"));
        created = repository.saveAndFlush(created);
        var id = created.getId();
        entityManager.clear();

        WorkItem reopened = repository.findById(id).orElseThrow();
        assertEquals("#4F8F72", reopened.getDisplayColor());
        assertEquals("#FFFFFF", reopened.getTextColor());
        reopened.setDisplayColor(DisplayColorValidator.normalize("#547aa5"));
        reopened.setTextColor(DisplayColorValidator.normalize("#000000"));
        repository.saveAndFlush(reopened);
        entityManager.clear();

        assertEquals("#547AA5", repository.findById(id).orElseThrow().getDisplayColor());
        assertEquals("#000000", repository.findById(id).orElseThrow().getTextColor());
    }
}
