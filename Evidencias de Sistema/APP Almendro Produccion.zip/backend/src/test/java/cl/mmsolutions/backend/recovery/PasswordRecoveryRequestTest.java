package cl.mmsolutions.backend.recovery;

import cl.mmsolutions.backend.user.AppUser;
import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

class PasswordRecoveryRequestTest {
    @Test
    void codeStopsAfterMaximumAttemptsAndResetTokenIsOneUse() {
        OffsetDateTime now = OffsetDateTime.now();
        PasswordRecoveryRequest request = new PasswordRecoveryRequest(
                mock(AppUser.class), "encoded-code", now.plusMinutes(15));

        for (int attempt = 0; attempt < 4; attempt++) request.failAttempt(now, 5);
        assertTrue(request.isCodeUsable(now, 5));
        request.failAttempt(now, 5);
        assertFalse(request.isCodeUsable(now, 5));

        PasswordRecoveryRequest verified = new PasswordRecoveryRequest(
                mock(AppUser.class), "encoded-code", now.plusMinutes(15));
        verified.verify(now, "reset-token-hash");
        assertTrue(verified.isResetUsable(now));
        verified.use(now);
        assertFalse(verified.isResetUsable(now));
    }

    @Test
    void expiredCodesCannotBeUsed() {
        OffsetDateTime now = OffsetDateTime.now();
        PasswordRecoveryRequest request = new PasswordRecoveryRequest(
                mock(AppUser.class), "encoded-code", now.minusSeconds(1));
        assertFalse(request.isCodeUsable(now, 5));
    }
}
