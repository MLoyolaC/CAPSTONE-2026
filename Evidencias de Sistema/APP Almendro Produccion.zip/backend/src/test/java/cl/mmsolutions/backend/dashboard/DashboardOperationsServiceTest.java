package cl.mmsolutions.backend.dashboard;

import cl.mmsolutions.backend.dashboard.DashboardOperationsRepository.AreaRow;
import cl.mmsolutions.backend.dashboard.DashboardOperationsRepository.ItemRow;
import cl.mmsolutions.backend.dashboard.DashboardOperationsResponse.AreaOverview;
import cl.mmsolutions.backend.security.PermissionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class DashboardOperationsServiceTest {
    private static final LocalDate TODAY = LocalDate.of(2026, 11, 9);
    private DashboardOperationsRepository repository;
    private PermissionService permissions;
    private DashboardOperationsService service;

    @BeforeEach
    void setUp() {
        repository = mock(DashboardOperationsRepository.class);
        permissions = mock(PermissionService.class);
        service = new DashboardOperationsService(repository, permissions);
    }

    @Test
    void normalizaEstadosFechasProximasYLegacySinPerderRegistros() {
        when(permissions.permissionsFor("admin")).thenReturn(Set.of(
                "dashboard", "mantencion-general", "mejoras"));
        when(repository.findAreas(anySet())).thenReturn(List.of(
                new AreaRow("mantencion-general", "Mantención General"),
                new AreaRow("mejoras", "Mejoras")));
        when(repository.findItems(anySet())).thenReturn(List.of(
                row("mantencion-general", "PENDING", TODAY.minusDays(1), null),
                row("mantencion-general", "IN_PROGRESS", TODAY.plusDays(20), null),
                row("mantencion-general", "PLANNED", TODAY.plusDays(7), null),
                row("mantencion-general", "LEGACY_ACTIVE", null, null),
                row("mantencion-general", "COMPLETED", TODAY.minusDays(30), TODAY.minusDays(20)),
                row("mejoras", "OVERDUE", TODAY.plusDays(3), null),
                row("mejoras", "CANCELLED", TODAY.plusDays(2), null)));

        DashboardOperationsResponse result = service.overview("admin", TODAY);

        AreaOverview general = area(result, "mantencion-general");
        assertEquals(4, general.open());
        assertEquals(1, general.overdue());
        assertEquals(1, general.inProgress());
        assertEquals(1, general.pending());
        assertEquals(1, general.otherOpen());
        assertEquals(1, general.upcoming());
        assertEquals(1, general.completed());
        assertEquals(5, general.total());
        assertEquals("OTHER_OPEN", result.items().stream()
                .filter(item -> "LEGACY_ACTIVE".equals(item.status())).findFirst().orElseThrow().operationalState());

        AreaOverview improvements = area(result, "mejoras");
        assertEquals(1, improvements.overdue());
        assertEquals(0, improvements.upcoming());
        assertEquals(1, improvements.cancelled());
    }

    @Test
    void incluyeAreasAutorizadasSinRegistrosConConteosEnCero() {
        when(permissions.permissionsFor("operator")).thenReturn(Set.of("dashboard", "maquinas"));
        when(repository.findAreas(Set.of("mantencion-maquinas"))).thenReturn(List.of(
                new AreaRow("mantencion-maquinas", "Mantención de Máquinas")));
        when(repository.findItems(Set.of("mantencion-maquinas"))).thenReturn(List.of());

        DashboardOperationsResponse result = service.overview("operator", TODAY);

        assertEquals(1, result.areas().size());
        assertEquals(0, result.areas().getFirst().total());
        assertEquals(0, result.areas().getFirst().open());
        assertTrue(result.items().isEmpty());
    }

    @Test
    void usuarioParcialNoConsultaNiRecibeAreasSinPermiso() {
        when(permissions.permissionsFor("partial")).thenReturn(Set.of("dashboard", "prevencion"));
        when(repository.findAreas(Set.of("prevencion-riesgos"))).thenReturn(List.of(
                new AreaRow("prevencion-riesgos", "Prevención de Riesgos")));
        when(repository.findItems(Set.of("prevencion-riesgos"))).thenReturn(List.of(
                row("prevencion-riesgos", "PENDING", TODAY.plusDays(2), null)));

        DashboardOperationsResponse result = service.overview("partial", TODAY);

        assertEquals(List.of("prevencion-riesgos"), result.areas().stream().map(AreaOverview::slug).toList());
        assertTrue(result.items().stream().allMatch(item -> item.areaSlug().equals("prevencion-riesgos")));
        verify(repository).findAreas(Set.of("prevencion-riesgos"));
        verify(repository).findItems(Set.of("prevencion-riesgos"));
    }

    @Test
    void detalleUsaDimensionRealSegunAreaYSumaCostosPersistidos() {
        ItemRow improvement = row("mejoras", "IN_PROGRESS", TODAY.plusDays(20), null,
                "Metas Obras", "Recepción", new BigDecimal("250000"), new BigDecimal("100000"));
        when(permissions.permissionsFor("admin")).thenReturn(Set.of("dashboard", "mejoras"));
        when(repository.findAreas(anySet())).thenReturn(List.of(new AreaRow("mejoras", "Mejoras")));
        when(repository.findItems(anySet())).thenReturn(List.of(improvement));

        AreaOverview overview = service.overview("admin", TODAY).areas().getFirst();

        assertEquals("Categorías / orígenes", overview.dimensionLabel());
        assertEquals("Metas Obras", overview.dimensions().getFirst().label());
        assertEquals(0, overview.estimatedCost().compareTo(new BigDecimal("250000")));
        assertEquals(0, overview.actualCost().compareTo(new BigDecimal("100000")));
    }

    @Test
    void sinPermisosDeAreaNoExponeDatosOperativos() {
        when(permissions.permissionsFor("dashboard-only")).thenReturn(Set.of("dashboard"));

        DashboardOperationsResponse result = service.overview("dashboard-only", TODAY);

        assertTrue(result.areas().isEmpty());
        assertTrue(result.items().isEmpty());
        verify(repository).findAreas(Set.of());
        verify(repository).findItems(Set.of());
    }

    private AreaOverview area(DashboardOperationsResponse response, String slug) {
        return response.areas().stream().filter(area -> area.slug().equals(slug)).findFirst().orElseThrow();
    }

    private ItemRow row(String area, String status, LocalDate start, LocalDate completed) {
        return row(area, status, start, completed, "Operación", "Sector Norte", BigDecimal.ZERO, BigDecimal.ZERO);
    }

    private ItemRow row(
            String area,
            String status,
            LocalDate start,
            LocalDate completed,
            String category,
            String location,
            BigDecimal estimated,
            BigDecimal actual
    ) {
        return new ItemRow(UUID.randomUUID(), area, area, "TYPE", "Tarea real", location,
                "Responsable", "NORMAL", status, start, start, completed, new BigDecimal("25"),
                2026, 11, category, "Equipo", "Mensual", "Primavera", estimated, actual,
                OffsetDateTime.parse("2026-11-09T10:00:00-03:00"));
    }
}
