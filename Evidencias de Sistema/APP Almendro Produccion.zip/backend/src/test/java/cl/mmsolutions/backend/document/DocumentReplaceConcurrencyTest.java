package cl.mmsolutions.backend.document;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockMultipartFile;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class DocumentReplaceConcurrencyTest {
    @Autowired private DocumentService documents;
    @Autowired private DocumentStorageProvider storage;
    @Autowired private JdbcTemplate jdbc;

    @Test
    void simultaneousReplacementsReceiveDistinctSequentialVersions() throws Exception {
        String username = jdbc.queryForObject("SELECT username FROM app_user ORDER BY id LIMIT 1", String.class);
        String areaSlug = jdbc.queryForObject("SELECT slug FROM area WHERE active = TRUE ORDER BY sort_order LIMIT 1", String.class);
        UUID documentId = null;
        ExecutorService executor = Executors.newFixedThreadPool(2);
        try {
            documentId = documents.upload(areaSlug, workbook("concurrency-initial.xlsx", "initial"), username).id();
            UUID target = documentId;
            CountDownLatch start = new CountDownLatch(1);
            Future<Integer> first = executor.submit(() -> replaceAfter(start, target,
                    workbook("concurrency-first.xlsx", "first"), username));
            Future<Integer> second = executor.submit(() -> replaceAfter(start, target,
                    workbook("concurrency-second.xlsx", "second"), username));

            start.countDown();
            List<Integer> returnedVersions = new ArrayList<>(List.of(
                    first.get(30, TimeUnit.SECONDS),
                    second.get(30, TimeUnit.SECONDS)));
            Collections.sort(returnedVersions);

            assertThat(returnedVersions).containsExactly(2, 3);
            assertThat(jdbc.queryForList(
                    "SELECT version_number FROM document_version WHERE document_id = ? ORDER BY version_number",
                    Integer.class, documentId)).containsExactly(1, 2, 3);
            assertThat(jdbc.queryForObject(
                    "SELECT dv.version_number FROM document d JOIN document_version dv ON dv.id = d.current_version_id WHERE d.id = ?",
                    Integer.class, documentId)).isEqualTo(3);
        } finally {
            executor.shutdownNow();
            if (documentId != null) cleanup(documentId);
        }
    }

    private int replaceAfter(CountDownLatch start, UUID documentId, MockMultipartFile file, String username)
            throws Exception {
        start.await(10, TimeUnit.SECONDS);
        return documents.replace(documentId, file, username).versionNumber();
    }

    private MockMultipartFile workbook(String filename, String value) throws Exception {
        try (XSSFWorkbook book = new XSSFWorkbook(); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            book.createSheet("Data").createRow(0).createCell(0).setCellValue(value);
            book.write(output);
            return new MockMultipartFile("file", filename,
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", output.toByteArray());
        }
    }

    private void cleanup(UUID documentId) {
        List<String> keys = jdbc.queryForList(
                "SELECT COALESCE(local_storage_path, cloud_storage_path) FROM document_version WHERE document_id = ?",
                String.class, documentId);
        keys.forEach(storage::delete);
        jdbc.update("DELETE FROM document_activity WHERE document_id = ?", documentId);
        jdbc.update("DELETE FROM document_search_fragment WHERE document_id = ?", documentId);
        jdbc.update("DELETE FROM document_search_entry WHERE document_id = ?", documentId);
        jdbc.update("DELETE FROM document_edit_session WHERE document_id = ?", documentId);
        jdbc.update("DELETE FROM worker_document WHERE document_id = ?", documentId);
        jdbc.update("DELETE FROM mg_import_batch WHERE document_id = ?", documentId);
        jdbc.update("UPDATE document SET current_version_id = NULL WHERE id = ?", documentId);
        jdbc.update("DELETE FROM document_version WHERE document_id = ?", documentId);
        jdbc.update("DELETE FROM document WHERE id = ?", documentId);
    }
}
