package cl.mmsolutions.backend.document;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class DocumentControllerTest {
    @TempDir
    Path temporaryDirectory;

    @Test
    void downloadKeepsTheRealFilenameAndContentType() throws Exception {
        UUID documentId = UUID.randomUUID();
        Path file = temporaryDirectory.resolve("informe final.pdf");
        Files.writeString(file, "pdf");
        DocumentService service = mock(DocumentService.class);
        when(service.getCurrentFile(documentId)).thenReturn(storedFile(file));
        when(service.openStoredFile(org.mockito.ArgumentMatchers.any())).thenReturn(new ByteArrayInputStream("pdf".getBytes()));

        var auth = UsernamePasswordAuthenticationToken.authenticated("admin", "", java.util.List.of());
        var response = new DocumentController(service).download(documentId, auth);

        assertThat(response.getHeaders().getContentType()).isEqualTo(MediaType.APPLICATION_PDF);
        assertThat(response.getHeaders().getContentDisposition().isAttachment()).isTrue();
        assertThat(response.getHeaders().getContentDisposition().getFilename()).isEqualTo("informe final.pdf");
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        response.getBody().writeTo(output);
        assertThat(output.toString()).isEqualTo("pdf");
        verify(service).recordAccess(documentId, "admin", "DOWNLOADED");
    }

    @Test
    void inlinePdfUsesInlineDisposition() throws Exception {
        UUID documentId = UUID.randomUUID();
        Path file = temporaryDirectory.resolve("manual.pdf");
        Files.writeString(file, "pdf");
        DocumentService service = mock(DocumentService.class);
        when(service.getCurrentFile(documentId)).thenReturn(storedFile(file));
        when(service.openStoredFile(org.mockito.ArgumentMatchers.any())).thenReturn(new ByteArrayInputStream("pdf".getBytes()));

        var auth = UsernamePasswordAuthenticationToken.authenticated("admin", "", java.util.List.of());
        var response = new DocumentController(service).inline(documentId, auth);

        assertThat(response.getHeaders().getContentType()).isEqualTo(MediaType.APPLICATION_PDF);
        assertThat(response.getHeaders().getContentDisposition().isInline()).isTrue();
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        response.getBody().writeTo(output);
        verify(service).recordAccess(documentId, "admin", "OPENED");
    }

    private DocumentService.StoredDocumentFile storedFile(Path file) throws Exception {
        return new DocumentService.StoredDocumentFile(
                file.getFileName().toString(),
                "application/pdf",
                "PDF",
                file.getFileName().toString(),
                1,
                Files.size(file),
                "hash"
        );
    }
}
