package cl.mmsolutions.backend.document;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.mock.web.MockMultipartFile;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import java.util.UUID;
import java.time.OffsetDateTime;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class DocumentReplaceTest {
    @TempDir
    Path temporaryDirectory;

    @Test
    void replacementCreatesANewVersionWithoutCreatingAnotherLogicalDocument() throws Exception {
        UUID documentId = UUID.randomUUID();
        StubJdbcTemplate jdbc = new StubJdbcTemplate(documentId, sha256("anterior"));
        LocalDocumentStorageProvider storage = new LocalDocumentStorageProvider(temporaryDirectory.toString());
        DocumentService service = new DocumentService(jdbc, storage);
        byte[] workbook = workbook("contenido-nuevo");
        var file = new MockMultipartFile(
                "file",
                "plan-actualizado.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                workbook
        );

        DocumentService.DocumentSummary updated = service.replace(documentId, file, "admin");

        assertThat(updated.id()).isEqualTo(documentId);
        assertThat(updated.name()).isEqualTo("plan-actualizado.xlsx");
        assertThat(updated.versionNumber()).isEqualTo(2);
        assertThat(storage.list()).hasSize(1);
        assertThat(storage.open(storage.list().getFirst().key()).readAllBytes()).isEqualTo(workbook);
        assertThat(jdbc.sqlStatements).noneMatch(sql -> sql.contains("INSERT INTO document ("));
        assertThat(jdbc.sqlStatements).anyMatch(sql -> sql.contains("INSERT INTO document_version"));
        assertThat(jdbc.sqlStatements).anyMatch(sql -> sql.contains("action") && sql.contains("REPLACED"));
        assertThat(jdbc.persistedStoragePath).startsWith(documentId + "/").endsWith("/plan-actualizado.xlsx");
        assertThat(jdbc.sqlStatements).anyMatch(sql -> sql.contains("FOR UPDATE"));
    }

    @Test
    void failedNewStorageLeavesThePreviousVersionCurrent() throws Exception {
        UUID documentId = UUID.randomUUID();
        StubJdbcTemplate jdbc = new StubJdbcTemplate(documentId, sha256("anterior"));
        LocalDocumentStorageProvider storage = new LocalDocumentStorageProvider(temporaryDirectory.toString()) {
            @Override
            public StoredObject store(String key, InputStream input, long contentLength, String mimeType) {
                throw new DocumentStorageException("storage unavailable");
            }
        };
        DocumentService service = new DocumentService(jdbc, storage);

        assertThatThrownBy(() -> service.replace(documentId,
                new MockMultipartFile("file", "plan-actualizado.xlsx",
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        workbook("contenido-nuevo")), "admin"))
                .isInstanceOf(org.springframework.web.server.ResponseStatusException.class);

        assertThat(jdbc.sqlStatements).noneMatch(sql -> sql.contains("INSERT INTO document_version"));
        assertThat(jdbc.sqlStatements).noneMatch(sql -> sql.contains("UPDATE document\nSET\n    current_version_id"));
    }

    private byte[] workbook(String value) throws Exception {
        try (XSSFWorkbook workbook = new XSSFWorkbook(); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            workbook.createSheet("Datos").createRow(0).createCell(0).setCellValue(value);
            workbook.write(output);
            return output.toByteArray();
        }
    }

    private String sha256(String value) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value.getBytes()));
    }

    private static final class StubJdbcTemplate extends JdbcTemplate {
        private final UUID documentId;
        private final String currentHash;
        private final List<String> sqlStatements = new ArrayList<>();
        private String persistedStoragePath;

        private StubJdbcTemplate(UUID documentId, String currentHash) {
            this.documentId = documentId;
            this.currentHash = currentHash;
        }

        @Override
        public <T> List<T> query(String sql, RowMapper<T> rowMapper, Object... args) {
            sqlStatements.add(sql);
            if (sql.contains("FROM app_user")) {
                @SuppressWarnings("unchecked")
                T userId = (T) Long.valueOf(7);
                return List.of(userId);
            }
            ResultSet result = mock(ResultSet.class);
            try {
                when(result.getObject("id", UUID.class)).thenReturn(documentId);
                when(result.getString("name")).thenReturn("plan.xlsx");
                when(result.getString("file_type")).thenReturn("XLSX");
                when(result.getObject("created_at", OffsetDateTime.class)).thenReturn(OffsetDateTime.now());
                when(result.getObject("version_id", UUID.class)).thenReturn(UUID.randomUUID());
                when(result.getInt("version_number")).thenReturn(1);
                when(result.getString("sha256")).thenReturn(currentHash);
                return List.of(rowMapper.mapRow(result, 0));
            } catch (SQLException exception) {
                throw new IllegalStateException(exception);
            }
        }

        @Override
        public int update(String sql, Object... args) {
            sqlStatements.add(sql);
            if (sql.contains("INSERT INTO document_version")) persistedStoragePath = String.valueOf(args[7]);
            return 1;
        }
    }
}
