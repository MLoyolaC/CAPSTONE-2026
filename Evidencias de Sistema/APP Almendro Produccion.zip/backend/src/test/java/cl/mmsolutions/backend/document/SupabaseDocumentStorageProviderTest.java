package cl.mmsolutions.backend.document;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import tools.jackson.databind.json.JsonMapper;

import java.io.ByteArrayInputStream;
import java.net.InetSocketAddress;
import java.net.http.HttpClient;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class SupabaseDocumentStorageProviderTest {
    private HttpServer server;
    private final AtomicReference<byte[]> stored = new AtomicReference<>();
    private final AtomicReference<String> authorization = new AtomicReference<>();
    private final AtomicReference<String> apiKey = new AtomicReference<>();

    @BeforeEach
    void startServer() throws Exception {
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/storage/v1/", this::handle);
        server.start();
    }

    @AfterEach void stopServer() { server.stop(0); }

    @Test
    void privateProviderUploadsDownloadsAndDeletesWithoutPublicUrls() throws Exception {
        SupabaseDocumentStorageProvider provider = provider();
        String key = provider.buildKey(UUID.randomUUID(), UUID.randomUUID(), "manual.pdf");
        byte[] bytes = "%PDF-test".getBytes(StandardCharsets.US_ASCII);

        provider.store(key, new ByteArrayInputStream(bytes), bytes.length, "application/pdf");

        assertThat(key).startsWith("documents/").doesNotContain("http");
        assertThat(apiKey.get()).isEqualTo("sb_secret_test");
        assertThat(authorization.get()).isNull();
        assertThat(provider.open(key).readAllBytes()).isEqualTo(bytes);
        assertThat(provider.metadata(key).size()).isEqualTo(bytes.length);
        assertThat(provider.exists(key)).isTrue();
        provider.delete(key);
        assertThat(stored.get()).isNull();
    }

    @Test
    void rejectsPublicBucketBeforeUploading() {
        server.removeContext("/storage/v1/");
        server.createContext("/storage/v1/", exchange -> respond(exchange, 200, "{\"public\":true}"));
        SupabaseDocumentStorageProvider provider = provider();

        assertThatThrownBy(() -> provider.store("documents/a/b/file.pdf",
                new ByteArrayInputStream(new byte[]{1}), 1, "application/pdf"))
                .isInstanceOf(DocumentStorageException.class)
                .hasMessageContaining("público");
        assertThat(stored.get()).isNull();
    }

    private SupabaseDocumentStorageProvider provider() {
        String url = "http://127.0.0.1:" + server.getAddress().getPort();
        return new SupabaseDocumentStorageProvider(url, "omm-documents", "sb_secret_test",
                JsonMapper.builder().build(), HttpClient.newHttpClient());
    }

    private void handle(HttpExchange exchange) throws java.io.IOException {
        authorization.set(exchange.getRequestHeaders().getFirst("Authorization"));
        apiKey.set(exchange.getRequestHeaders().getFirst("apikey"));
        String path = exchange.getRequestURI().getPath();
        if (path.equals("/storage/v1/bucket/omm-documents")) {
            respond(exchange, 200, "{\"public\":false}");
            return;
        }
        if (path.startsWith("/storage/v1/object/omm-documents/documents/") && exchange.getRequestMethod().equals("POST")) {
            stored.set(exchange.getRequestBody().readAllBytes()); respond(exchange, 200, "{}");
            return;
        }
        if (path.startsWith("/storage/v1/object/authenticated/omm-documents/documents/")) {
            switch (exchange.getRequestMethod()) {
                case "GET" -> {
                    byte[] value = stored.get();
                    if (value == null) { respond(exchange, 404, ""); return; }
                    exchange.getResponseHeaders().add("Content-Type", "application/pdf");
                    exchange.sendResponseHeaders(200, value.length);
                    exchange.getResponseBody().write(value);
                    exchange.close();
                }
                case "HEAD" -> {
                    byte[] value = stored.get();
                    if (value == null) { exchange.sendResponseHeaders(404, -1); exchange.close(); return; }
                    exchange.getResponseHeaders().add("Content-Length", Integer.toString(value.length));
                    exchange.getResponseHeaders().add("Content-Type", "application/pdf");
                    exchange.sendResponseHeaders(200, -1);
                    exchange.close();
                }
                default -> respond(exchange, 405, "");
            }
            return;
        }
        if (path.equals("/storage/v1/object/omm-documents") && exchange.getRequestMethod().equals("DELETE")) {
            stored.set(null); respond(exchange, 200, "[]"); return;
        }
        respond(exchange, 404, "");
    }

    private static void respond(HttpExchange exchange, int status, String body) throws java.io.IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().add("Content-Type", "application/json");
        exchange.sendResponseHeaders(status, bytes.length);
        exchange.getResponseBody().write(bytes);
        exchange.close();
    }
}
