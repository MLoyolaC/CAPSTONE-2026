package cl.mmsolutions.backend.workitem;

import org.junit.jupiter.api.Test;
import org.springframework.web.server.ResponseStatusException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

class DisplayColorValidatorTest {

    @Test
    void acceptsAndNormalizesHexColors() {
        assertEquals("#4F8F72", DisplayColorValidator.normalize("#4f8f72"));
        assertEquals("#D4A72C", DisplayColorValidator.normalize(" #D4A72C "));
        assertEquals("#FFFFFF", DisplayColorValidator.normalize("#ffffff"));
        assertEquals("#000000", DisplayColorValidator.normalize("#000000"));
        assertEquals("#F4F1E8", DisplayColorValidator.normalize("#f4f1e8"));
        assertNull(DisplayColorValidator.normalize(null));
        assertNull(DisplayColorValidator.normalize("  "));
    }

    @Test
    void rejectsAnythingOtherThanSixDigitHex() {
        for (String invalid : new String[]{"red", "black", "verde", "123456", "#FFF", "rgb(1,2,3)", "rgba(1,2,3,1)", "var(--text)", "<script>", "url(test)"}) {
            assertThrows(ResponseStatusException.class, () -> DisplayColorValidator.normalize(invalid));
        }
    }
}
