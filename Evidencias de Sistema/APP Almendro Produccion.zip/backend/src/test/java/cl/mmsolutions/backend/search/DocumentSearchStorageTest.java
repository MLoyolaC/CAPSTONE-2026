package cl.mmsolutions.backend.search;

import cl.mmsolutions.backend.document.DocumentStorageProvider;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.sql.ResultSet;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class DocumentSearchStorageTest {
    @Test
    void indexesExcelUsingProviderStreamInsteadOfFilesystemPath() throws Exception {
        byte[] content;
        try (XSSFWorkbook workbook = new XSSFWorkbook(); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            workbook.createSheet("Plan").createRow(0).createCell(0).setCellValue("Caldera");
            workbook.write(output);
            content = output.toByteArray();
        }
        MemoryProvider provider = new MemoryProvider(content);
        SearchJdbc jdbc = new SearchJdbc();

        List<DocumentSearchService.SearchResult> result = new DocumentSearchService(jdbc, provider)
                .search("caldera", null);

        assertThat(result).isEmpty();
        assertThat(provider.openCount).isEqualTo(1);
        assertThat(jdbc.indexedFragments).isPositive();
    }

    private static final class SearchJdbc extends JdbcTemplate {
        private final UUID documentId = UUID.randomUUID();
        private final UUID versionId = UUID.randomUUID();
        private int indexedFragments;

        @Override public <T> List<T> query(String sql, RowMapper<T> mapper) {
            return query(sql, mapper, new Object[0]);
        }

        @Override public <T> List<T> query(String sql, RowMapper<T> mapper, Object... args) {
            if (sql.contains("INNER JOIN document_version")) {
                ResultSet rs = mock(ResultSet.class);
                try {
                    when(rs.getObject("id", UUID.class)).thenReturn(documentId);
                    when(rs.getString("name")).thenReturn("plan.xlsx");
                    when(rs.getString("file_type")).thenReturn("XLSX");
                    when(rs.getString("index_status")).thenReturn("PENDING");
                    when(rs.getObject("version_id", UUID.class)).thenReturn(versionId);
                    when(rs.getString("original_filename")).thenReturn("plan.xlsx");
                    when(rs.getInt("version_number")).thenReturn(1);
                    when(rs.getString("local_storage_path")).thenReturn("documents/test/version/plan.xlsx");
                    when(rs.getString("cloud_storage_path")).thenReturn(null);
                    return List.of(mapper.mapRow(rs, 0));
                } catch (Exception exception) { throw new IllegalStateException(exception); }
            }
            return List.of();
        }

        @Override public <T> T queryForObject(String sql, Class<T> requiredType, Object... args) {
            return requiredType.cast(Integer.valueOf(0));
        }

        @Override public int update(String sql, Object... args) { return 1; }
        @Override public int update(String sql) { return 1; }

        @Override public int[] batchUpdate(String sql, List<? extends Object[]> batchArgs) {
            indexedFragments += batchArgs.size();
            return new int[batchArgs.size()];
        }
    }

    private static final class MemoryProvider implements DocumentStorageProvider {
        private final byte[] content;
        private int openCount;
        private MemoryProvider(byte[] content) { this.content = content; }
        @Override public Kind kind() { return Kind.LOCAL; }
        @Override public String buildKey(UUID documentId, UUID versionId, String filename) { return "unused"; }
        @Override public StoredObject store(String key, InputStream input, long contentLength, String mimeType) { throw new UnsupportedOperationException(); }
        @Override public InputStream open(String key) { openCount++; return new ByteArrayInputStream(content); }
        @Override public StorageMetadata metadata(String key) { return new StorageMetadata(key, content.length, "application/test"); }
        @Override public boolean exists(String key) { return true; }
        @Override public void delete(String key) { }
        @Override public List<StoredObject> list() { return List.of(); }
    }
}
