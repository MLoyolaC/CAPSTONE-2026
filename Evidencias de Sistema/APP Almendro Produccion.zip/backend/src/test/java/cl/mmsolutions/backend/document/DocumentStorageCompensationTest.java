package cl.mmsolutions.backend.document;

import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.mock.web.MockMultipartFile;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class DocumentStorageCompensationTest {
    @Test
    void removesStoredObjectWhenDatabaseWriteFails() {
        FailingJdbc jdbc = new FailingJdbc();
        MemoryProvider storage = new MemoryProvider(false);
        DocumentService service = new DocumentService(jdbc, storage);
        MockMultipartFile file = new MockMultipartFile("file", "manual.pdf", "application/pdf",
                "%PDF-contenido".getBytes(StandardCharsets.US_ASCII));

        assertThatThrownBy(() -> service.upload("general", file, "admin"))
                .isInstanceOf(IllegalStateException.class);

        assertThat(storage.keys).isEmpty();
        assertThat(jdbc.updates).isEqualTo(1);
    }

    @Test
    void storageFailureDoesNotWriteDatabaseMetadata() {
        FailingJdbc jdbc = new FailingJdbc();
        MemoryProvider storage = new MemoryProvider(true);
        DocumentService service = new DocumentService(jdbc, storage);
        MockMultipartFile file = new MockMultipartFile("file", "manual.pdf", "application/pdf",
                "%PDF-contenido".getBytes(StandardCharsets.US_ASCII));

        assertThatThrownBy(() -> service.upload("general", file, "admin"))
                .isInstanceOf(org.springframework.web.server.ResponseStatusException.class);
        assertThat(jdbc.updates).isZero();
    }

    private static final class FailingJdbc extends JdbcTemplate {
        private int queries;
        private int updates;
        @Override public <T> List<T> query(String sql, RowMapper<T> mapper, Object... args) {
            queries++;
            @SuppressWarnings("unchecked") T value = (T) Long.valueOf(queries);
            return List.of(value);
        }
        @Override public int update(String sql, Object... args) {
            updates++;
            throw new IllegalStateException("database unavailable");
        }
    }

    private static final class MemoryProvider implements DocumentStorageProvider {
        private final boolean failStore;
        private final List<String> keys = new ArrayList<>();
        private byte[] content;
        private MemoryProvider(boolean failStore) { this.failStore = failStore; }
        @Override public Kind kind() { return Kind.LOCAL; }
        @Override public String buildKey(UUID documentId, UUID versionId, String filename) { return documentId + "/" + versionId + "/" + filename; }
        @Override public StoredObject store(String key, InputStream input, long length, String mime) {
            if (failStore) throw new DocumentStorageException("storage unavailable");
            try { content = input.readAllBytes(); } catch (IOException exception) { throw new DocumentStorageException("read", exception); }
            keys.add(key); return new StoredObject(key, content.length, mime);
        }
        @Override public InputStream open(String key) { return new ByteArrayInputStream(content); }
        @Override public StorageMetadata metadata(String key) { return new StorageMetadata(key, content.length, "application/pdf"); }
        @Override public boolean exists(String key) { return keys.contains(key); }
        @Override public void delete(String key) { keys.remove(key); content = null; }
        @Override public List<StoredObject> list() { return List.of(); }
    }
}
