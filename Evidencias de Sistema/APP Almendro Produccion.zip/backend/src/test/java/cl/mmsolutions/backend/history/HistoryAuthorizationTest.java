package cl.mmsolutions.backend.history;

import cl.mmsolutions.backend.user.AppUser;
import cl.mmsolutions.backend.user.AppUserRepository;
import cl.mmsolutions.backend.user.Role;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.authorization.AuthorizationDeniedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
class HistoryAuthorizationTest {
    @Autowired HistoryController controller;
    @Autowired AppUserRepository users;

    @AfterEach void clearSecurity() { SecurityContextHolder.clearContext(); }

    @Test
    void userWithHistoryCanReadGeneralHistory() {
        Authentication auth = authenticateUser("history_allowed", Set.of("history", "prevencion"));
        assertDoesNotThrow(() -> controller.getHistory(null, null, auth));
    }

    @Test
    void userWithoutHistoryIsDenied() {
        Authentication auth = authenticateUser("history_denied", Set.of("prevencion"));
        assertThrows(AuthorizationDeniedException.class, () -> controller.getHistory(null, null, auth));
    }

    @Test
    void controllerExposesOnlyReadOperations() {
        assertTrue(Arrays.stream(HistoryController.class.getDeclaredMethods())
                .filter(method -> method.getName().equals("getHistory"))
                .allMatch(method -> method.isAnnotationPresent(GetMapping.class)));
        assertEquals(1, Arrays.stream(HistoryController.class.getDeclaredMethods())
                .filter(method -> method.getName().equals("getHistory")).count());
    }

    private Authentication authenticateUser(String username, Set<String> permissions) {
        AppUser user = new AppUser(username, "hash", Role.USER, true);
        user.updateProfile(username, username + "@example.invalid", Role.USER, permissions);
        users.saveAndFlush(user);
        Authentication auth = new UsernamePasswordAuthenticationToken(username, "", List.of());
        SecurityContextHolder.getContext().setAuthentication(auth);
        return auth;
    }
}
