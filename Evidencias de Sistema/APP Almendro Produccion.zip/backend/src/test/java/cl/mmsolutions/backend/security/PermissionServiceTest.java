package cl.mmsolutions.backend.security;

import cl.mmsolutions.backend.user.AppUserRepository;
import cl.mmsolutions.backend.user.AppUser;
import cl.mmsolutions.backend.user.Role;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;

import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;

class PermissionServiceTest {
    @Test
    void deletedUserSessionLosesPermissionsWithoutInternalError() {
        AppUserRepository users = mock(AppUserRepository.class);
        when(users.findByUsernameIgnoreCase("deleted-user")).thenReturn(Optional.empty());
        PermissionService service = new PermissionService(users, mock(JdbcTemplate.class));
        Authentication authentication = mock(Authentication.class);
        when(authentication.isAuthenticated()).thenReturn(true);
        when(authentication.getName()).thenReturn("deleted-user");

        assertTrue(service.permissionsFor("deleted-user").isEmpty());
        assertFalse(service.has(authentication, "dashboard"));
    }

    @Test
    void documentsPermissionAloneDoesNotAuthorizeWorkerDocuments() {
        PermissionFixture fixture = fixture(Set.of("documentos"));

        assertFalse(fixture.service().hasDocument(fixture.authentication(), fixture.documentId()));
    }

    @Test
    void workersPermissionAuthorizesWorkerDocuments() {
        PermissionFixture fixture = fixture(Set.of("trabajadores"));

        assertTrue(fixture.service().hasDocument(fixture.authentication(), fixture.documentId()));
    }

    private PermissionFixture fixture(Set<String> permissions) {
        UUID documentId = UUID.randomUUID();
        AppUserRepository users = mock(AppUserRepository.class);
        AppUser user = mock(AppUser.class);
        when(user.isEnabled()).thenReturn(true);
        when(user.getRole()).thenReturn(Role.USER);
        when(user.getPermissions()).thenReturn(permissions);
        when(users.findByUsernameIgnoreCase("operator")).thenReturn(Optional.of(user));

        JdbcTemplate jdbc = mock(JdbcTemplate.class);
        when(jdbc.queryForObject(anyString(), eq(String.class), eq(documentId)))
                .thenReturn("trabajadores");

        Authentication authentication = mock(Authentication.class);
        when(authentication.isAuthenticated()).thenReturn(true);
        when(authentication.getName()).thenReturn("operator");

        return new PermissionFixture(new PermissionService(users, jdbc), authentication, documentId);
    }

    private record PermissionFixture(PermissionService service, Authentication authentication, UUID documentId) {}
}
