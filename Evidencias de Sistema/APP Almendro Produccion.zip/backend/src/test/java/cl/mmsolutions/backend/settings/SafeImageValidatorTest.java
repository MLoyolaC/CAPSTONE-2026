package cl.mmsolutions.backend.settings;

import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockMultipartFile;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;

import static org.junit.jupiter.api.Assertions.*;

class SafeImageValidatorTest {
    private final SafeImageValidator validator = new SafeImageValidator();

    @Test
    void acceptsARealPng() throws Exception {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        ImageIO.write(new BufferedImage(20, 20, BufferedImage.TYPE_INT_RGB), "png", output);
        var result = validator.validate(new MockMultipartFile("file", "avatar.png", "image/png", output.toByteArray()));
        assertEquals("image/png", result.mime());
        assertTrue(result.bytes().length > 0);
    }

    @Test
    void rejectsAnExtensionThatDoesNotMatchTheRealMime() {
        var file = new MockMultipartFile("file", "avatar.jpg", "image/jpeg",
                new byte[]{(byte)0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a});
        assertThrows(IllegalArgumentException.class, () -> validator.validate(file));
    }

    @Test
    void rejectsUnsupportedAndOversizedFiles() {
        assertThrows(IllegalArgumentException.class, () -> validator.validate(
                new MockMultipartFile("file", "avatar.svg", "image/svg+xml", "<svg/>".getBytes())));
        assertThrows(IllegalArgumentException.class, () -> validator.validate(
                new MockMultipartFile("file", "avatar.png", "image/png", new byte[SafeImageValidator.MAX_BYTES + 1])));
    }
}
