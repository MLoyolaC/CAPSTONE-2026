package cl.mmsolutions.backend.user;

import cl.mmsolutions.backend.invitation.InvitationEmailService;
import cl.mmsolutions.backend.invitation.InvitationService;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class UserAdministrationServiceTest {
    @Test
    void primaryAdministratorCannotBeDemotedOrDisabled() {
        AppUserRepository users = mock(AppUserRepository.class);
        AppUser primary = mock(AppUser.class);
        when(primary.getId()).thenReturn(1L);
        when(primary.getRole()).thenReturn(Role.ADMIN);
        when(users.findById(1L)).thenReturn(Optional.of(primary));
        when(users.findFirstByRoleOrderByIdAsc(Role.ADMIN)).thenReturn(Optional.of(primary));
        UserAdministrationService service = new UserAdministrationService(
                users, mock(InvitationService.class), mock(InvitationEmailService.class), mock(JdbcTemplate.class));

        UserAdministrationService.UpdateUserRequest demotion =
                new UserAdministrationService.UpdateUserRequest(
                        "Administrador", "admin", "admin@example.com", Role.USER, true, Set.of());
        UserAdministrationService.UpdateUserRequest disabling =
                new UserAdministrationService.UpdateUserRequest(
                        "Administrador", "admin", "admin@example.com", Role.ADMIN, false, Set.of());

        assertThrows(UserAdministrationService.ProtectedUserException.class,
                () -> service.update(1L, demotion));
        assertThrows(UserAdministrationService.ProtectedUserException.class,
                () -> service.update(1L, disabling));
    }

    @Test
    void manageAccessRequiresConfigurationPermission() {
        AppUserRepository users = mock(AppUserRepository.class);
        AppUser user = mock(AppUser.class);
        when(user.getId()).thenReturn(11L);
        when(user.getRole()).thenReturn(Role.USER);
        when(user.getUsername()).thenReturn("operator");
        when(user.getAccountStatus()).thenReturn(AccountStatus.ACTIVE);
        when(users.findById(11L)).thenReturn(Optional.of(user));
        when(users.findByUsernameIgnoreCase("operator")).thenReturn(Optional.of(user));
        when(users.findByEmailIgnoreCase("operator@example.com")).thenReturn(Optional.of(user));
        UserAdministrationService service = new UserAdministrationService(
                users, mock(InvitationService.class), mock(InvitationEmailService.class), mock(JdbcTemplate.class));
        UserAdministrationService.UpdateUserRequest incoherent =
                new UserAdministrationService.UpdateUserRequest(
                        "Operator", "operator", "operator@example.com", Role.USER, true,
                        Set.of("manage-access"));

        assertThrows(IllegalArgumentException.class, () -> service.update(11L, incoherent));
    }
}
