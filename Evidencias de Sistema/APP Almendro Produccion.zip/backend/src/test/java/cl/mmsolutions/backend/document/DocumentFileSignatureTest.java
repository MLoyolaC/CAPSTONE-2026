package cl.mmsolutions.backend.document;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.server.ResponseStatusException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verifyNoInteractions;

class DocumentFileSignatureTest {
    @ParameterizedTest
    @ValueSource(strings = {"pdf", "docx", "xlsx"})
    void rejectsContentWhoseSignatureDoesNotMatchExtension(String extension) {
        JdbcTemplate jdbc = mock(JdbcTemplate.class);
        DocumentStorageProvider storage = mock(DocumentStorageProvider.class);
        DocumentService service = new DocumentService(jdbc, storage);
        MockMultipartFile file = new MockMultipartFile("file", "archivo." + extension,
                "application/octet-stream", "contenido-falso".getBytes());

        assertThatThrownBy(() -> service.upload("general", file, "admin"))
                .isInstanceOfSatisfying(ResponseStatusException.class,
                        exception -> assertThat(exception.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST));
        verifyNoInteractions(jdbc, storage);
    }
}
