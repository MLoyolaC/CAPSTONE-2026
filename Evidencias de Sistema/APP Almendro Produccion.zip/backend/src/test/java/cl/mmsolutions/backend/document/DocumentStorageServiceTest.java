package cl.mmsolutions.backend.document;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class DocumentStorageServiceTest {
    @TempDir Path temporaryDirectory;

    @Test
    void localProviderStoresReadsListsAndDeletesPortableKeys() throws Exception {
        LocalDocumentStorageProvider storage = new LocalDocumentStorageProvider(temporaryDirectory.toString());
        String key = storage.buildKey(UUID.randomUUID(), UUID.randomUUID(), "plan.xlsx");
        byte[] content = "contenido".getBytes(StandardCharsets.UTF_8);

        storage.store(key, new ByteArrayInputStream(content), content.length, "application/test");

        assertThat(key).doesNotContain("\\").doesNotStartWith("/");
        assertThat(storage.exists(key)).isTrue();
        assertThat(storage.metadata(key).size()).isEqualTo(content.length);
        assertThat(storage.open(key).readAllBytes()).isEqualTo(content);
        assertThat(storage.list()).extracting(DocumentStorageProvider.StoredObject::key).containsExactly(key);

        storage.delete(key);
        assertThat(storage.exists(key)).isFalse();
    }

    @Test
    void localProviderUsesImmutableVersionUuidAndRejectsEscapes() {
        LocalDocumentStorageProvider storage = new LocalDocumentStorageProvider(temporaryDirectory.toString());
        UUID documentId = UUID.randomUUID();
        UUID first = UUID.randomUUID();
        UUID second = UUID.randomUUID();

        assertThat(storage.buildKey(documentId, first, "manual.pdf"))
                .isNotEqualTo(storage.buildKey(documentId, second, "manual.pdf"));
        assertThatThrownBy(() -> storage.store("../outside.pdf", new ByteArrayInputStream(new byte[0]), 0, "application/pdf"))
                .isInstanceOf(DocumentStorageException.class);
        assertThatThrownBy(() -> storage.buildKey(documentId, first, "../../outside.pdf"))
                .isInstanceOf(DocumentStorageException.class);
    }
}
