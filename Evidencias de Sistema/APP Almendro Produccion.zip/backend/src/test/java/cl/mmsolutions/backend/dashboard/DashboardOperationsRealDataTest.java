package cl.mmsolutions.backend.dashboard;

import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@Transactional(readOnly = true)
class DashboardOperationsRealDataTest {
    private static final Set<String> OPERATIONAL_SLUGS = Set.of(
            "mantencion-general", "mantencion-reactiva", "mejoras", "remodelacion",
            "mantencion-maquinas", "mantencion-jardineria", "prevencion-riesgos"
    );

    @Autowired
    private DashboardOperationsService service;

    @Autowired
    private JdbcTemplate jdbc;

    @Test
    void administradorRecibeLasSieteAreasYLosConteosPersistidos() {
        List<String> admins = jdbc.queryForList("""
                SELECT username FROM app_user
                WHERE role = 'ADMIN' AND enabled = TRUE
                ORDER BY id LIMIT 1
                """, String.class);
        Assumptions.assumeFalse(admins.isEmpty(), "La base local no tiene administrador activo");

        DashboardOperationsResponse result = service.overview(admins.getFirst(), LocalDate.of(2026, 11, 9));

        assertEquals(OPERATIONAL_SLUGS, new LinkedHashSet<>(result.areas().stream()
                .map(DashboardOperationsResponse.AreaOverview::slug).toList()));
        int expectedTotal = 0;
        for (DashboardOperationsResponse.AreaOverview area : result.areas()) {
            Integer persisted = jdbc.queryForObject("""
                    SELECT COUNT(*) FROM work_item w
                    JOIN area a ON a.id = w.area_id
                    WHERE a.slug = ?
                    """, Integer.class, area.slug());
            assertEquals(persisted, area.total(), area.slug());
            assertEquals(area.total(), area.open() + area.completed() + area.cancelled(), area.slug());
            assertEquals(area.open(), area.pending() + area.inProgress() + area.overdue() + area.otherOpen(), area.slug());
            expectedTotal += area.total();
        }
        assertEquals(expectedTotal, result.items().size());
        assertTrue(result.items().stream().allMatch(item -> OPERATIONAL_SLUGS.contains(item.areaSlug())));
        assertFalse(result.items().stream().anyMatch(item -> item.operationalState() == null));
    }

    @Test
    void usuarioRealParcialSoloProduceAreasOperativasAutorizadas() {
        List<String> users = jdbc.queryForList("""
                SELECT username FROM app_user
                WHERE role = 'USER' AND enabled = TRUE
                ORDER BY id LIMIT 1
                """, String.class);
        Assumptions.assumeFalse(users.isEmpty(), "La base local no tiene usuario parcial activo");

        String username = users.getFirst();
        Set<String> permissions = Set.copyOf(jdbc.queryForList("""
                SELECT p.permission FROM app_user_permission p
                JOIN app_user u ON u.id = p.user_id
                WHERE LOWER(u.username) = LOWER(?)
                """, String.class, username));
        Set<String> expected = new LinkedHashSet<>();
        if (permissions.contains("mantencion-general")) expected.add("mantencion-general");
        if (permissions.contains("mantencion-reactiva")) expected.add("mantencion-reactiva");
        if (permissions.contains("mejoras")) expected.add("mejoras");
        if (permissions.contains("remodelacion")) expected.add("remodelacion");
        if (permissions.contains("maquinas")) expected.add("mantencion-maquinas");
        if (permissions.contains("jardineria")) expected.add("mantencion-jardineria");
        if (permissions.contains("prevencion")) expected.add("prevencion-riesgos");

        DashboardOperationsResponse result = service.overview(username, LocalDate.of(2026, 11, 9));

        assertEquals(expected, new LinkedHashSet<>(result.areas().stream()
                .map(DashboardOperationsResponse.AreaOverview::slug).toList()));
        assertTrue(result.items().stream().allMatch(item -> expected.contains(item.areaSlug())));
        assertTrue(result.areas().stream().noneMatch(area -> !expected.contains(area.slug())));
    }
}
