package cl.mmsolutions.backend.workitem;

import cl.mmsolutions.backend.history.HistoryService;
import cl.mmsolutions.backend.user.AppUser;
import cl.mmsolutions.backend.user.AppUserRepository;
import cl.mmsolutions.backend.user.Role;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@Transactional
class WorkItemAuditAndBulkStatusTest {

    @Autowired WorkItemService service;
    @Autowired WorkItemRepository repository;
    @Autowired JdbcTemplate jdbcTemplate;
    @Autowired HistoryService historyService;
    @Autowired AppUserRepository users;

    @Test
    void twoUsersKeepIndependentRecordsAndAuthenticatedAuditSnapshots() {
        String suffix = UUID.randomUUID().toString().substring(0, 8);
        AppUser firstUser = users.saveAndFlush(new AppUser("qa-a-" + suffix, "hash", Role.USER, true));
        AppUser secondUser = users.saveAndFlush(new AppUser("qa-b-" + suffix, "hash", Role.USER, true));

        WorkItem first = service.create(request("Registro simultáneo A", "PENDING", null, null), firstUser.getUsername());
        WorkItem second = service.create(request("Registro simultáneo B", "PENDING", null, null), secondUser.getUsername());
        service.update(first.getId(), request("Registro actualizado A", "IN_PROGRESS", null, null), firstUser.getUsername());
        service.update(second.getId(), request("Registro actualizado B", "COMPLETED", null, null), secondUser.getUsername());

        assertTrue(repository.existsById(first.getId()));
        assertTrue(repository.existsById(second.getId()));
        assertEquals(firstUser.getUsername(), entryWithAction(first.getId(), "UPDATED").username());
        assertEquals(secondUser.getUsername(), entryWithAction(second.getId(), "UPDATED").username());
        assertEquals(firstUser.getId(), actorId(first.getId(), "UPDATED"));
        assertEquals(secondUser.getId(), actorId(second.getId(), "UPDATED"));
    }

    @Test
    void creationPersistsDetailedAuditAndAuthenticatedUserSnapshot() {
        String username = existingUsername();
        WorkItem created = service.create(request("Auditoría creación", "PENDING", "#FF0000", null), username);

        var entry = entryWithAction(created.getId(), "CREATED");
        assertEquals("CREATED", entry.action());
        assertEquals(username, entry.username());
        assertTrue(entry.changes().stream().anyMatch(change -> "title".equals(change.field())));
        assertTrue(entry.changes().stream().anyMatch(change -> "displayColor".equals(change.field())));
    }

    @Test
    void modificationStoresOnlyRealChangesIncludingDisplayAndTextColors() {
        String username = existingUsername();
        WorkItem created = service.create(request("Auditoría colores", "PENDING", "#FF0000", null), username);
        service.update(created.getId(), request("Auditoría colores", "PENDING", "#4F8F73", "#FFFFFF"), username);

        var entry = entryWithAction(created.getId(), "UPDATED");
        assertEquals("UPDATED", entry.action());
        assertEquals(2, entry.changes().size());
        assertTrue(entry.changes().stream().anyMatch(change ->
                "displayColor".equals(change.field())
                        && "#FF0000".equals(change.previousValue())
                        && "#4F8F73".equals(change.newValue())));
        assertTrue(entry.changes().stream().anyMatch(change ->
                "textColor".equals(change.field())
                        && change.previousValue() == null
                        && "#FFFFFF".equals(change.newValue())));
    }

    @Test
    void unchangedUpdateDoesNotCreateFalseAuditEntry() {
        String username = existingUsername();
        WorkItem created = service.create(request("Sin cambios", "PENDING", null, null), username);
        int before = activityCount(created.getId());

        service.update(created.getId(), request("Sin cambios", "PENDING", null, null), username);

        assertEquals(before, activityCount(created.getId()));
    }

    @Test
    void individualStatusChangeHasSpecificAction() {
        String username = existingUsername();
        WorkItem created = service.create(request("Estado individual", "PENDING", null, null), username);

        service.update(created.getId(), request("Estado individual", "IN_PROGRESS", null, null), username);

        var entry = entryWithAction(created.getId(), "STATUS_CHANGED");
        assertEquals("STATUS_CHANGED", entry.action());
        assertTrue(entry.changes().stream().anyMatch(change -> "status".equals(change.field())));
    }

    @Test
    void bulkStatusPersistsEveryItemWithOneTraceableOperation() {
        String username = existingUsername();
        WorkItem first = service.create(request("Masivo uno", "PENDING", null, null), username);
        WorkItem second = service.create(request("Masivo dos", "IN_PROGRESS", null, null), username);

        WorkItemService.BulkStatusResult result = service.bulkUpdateStatus(
                List.of(first.getId(), second.getId()), "prevencion-riesgos", "COMPLETED", username);

        assertEquals(2, result.items().size());
        assertNotNull(result.operationId());
        assertEquals("COMPLETED", repository.findById(first.getId()).orElseThrow().getStatus());
        assertEquals("COMPLETED", repository.findById(second.getId()).orElseThrow().getStatus());
        assertEquals(2, jdbcTemplate.queryForObject(
                "SELECT count(*) FROM work_item_activity WHERE operation_id = ? AND action = 'BULK_STATUS_CHANGED'",
                Integer.class,
                result.operationId()
        ));
    }

    @Test
    void bulkStatusRejectsMissingRecordBeforeAnyChange() {
        String username = existingUsername();
        WorkItem valid = service.create(request("Rollback masivo", "PENDING", null, null), username);

        assertThrows(ResponseStatusException.class, () -> service.bulkUpdateStatus(
                List.of(valid.getId(), UUID.randomUUID()), "prevencion-riesgos", "COMPLETED", username));

        assertEquals("PENDING", repository.findById(valid.getId()).orElseThrow().getStatus());
        assertFalse(historyService.getHistory("prevencion-riesgos", null).stream().anyMatch(entry ->
                valid.getId().toString().equals(entry.itemId()) && "BULK_STATUS_CHANGED".equals(entry.action())));
    }

    @Test
    void historyKeepsLegacyEntriesCompatible() {
        WorkItem created = service.create(request("Compatibilidad antigua", "PENDING", null, null), existingUsername());
        UUID legacyId = UUID.randomUUID();
        jdbcTemplate.update(
                """
                INSERT INTO work_item_activity (
                    id, work_item_id, area_id, work_type, item_title, action, details
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                legacyId,
                created.getId(),
                created.getArea().getId(),
                created.getWorkType(),
                created.getTitle(),
                "UPDATED",
                "Entrada histórica anterior"
        );

        var entry = historyService.getHistory("prevencion-riesgos", null).stream()
                .filter(candidate -> legacyId.toString().equals(candidate.id()))
                .findFirst()
                .orElseThrow();
        assertTrue(entry.changes().isEmpty());
        assertEquals("Entrada histórica anterior", entry.details());
    }

    private WorkItemController.WorkItemRequest request(
            String title,
            String status,
            String displayColor,
            String textColor
    ) {
        return new WorkItemController.WorkItemRequest(
                "prevencion-riesgos", "PREVENTION", "Planificación", 2026, 11,
                title, "Descripción de prueba", "Zona segura", "Responsable QA", "NORMAL", status,
                LocalDate.of(2026, 11, 8), LocalDate.of(2026, 11, 10), displayColor, textColor,
                BigDecimal.ZERO, "Observación", "Inspección", null, null, null, null, null,
                null, null, null, null
        );
    }

    private String existingUsername() {
        List<String> usernames = jdbcTemplate.query(
                "SELECT username FROM app_user ORDER BY id LIMIT 1",
                (rs, rowNum) -> rs.getString(1)
        );
        return usernames.isEmpty() ? "Sistema" : usernames.getFirst();
    }

    private HistoryService.HistoryEntry latestEntry(UUID itemId) {
        return historyService.getHistory("prevencion-riesgos", null).stream()
                .filter(entry -> itemId.toString().equals(entry.itemId()))
                .findFirst()
                .orElseThrow();
    }

    private HistoryService.HistoryEntry entryWithAction(UUID itemId, String action) {
        return historyService.getHistory("prevencion-riesgos", null).stream()
                .filter(entry -> itemId.toString().equals(entry.itemId()) && action.equals(entry.action()))
                .findFirst()
                .orElseThrow();
    }

    private int activityCount(UUID itemId) {
        return jdbcTemplate.queryForObject(
                "SELECT count(*) FROM work_item_activity WHERE work_item_id = ?",
                Integer.class,
                itemId
        );
    }

    private Long actorId(UUID itemId, String action) {
        return jdbcTemplate.queryForObject(
                "SELECT user_id FROM work_item_activity WHERE work_item_id = ? AND action = ? ORDER BY created_at DESC LIMIT 1",
                Long.class,
                itemId,
                action
        );
    }
}
