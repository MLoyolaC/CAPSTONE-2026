package cl.mmsolutions.backend.recovery;

import cl.mmsolutions.backend.invitation.InvitationEmailService;
import cl.mmsolutions.backend.user.AccountStatus;
import cl.mmsolutions.backend.user.AppUser;
import cl.mmsolutions.backend.user.AppUserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionInformation;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

class PasswordRecoveryServiceTest {
    private PasswordRecoveryRepository requests;
    private AppUserRepository users;
    private PasswordEncoder encoder;
    private InvitationEmailService emails;
    private SessionRegistry sessions;
    private PasswordRecoveryService service;

    @BeforeEach
    void setUp() {
        requests = mock(PasswordRecoveryRepository.class);
        users = mock(AppUserRepository.class);
        encoder = mock(PasswordEncoder.class);
        emails = mock(InvitationEmailService.class);
        sessions = mock(SessionRegistry.class);
        when(sessions.getAllPrincipals()).thenReturn(java.util.List.of());
        service = new PasswordRecoveryService(requests, users, encoder, emails, sessions, 15, 5, 60);
    }

    @Test
    void requestIsNeutralForUnknownAndEligibleAccounts() {
        PasswordRecoveryService.RequestResult unknown = service.request("unknown@example.com");
        assertEquals(60, unknown.cooldownSeconds());
        verifyNoInteractions(requests, encoder, emails);

        AppUser user = activeUser();
        when(users.findByEmailIgnoreCase("person@example.com")).thenReturn(Optional.of(user));
        when(users.findByIdForUpdate(7L)).thenReturn(Optional.of(user));
        when(requests.findFirstByUserIdOrderByCreatedAtDesc(7L))
                .thenReturn(Optional.empty());
        when(encoder.encode(anyString())).thenReturn("{bcrypt}encoded");
        when(requests.saveAndFlush(any())).thenAnswer(invocation -> invocation.getArgument(0));

        PasswordRecoveryService.RequestResult eligible = service.request(" Person@Example.com ");
        assertEquals(unknown.message(), eligible.message());
        verify(emails).sendPasswordRecovery(eq(user), matches("\\d{6}"), eq(15));
    }

    @Test
    void disabledAccountNeverReceivesRecoveryEmail() {
        AppUser user = mock(AppUser.class);
        when(user.getId()).thenReturn(7L);
        when(user.isEnabled()).thenReturn(false);
        when(users.findByEmailIgnoreCase("person@example.com")).thenReturn(Optional.of(user));
        when(users.findByIdForUpdate(7L)).thenReturn(Optional.of(user));

        service.request("person@example.com");

        verifyNoInteractions(emails);
        verifyNoInteractions(requests);
    }

    @Test
    void pendingAccountNeverReceivesRecoveryEmailEvenIfEnabledFlagIsInconsistent() {
        AppUser user = mock(AppUser.class);
        when(user.getId()).thenReturn(7L);
        when(user.isEnabled()).thenReturn(true);
        when(user.getAccountStatus()).thenReturn(AccountStatus.PENDING_ACTIVATION);
        when(users.findByEmailIgnoreCase("person@example.com")).thenReturn(Optional.of(user));
        when(users.findByIdForUpdate(7L)).thenReturn(Optional.of(user));

        service.request("person@example.com");

        verifyNoInteractions(emails);
        verifyNoInteractions(requests);
    }

    @Test
    void cooldownAppliesEvenWhenPreviousRequestWasInvalidated() {
        AppUser user = activeUser();
        PasswordRecoveryRequest previous = mock(PasswordRecoveryRequest.class);
        when(previous.getCreatedAt()).thenReturn(java.time.OffsetDateTime.now());
        when(users.findByEmailIgnoreCase("person@example.com")).thenReturn(Optional.of(user));
        when(users.findByIdForUpdate(7L)).thenReturn(Optional.of(user));
        when(requests.findFirstByUserIdOrderByCreatedAtDesc(7L)).thenReturn(Optional.of(previous));

        service.request("person@example.com");

        verifyNoInteractions(emails);
        verify(encoder, never()).encode(anyString());
    }

    @Test
    void verifiedCodeProducesOneTimeGrant() {
        AppUser user = activeUser();
        PasswordRecoveryRequest recovery = new PasswordRecoveryRequest(
                user, "{bcrypt}encoded", java.time.OffsetDateTime.now().plusMinutes(15));
        when(users.findByEmailIgnoreCase("person@example.com")).thenReturn(Optional.of(user));
        when(users.findByIdForUpdate(7L)).thenReturn(Optional.of(user));
        when(requests.findFirstByUserIdAndUsedAtIsNullAndInvalidatedAtIsNullOrderByCreatedAtDesc(7L))
                .thenReturn(Optional.of(recovery));
        when(encoder.matches("123456", "{bcrypt}encoded")).thenReturn(true);

        PasswordRecoveryService.VerificationResult result = service.verify("person@example.com", "123456");
        assertFalse(result.resetToken().isBlank());
        assertThrows(PasswordRecoveryService.RecoveryException.class,
                () -> service.verify("person@example.com", "123456"));
    }

    @Test
    void resetChangesPasswordConsumesGrantAndExpiresExistingSessions() {
        AppUser user = activeUser();
        PasswordRecoveryRequest recovery = new PasswordRecoveryRequest(
                user, "{bcrypt}encoded", java.time.OffsetDateTime.now().plusMinutes(15));
        recovery.verify(java.time.OffsetDateTime.now(), "reset-token-hash");
        when(requests.findByResetTokenHashForUpdate(anyString())).thenReturn(Optional.of(recovery));
        when(encoder.encode("Una contraseña nueva")).thenReturn("{bcrypt}new");
        UserDetails principal = mock(UserDetails.class);
        SessionInformation session = mock(SessionInformation.class);
        when(principal.getUsername()).thenReturn("person");
        when(sessions.getAllPrincipals()).thenReturn(java.util.List.of(principal));
        when(sessions.getAllSessions(principal, false)).thenReturn(java.util.List.of(session));

        service.reset("one-time-token", "Una contraseña nueva", "Una contraseña nueva");

        verify(user).resetPassword("{bcrypt}new");
        verify(session).expireNow();
        assertFalse(recovery.isResetUsable(java.time.OffsetDateTime.now()));
    }

    private AppUser activeUser() {
        AppUser user = mock(AppUser.class);
        when(user.getId()).thenReturn(7L);
        when(user.isEnabled()).thenReturn(true);
        when(user.getAccountStatus()).thenReturn(AccountStatus.ACTIVE);
        when(user.getPasswordHash()).thenReturn("{bcrypt}current");
        when(user.getEmail()).thenReturn("person@example.com");
        when(user.getUsername()).thenReturn("person");
        return user;
    }
}
