package cl.mmsolutions.backend.importing;

import org.apache.poi.ss.usermodel.DateUtil;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.TimeZone;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ExcelDateSupportTest {
    @Test
    void preservesTheExcelCalendarDayRegardlessOfJvmTimezone() {
        LocalDate expected = LocalDate.of(2026, 11, 4);
        double serial = DateUtil.getExcelDate(LocalDateTime.of(2026, 11, 4, 0, 0));
        TimeZone original = TimeZone.getDefault();
        try {
            for (String timezone : new String[]{"America/Santiago", "UTC", "Pacific/Auckland"}) {
                TimeZone.setDefault(TimeZone.getTimeZone(timezone));
                assertEquals(expected, ExcelDateSupport.toLocalDate(serial));
            }
        } finally {
            TimeZone.setDefault(original);
        }
    }
}
